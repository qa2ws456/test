[CmdletBinding()]
param(
    # -Force removes only this package's prior XML output folder and days30.jsonl.
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$ScenarioDir = $PSScriptRoot
$ProjectRoot = [System.IO.Path]::GetFullPath((Join-Path $ScenarioDir '..\..'))
Set-Location $ProjectRoot

$ScenarioFile = 'scenarios/northside-30day/scenario_30day.yaml'
$Builder = 'scenarios/northside-30day/generate_30day_configs.py'
$EmitterOutput = 'scenarios/northside-30day/output'
$Converter = 'xml_to_jsonl.py'
$EventsOut = 'days30.jsonl'
$Validator = 'scenarios/northside-30day/validate_days30.py'
$Plan = 'scenarios/northside-30day/attack_window_plan.csv'

# Keep Python/EvidenceForge temp and the SQLite spool off a full C: drive.
$TempRoot = Join-Path $ProjectRoot 'eforge_temp'
$SpoolRoot = Join-Path $TempRoot 'spool'
New-Item -ItemType Directory -Force $TempRoot | Out-Null
New-Item -ItemType Directory -Force $SpoolRoot | Out-Null
$env:TEMP = $TempRoot
$env:TMP = $TempRoot
$env:EFORGE_SPOOL_DIR = $SpoolRoot
$env:UV_CACHE_DIR = Join-Path $ProjectRoot '.uv-cache'
New-Item -ItemType Directory -Force $env:UV_CACHE_DIR | Out-Null
Write-Host "TEMP=$env:TEMP" -ForegroundColor DarkCyan
Write-Host "EFORGE_SPOOL_DIR=$env:EFORGE_SPOOL_DIR" -ForegroundColor DarkCyan

if ((Test-Path $EmitterOutput) -or (Test-Path $EventsOut)) {
    if (-not $Force) {
        throw "Output already exists. Inspect or back it up first; rerun with -Force only if you want to delete '$EmitterOutput' and '$EventsOut'."
    }
    if (Test-Path $EmitterOutput) { Remove-Item -Recurse -Force $EmitterOutput }
    if (Test-Path $EventsOut) { Remove-Item -Force $EventsOut }
}

Write-Host '[1/5] Building 30-day scenario, ground truth, and attack plan...' -ForegroundColor Cyan
uv run python $Builder
if ($LASTEXITCODE -ne 0) { throw 'Scenario config builder failed.' }

Write-Host '[2/5] Validating EvidenceForge scenario...' -ForegroundColor Cyan
uv run eforge validate $ScenarioFile
if ($LASTEXITCODE -ne 0) { throw 'EvidenceForge scenario validation failed.' }

Write-Host '[3/5] Emitting Windows Security and Sysmon XML...' -ForegroundColor Cyan
uv run eforge generate $ScenarioFile
if ($LASTEXITCODE -ne 0) { throw 'EvidenceForge log generation failed.' }

if (-not (Test-Path $Converter)) {
    throw "Could not find '$Converter' in the EvidenceForge project root. Run the existing XML-to-JSONL converter manually, then call validate_days30.py."
}

Write-Host '[4/5] Converting XML to days30.jsonl...' -ForegroundColor Cyan
uv run python $Converter --data-dir $EmitterOutput --out $EventsOut
if ($LASTEXITCODE -ne 0) { throw 'XML-to-JSONL conversion failed.' }

Write-Host '[5/5] Validating generated JSONL and attack-family coverage...' -ForegroundColor Cyan
uv run python $Validator --events $EventsOut --plan $Plan
if ($LASTEXITCODE -ne 0) { throw 'days30.jsonl validation failed.' }

Write-Host "Completed. JSONL: $ProjectRoot\$EventsOut" -ForegroundColor Green
Write-Host 'Open finalmapped_fixed_v9_context_features_memfix_30day.ipynb from the project root and restart/run all.' -ForegroundColor Green
