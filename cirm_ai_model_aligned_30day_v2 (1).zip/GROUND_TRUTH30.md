# Ground Truth: Northside AD Behavioral Baseline — 30 days

**Scenario:** 30-day synthetic Windows Security/Sysmon corpus. First seven scenario days are baseline-only; following 23 days contain planned attack episodes.
**Scenario start:** 2026-07-28 00:00:00 UTC
**Baseline end / test start:** 2026-08-04 00:00:00 UTC
**Scenario end (exclusive):** 2026-08-27 00:00:00 UTC
**Planned attack episodes:** 80. The final count of positive user-window labels must be recalculated from emitted and attributed events; credential-spray fan-out may produce additional user windows.
**Identity note:** All human principals are fictional names. External IPs/domains use documentation-only address/domain ranges and must not be used as real destinations.

## Attack Summary

1. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
2. **vivaan.sharma** on **PC-003**: Host and domain discovery through built-in Windows administration tools (observable evidence: Sysmon 1; discovery-tool process counts and process diversity)
3. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
4. **aarav.malhotra** on **PC-002**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
5. **aditya.saxena** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
6. **prerna.verma** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
7. **vivaan.sharma** on **PC-003**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
8. **aditya.saxena** on **DC-01**: Windows Security event log cleared after administrative command activity (observable evidence: wevtutil.exe process; Security 1102 / System 104 log-clear feature)
9. **prerna.verma** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
10. **kabir.chauhan** on **PC-005**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
11. **ishita.kapoor** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
12. **diya.singh** on **PC-004**: Explicit use of a privileged account for remote administration (observable evidence: Security 4648; psexec remote-execution process; SMB port 445)
13. **aditya.saxena** on **PC-007**: Archive/transfer utility activity followed by an external connection (observable evidence: 7z/certutil transfer-tool process plus external TCP/443 connection)
14. **aarav.malhotra** on **PC-002**: Explicit use of a privileged account for remote administration (observable evidence: Security 4648; psexec remote-execution process; SMB port 445)
15. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
16. **ishita.kapoor** on **PC-001**: Archive/transfer utility activity followed by an external connection (observable evidence: 7z/certutil transfer-tool process plus external TCP/443 connection)
17. **diya.singh** on **PC-004**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
18. **prerna.verma** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
19. **SYSTEM** on **DC-01**: Password-spray pattern against several domain accounts from an external source (observable evidence: Security 4625 failed-authentication burst from an external source address)
20. **meera.bansal** on **PC-006**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
21. **ishita.kapoor** on **PC-001**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
22. **kabir.chauhan** on **PC-005**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
23. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
24. **vivaan.sharma** on **PC-003**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
25. **aditya.saxena** on **PC-007**: Explicit use of a privileged account for remote administration (observable evidence: Security 4648; psexec remote-execution process; SMB port 445)
26. **aarav.malhotra** on **PC-002**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
27. **kabir.chauhan** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
28. **prerna.verma** on **PC-008**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
29. **diya.singh** on **PC-004**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
30. **aditya.saxena** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
31. **aarav.malhotra** on **PC-002**: Host and domain discovery through built-in Windows administration tools (observable evidence: Sysmon 1; discovery-tool process counts and process diversity)
32. **meera.bansal** on **PC-006**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
33. **ishita.kapoor** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
34. **prerna.verma** on **DC-01**: Windows Security event log cleared after administrative command activity (observable evidence: wevtutil.exe process; Security 1102 / System 104 log-clear feature)
35. **aditya.saxena** on **PC-007**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
36. **aditya.saxena** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
37. **meera.bansal** on **PC-006**: Host and domain discovery through built-in Windows administration tools (observable evidence: Sysmon 1; discovery-tool process counts and process diversity)
38. **ishita.kapoor** on **PC-001**: Host and domain discovery through built-in Windows administration tools (observable evidence: Sysmon 1; discovery-tool process counts and process diversity)
39. **kabir.chauhan** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
40. **prerna.verma** on **PC-008**: Explicit use of a privileged account for remote administration (observable evidence: Security 4648; psexec remote-execution process; SMB port 445)
41. **vivaan.sharma** on **PC-003**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
42. **meera.bansal** on **PC-006**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
43. **prerna.verma** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
44. **SYSTEM** on **DC-01**: Password-spray pattern against several domain accounts from an external source (observable evidence: Security 4625 failed-authentication burst from an external source address)
45. **prerna.verma** on **PC-008**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
46. **diya.singh** on **PC-004**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
47. **aditya.saxena** on **PC-007**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
48. **aarav.malhotra** on **PC-002**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
49. **kabir.chauhan** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
50. **ishita.kapoor** on **PC-001**: Archive/transfer utility activity followed by an external connection (observable evidence: 7z/certutil transfer-tool process plus external TCP/443 connection)
51. **diya.singh** on **PC-004**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
52. **aditya.saxena** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
53. **vivaan.sharma** on **PC-003**: Host and domain discovery through built-in Windows administration tools (observable evidence: Sysmon 1; discovery-tool process counts and process diversity)
54. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
55. **ishita.kapoor** on **PC-001**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
56. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
57. **prerna.verma** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
58. **vivaan.sharma** on **PC-003**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
59. **prerna.verma** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
60. **aarav.malhotra** on **PC-002**: Archive/transfer utility activity followed by an external connection (observable evidence: 7z/certutil transfer-tool process plus external TCP/443 connection)
61. **aditya.saxena** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
62. **prerna.verma** on **PC-008**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
63. **aditya.saxena** on **DC-01**: Windows Security event log cleared after administrative command activity (observable evidence: wevtutil.exe process; Security 1102 / System 104 log-clear feature)
64. **aditya.saxena** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
65. **aarav.malhotra** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
66. **kabir.chauhan** on **PC-005**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
67. **ishita.kapoor** on **PC-001**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
68. **SYSTEM** on **DC-01**: Password-spray pattern against several domain accounts from an external source (observable evidence: Security 4625 failed-authentication burst from an external source address)
69. **aditya.saxena** on **PC-007**: Archive/transfer utility activity followed by an external connection (observable evidence: 7z/certutil transfer-tool process plus external TCP/443 connection)
70. **aarav.malhotra** on **PC-002**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
71. **prerna.verma** on **DC-01**: Windows Security event log cleared after administrative command activity (observable evidence: wevtutil.exe process; Security 1102 / System 104 log-clear feature)
72. **aditya.saxena** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
73. **diya.singh** on **PC-004**: Unusual remote-thread activity targeting a sensitive Windows process (observable evidence: Sysmon 1 temporary-path process plus Sysmon 8 remote-thread feature)
74. **prerna.verma** on **PC-008**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)
75. **aditya.saxena** on **FILE-01**: Creation of a new Windows service on a server (observable evidence: sc.exe process; Security 4697 / System 7045 service-install feature)
76. **meera.bansal** on **FILE-01**: Network-share enumeration and bulk file staging via a transfer utility (observable evidence: Sysmon 1 robocopy; SMB port 445; transfer-tool and sensitive-port features)
77. **ishita.kapoor** on **PC-001**: Internal service discovery across common Windows infrastructure ports (observable evidence: PowerShell process plus multiple Sysmon 3/5156 connections to sensitive ports)
78. **aditya.saxena** on **DC-01**: Windows Security event log cleared after administrative command activity (observable evidence: wevtutil.exe process; Security 1102 / System 104 log-clear feature)
79. **prerna.verma** on **DC-01**: Domain account creation followed by a group-membership change (observable evidence: net.exe process; Security 4720 account creation and 4728/4732 group change)
80. **vivaan.sharma** on **PC-003**: Scheduled task registered with a nonstandard executable path (observable evidence: schtasks process; Security 4698 scheduled-task feature)

## Timeline

| Timestamp | Actor | System | Event Type | Details |
|-----------|-------|--------|------------|---------|
| 2026-08-04 08:00:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-04 16:20:00 UTC | vivaan.sharma | PC-003 | Process | Host and domain discovery through built-in Windows administration tools |
| 2026-08-04 20:40:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-05 04:00:00 UTC | aarav.malhotra | PC-002 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-05 13:00:00 UTC | aditya.saxena | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-05 19:00:00 UTC | prerna.verma | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-05 22:00:00 UTC | vivaan.sharma | PC-003 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-06 03:00:00 UTC | aditya.saxena | DC-01 | Process | Windows Security event log cleared after administrative command activity |
| 2026-08-06 08:30:00 UTC | prerna.verma | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-06 12:20:00 UTC | kabir.chauhan | PC-005 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-07 07:50:00 UTC | ishita.kapoor | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-07 10:00:00 UTC | diya.singh | PC-004 | Explicit_Credentials | Explicit use of a privileged account for remote administration |
| 2026-08-07 12:50:00 UTC | aditya.saxena | PC-007 | Process | Archive/transfer utility activity followed by an external connection |
| 2026-08-07 19:10:00 UTC | aarav.malhotra | PC-002 | Explicit_Credentials | Explicit use of a privileged account for remote administration |
| 2026-08-08 05:00:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-08 08:00:00 UTC | ishita.kapoor | PC-001 | Process | Archive/transfer utility activity followed by an external connection |
| 2026-08-08 21:50:00 UTC | diya.singh | PC-004 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-09 03:30:00 UTC | prerna.verma | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-09 11:10:00 UTC | SYSTEM | DC-01 | Credential_Spray | Password-spray pattern against several domain accounts from an external source |
| 2026-08-09 16:30:00 UTC | meera.bansal | PC-006 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-09 19:10:00 UTC | ishita.kapoor | PC-001 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-10 01:40:00 UTC | kabir.chauhan | PC-005 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-10 04:50:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-10 14:30:00 UTC | vivaan.sharma | PC-003 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-11 02:40:00 UTC | aditya.saxena | PC-007 | Explicit_Credentials | Explicit use of a privileged account for remote administration |
| 2026-08-11 04:40:00 UTC | aarav.malhotra | PC-002 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-11 09:40:00 UTC | kabir.chauhan | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-11 14:50:00 UTC | prerna.verma | PC-008 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-12 07:00:00 UTC | diya.singh | PC-004 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-12 11:40:00 UTC | aditya.saxena | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-12 22:10:00 UTC | aarav.malhotra | PC-002 | Process | Host and domain discovery through built-in Windows administration tools |
| 2026-08-13 04:30:00 UTC | meera.bansal | PC-006 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-13 08:30:00 UTC | ishita.kapoor | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-13 17:00:00 UTC | prerna.verma | DC-01 | Process | Windows Security event log cleared after administrative command activity |
| 2026-08-13 20:10:00 UTC | aditya.saxena | PC-007 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-14 03:20:00 UTC | aditya.saxena | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-14 12:40:00 UTC | meera.bansal | PC-006 | Process | Host and domain discovery through built-in Windows administration tools |
| 2026-08-14 16:50:00 UTC | ishita.kapoor | PC-001 | Process | Host and domain discovery through built-in Windows administration tools |
| 2026-08-15 01:00:00 UTC | kabir.chauhan | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-15 04:50:00 UTC | prerna.verma | PC-008 | Explicit_Credentials | Explicit use of a privileged account for remote administration |
| 2026-08-15 07:00:00 UTC | vivaan.sharma | PC-003 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-15 11:20:00 UTC | meera.bansal | PC-006 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-16 12:10:00 UTC | prerna.verma | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-16 15:00:00 UTC | SYSTEM | DC-01 | Credential_Spray | Password-spray pattern against several domain accounts from an external source |
| 2026-08-16 18:50:00 UTC | prerna.verma | PC-008 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-17 06:50:00 UTC | diya.singh | PC-004 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-17 11:40:00 UTC | aditya.saxena | PC-007 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-17 13:50:00 UTC | aarav.malhotra | PC-002 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-17 21:00:00 UTC | kabir.chauhan | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-18 04:50:00 UTC | ishita.kapoor | PC-001 | Process | Archive/transfer utility activity followed by an external connection |
| 2026-08-18 09:20:00 UTC | diya.singh | PC-004 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-18 15:10:00 UTC | aditya.saxena | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-19 04:10:00 UTC | vivaan.sharma | PC-003 | Process | Host and domain discovery through built-in Windows administration tools |
| 2026-08-19 11:10:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-19 18:00:00 UTC | ishita.kapoor | PC-001 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-19 22:00:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-20 01:00:00 UTC | prerna.verma | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-20 04:40:00 UTC | vivaan.sharma | PC-003 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-20 15:50:00 UTC | prerna.verma | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-21 05:20:00 UTC | aarav.malhotra | PC-002 | Process | Archive/transfer utility activity followed by an external connection |
| 2026-08-21 07:20:00 UTC | aditya.saxena | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-21 09:40:00 UTC | prerna.verma | PC-008 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-21 12:20:00 UTC | aditya.saxena | DC-01 | Process | Windows Security event log cleared after administrative command activity |
| 2026-08-22 11:00:00 UTC | aditya.saxena | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-22 19:40:00 UTC | aarav.malhotra | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-22 22:50:00 UTC | kabir.chauhan | PC-005 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-23 02:10:00 UTC | ishita.kapoor | PC-001 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-23 08:10:00 UTC | SYSTEM | DC-01 | Credential_Spray | Password-spray pattern against several domain accounts from an external source |
| 2026-08-23 11:30:00 UTC | aditya.saxena | PC-007 | Process | Archive/transfer utility activity followed by an external connection |
| 2026-08-23 22:00:00 UTC | aarav.malhotra | PC-002 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-24 01:20:00 UTC | prerna.verma | DC-01 | Process | Windows Security event log cleared after administrative command activity |
| 2026-08-24 16:30:00 UTC | aditya.saxena | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-24 21:20:00 UTC | diya.singh | PC-004 | Process | Unusual remote-thread activity targeting a sensitive Windows process |
| 2026-08-25 06:00:00 UTC | prerna.verma | PC-008 | Process | Scheduled task registered with a nonstandard executable path |
| 2026-08-25 09:40:00 UTC | aditya.saxena | FILE-01 | Process | Creation of a new Windows service on a server |
| 2026-08-25 18:00:00 UTC | meera.bansal | FILE-01 | Logon | Network-share enumeration and bulk file staging via a transfer utility |
| 2026-08-25 22:00:00 UTC | ishita.kapoor | PC-001 | Process | Internal service discovery across common Windows infrastructure ports |
| 2026-08-26 09:00:00 UTC | aditya.saxena | DC-01 | Process | Windows Security event log cleared after administrative command activity |
| 2026-08-26 15:40:00 UTC | prerna.verma | DC-01 | Process | Domain account creation followed by a group-membership change |
| 2026-08-26 20:00:00 UTC | vivaan.sharma | PC-003 | Process | Scheduled task registered with a nonstandard executable path |

## Indicators of Compromise

Evaluation-only synthetic sources for recovering password-spray victim windows. These values are not detection rules and use reserved documentation IP ranges.

- `192.0.2.25` (synthetic password-spray source; evaluation only)
- `203.0.113.116` (synthetic password-spray source; evaluation only)
- `203.0.113.147` (synthetic password-spray source; evaluation only)

## Red Herrings

Benign look-alike activities emitted separately from attack ground truth.

| Timestamp | Actor | System | Activity | Why It's Benign |
|-----------|-------|--------|----------|-----------------|
| 2026-08-07 05:00:00 UTC | prerna.verma | PC-008 | Scheduled security audit performs normal domain inventory | Approved audit by the security analyst; discovery utilities can be legitimate. |
| 2026-08-12 07:15:00 UTC | kabir.chauhan | PC-001 | Help-desk remote session to a finance workstation | Approved troubleshooting; a remote-session signal alone is not attack ground truth. |
| 2026-08-19 12:00:00 UTC | aditya.saxena | FILE-01 | Approved monthly server patching | Authorized maintenance; process activity is not service creation or persistence. |
| 2026-08-24 04:20:00 UTC | ishita.kapoor | PC-001 | Routine PowerShell inventory of running processes | Normal local inventory without a linked external connection or persistence signal. |

## Evaluation Notes

- These are planned ground-truth windows, not proof of what the emitter ultimately produced. Verify each labeled user/window has matching emitted telemetry and correct attribution.
- Train dates are July 28-August 3, 2026 inclusive; test dates are August 4-August 26, 2026 inclusive, all in UTC.
- Keep the scoring threshold selected using baseline/validation data only. Do not choose features or threshold by maximizing metrics on the final attack/test labels.
- Attack templates were limited to feature families represented in the current notebook. Single remote-logon-only and DNS-beacon-only episodes were excluded because the supplied miss analysis showed weak scores or missing attribution for those patterns.
- Feature-supported means the event family has a feature path; it does not guarantee the risk will exceed the threshold. Reconcile emitted and attributed events, then report recall from the actual scoring output.
