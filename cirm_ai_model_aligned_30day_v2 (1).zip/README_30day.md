# Northside 30-day AD/Sysmon dataset package

This package is laid out in the same file-oriented style as the prior 20-day bundle. It generates **30 complete UTC scenario days** from July 28 through August 26, 2026. Days 1–7 are baseline-only; days 8–30 are the test period. The storyline contains **80 planned attack episodes**.

## YAML configuration files

- `environment_northside.yaml` — generated fictional AD environment and users.
- `environment_template_northside.yaml` — input template used by the builder.
- `storyline_30day.yaml` — 80 scheduled test-period episodes.
- `scenario_30day.yaml` — the EvidenceForge 30-day scenario, including the environment and storyline files.

## Attack families aligned to current model features

The scenarios target event/feature families that exist in the current notebook: process-based host/domain discovery; SMB share collection; explicit credentials and remote execution; service installation; scheduled-task creation; account/group changes; event-log clearing; Sysmon remote-thread activity; internal network/service discovery; archive/transfer tool execution with network telemetry; and failed-authentication bursts.

The package excludes standalone remote-logon-only, DNS/beacon-only, and workstation lock/unlock-only attacks because the supplied miss analysis showed missing attribution or weak scoring for these patterns. Feature support does **not** guarantee an alert; emission, attribution, baseline familiarity, and the existing calibrated threshold still affect results.

## Other files

- `generate_30day_configs.py` — regenerates the environment, storyline, scenario, ground truth and attack plan.
- `GROUND_TRUTH30.md` — expected attack timeline used only for evaluation, not as detector input.
- `attack_window_plan.csv` — one row per planned episode with UTC window and intended observable evidence.
- `validate_days30.py` — checks the converted JSONL dataset against duration and plan expectations.
- `run_northside_30day.ps1` — builds, validates, emits Security/Sysmon XML, converts to `days30.jsonl`, and validates coverage.
- `finalmapped_fixed_v9_context_features_memfix_30day.ipynb` — notebook configured for the 30-day corpus, 7/23-day split, and separate `cache30` / `baseline_output30` output directories.

## Install and run

**Important:** the ZIP has files at its root (no extra outer folder). Extract all its contents into:

`D:\EvidenceForge\scenarios\northside-30day\`

From an activated PowerShell terminal at the EvidenceForge project root:

```powershell
Set-Location D:\EvidenceForge
.\scenarios\northside-30day\run_northside_30day.ps1
```

The runner sets `TEMP`, `TMP`, `EFORGE_SPOOL_DIR` and `UV_CACHE_DIR` to paths on D:. It then runs the config builder, `uv run eforge validate`, `uv run eforge generate`, the existing root-level `xml_to_jsonl.py`, and `validate_days30.py`. Windows may still need free space on C: for unrelated system operations, but the package paths for its temp/spool/cache/data are on D:.

The runner refuses to overwrite existing output by default. Use `-Force` only if you intend to delete `scenarios/northside-30day/output` and the project-root `days30.jsonl`; back them up first if needed. It does not resume a failed generation.

## Run the model and get results

Open Jupyter with `D:\EvidenceForge` as the working directory. Open the notebook, restart the kernel, and choose **Restart & Run All**. It reads `days30.jsonl` and `GROUND_TRUTH30.md`, and writes artifacts to `cache30` and `baseline_output30` without overwriting the earlier experiment's outputs.

**This package does not yet contain model metrics for the 30-day corpus.** The notebook's saved outputs are cleared intentionally; actual precision, recall, TP/FP/FN/TN, recovered misses, and attack-window detection counts can only be computed after EvidenceForge emits the XML, conversion creates `days30.jsonl`, and the notebook is run on that exact dataset. A plan row is not proof that an event was emitted or attributed to the expected user.

## Evaluation safeguards

The ground-truth timeline is for evaluation only. Reconcile planned episodes against emitted, attributed events before interpreting misses. Keep the scoring logic and threshold policy unchanged for the first evaluation; do not tune features or thresholds using final test labels.
