#!/usr/bin/env python3
"""Validate a generated days30.jsonl against the planned 30-day corpus.

Usage: python validate_days50.py --events days30.jsonl [--plan attack_window_plan.csv]
This validates shape/time/event-family coverage; review all warnings before evaluation.
"""
from __future__ import annotations
import argparse, csv, json, re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ID_FIELDS = ("EventID", "event_id", "eventid")
TS_FIELDS = ("timestamp", "Timestamp", "TimeCreated_raw", "UtcTime", "time")
USER_FIELDS = ("User", "SubjectUserName", "TargetUserName", "AccountName", "user", "actor", "SourceUser")
HOST_FIELDS = ("Computer", "computer", "host", "system", "Hostname")


def get(d, keys):
    for k in keys:
        v = d.get(k)
        if v not in (None, "", "-"):
            return v
    return None


def parse_ts(v):
    if not v:
        return None
    s = str(v).strip().replace("Z", "+00:00")
    # Sysmon UtcTime may not include timezone.
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def norm_user(v):
    if not v:
        return None
    s = str(v).strip().lower()
    if "\\" in s:
        s = s.rsplit("\\", 1)[-1]
    if "@" in s:
        s = s.split("@", 1)[0]
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--events", default="days30.jsonl")
    ap.add_argument("--plan", default="attack_window_plan.csv")
    args = ap.parse_args()
    ep = Path(args.events)
    if not ep.exists():
        raise SystemExit(f"Events file not found: {ep}")

    total = 0; bad_json = 0; bad_ts = 0
    eids = Counter(); dates = Counter(); users = set(); hosts = set()
    feature_eventids = Counter()
    # Read line-by-line to support large JSONL files.
    with ep.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.strip(): continue
            try: d = json.loads(line)
            except json.JSONDecodeError:
                bad_json += 1; continue
            total += 1
            eid = str(get(d, ID_FIELDS) or "UNKNOWN")
            eids[eid] += 1
            ts = parse_ts(get(d, TS_FIELDS))
            if ts is None:
                bad_ts += 1
            else:
                dates[ts.strftime("%Y-%m-%d")] += 1
            for field in USER_FIELDS:
                u = norm_user(d.get(field))
                if u and u != "system": users.add(u)
            h = get(d, HOST_FIELDS)
            if h: hosts.add(str(h).split(".")[0].upper())
            if eid in {"1", "3", "8", "10", "4624", "4625", "4648", "4672", "4720", "4728", "4732", "4697", "7045", "4698", "1102", "104", "5156"}:
                feature_eventids[eid] += 1

    print("JSONL validation summary")
    print(f"  parsed records: {total:,}")
    print(f"  malformed JSON lines: {bad_json:,}")
    print(f"  missing/unparseable timestamps: {bad_ts:,}")
    print(f"  observed UTC dates: {len(dates)}" + (f" ({min(dates)} .. {max(dates)})" if dates else ""))
    print(f"  observed user-like values: {len(users)}")
    print(f"  observed hosts: {len(hosts)}")
    print("  detector-relevant EventID counts:")
    for eid in sorted(feature_eventids, key=lambda s: int(s)):
        print(f"    {eid}: {feature_eventids[eid]:,}")

    if bad_json or bad_ts:
        print("WARNING: investigate malformed records/timestamps before scoring.")
    if len(dates) != 30:
        print(f"WARNING: expected 30 UTC calendar dates but observed {len(dates)}; confirm the emitter ran the full interval and check missing/partial days.")
    expected_users = {"ishita.kapoor", "aarav.malhotra", "vivaan.sharma", "diya.singh", "kabir.chauhan", "meera.bansal", "aditya.saxena", "prerna.verma"}
    missing = expected_users - users
    if missing:
        print("WARNING: expected principals not visibly present in sampled identity fields:", ", ".join(sorted(missing)))
    # Some Windows action types are represented by alternate valid event IDs
    # depending on the channel/provider used by the emitter.
    required_any = [
        ("Sysmon process create", {"1"}),
        ("network connection telemetry (Sysmon/WFP)", {"3", "5156"}),
        ("Sysmon remote-thread event", {"8"}),
        ("successful logon", {"4624"}),
        ("failed logon/password spray", {"4625"}),
        ("explicit credentials", {"4648"}),
        ("account creation", {"4720"}),
        ("group membership change", {"4728", "4732"}),
        ("service installation", {"4697", "7045"}),
        ("scheduled task registration", {"4698"}),
        ("event log clear", {"1102", "104"}),
    ]
    missing_families = [label for label, alternatives in required_any
                        if not (alternatives & set(feature_eventids))]
    if missing_families:
        print("WARNING: no records found for expected event families:", "; ".join(missing_families),
              "(check scenario emission and event field normalization)")

    pp = Path(args.plan)
    if pp.exists():
        with pp.open("r", newline="", encoding="utf-8") as f:
            plan = list(csv.DictReader(f))
        print(f"  planned attack episodes: {len(plan)}")
        if len(plan) != 80:
            print("WARNING: attack plan does not contain 80 rows")
        # Count distinct planned user-window labels, excluding SYSTEM fan-out rows.
        labels = {(r["actor"], r["window_start_utc"]) for r in plan if r.get("actor") and r["actor"] != "SYSTEM"}
        print(f"  planned principal-window pairs (excluding spray fan-out): {len(labels)}")
        print("  Note: this check does not assert that an attack was correctly attributed; reconcile plan rows with actual event evidence before computing metrics.")

if __name__ == "__main__":
    main()
