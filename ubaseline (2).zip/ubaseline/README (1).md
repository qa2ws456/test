# ubaseline_service — streaming per-user behavioural scoring

Productionizes the `final.ipynb` notebook: Windows Security + Sysmon events arrive on
**Kafka** (JSONL), are collected into **10-minute windows** by event time, split
**per user**, and scored against **that user's hour-of-day baseline** (the artifacts
written by the notebook's section 23). Users with no baseline are stored in
**ClickHouse** for later retraining. All feature names, scoring math, weights and
threshold logic are ports of the notebook — `baseline_output/` artifacts apply
unchanged.

```text
Kafka topic (win-events, JSONL)
   │
   ▼  normalize.py          flat/nested shippers -> notebook schema, UTC timestamps
   ▼  attribution.py        A1 Sysmon User / A2 Security actor field
                            B1 ProcessGuid -> user (streaming-only fallback)
                            B2 5156 -> (host, PID, time) inside a process lifetime
                            C  unattributed -> counter (never crashes)
   ▼  windower.py           tumbling 10-min windows by EVENT time, watermark = max_ts - grace
   ▼  split per attributed, person-like user
   ├── user HAS baseline  -> features.py (71-feature registry + items)
   │                          -> scoring.py (z/novelty/rarity/activation/ML -> fuse
   │                             -> per-(user,hour) threshold -> alert + reasons)
   │                          -> result sink: logs, /results API, optional Kafka topic,
   │                             optional ClickHouse window_results table
   └── user has NO baseline -> clickhouse_sink.py (events table; JSONL fallback in dev)
```

## Layout

```
config.yaml                 all knobs: kafka, window/grace, baseline dir, weights fallbacks,
                            clickhouse mode, api port
app/config.py               typed access to config.yaml
app/normalize.py            shipper-shape tolerant projection (incl. 1102 namespaced fields)
app/attribution.py          tiered attribution + live process tables (Sysmon 1/5)
app/windower.py             event-time tumbling windows + watermark sealing
app/features.py             notebook §09.2/§11 port: prepare(), build_features(), build_items()
app/baseline_store.py       loads baseline_output/ (model.pkl + parquets), hot-reload,
                            reconstructs EID totals that the notebook did not export
app/scoring.py              notebook §16-19 port: 5 signals, noisy-OR fuse, threshold, reasons
app/clickhouse_sink.py      DDL + inserts; JSONL fallback when no cluster configured
app/consumer.py             Pipeline class + Kafka loop + --mock mode
app/api.py                  FastAPI: /health /metrics /baselines /results, POST /mock/run
scripts/profile_topic.py    onboarding profiler (per-Event-ID field availability)
tests/test_pipeline.py      end-to-end smoke test (no infra needed)
```

## Quick start (zero infrastructure)

```bash
pip install -r requirements.txt          # confluent-kafka / clickhouse-connect optional
python3 tests/test_pipeline.py           # fabricates a baseline + attack evening, asserts
# or score your real generated file:
python3 -m app.consumer --mock /path/to/events.jsonl
```

Mock mode reads any JSONL in the notebook's `events.jsonl` format, seals every
10-minute window in event-time order, and writes `mock_results_*.jsonl` with one
result per (user, window). Baselines come from `baseline.dir` in config.yaml —
copy the notebook's `baseline_output/` there for real scoring.

## Real deployment

```bash
# config.yaml: set kafka.bootstrap_servers, topics, clickhouse.host
python3 -m app.consumer                                   # consumer + scorer (logs alerts)
uvicorn app.api:app --port 8080                           # REST shell (starts consumer too)
```

- **Windows** seal `grace_seconds` (default 120 s) after their last event-time passes;
  out-of-order events inside a poll batch are sorted before attribution.
- **Retraining**: re-run the notebook on ClickHouse-held data, overwrite
  `baseline_output/` — the service hot-reloads within `hot_reload_seconds`.
- **ClickHouse modes**: `unbaselined` (per the brief), `all` (full audit trail),
  `none`. Without a cluster everything lands in `./clickhouse_fallback/*.jsonl`.

## Result contract (per user, per 10-minute window)

```json
{
  "user": "charlie.brown", "date": "2026-08-04", "hour": 21,
  "window_start": "2026-08-04T21:30:00+00:00", "window": "21:30-21:40",
  "event_count": 9,
  "signals": {"statistical": 0.0, "novelty": 0.93, "rarity": 0.61,
               "activation": 0.99, "ml": 0.0},
  "risk_score": 0.985, "risk_level": "CRITICAL",
  "threshold": 0.576, "risk_ratio": 1.71, "alert": true,
  "reasons": [
    {"signal": "activation", "weight": 0.79,
     "text": "first occurrence for charlie.brown: lsass_hi_count = 1 (zero in every baseline hour)"},
    {"signal": "novelty", "weight": 0.77,
     "text": "new authentication source IP: 203.0.113.117 (never seen anywhere in the baseline)"}
  ]
}
```

## Notes carried over from the notebook's findings

- `risk_score` is a behavioural-deviation score with bands, never a maliciousness
  probability; the alert cut is the per-(user,hour) threshold surface if
  `threshold_surface.parquet` exists, else the flat fallback.
- Machine accounts (SYSTEM, `PC-003$`, DWM-*) are never scored — their events go the
  ClickHouse route; the person-like filter lives in `attribution.py`.
- Sysmon EID 22 (DNS) often renders under `LOCAL SERVICE` (the resolver service),
  so DNS-based behaviour is attributed only when a user process issued the query —
  same limitation the notebook documents for its step 16.
- Monitor `/metrics`: `attribution_tiers` dropping (B1/B2 rising, A1 falling) means a
  Sysmon upgrade/config push changed field coverage — run `scripts/profile_topic.py`.
