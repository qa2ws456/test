---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
  language_info:
    codemirror_mode:
      name: ipython
      version: 3
    file_extension: .py
    mimetype: text/x-python
    name: python
    nbconvert_exporter: python
    pygments_lexer: ipython3
    version: 3.10.0
  nbformat: 4
  nbformat_minor: 5
---

::: {#9dbcdd6a .cell .markdown}
# Per-User, Per-Hour Active Directory Behavioural Baseline & Risk Scoring {#per-user-per-hour-active-directory-behavioural-baseline--risk-scoring}

**Windows Security + Sysmon telemetry → user attribution → 10-minute
windows → behavioural features → Day 1-7 baselines → Day 8-12 scoring →
explainable risk alerts.**

------------------------------------------------------------------------

### What this notebook builds

  -----------------------------------------------------------------------
  Stage                               Output
  ----------------------------------- -----------------------------------
  Normalisation                       one event-level dataframe covering
                                      every Security + Sysmon record

  User attribution                    evidence-based mapping of each
                                      event to a security principal (3
                                      tiers + an explicit \"cannot
                                      attribute\" bucket)

  Windowing                           a **complete**
                                      `user x 10-minute window` grid -
                                      empty windows are kept, never
                                      dropped

  Features                            \~70 numeric features + 11
                                      categorical behaviour dimensions
                                      per window

  Baseline                            robust `user x hour-of-day`
                                      statistics + per-user behavioural
                                      inventories, learned from the 7
                                      normal days only

  Scoring                             5 complementary anomaly signals
                                      fused into a bounded `risk_score`
                                      in \[0, 1\]

  Explainability                      ranked, human-readable reasons for
                                      every alert

  Evaluation                          precision / recall / PR-AUC /
                                      detection rate / **false positives
                                      per user per day**, against the
                                      scenario ground truth
  -----------------------------------------------------------------------

### Design commitments

1.  **The baseline is user-specific and hour-specific, and deliberately
    *not* day-of-week specific.** `alice + hour 09` pools all six
    10-minute windows of 09:00-10:00 from all seven training days (42
    observations).
2.  **No leakage.** Baselines, inventories, rarity tables and the ML
    model are fitted on days 1-7 only. Training-fold scores are produced
    by **leave-one-day-out** re-fitting so the \"normal\" score
    distribution is honest and usable for threshold selection.
3.  **Anomaly is not maliciousness.** The output is a
    behavioural-deviation score with risk *bands*, plus the evidence
    that produced it.
4.  **Assumptions are reported, never hidden.** Section 08 and the
    closing section list every event class that could not be attributed,
    every principal without a usable baseline, and every ground-truth
    step for which the dataset contains no attributable evidence.
:::

::: {#5e8536c4 .cell .markdown}

------------------------------------------------------------------------

## 01. Project Configuration {#01-project-configuration}

Everything that a reviewer might want to change - paths, the timezone
the \"day\" and \"hour\" are measured in, the window length, the
train/test split, the fusion weights - lives in this one cell.

**Timezone: everything is UTC.** Every timestamp in `events.jsonl` is
UTC, and every timestamp in the `## Timeline` and `## Red Herrings`
tables of `GROUND_TRUTH.md` is explicitly suffixed `UTC`. The only place
that file mentions another zone is one header line describing *its own*
suggested split
(`Baseline fit window : 2026-07-29 .. 2026-08-04 (7 days, local IST)`).
Since the project configuration below fixes its own split, no conversion
is applied anywhere: `hour` means UTC hour, `date` means UTC date, and
window boundaries are UTC. Nothing in the pipeline shifts a clock.

**Capture coverage.** The log starts at `2026-07-28T18:30:21Z` and ends
at `2026-08-09T18:29:57Z`, so the first and last configured days are
only partly covered by the sensor. Section 06 detects this from the data
and marks the uncovered windows `has_telemetry = False`. Those windows
are excluded from the baseline and from scoring - **not** because they
are empty, but because \"no sensor\" and \"user was idle\" are different
facts and only the second one is behaviour. Every empty window *inside*
the capture range is kept.
:::

::: {#7bff45d2 .cell .code execution_count="1" execution="{\"iopub.execute_input\":\"2026-08-25T08:58:55.916910Z\",\"iopub.status.busy\":\"2026-08-25T08:58:55.916503Z\",\"iopub.status.idle\":\"2026-08-25T08:58:55.934296Z\",\"shell.execute_reply\":\"2026-08-25T08:58:55.932330Z\"}"}
``` python
import os

# --- paths -----------------------------------------------------------------------
ROOT        = os.getcwd()          # run the notebook from the folder holding events.jsonl
EVENTS_PATH = os.path.join(ROOT, "events.jsonl")
GT_PATH     = os.path.join(ROOT, "groundtruth.md")
CACHE_DIR   = os.path.join(ROOT, "cache1")
OUT_DIR     = os.path.join(ROOT, "baseline_output1")
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

# --- time ------------------------------------------------------------------------
# All analysis happens in UTC, which is the zone every timestamp in events.jsonl and in
# GROUND_TRUTH.md is already recorded in. No timezone conversion happens anywhere below.
TZ               = "UTC"
WINDOW           = "10min"     # the behavioural window length
WINDOWS_PER_HOUR = 6           # 60 / 10
WINDOWS_PER_DAY  = 144         # 24 * 6

# Baseline period: assumed to contain only normal activity.
TRAIN_DATES = ["2026-07-28", "2026-07-29", "2026-07-30", "2026-07-31",
               "2026-08-01", "2026-08-02", "2026-08-03"]
# Scoring period: may contain malicious activity. The first ground-truth attack event is
# 2026-08-04 21:40:06 UTC, so the whole attack chain falls inside this window.
TEST_DATES  = ["2026-08-04", "2026-08-05", "2026-08-06",
               "2026-08-07", "2026-08-08", "2026-08-09"]
ALL_DATES   = TRAIN_DATES + TEST_DATES

# --- scoping ---------------------------------------------------------------------
MIN_TRAIN_EVENTS = 200      # a principal below this cannot support a 24-hour baseline
BS = chr(92)                # backslash - Windows paths appear everywhere below

# --- scoring hyper-parameters ----------------------------------------------------
Z0, Z1        = 9.0, 22.0   # robust-z band where the statistical severity ramps 0 -> 1
K_STAT        = 1.6         # saturation constants for each component's squash
K_NOV         = 4.5
K_RARE        = 1.2
K_ACT         = 2.5
W_STAT, W_NOV, W_RARE, W_ACT, W_ML = 0.55, 0.88, 0.90, 0.80, 0.12   # noisy-OR fusion caps

RISK_BANDS = [(0.25, "NORMAL"), (0.45, "LOW"), (0.60, "MEDIUM"), (0.80, "HIGH"), (1.01, "CRITICAL")]
# Operational alert budget: about one alert per user per five days - a queue a small
# SOC can actually work. The alert threshold is DERIVED
# from this on the baseline null in section 18; it is never tuned on the scored days.
FP_BUDGET_PER_USER_DAY = 0.20

RANDOM_STATE = 0
assert os.path.exists(EVENTS_PATH), (
    f"events.jsonl not found in {ROOT!r} - start Jupyter from the folder that contains it, "
    "or set ROOT explicitly above")
print("configuration loaded")
print(f"  timezone : {TZ} (no conversion applied anywhere)")
print(f"  window   : {WINDOW}  ->  {WINDOWS_PER_HOUR}/hour, {WINDOWS_PER_DAY}/day")
print(f"  train    : {TRAIN_DATES[0]} -> {TRAIN_DATES[-1]}  ({len(TRAIN_DATES)} calendar days)")
print(f"  test     : {TEST_DATES[0]} -> {TEST_DATES[-1]}  ({len(TEST_DATES)} calendar days)")
```

::: {.output .stream .stdout}
    configuration loaded
      timezone : UTC (no conversion applied anywhere)
      window   : 10min  ->  6/hour, 144/day
      train    : 2026-07-28 -> 2026-08-03  (7 calendar days)
      test     : 2026-08-04 -> 2026-08-09  (6 calendar days)
:::
:::

::: {#a18348f2 .cell .markdown}

------------------------------------------------------------------------

## 02. Imports {#02-imports}
:::

::: {#504d828f .cell .code execution_count="2" execution="{\"iopub.execute_input\":\"2026-08-25T08:58:55.938530Z\",\"iopub.status.busy\":\"2026-08-25T08:58:55.938135Z\",\"iopub.status.idle\":\"2026-08-25T08:58:59.538423Z\",\"shell.execute_reply\":\"2026-08-25T08:58:59.536880Z\"}"}
``` python
import json, re, math, warnings, textwrap
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch

from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.metrics import (average_precision_score, roc_auc_score,
                             precision_recall_curve, roc_curve, f1_score)

warnings.filterwarnings("ignore")
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 60)
pd.set_option("display.max_colwidth", 70)

# ---- chart system ---------------------------------------------------------------
# Validated categorical order (adjacent-pair CVD-safe), one sequential blue ramp,
# reserved status colours. Colour is assigned by role, never by rank.
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
SEQ = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
STATUS = {"good": "#0ca30c", "warning": "#fab219", "serious": "#ec835a", "critical": "#d03b3b"}
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
GRID, AXIS, SURFACE = "#e1e0d9", "#c3c2b7", "#fcfcfb"
BLUES = LinearSegmentedColormap.from_list("blues", SEQ)

mpl.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "font.family": "sans-serif",
    "font.sans-serif": ["Segoe UI", "DejaVu Sans", "sans-serif"],
    "font.size": 9.5, "axes.titlesize": 11, "axes.titleweight": "600",
    "axes.labelsize": 9.5, "axes.labelcolor": INK2, "axes.edgecolor": AXIS,
    "axes.titlecolor": INK, "axes.linewidth": 0.8, "axes.grid": True, "axes.axisbelow": True,
    "grid.color": GRID, "grid.linewidth": 0.7, "grid.linestyle": "-",
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
    "legend.frameon": False, "legend.fontsize": 8.5,
    "figure.dpi": 110, "lines.linewidth": 2.0, "lines.markersize": 5,
})

def finish(ax, title=None, sub=None, xlabel=None, ylabel=None, xgrid=False):
    """Recessive chrome: hairline grid on the value axis only, no top/right spines."""
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.spines["left"].set_color(AXIS); ax.spines["bottom"].set_color(AXIS)
    ax.grid(axis="x" if xgrid else "y")
    ax.grid(axis="y" if xgrid else "x", visible=False)
    if title:
        ax.set_title(title, loc="left", pad=21 if sub else 8)
    if sub:
        ax.text(0, 1.012, sub, transform=ax.transAxes, color=MUTED, fontsize=8.5, va="bottom")
    if xlabel: ax.set_xlabel(xlabel)
    if ylabel: ax.set_ylabel(ylabel)
    return ax

print("numpy", np.__version__, "| pandas", pd.__version__, "| matplotlib", mpl.__version__)
```

::: {.output .stream .stdout}
    numpy 2.2.6 | pandas 2.3.3 | matplotlib 3.10.9
:::
:::

::: {#8c720634 .cell .markdown}

------------------------------------------------------------------------

## 03. Load Dataset {#03-load-dataset}

`events.jsonl` is \~795 MB of one-JSON-object-per-line records that were
flattened from `windows_event_security.xml` and
`windows_event_sysmon.xml`. 172 distinct keys appear across the file,
but only a subset carries identity or behaviour; the loader keeps that
subset and writes a compact parquet cache so the notebook can be re-run
cheaply.

Two normalisations happen here:

-   the namespaced `{http://manifests.microsoft.com/...}SubjectUserName`
    fields emitted by Event 1102 are folded onto their plain names;
-   Sysmon\'s inconsistent `SourceProcessGUID` / `SourceProcessGuid`
    casing is unified.
:::

::: {#4d2ae983 .cell .code execution_count="3" execution="{\"iopub.execute_input\":\"2026-08-25T08:58:59.543014Z\",\"iopub.status.busy\":\"2026-08-25T08:58:59.542392Z\",\"iopub.status.idle\":\"2026-08-25T08:59:02.184118Z\",\"shell.execute_reply\":\"2026-08-25T08:59:02.182645Z\"}"}
``` python
KEEP_FIELDS = [
    "timestamp", "EventID", "Channel", "Computer", "Provider", "EventRecordID",
    # Security - identity & session
    "SubjectUserName", "SubjectDomainName", "SubjectLogonId",
    "TargetUserName", "TargetDomainName", "TargetLogonId", "TargetSid",
    "LogonType", "LogonGuid", "LogonProcessName", "AuthenticationPackageName", "WorkstationName",
    "IpAddress", "IpPort", "Status", "SubStatus", "FailureReason", "ElevatedToken",
    "PrivilegeList", "SessionId", "PackageName", "Workstation",
    # Security - process / object
    "NewProcessId", "NewProcessName", "ParentProcessName", "ProcessId", "ProcessName",
    "CommandLine", "TokenElevationType", "TargetServerName", "ServiceName",
    "MemberName", "SamAccountName", "ServiceFileName", "ServiceAccount", "TaskName",
    # Security 5156 (filtering-platform connection)
    "ProcessID", "Application", "Direction", "SourceAddress", "SourcePort",
    "DestAddress", "DestPort", "Protocol",
    # Sysmon - common
    "User", "ProcessGuid", "Image", "IntegrityLevel", "TerminalSessionId", "LogonId",
    "ParentProcessGuid", "ParentProcessId", "ParentImage", "ParentUser", "OriginalFileName",
    # Sysmon 3 / 22 / 11 / 12-14 / 7 / 8 / 10
    "Initiated", "SourceIp", "DestinationIp", "DestinationHostname",
    "DestinationPort", "DestinationPortName",
    "QueryName", "QueryStatus", "TargetFilename", "EventType", "TargetObject",
    "ImageLoaded", "Signed", "SignatureStatus",
    "SourceProcessGuid", "SourceProcessGUID", "SourceProcessId", "SourceImage", "SourceUser",
    "TargetProcessGuid", "TargetProcessGUID", "TargetProcessId", "TargetImage", "TargetUser",
    "GrantedAccess", "StartModule", "StartFunction",
]
_NS = "{http://manifests.microsoft.com/win/2004/08/windows/eventlog}"
_NSMAP = {_NS + k: k for k in
          ["SubjectUserName", "SubjectDomainName", "SubjectLogonId", "SubjectUserSid"]}
_KEEP = set(KEEP_FIELDS)
CHUNK = 100_000


FINAL_COLS = [c for c in KEEP_FIELDS if not c.endswith("GUID")] + ["SubjectUserSid"]


def _chunk_frame(buf):
    """Fixed schema per chunk so the parquet writer stays happy across chunks."""
    d = pd.DataFrame(buf)
    for alt, canon in [("SourceProcessGUID", "SourceProcessGuid"),
                       ("TargetProcessGUID", "TargetProcessGuid")]:
        if alt in d.columns:
            d[canon] = d[canon].fillna(d[alt]) if canon in d.columns else d[alt]
            d = d.drop(columns=[alt])
    d = d.reindex(columns=FINAL_COLS)
    return d.astype("string")


def load_events(path=EVENTS_PATH, cache=os.path.join(CACHE_DIR, "events_raw.parquet"), rebuild=False):
    """Stream the JSONL in chunks, project onto KEEP_FIELDS, normalise, cache as parquet.

    The raw file is ~795 MB. Materialising all 811k records at once needs several GB, so chunks
    are written straight through to parquet and the tidy frame is read back once at the end.
    """
    import gc
    import pyarrow as pa, pyarrow.parquet as pq

    if not (os.path.exists(cache) and not rebuild):
        writer, buf, malformed, n = None, [], 0, 0

        def flush(b):
            nonlocal writer
            tbl = pa.Table.from_pandas(_chunk_frame(b), preserve_index=False)
            if writer is None:
                writer = pq.ParquetWriter(cache, tbl.schema, compression="snappy")
            writer.write_table(tbl)

        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    e = json.loads(line)
                except Exception:
                    malformed += 1
                    continue
                r = {}
                for k, v in e.items():
                    if k in _NSMAP:
                        r[_NSMAP[k]] = v
                    elif k in _KEEP:
                        r[k] = v
                buf.append(r); n += 1
                if len(buf) >= CHUNK:
                    flush(buf); buf = []; gc.collect()
                    print(f"   parsed {n:,} lines ...")
        if buf:
            flush(buf)
        writer.close()
        del buf; gc.collect()
        print(f"parsed {n:,} events ({malformed} malformed lines skipped) -> {cache}")

    df = pd.read_parquet(cache)
    df["EventID"] = df["EventID"].astype("int32")
    df["timestamp"] = pd.to_datetime(df["timestamp"], format="ISO8601", utc=True)
    if not df.timestamp.is_monotonic_increasing:
        df = df.sort_values("timestamp", ignore_index=True)
        print("   (records were not time-ordered on disk; sorted)")
    print(f"loaded {len(df):,} events x {df.shape[1]} retained fields "
          f"({os.path.getsize(cache)/1e6:.0f} MB cached)")
    return df


raw = load_events()
raw.head(3)[["timestamp", "EventID", "Channel", "Computer", "TargetUserName", "User"]]
```


::: {#02aa8a1b .cell .markdown}

------------------------------------------------------------------------

## 04. Dataset Profiling {#04-dataset-profiling}
:::

::: {#f43e1a6c .cell .code execution_count="4" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:02.187945Z\",\"iopub.status.busy\":\"2026-08-25T08:59:02.187570Z\",\"iopub.status.idle\":\"2026-08-25T08:59:09.638084Z\",\"shell.execute_reply\":\"2026-08-25T08:59:09.636525Z\"}"}
``` python
n_events = len(raw)
t0, t1 = raw.timestamp.min(), raw.timestamp.max()
print(f"files parsed        : 1 consolidated JSONL ({raw.Provider.notna().sum():,} provider-tagged records)")
print(f"total events        : {n_events:,}")
print(f"UTC range           : {t0}  ->  {t1}")
print(f"analysis tz         : {TZ} (source timestamps are already UTC)")
print(f"span                : {(t1 - t0).total_seconds() / 86400:.3f} days")
print()
print("channel distribution")
for ch, n in raw.Channel.value_counts().items():
    print(f"  {ch:40s} {n:>9,}  ({n / n_events:5.1%})")

_local = raw.timestamp.dt.tz_convert(TZ)
per_day = _local.dt.strftime("%Y-%m-%d").value_counts().sort_index()
print()
print("events per UTC day  (train / test as configured in section 01)")
for d, n in per_day.items():
    tag = "train" if d in TRAIN_DATES else ("test " if d in TEST_DATES else "  -  ")
    print(f"  {d}  {tag}  {n:>7,}")

print()
print("missing-value profile of the identity fields that matter")
idf = ["TargetUserName", "SubjectUserName", "User", "SourceUser", "Computer",
       "LogonId", "LogonGuid", "ProcessGuid", "IpAddress"]
prof = pd.DataFrame({
    "present": [int(raw[c].notna().sum()) for c in idf],
    "missing_pct": [f"{1 - raw[c].notna().mean():.1%}" for c in idf],
    "distinct": [int(raw[c].nunique()) for c in idf],
}, index=idf)
prof
```

::: {.output .stream .stdout}
    files parsed        : 1 consolidated JSONL (811,088 provider-tagged records)
    total events        : 811,088
    UTC range           : 2026-07-28 18:30:21.775788+00:00  ->  2026-08-09 18:29:57.391886+00:00
    analysis tz         : UTC (source timestamps are already UTC)
    span                : 12.000 days

    channel distribution
      Security                                   618,968  (76.3%)
      Microsoft-Windows-Sysmon/Operational       192,120  (23.7%)

    events per UTC day  (train / test as configured in section 01)
      2026-07-28  train   15,645
      2026-07-29  train   73,447
      2026-07-30  train   73,146
      2026-07-31  train   71,121
      2026-08-01  train   55,948
      2026-08-02  train   56,164
      2026-08-03  train   74,094
      2026-08-04  test    74,789
      2026-08-05  test    72,851
      2026-08-06  test    71,836
      2026-08-07  test    72,356
      2026-08-08  test    56,404
      2026-08-09  test    43,287

    missing-value profile of the identity fields that matter
:::

``` python
fig, axes = plt.subplots(1, 2, figsize=(13, 3.6))

ax = axes[0]
days = list(per_day.index)
colors = [CAT[0] if d in TRAIN_DATES else CAT[1] for d in days]
ax.bar(range(len(days)), per_day.values, color=colors, width=0.72)
ax.set_xticks(range(len(days)))
ax.set_xticklabels([d[5:] for d in days], rotation=0)
ax.yaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, p: f"{v/1000:.0f}k"))
finish(ax, "Events per UTC day",
       f"blue = baseline ({TRAIN_DATES[0]}..{TRAIN_DATES[-1]})   "
       f"orange = scoring ({TEST_DATES[0]}..{TEST_DATES[-1]})", ylabel="events")
ax.legend(handles=[Patch(color=CAT[0], label="baseline"), Patch(color=CAT[1], label="scoring")],
          loc="lower left", ncols=2)

ax = axes[1]
hourly = _local.dt.hour.value_counts().sort_index()
ax.fill_between(hourly.index, hourly.values, color=CAT[0], alpha=0.18)
ax.plot(hourly.index, hourly.values, color=CAT[0])
ax.set_xticks(range(0, 24, 3))
ax.yaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, p: f"{v/1000:.0f}k"))
finish(ax, "Events by UTC hour of day", "pooled over the whole capture - the shape the baseline learns",
       xlabel="hour (UTC)", ylabel="events")
plt.tight_layout(); plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/8f7c8ca8942c3e188b9ec002362fef021c913a3e.png)
:::
:::

::: {#5c33616b .cell .markdown}

------------------------------------------------------------------------

## 05. Event ID Analysis {#05-event-id-analysis}

Nothing about the event set is assumed. The table below is generated
from the data: for every Event ID actually present we report its volume,
which identity field carries the *actor*, and the attribution route that
will be used in section 07-08.

The \"actor\" choice is deliberate and follows Windows semantics:

-   **`TargetUserName`** is the actor for authentication events
    (`4624/4625/4634/4768/4769/4771/4776/4800/4801`) - the account that
    logged on, failed to log on, or was targeted by a ticket request.
-   **`SubjectUserName`** is the actor for events performed *by* a
    session (`4688/4689/4672/4648/4720/4728/4697/4698/1102` \...).
-   **`User` / `SourceUser`** is the actor for Sysmon.
-   `5156` carries **no** identity field at all and must be correlated
    (section 08).
:::

::: {#f13501d7 .cell .code execution_count="6" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:10.287984Z\",\"iopub.status.busy\":\"2026-08-25T08:59:10.287446Z\",\"iopub.status.idle\":\"2026-08-25T08:59:14.579407Z\",\"shell.execute_reply\":\"2026-08-25T08:59:14.577826Z\"}"}
``` python
SECURITY_ACTOR_FIELD = {
    4624: "TargetUserName", 4625: "TargetUserName", 4634: "TargetUserName", 4647: "TargetUserName",
    4768: "TargetUserName", 4769: "TargetUserName", 4770: "TargetUserName", 4771: "TargetUserName",
    4776: "TargetUserName", 4800: "TargetUserName", 4801: "TargetUserName",
    4688: "SubjectUserName", 4689: "SubjectUserName", 4672: "SubjectUserName",
    4648: "SubjectUserName", 4720: "SubjectUserName", 4722: "SubjectUserName",
    4724: "SubjectUserName", 4726: "SubjectUserName", 4738: "SubjectUserName",
    4740: "SubjectUserName", 4728: "SubjectUserName", 4732: "SubjectUserName",
    4756: "SubjectUserName", 4697: "SubjectUserName", 4698: "SubjectUserName",
    1102: "SubjectUserName",
}
SYSMON_ACTOR_FIELD = {
    1: "User", 2: "User", 3: "User", 5: "User", 6: "User", 7: "User", 11: "User", 12: "User",
    13: "User", 14: "User", 15: "User", 17: "User", 18: "User", 22: "User", 23: "User", 25: "User",
    8: "SourceUser", 10: "SourceUser",
}
EVENT_MEANING = {
    1: "Sysmon process create", 3: "Sysmon network connection", 5: "Sysmon process terminated",
    7: "Sysmon image loaded", 8: "Sysmon CreateRemoteThread", 10: "Sysmon process access",
    11: "Sysmon file create", 13: "Sysmon registry value set", 22: "Sysmon DNS query",
    1102: "Security log cleared", 4624: "Logon success", 4625: "Logon failure",
    4634: "Logoff", 4648: "Logon with explicit credentials", 4672: "Special privileges assigned",
    4688: "Process creation", 4689: "Process exit", 4697: "Service installed",
    4698: "Scheduled task created", 4720: "User account created", 4724: "Password reset attempt",
    4728: "Member added to global group", 4738: "User account changed",
    4768: "Kerberos TGT requested", 4769: "Kerberos service ticket requested",
    4770: "Kerberos ticket renewed", 4771: "Kerberos pre-auth failed",
    4776: "NTLM credential validation", 4800: "Workstation locked", 4801: "Workstation unlocked",
    5156: "Filtering platform allowed a connection",
}

rows = []
for eid, n in raw.EventID.value_counts().items():
    sub = raw[raw.EventID == eid]
    ch = sub.Channel.iloc[0]
    if eid in SYSMON_ACTOR_FIELD:
        fld, route = SYSMON_ACTOR_FIELD[eid], "direct (Sysmon)"
    elif eid in SECURITY_ACTOR_FIELD:
        fld, route = SECURITY_ACTOR_FIELD[eid], "direct (Security)"
    elif eid == 5156:
        fld, route = "-", "correlated (PID + host + time)"
    else:
        fld, route = "-", "NOT ATTRIBUTABLE"
    cov = f"{sub[fld].notna().mean():.0%}" if fld in sub.columns and fld != "-" else "-"
    rows.append({"event_id": eid, "channel": "Sysmon" if "Sysmon" in str(ch) else "Security",
                 "count": n, "pct": n / n_events, "actor_field": fld, "field_coverage": cov,
                 "attribution": route, "meaning": EVENT_MEANING.get(eid, "?")})

event_catalog = pd.DataFrame(rows).sort_values("count", ascending=False).reset_index(drop=True)
event_catalog["pct"] = event_catalog["pct"].map(lambda v: f"{v:.2%}")
event_catalog["count"] = event_catalog["count"].map(lambda v: f"{v:,}")
event_catalog
```

```
:::
:::


::: {#2624e92a .cell .markdown}

------------------------------------------------------------------------

## 06. Timestamp Normalisation & Capture Coverage {#06-timestamp-normalisation--capture-coverage}

Every event gets a UTC date, a UTC hour-of-day and its 10-minute window
start. No conversion is applied - the source timestamps are already UTC.

The second half of this section measures **capture coverage**. The
configured period is 13 calendar days, but the sensor only produced data
for 12 x 24 hours of it: the log opens partway through the first day and
closes partway through the last. Those uncovered windows are identified
here so that later stages can tell \"the sensor was not running\" apart
from \"the user was idle\".
:::

::: {#90185b6d .cell .code execution_count="8" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:18.665643Z\",\"iopub.status.busy\":\"2026-08-25T08:59:18.665103Z\",\"iopub.status.idle\":\"2026-08-25T08:59:25.875349Z\",\"shell.execute_reply\":\"2026-08-25T08:59:25.873350Z\"}"}
``` python
# The source column is already tz-aware UTC; ts_utc and ts are the same clock and are kept
# as two names only so that downstream code reads unambiguously.
raw["ts_utc"] = raw["timestamp"]
raw["ts"]     = raw["ts_utc"]
raw["date"]   = raw["ts"].dt.strftime("%Y-%m-%d")     # UTC calendar date
raw["hour"]   = raw["ts"].dt.hour                     # UTC hour of day, 0..23
raw["win"]    = raw["ts"].dt.floor(WINDOW)            # start of the 10-minute window

observed_days = sorted(raw.date.unique())
print(f"UTC days observed   : {len(observed_days)}  ({observed_days[0]} .. {observed_days[-1]})")
print(f"configured days     : {len(ALL_DATES)}  ({ALL_DATES[0]} .. {ALL_DATES[-1]})")
assert set(observed_days) <= set(ALL_DATES), "events exist outside the configured date range"
print(f"first event (UTC)   : {raw.ts.min()}")
print(f"last  event (UTC)   : {raw.ts.max()}")

# ---- capture coverage -------------------------------------------------------------
# Anything before the first event or after the last one is "sensor not running", not "quiet user".
CAPTURE_START = raw.ts.min().floor(WINDOW)
CAPTURE_END   = raw.ts.max().floor(WINDOW) + pd.Timedelta(WINDOW)
total_windows = len(ALL_DATES) * WINDOWS_PER_DAY
covered = int(((pd.date_range(pd.Timestamp(ALL_DATES[0] + " 00:00", tz=TZ),
                              pd.Timestamp(ALL_DATES[-1] + " 23:50", tz=TZ),
                              freq=WINDOW, tz=TZ) >= CAPTURE_START) &
               (pd.date_range(pd.Timestamp(ALL_DATES[0] + " 00:00", tz=TZ),
                              pd.Timestamp(ALL_DATES[-1] + " 23:50", tz=TZ),
                              freq=WINDOW, tz=TZ) < CAPTURE_END)).sum())
print()
print("CAPTURE COVERAGE")
print(f"  sensor active from  : {CAPTURE_START}  to  {CAPTURE_END}")
print(f"  windows in the configured range : {total_windows:,}")
print(f"  windows with sensor coverage    : {covered:,}")
print(f"  windows WITHOUT coverage        : {total_windows - covered:,}  "
      f"({(total_windows - covered) / total_windows:.1%})")
print()
print("  WARNING: the configured period spans 13 calendar days but the sensor only covers")
print(f"  {covered / WINDOWS_PER_DAY:.2f} days of it. {ALL_DATES[0]} starts at "
      f"{CAPTURE_START:%H:%M} and {ALL_DATES[-1]} ends at {CAPTURE_END:%H:%M}, so UTC hours")
print("  00-17 receive one fewer baseline day than hours 19-23. Section 10 reports the exact")
print("  observation count per user x hour cell rather than assuming a flat 42.")
print()
print(f"distinct 10-min windows populated by at least one event: {raw.win.nunique():,}")
dup = raw.duplicated(subset=["EventRecordID", "Computer", "EventID", "ts_utc"]).sum()
print(f"exact duplicate records (EventRecordID+host+id+time)   : {dup}")
```

::: {.output .stream .stdout}
    UTC days observed   : 13  (2026-07-28 .. 2026-08-09)
    configured days     : 13  (2026-07-28 .. 2026-08-09)
    first event (UTC)   : 2026-07-28 18:30:21.775788+00:00
    last  event (UTC)   : 2026-08-09 18:29:57.391886+00:00

    CAPTURE COVERAGE
      sensor active from  : 2026-07-28 18:30:00+00:00  to  2026-08-09 18:30:00+00:00
      windows in the configured range : 1,872
      windows with sensor coverage    : 1,728
      windows WITHOUT coverage        : 144  (7.7%)

      WARNING: the configured period spans 13 calendar days but the sensor only covers
      12.00 days of it. 2026-07-28 starts at 18:30 and 2026-08-09 ends at 18:30, so UTC hours
      00-17 receive one fewer baseline day than hours 19-23. Section 10 reports the exact
      observation count per user x hour cell rather than assuming a flat 42.

    distinct 10-min windows populated by at least one event: 1,728
    exact duplicate records (EventRecordID+host+id+time)   : 0
:::
:::

::: {#80b915ed .cell .markdown}

------------------------------------------------------------------------

## 07. User Identification {#07-user-identification}

Attribution runs in tiers, most-reliable first. A later tier never
overwrites an earlier one.

  -----------------------------------------------------------------------
  Tier                    Rule                    Confidence
  ----------------------- ----------------------- -----------------------
  **A1**                  Sysmon event carries    high - the sensor
                          `User` (or `SourceUser` resolved the token
                          for 8/10)               owner

  **A2**                  Security event carries  high - written by LSASS
                          the actor field from    
                          the section-05 map      

  **B**                   Security 5156 matched   medium - see section 08
                          to a Sysmon process by  for the validation
                          `(Computer, PID)` with  
                          the event time inside   
                          the process lifetime    

  **C**                   everything else         **not attributed -
                                                  excluded from all
                                                  baselines**
  -----------------------------------------------------------------------

Domain prefixes (`CORP\`, `NT AUTHORITY\`, \...) are stripped so
`CORP\alice.smith` and `alice.smith` are one principal.
:::

::: {#aa26af8b .cell .code execution_count="9" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:25.879914Z\",\"iopub.status.busy\":\"2026-08-25T08:59:25.879106Z\",\"iopub.status.idle\":\"2026-08-25T08:59:27.685834Z\",\"shell.execute_reply\":\"2026-08-25T08:59:27.684462Z\"}"}
``` python
def strip_domain(s):
    s = s.astype("string")
    s = s.str.replace(r"^(CORP|CORP\.LOCAL|NT AUTHORITY|NT SERVICE|BUILTIN|Window Manager|"
                      r"Font Driver Host)\\", "", regex=True, case=False)
    return s.str.strip()


raw["attr_user"]   = pd.NA
raw["attr_method"] = pd.NA

# --- Tier A1: Sysmon direct identity ---------------------------------------------
for eid, fld in SYSMON_ACTOR_FIELD.items():
    if fld not in raw.columns:
        continue
    m = (raw.EventID == eid) & raw[fld].notna()
    if m.any():
        raw.loc[m, "attr_user"]   = raw.loc[m, fld]
        raw.loc[m, "attr_method"] = "A1_sysmon_" + fld

# --- Tier A2: Security direct identity -------------------------------------------
for eid, fld in SECURITY_ACTOR_FIELD.items():
    if fld not in raw.columns:
        continue
    m = (raw.EventID == eid) & raw[fld].notna() & (raw[fld] != "-")
    if m.any():
        raw.loc[m, "attr_user"]   = raw.loc[m, fld]
        raw.loc[m, "attr_method"] = "A2_security_" + fld

raw["attr_user"] = strip_domain(raw["attr_user"])

covered = raw.attr_user.notna()
print(f"tier A (direct identity): {covered.sum():,} / {len(raw):,}  ({covered.mean():.1%})")
print()
print(raw.attr_method.value_counts().to_string())
print()
print("distinct principal strings seen so far:", raw.attr_user.nunique())
```

::: {.output .stream .stdout}
    tier A (direct identity): 477,377 / 811,088  (58.9%)

    attr_method
    A2_security_TargetUserName     183519
    A1_sysmon_User                 156377
    A2_security_SubjectUserName    101738
    A1_sysmon_SourceUser            35743

    distinct principal strings seen so far: 28
:::
:::

::: {#4ecb1fdb .cell .markdown}
### 7.3 ProcessGuid fallback for Sysmon events without a native User field {#73-processguid-fallback-for-sysmon-events-without-a-native-user-field}

Tier A1 above trusts each Sysmon EventID\'s own actor field directly
(`User` or `SourceUser`). In **this** dataset that field is 100%
populated on every sampled Sysmon EventID (see the coverage table in
section 06/8.3) --- but that is a property of how this particular
capture was generated, not a guarantee real Sysmon deployments make. In
genuine production Sysmon logs, EventIDs 5 (process terminate), 7 (image
load), 8 (CreateRemoteThread) and 13 (registry) typically do **not**
carry a native `User` field --- only 1, 3, 10, 11 and 22 reliably do.
Relying on direct-field presence alone is fragile if this pipeline is
ever pointed at real logs instead of this capture.

The fix: every Sysmon event also carries a `ProcessGuid` (or, for 8/10,
a *source* process GUID) tying it back to the Sysmon Event 1 that
created that exact process. Unlike a raw PID, a ProcessGuid is
**globally unique** --- Sysmon constructs it from the host, PID and
process-creation time together, so it never repeats and never needs the
interval/time-bounding that the 5156 correlation (section 8.2) needs for
a PID. This makes it a plain, safe dictionary lookup: build
`ProcessGuid -> attr_user` from every Sysmon Event 1 row that already
has a trusted actor, then fill in any Sysmon event whose own direct
field came back empty.

On this dataset this tier should attribute close to nothing new (direct
coverage is already 100%) --- the count printed below is the honest
measure of that, not a target to hit. It exists so the notebook still
produces valid attribution if run against a real Sysmon deployment where
the direct field is sparse.
:::

::: {#cbd23876 .cell .code execution_count="10"}
``` python
# ---- 7.3 Tier A1b: ProcessGuid fallback for Sysmon events missing a direct actor field ----
# Field name for the process-identifying GUID differs for the two "two-actor" event types
# (8 = CreateRemoteThread, 10 = ProcessAccess use a SOURCE process guid; everything else uses
# the plain ProcessGuid). Try the real column name for each, skip gracefully if absent.
SYSMON_GUID_FIELD = {eid: "ProcessGuid" for eid in SYSMON_ACTOR_FIELD}
for eid in (8, 10):
    for cand in ("SourceProcessGUID", "SourceProcessGuid"):
        if cand in raw.columns:
            SYSMON_GUID_FIELD[eid] = cand
            break

# Anchors: Sysmon Event 1 rows that already have a trusted attr_user (Tier A1 direct field).
anchors = raw[(raw.EventID == 1) & raw.attr_user.notna() & raw.ProcessGuid.notna()]
guid_to_user = dict(zip(anchors.ProcessGuid, anchors.attr_user))
print(f"ProcessGuid -> user lookup built from {len(guid_to_user):,} anchored Sysmon Event 1 rows.")

n_fixed = 0
for eid, guid_field in SYSMON_GUID_FIELD.items():
    if guid_field not in raw.columns:
        continue
    m = (raw.EventID == eid) & raw.attr_user.isna() & raw[guid_field].notna()
    if not m.any():
        continue
    fallback_user = raw.loc[m, guid_field].map(guid_to_user)
    hit = fallback_user.notna()
    if hit.any():
        idx = raw.loc[m].index[hit]
        raw.loc[idx, "attr_user"] = fallback_user[hit].values
        raw.loc[idx, "attr_method"] = f"A1b_sysmon_processguid_fallback_eid{eid}"
        n_fixed += int(hit.sum())

raw["attr_user"] = strip_domain(raw["attr_user"])  # re-normalize after any new fills
print(f"Sysmon events recovered via ProcessGuid fallback (direct field was empty): {n_fixed:,}")
print(f"Tier A (direct + ProcessGuid fallback) coverage now: "
      f"{raw.attr_user.notna().sum():,} / {len(raw):,}  ({raw.attr_user.notna().mean():.1%})")
```

::: {.output .stream .stdout}
    ProcessGuid -> user lookup built from 40,712 anchored Sysmon Event 1 rows.
    Sysmon events recovered via ProcessGuid fallback (direct field was empty): 0
    Tier A (direct + ProcessGuid fallback) coverage now: 477,377 / 811,088  (58.9%)
:::
:::

::: {#4f5c1407 .cell .markdown}

------------------------------------------------------------------------

## 08. Security / Sysmon Correlation {#08-security--sysmon-correlation}

### 8.1 The logon-session table (Security 4624) {#81-the-logon-session-table-security-4624}

The prompt asks for a `Username + LogonId + Computer + Timestamp`
session map, and for Sysmon Event 1 to be tied back to it through
`LogonId + Computer + time`. We build that map - and then we
**validate** it rather than trusting it: Sysmon Event 1 already carries
an independent `User` field, so the two can be compared. The agreement
rate is reported below and is the evidence for how far a LogonId-based
join can be trusted in this dataset.

### 8.2 The process-lifetime table (the route that actually earns its keep) {#82-the-process-lifetime-table-the-route-that-actually-earns-its-keep}

Sysmon 1 (start) and Sysmon 5 (exit) bound each process\'s lifetime.
Keyed by `(Computer, PID)` that gives an interval table which can
attribute Security **5156** - 41% of the corpus and the only source that
records *which* process opened a connection on the Security channel.

PID reuse is handled by requiring the 5156 timestamp to fall inside the
interval; a 5156 whose PID belongs to a process the sensor never saw
start (long-running services present before logging began) is left
unattributed rather than guessed.
:::

::: {#9bf751b2 .cell .code execution_count="11" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:27.690721Z\",\"iopub.status.busy\":\"2026-08-25T08:59:27.690320Z\",\"iopub.status.idle\":\"2026-08-25T08:59:28.292438Z\",\"shell.execute_reply\":\"2026-08-25T08:59:28.291065Z\"}"}
``` python
# ---- 8.1 logon sessions ----------------------------------------------------------
sess = raw[raw.EventID == 4624][
    ["ts", "Computer", "TargetUserName", "TargetDomainName", "TargetLogonId",
     "LogonType", "LogonGuid", "IpAddress", "WorkstationName", "ProcessName"]].copy()
sess["user"] = strip_domain(sess.TargetUserName)
sess = sess.rename(columns={"TargetLogonId": "logon_id", "ts": "logon_time"})
print(f"logon sessions (4624): {len(sess):,}   distinct LogonIds: {sess.logon_id.nunique():,}")
print(sess.LogonType.value_counts().rename("count").to_frame().T.to_string())

# A LogonId is reused across many 4624 records (0x3e7 is SYSTEM on every host, forever), so the
# session table is first collapsed to one row per (Computer, LogonId) - which also measures how
# often that key is ambiguous, i.e. maps to more than one account.
sess_key = (sess.groupby(["Computer", "logon_id"])
              .agg(n_users=("user", "nunique"), user=("user", "first"),
                   first_logon=("logon_time", "min"), n_logons=("user", "size"))
              .reset_index())
ambiguous = int((sess_key.n_users > 1).sum())
print(f"\ndistinct (Computer, LogonId) session keys: {len(sess_key):,}")
print(f"  keys that map to more than one account  : {ambiguous} "
      f"({ambiguous / len(sess_key):.2%})  <- the ceiling on this correlation's precision")

# ---- validate a LogonId-based join against Sysmon-1's own User field -------------
s1 = raw[raw.EventID == 1][["ts", "Computer", "LogonId", "User", "ProcessGuid"]].copy()
s1["user_direct"] = strip_domain(s1.User)
j = s1.merge(sess_key[["Computer", "logon_id", "user", "first_logon", "n_users"]],
             left_on=["Computer", "LogonId"], right_on=["Computer", "logon_id"], how="left")
j = j[j.user.notna() & (j.first_logon <= j.ts)]     # the session must precede the process
agree = (j.user == j.user_direct).mean()
print()
print("VALIDATION of the LogonId + Computer + time correlation, against Sysmon-1's own User field")
print(f"  Sysmon-1 events joinable to a 4624 session : {len(j):,} / {len(s1):,} "
      f"({len(j) / len(s1):.1%})")
print(f"  agreement with the direct User field       : {agree:.2%}")
print(f"  disagreements                              : {int((j.user != j.user_direct).sum()):,}")
print("  -> the correlation is sound, but the direct User field is present on 100% of Sysmon")
print("     events and is strictly better, so it is preferred for attribution. The session table")
print("     is retained for authentication features (source IP, logon type, workstation).")
del s1, j
```

::: {.output .stream .stdout}
    logon sessions (4624): 48,546   distinct LogonIds: 31,624
    LogonType      3      5   10    2   7
    count      30300  16846  799  522  79

    distinct (Computer, LogonId) session keys: 31,657
      keys that map to more than one account  : 0 (0.00%)  <- the ceiling on this correlation's precision

    VALIDATION of the LogonId + Computer + time correlation, against Sysmon-1's own User field
      Sysmon-1 events joinable to a 4624 session : 40,433 / 40,712 (99.3%)
      agreement with the direct User field       : 100.00%
      disagreements                              : 0
      -> the correlation is sound, but the direct User field is present on 100% of Sysmon
         events and is strictly better, so it is preferred for attribution. The session table
         is retained for authentication features (source IP, logon type, workstation).
:::
:::

::: {#0c6d208e .cell .code execution_count="12" execution="{\"iopub.execute_input\":\"2026-08-25T08:59:28.297018Z\",\"iopub.status.busy\":\"2026-08-25T08:59:28.296611Z\",\"iopub.status.idle\":\"2026-08-25T09:00:33.209589Z\",\"shell.execute_reply\":\"2026-08-25T09:00:33.208260Z\"}"}
``` python
# ---- 8.2 process-lifetime table --------------------------------------------------
starts = raw[raw.EventID == 1][["ts_utc", "Computer", "ProcessId", "ProcessGuid",
                                "Image", "attr_user"]].copy()
ends = raw[raw.EventID == 5][["ts_utc", "ProcessGuid"]].rename(columns={"ts_utc": "proc_end"})
proc = starts.merge(ends, on="ProcessGuid", how="left")
n_open = int(proc.proc_end.isna().sum())
proc["proc_end"] = proc.proc_end.fillna(raw.ts_utc.max() + pd.Timedelta("1h"))
proc["pid"] = pd.to_numeric(proc.ProcessId, errors="coerce")
proc = proc.dropna(subset=["pid"])
proc["pid"] = proc.pid.astype("int64")
proc["key"] = proc.Computer.astype(str) + "|" + proc.pid.astype(str)
proc = proc.sort_values("ts_utc")
print(f"process lifetime rows: {len(proc):,}  ({n_open:,} still running at end of capture)")

lifetimes = {k: g[["ts_utc", "proc_end", "attr_user", "Image"]].to_numpy()
             for k, g in proc.groupby("key")}

fw_idx = raw.index[raw.EventID == 5156]
fw_pid = pd.to_numeric(raw.loc[fw_idx, "ProcessID"], errors="coerce")
fw_key = raw.loc[fw_idx, "Computer"].astype(str) + "|" + fw_pid.astype("Int64").astype(str)
fw_ts  = raw.loc[fw_idx, "ts_utc"].to_numpy()

res_u, res_img = [], []
for k, t in zip(fw_key.to_numpy(), fw_ts):
    g = lifetimes.get(k)
    u = im = None
    if g is not None:
        for st, en, us, gim in g:
            if st <= t <= en:
                u, im = us, gim
                break
    res_u.append(u); res_img.append(im)

raw.loc[fw_idx, "attr_user"]   = pd.array(res_u, dtype="string")
raw.loc[fw_idx, "attr_method"] = np.where(pd.notna(res_u), "B_5156_proc_lifetime", pd.NA)
raw.loc[fw_idx, "Image"]       = pd.array(res_img, dtype="string")

n_fw = len(fw_idx); n_ok = int(pd.notna(res_u).sum())
print(f"5156 events attributed via process lifetime: {n_ok:,} / {n_fw:,}  ({n_ok/n_fw:.1%})")
```

::: {.output .stream .stdout}
    process lifetime rows: 40,712  (209 still running at end of capture)
    5156 events attributed via process lifetime: 13,430 / 333,711  (4.0%)
:::
:::

::: {#48bd1d15 .cell .markdown}
### 8.3 Attribution report and the events that could **not** be attributed {#83-attribution-report-and-the-events-that-could-not-be-attributed}

Everything that follows is driven by this table. Read the warnings -
they are the honest limits of the system, not footnotes.
:::

::: {#ca10efb3 .cell .code execution_count="13" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:33.213246Z\",\"iopub.status.busy\":\"2026-08-25T09:00:33.212872Z\",\"iopub.status.idle\":\"2026-08-25T09:00:34.490452Z\",\"shell.execute_reply\":\"2026-08-25T09:00:34.489174Z\"}"}
``` python
raw["attr_method"] = raw.attr_method.fillna("C_unattributed")
report = (raw.groupby("attr_method")
             .agg(events=("EventID", "size"),
                  event_ids=("EventID", lambda s: ", ".join(map(str, sorted(s.unique())[:12]))))
             .sort_values("events", ascending=False))
report["pct"] = (report.events / len(raw)).map(lambda v: f"{v:.1%}")
display(report[["events", "pct", "event_ids"]])

un = raw[raw.attr_method == "C_unattributed"]
print()
print("=" * 88)
print("WARNINGS - events that cannot be confidently attributed (excluded from every baseline)")
print("=" * 88)
for eid, n in un.EventID.value_counts().items():
    ex = un[un.EventID == eid]
    why = ("no identity field on the event AND the owning PID belongs to a process the Sysmon "
           "sensor never saw start (long-running service)" if eid == 5156 else
           "no usable actor field present")
    print(f"\nEventID {eid} - {n:,} events ({EVENT_MEANING.get(eid,'?')})")
    print(textwrap.fill(f"reason: {why}", 86, initial_indent="  ", subsequent_indent="          "))
    if eid == 5156:
        apps = ex.Application.fillna("-").str.rsplit(BS, n=1).str[-1].value_counts().head(5)
        print("  dominant applications: " + ", ".join(f"{k} ({v:,})" for k, v in apps.items()))
        print("  impact: these are almost entirely lsass/svchost/dns/System traffic, i.e. machine")
        print(f"          rather than user behaviour. All {n_ok:,} connections opened by a process the")
        print("          Sysmon sensor did observe were attributed successfully.")
```

```
:::

::: {.output .stream .stdout}

    ========================================================================================
    WARNINGS - events that cannot be confidently attributed (excluded from every baseline)
    ========================================================================================

    EventID 5156 - 320,281 events (Filtering platform allowed a connection)
      reason: no identity field on the event AND the owning PID belongs to a process the
              Sysmon sensor never saw start (long-running service)
      dominant applications: lsass.exe (157,259), svchost.exe (64,044), System (55,515), dns.exe (43,340), chrome.exe (71)
      impact: these are almost entirely lsass/svchost/dns/System traffic, i.e. machine
              rather than user behaviour. All 13,430 connections opened by a process the
              Sysmon sensor did observe were attributed successfully.
:::
:::

::: {#85ff907d .cell .markdown}

------------------------------------------------------------------------

## 09. Data Cleaning & Principal Scoping {#09-data-cleaning--principal-scoping}

Not every attributed string is a *person-like* principal worth
baselining. Machine accounts (`PC-003$`), built-in service identities
(`SYSTEM`, `LOCAL SERVICE`, `NETWORK SERVICE`), and `ANONYMOUS LOGON`
produce enormous, machine-driven volumes that would swamp the user model
and generate noise alerts.

They are **kept in the event table** (so they can be inspected) but are
**not scored**. The exclusion is listed explicitly below rather than
being applied silently.

A second filter removes principals whose 7 baseline days contain too few
events to support 24 hourly profiles - scoring them would be scoring
noise.
:::

::: {#2a6bd1b9 .cell .code execution_count="14" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:34.493936Z\",\"iopub.status.busy\":\"2026-08-25T09:00:34.493585Z\",\"iopub.status.idle\":\"2026-08-25T09:00:36.387683Z\",\"shell.execute_reply\":\"2026-08-25T09:00:36.385766Z\"}"}
``` python
BUILTIN = {"SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "ANONYMOUS LOGON", "-",
           "IUSR", "MSSQLSERVER"}


def is_person_like(u):
    if pd.isna(u):
        return False
    u = str(u)
    if u in BUILTIN or u.endswith("$") or u.startswith("DWM-") or u.startswith("UMFD-"):
        return False
    return True


raw["in_scope"] = raw.attr_user.map(is_person_like)
scoped_all = raw[raw.in_scope]
tr_counts = scoped_all[scoped_all.date.isin(TRAIN_DATES)].groupby("attr_user").size()
PRINCIPALS = sorted(tr_counts[tr_counts >= MIN_TRAIN_EVENTS].index)
LOW_DATA = sorted(set(scoped_all.attr_user.unique()) - set(PRINCIPALS))

excluded = raw[raw.attr_user.notna() & ~raw.in_scope].attr_user.value_counts()
print("excluded non-person principals (kept in the event table, never scored)")
for u, n in excluded.head(14).items():
    print(f"  {u:22s} {n:>8,}")
print()
print(f"BASELINED PRINCIPALS ({len(PRINCIPALS)}):")
for u in PRINCIPALS:
    print(f"  {u:16s} {tr_counts[u]:>6,} training events")
print()
print("WARNING - principals with insufficient baseline data (reported, not scored):")
for u in LOW_DATA:
    n = int(tr_counts.get(u, 0))
    tot = int((scoped_all.attr_user == u).sum())
    print(f"  {u:16s} {n:>4} training events / {tot:>4} total  -> no reliable user x hour baseline")
print()
print("  These are stale or service accounts that appear almost exclusively as failed-authentication")
print("  targets. Activity from them is surfaced in the section-22 'unbaselined principals' table")
print("  instead of being forced into a model that cannot support it.")
```

::: {.output .stream .stdout}
    excluded non-person principals (kept in the event table, never scored)
      SYSTEM                  205,568
      NETWORK SERVICE          33,163
      LOCAL SERVICE            27,988
      SQL-01$                  17,991
      FILE-01$                 16,562
      ANONYMOUS LOGON          16,262
      APP-01$                  12,502
      PC-004$                  10,759
      PC-003$                  10,717
      PC-006$                  10,706
      PC-001$                  10,245
      PC-002$                  10,188
      PC-005$                   9,701
      PC-008$                   9,496

    BASELINED PRINCIPALS (8):
      alice.smith       3,095 training events
      bob.miller        2,690 training events
      charlie.brown     5,524 training events
      diana.prince      7,092 training events
      ethan.hayes       8,798 training events
      frank.dsouza      2,745 training events
      grace.lin         2,859 training events
      nina.kapoor       8,055 training events

    WARNING - principals with insufficient baseline data (reported, not scored):
      carla.nunez        52 training events /   93 total  -> no reliable user x hour baseline
      svc-print-old      64 training events /  100 total  -> no reliable user x hour baseline
      svc_backup        108 training events /  216 total  -> no reliable user x hour baseline
      svc_mgmt           16 training events /   28 total  -> no reliable user x hour baseline

      These are stale or service accounts that appear almost exclusively as failed-authentication
      targets. Activity from them is surfaced in the section-22 'unbaselined principals' table
      instead of being forced into a model that cannot support it.
:::
:::

::: {#74fe6335 .cell .markdown}
### 9.2 The normalised event table {#92-the-normalised-event-table}

One row per attributed event, with the heterogeneous Security/Sysmon
fields folded into a single behavioural schema. This is the table every
later stage reads.
:::

::: {#fc95b027 .cell .code execution_count="15" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:36.392203Z\",\"iopub.status.busy\":\"2026-08-25T09:00:36.391622Z\",\"iopub.status.idle\":\"2026-08-25T09:00:37.176200Z\",\"shell.execute_reply\":\"2026-08-25T09:00:37.174402Z\"}"}
``` python
ev = raw[raw.in_scope & raw.attr_user.isin(PRINCIPALS)].copy()
ev["user"] = ev.attr_user.astype(str)


def low(s):  return s.astype("string").str.lower()

# ---- process identity ------------------------------------------------------------
ev["image"] = low(ev["Image"])
# 5156 reports "\device\harddiskvolumeN\..." - fold onto a normal drive path
_DEV_RE = re.compile("^" + re.escape(BS) + "device" + re.escape(BS) +
                     r"harddiskvolume\d+" + re.escape(BS))
_umap = {u: _DEV_RE.sub(lambda m: "c:" + BS, u) for u in ev["image"].dropna().unique()}
ev["image"] = ev["image"].map(_umap).astype("string")
_m810 = ev.EventID.isin([8, 10])
ev.loc[_m810, "image"] = low(ev.loc[_m810, "SourceImage"])
ev["image_base"]   = ev["image"].str.rsplit(BS, n=1).str[-1]
ev["parent_image"] = low(ev["ParentImage"])
ev["parent_base"]  = ev["parent_image"].str.rsplit(BS, n=1).str[-1]
ev["pair"]         = ev["parent_base"].fillna("") + ">" + ev["image_base"].fillna("")
ev["cmd_low"]      = low(ev["CommandLine"])

# ---- network ---------------------------------------------------------------------
ev["dst_ip"]   = ev["DestinationIp"].astype("string")
ev["dst_port"] = pd.to_numeric(ev["DestinationPort"], errors="coerce")
_m5156 = ev.EventID == 5156
ev.loc[_m5156, "dst_ip"]   = ev.loc[_m5156, "DestAddress"].astype("string")
ev.loc[_m5156, "dst_port"] = pd.to_numeric(ev.loc[_m5156, "DestPort"], errors="coerce")

# ---- authentication ---------------------------------------------------------------
def clean_ip(s):
    s = s.astype("string").str.replace("::ffff:", "", regex=False)
    return s.where(~s.isin(["-", "::1", "127.0.0.1", "0.0.0.0"]), pd.NA)

ev["src_ip"]      = clean_ip(ev["IpAddress"])
ev["logon_type"]  = pd.to_numeric(ev["LogonType"], errors="coerce")
ev["workstation"] = ev["WorkstationName"].astype("string").where(lambda s: s != "-", pd.NA)
ev["computer"]    = ev["Computer"].astype("string").str.replace(".corp.local", "", regex=False)

# ---- DNS --------------------------------------------------------------------------
ev["domain"] = low(ev["QueryName"])

def registrable(d):
    """Reverse-lookup PTRs are per-connection noise; everything else folds to eTLD+1-ish."""
    if pd.isna(d):
        return pd.NA
    d = str(d)
    if d.endswith(".in-addr.arpa") or d.endswith(".ip6.arpa"):
        return pd.NA
    p = d.strip(".").split(".")
    if len(p) <= 2:
        return d
    if p[-2] in ("co", "com", "net", "org", "gov", "ac") and len(p[-1]) == 2:
        return ".".join(p[-3:])
    return ".".join(p[-2:])

ev["reg_domain"] = ev["domain"].map(registrable)

# ---- file / registry ---------------------------------------------------------------
ev["target_file"] = low(ev["TargetFilename"])
ev["reg_path"]    = low(ev["TargetObject"])

EVENT_TABLE_COLS = ["ts", "date", "hour", "win", "EventID", "Channel", "computer", "user",
                    "attr_method", "logon_type", "src_ip", "workstation", "image", "parent_image",
                    "cmd_low", "dst_ip", "dst_port", "domain", "reg_domain", "target_file", "reg_path"]
print(f"normalised, attributed event table: {len(ev):,} rows x {ev.shape[1]} columns")
print(ev.groupby("user").size().rename("events").to_frame().T.to_string())
ev[EVENT_TABLE_COLS].head(6)
```

::: {.output .stream .stdout}
    normalised, attributed event table: 79,268 rows x 112 columns
    user    alice.smith  bob.miller  charlie.brown  diana.prince  ethan.hayes  frank.dsouza  grace.lin  nina.kapoor
    events         5960        4653          10588         14938        16265          5590       5845        15429
:::

::

------------------------------------------------------------------------

## 10. 10-Minute Window Generation {#10-10-minute-window-generation}

The grid is built by **cross product**, not by grouping the events.
Every principal gets every 10-minute window of every configured UTC day,
whether or not anything happened in it:

    8 principals x 13 days x 144 windows = 14,976 rows

Windows with no events keep a full zero feature vector. This is the
requirement from section 4 of the brief - *inactivity is part of the
behavioural pattern*, and dropping quiet windows would make \"the user
was busy at 03:00\" indistinguishable from \"the user is always busy\".

**The one exception** is the windows section 06 flagged as outside the
sensor\'s capture range. A zero there means \"no log was being
written\", not \"the user did nothing\", so those rows are marked
`has_telemetry = False` and skipped by the baseline and the scorer. They
stay in the frame so the omission is visible rather than silent.

Because the capture starts at 18:30 on the first configured day, UTC
hours 00-17 get one baseline day fewer than hours 19-23. The table below
reports the real observation count for every `user x hour` cell instead
of assuming a flat 42.
:::

::: {#0b7404e9 .cell .code execution_count="16" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:37.180755Z\",\"iopub.status.busy\":\"2026-08-25T09:00:37.180207Z\",\"iopub.status.idle\":\"2026-08-25T09:00:37.407435Z\",\"shell.execute_reply\":\"2026-08-25T09:00:37.405089Z\"}"}
``` python
# Every 10-minute window of every configured day, for every principal - built by cross
# product so that quiet windows exist by construction and cannot be lost by a groupby.
window_index = pd.date_range(pd.Timestamp(ALL_DATES[0] + " 00:00", tz=TZ),
                             pd.Timestamp(ALL_DATES[-1] + " 23:50", tz=TZ),
                             freq=WINDOW, tz=TZ)
grid = (pd.MultiIndex.from_product([PRINCIPALS, window_index], names=["user", "win"])
          .to_frame(index=False))
grid["date"]          = grid.win.dt.strftime("%Y-%m-%d")   # UTC date
grid["hour"]          = grid.win.dt.hour                   # UTC hour 0..23
grid["slot"]          = grid.win.dt.minute // 10           # which of the 6 windows in the hour
grid["is_train"]      = grid.date.isin(TRAIN_DATES)
grid["has_telemetry"] = ((grid.win >= CAPTURE_START) & (grid.win < CAPTURE_END)).astype(bool)

print(f"grid: {len(grid):,} rows = {len(PRINCIPALS)} principals "
      f"x {len(ALL_DATES)} days x {WINDOWS_PER_DAY} windows")

# structural check: 6 windows in every hour of every day, always
chk = grid.groupby(["user", "date", "hour"]).size()
assert chk.eq(WINDOWS_PER_HOUR).all(), "every user-day-hour must contain exactly 6 windows"
print(f"windows per user-day-hour : {sorted(int(v) for v in chk.unique())}  (required: [{WINDOWS_PER_HOUR}])")

n_cov = int(grid.has_telemetry.sum())
print(f"windows with sensor coverage : {n_cov:,}  "
      f"({n_cov / len(grid):.1%});  without: {len(grid) - n_cov:,}")

# how many usable baseline observations each user x hour cell actually has
obs = (grid[grid.is_train & grid.has_telemetry]
       .groupby(["user", "hour"]).size().rename("n_obs").reset_index())
print(f"user x hour baseline cells   : {len(obs)} (= {len(PRINCIPALS)} users x 24 hours)")
print(f"observations per cell        : {sorted(int(v) for v in obs.n_obs.unique())}")
print()
print("OBSERVATIONS PER user x hour BASELINE CELL (identical for every principal, so one row shown)")
tbl = (obs[obs.user == PRINCIPALS[0]].set_index("hour")[["n_obs"]].T)
tbl.index = ["baseline observations"]
display(tbl)
print("hours 19-23 get all 7 configured days (42 = 6 windows x 7 days);")
print("hours 00-17 get 6 days (36) and hour 18 gets 6 days plus the 3 windows after 18:30 (39),")
print("because the sensor only starts at 18:30 on the first configured day.")
```

::: {.output .stream .stdout}
    grid: 14,976 rows = 8 principals x 13 days x 144 windows
    windows per user-day-hour : [6]  (required: [6])
    windows with sensor coverage : 13,824  (92.3%);  without: 1,152
    user x hour baseline cells   : 192 (= 8 users x 24 hours)
    observations per cell        : [36, 39, 42]

    OBSERVATIONS PER user x hour BASELINE CELL (identical for every principal, so one row shown)
:::


::: {.output .stream .stdout}
    hours 19-23 get all 7 configured days (42 = 6 windows x 7 days);
    hours 00-17 get 6 days (36) and hour 18 gets 6 days plus the 3 windows after 18:30 (39),
    because the sensor only starts at 18:30 on the first configured day.
:::
:::

::: {#fb0cd99f .cell .markdown}

------------------------------------------------------------------------

## 11. Feature Engineering {#11-feature-engineering}

Two products come out of this section.

**(a) 71 numeric window features**, every one of them declared in a
single **feature registry** in the next cell. Each entry states the
feature\'s name, what it measures in plain English, and the exact rule
that computes it. The registry is printed as a table, so there is never
a question of where a feature came from. Adding a feature later means
adding one line to that registry - aggregation, validation, the
baseline, scoring and the explanations all read it.

**(b) 11 categorical behaviour dimensions.** Counts alone cannot express
*what* a user does. These sets capture identity: which executables,
which parent-\>child relationships, which invocation styles, which
authentication paths, which destinations.

### The process taxonomy

The tool classes below are generic Windows security knowledge (LOLBins,
discovery utilities, admin tooling, script hosts), not signatures
derived from this scenario\'s ground truth. They give the model a way to
say \"this user started running *a class of tool* they never ran
before\" instead of only \"they ran one more process than usual\".

### Command-line signature

For shells and LOLBins, *how* a binary is invoked is behaviour.
`powershell.exe -NoProfile -Command ...` and
`powershell.exe -ExecutionPolicy Bypass -File ...` are different habits.
The signature keeps the flag sequence up to the first content-carrying
switch and discards all argument values, so it stays stable while
staying discriminative. GUI applications are excluded - their command
lines are pure churn (URLs, file paths).
:::

::: {#c3aa8385 .cell .code execution_count="17" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:37.413427Z\",\"iopub.status.busy\":\"2026-08-25T09:00:37.412724Z\",\"iopub.status.idle\":\"2026-08-25T09:00:37.939318Z\",\"shell.execute_reply\":\"2026-08-25T09:00:37.937863Z\"}"}
``` python
# =====================================================================================
# 11.1  PROCESS TAXONOMY
# Generic Windows security knowledge (LOLBins, discovery utilities, admin tooling,
# script hosts). None of it is derived from this scenario's ground truth.
# =====================================================================================
SHELLS       = {"powershell.exe", "pwsh.exe", "cmd.exe"}
SCRIPT_HOSTS = {"wscript.exe", "cscript.exe", "mshta.exe", "jscript.exe"}
DISCOVERY    = {"whoami.exe", "systeminfo.exe", "net.exe", "net1.exe", "nltest.exe", "dsquery.exe",
                "nbtstat.exe", "arp.exe", "route.exe", "quser.exe", "qwinsta.exe", "tasklist.exe",
                "netstat.exe", "ipconfig.exe", "hostname.exe", "wmic.exe", "setspn.exe", "adfind.exe"}
LOLBIN       = {"certutil.exe", "bitsadmin.exe", "regsvr32.exe", "rundll32.exe", "mshta.exe",
                "installutil.exe", "msbuild.exe", "cmstp.exe", "odbcconf.exe", "wmic.exe",
                "forfiles.exe", "pcalua.exe", "msiexec.exe", "curl.exe", "wget.exe",
                "esentutl.exe", "expand.exe", "extrac32.exe"}
ADMIN_TOOL   = {"sc.exe", "schtasks.exe", "at.exe", "reg.exe", "wevtutil.exe", "vssadmin.exe",
                "bcdedit.exe", "wbadmin.exe", "netsh.exe", "takeown.exe", "icacls.exe", "cacls.exe",
                "gpupdate.exe", "dsadd.exe", "ntdsutil.exe"}
REMOTE_EXEC  = {"psexec.exe", "psexec64.exe", "paexec.exe", "winrs.exe", "wmic.exe", "mstsc.exe",
                "putty.exe", "ssh.exe", "plink.exe"}
TRANSFER     = {"robocopy.exe", "xcopy.exe", "certutil.exe", "curl.exe", "wget.exe", "ftp.exe",
                "7z.exe", "winrar.exe", "rar.exe", "makecab.exe"}
SCRIPT_LOLBIN  = SHELLS | SCRIPT_HOSTS | LOLBIN | DISCOVERY | ADMIN_TOOL | TRANSFER
REMOTE_PARENTS = {"svchost.exe", "services.exe", "wmiprvse.exe", "winrshost.exe",
                  "wsmprovhost.exe", "psexesvc.exe", "taskeng.exe", "schtasks.exe"}

ARCHIVE_EXT = (".zip", ".rar", ".7z", ".tar", ".gz", ".cab", ".b64")
SCRIPT_EXT  = (".ps1", ".vbs", ".js", ".bat", ".cmd", ".hta", ".psm1", ".wsf")
EXE_EXT     = (".exe", ".dll", ".sys", ".scr", ".com")
SENSITIVE_PORTS = {135, 139, 445, 1433, 3306, 5432, 3389, 5985, 5986, 22, 23, 21, 5900}
PRIV_PAT = r"^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|127\.)"

# ---- event-class masks (reused by the registry and by the categorical dimensions) ----
ev["is_proc"]    = ev.EventID == 1            # Sysmon process create
ev["is_net"]     = ev.EventID.isin([3, 5156]) # Sysmon network connect + attributed 5156
ev["is_dns"]     = ev.EventID == 22           # Sysmon DNS query
ev["is_file"]    = ev.EventID == 11           # Sysmon file create
ev["is_reg"]     = ev.EventID.isin([12, 13, 14])
ev["is_imgload"] = ev.EventID == 7
ev["is_pacc"]    = ev.EventID == 10           # Sysmon process access
ev["is_rthread"] = ev.EventID == 8            # Sysmon CreateRemoteThread
ev["f_logon_ok"] = ev.EventID == 4624

# ---- shorthand columns the rules below read -----------------------------------------
ib  = ev["image_base"].fillna("")
pb  = ev["parent_base"].fillna("")
cl  = ev["cmd_low"].fillna("")
tf  = ev["target_file"].fillna("")
rp  = ev["reg_path"].fillna("")
ti  = ev["TargetImage"].fillna("").str.lower()
ALL = pd.Series(True, index=ev.index)
ev["dst_pair"]    = ev["dst_ip"].fillna("") + ":" + ev["dst_port"].astype("Int64").astype("string").fillna("")
ev["dst_port_s"]  = ev["dst_port"].astype("Int64").astype("string")
ev["logon_type_s"] = ev["logon_type"].astype("Int64").astype("string")
is_ext_dst = ev["dst_ip"].notna() & ~ev["dst_ip"].fillna("").str.match(PRIV_PAT)
is_ext_src = ev["src_ip"].notna() & ~ev["src_ip"].fillna("").str.match(PRIV_PAT)
is_sens_pt = ev["dst_port"].isin(SENSITIVE_PORTS)
is_script  = ib.isin(SCRIPT_LOLBIN)

# =====================================================================================
# 11.2  THE FEATURE REGISTRY  <-- this is where every window feature is defined
#
# One line per feature. Nothing is computed anywhere else, and nothing is derived
# from a name prefix, so "where does <feature> come from?" is answered by the table
# printed at the bottom of this cell.
#
#   count(...)  the feature is HOW MANY events in the window match `mask`
#   unique(...) the feature is HOW MANY DISTINCT values of `value` those events show
#
# To add a feature later, add one line here. Aggregation (11.3), validation (12),
# the baseline (14), scoring (16-18) and the explanations (19) all read this registry.
# =====================================================================================
FEATURE_REGISTRY = []


def count(name, group, meaning, how, mask):
    ev["_m_" + name] = mask.fillna(False).to_numpy(dtype=bool)
    FEATURE_REGISTRY.append(dict(feature=name, group=group, meaning=meaning,
                                 computed_from=how, kind="count"))


def unique(name, group, meaning, how, mask, value):
    ev["_m_" + name] = mask.fillna(False).to_numpy(dtype=bool)
    FEATURE_REGISTRY.append(dict(feature=name, group=group, meaning=meaning,
                                 computed_from=how, kind="unique", value=value))


# ---------------------------------------------------------------------- volume -------
count("event_count", "volume", "total events",
      "every attributed event in the window", ALL)

# --------------------------------------------------------------------- process -------
count("proc_count", "process", "process creations", "Sysmon 1", ev.is_proc)
count("ps_count", "process", "PowerShell launches",
      "Sysmon 1, image in {powershell.exe, pwsh.exe}", ev.is_proc & ib.isin({"powershell.exe", "pwsh.exe"}))
count("cmd_count", "process", "cmd.exe launches",
      "Sysmon 1, image = cmd.exe", ev.is_proc & (ib == "cmd.exe"))
count("scripthost_count", "process", "script-host launches",
      "Sysmon 1, image in SCRIPT_HOSTS (wscript/cscript/mshta)", ev.is_proc & ib.isin(SCRIPT_HOSTS))
count("discovery_count", "process", "discovery-tool executions",
      "Sysmon 1, image in DISCOVERY (whoami/net/nltest/systeminfo/wmic/...)",
      ev.is_proc & ib.isin(DISCOVERY))
count("lolbin_count", "process", "LOLBin executions",
      "Sysmon 1, image in LOLBIN (certutil/rundll32/regsvr32/bitsadmin/...)",
      ev.is_proc & ib.isin(LOLBIN))
count("admin_count", "process", "administrative-tool executions",
      "Sysmon 1, image in ADMIN_TOOL (sc/schtasks/reg/wevtutil/vssadmin/...)",
      ev.is_proc & ib.isin(ADMIN_TOOL))
count("remoteexec_count", "process", "remote-execution tool executions",
      "Sysmon 1, image in REMOTE_EXEC (mstsc/psexec/winrs/ssh/...)", ev.is_proc & ib.isin(REMOTE_EXEC))
count("transfer_count", "process", "file-transfer tool executions",
      "Sysmon 1, image in TRANSFER (robocopy/certutil/curl/7z/...)", ev.is_proc & ib.isin(TRANSFER))
count("temp_proc_count", "process", "processes started from a temp/appdata path",
      "Sysmon 1, image path contains \\temp\\ or \\appdata\\",
      ev.is_proc & ev["image"].fillna("").str.contains(
          "(?:" + re.escape(BS) + "temp" + re.escape(BS) + "|" + re.escape(BS) + "appdata" +
          re.escape(BS) + ")", regex=True))
count("encoded_count", "process", "encoded command lines",
      "Sysmon 1, command line matches -enc / encodedcommand / frombase64",
      ev.is_proc & cl.str.contains(r"-enc|frombase64|encodedcommand", regex=True))
count("hidden_ps_count", "process", "PowerShell run with -NoProfile or a hidden window",
      "Sysmon 1, command line matches -noprofile / -nop / -w hidden / -windowstyle hidden",
      ev.is_proc & cl.str.contains(r"-w\s+hidden|-windowstyle\s+hidden|-noprofile|-nop\b", regex=True))
count("remote_spawn_count", "process", "shells spawned by a service/WMI parent (remote execution)",
      "Sysmon 1, parent in REMOTE_PARENTS and image in the script/LOLBin set",
      ev.is_proc & pb.isin(REMOTE_PARENTS) & is_script)
unique("proc_unique", "process", "distinct executables",
       "Sysmon 1, distinct full image path", ev.is_proc, "image")
unique("parent_unique", "process", "distinct parent processes",
       "Sysmon 1, distinct parent image path", ev.is_proc, "parent_image")
unique("pair_unique", "process", "distinct parent->child pairs",
       "Sysmon 1, distinct parent_base>image_base", ev.is_proc, "pair")

# --------------------------------------------------------------------- network -------
count("net_conn_count", "network", "network connections",
      "Sysmon 3 plus Security 5156 attributed by process lifetime", ev.is_net)
count("ext_dst_count", "network", "connections to external (public) addresses",
      "network event whose destination is outside RFC1918", ev.is_net & is_ext_dst)
count("sens_port_count", "network", "connections to infrastructure ports",
      "network event whose destination port is in SENSITIVE_PORTS (445/3389/1433/5985/...)",
      ev.is_net & is_sens_pt)
count("script_net_count", "network", "connections made by a shell or LOLBin",
      "network event whose initiating image is in the script/LOLBin set", ev.is_net & is_script)
count("script_ext_net_count", "network", "shell/LOLBin connections to external addresses",
      "script_net AND destination outside RFC1918", ev.is_net & is_script & is_ext_dst)
count("script_sens_port_count", "network", "shell/LOLBin connections to infrastructure ports",
      "script_net AND destination port in SENSITIVE_PORTS", ev.is_net & is_script & is_sens_pt)
unique("dst_ip_unique", "network", "distinct destination IPs",
       "network events, distinct destination address", ev.is_net, "dst_ip")
unique("dst_port_unique", "network", "distinct destination ports",
       "network events, distinct destination port", ev.is_net, "dst_port")
unique("dst_pair_unique", "network", "distinct destination IP:port pairs",
       "network events, distinct address:port", ev.is_net, "dst_pair")

# ------------------------------------------------------------------------- dns -------
count("dns_count", "dns", "DNS queries", "Sysmon 22", ev.is_dns)
count("srv_lookup_count", "dns", "SRV record lookups",
      "Sysmon 22 where the query name starts with _", ev.is_dns & ev["domain"].fillna("").str.startswith("_"))
count("dns_fail_count", "dns", "DNS queries that failed to resolve",
      "Sysmon 22 with a non-zero QueryStatus",
      ev.is_dns & (pd.to_numeric(ev["QueryStatus"], errors="coerce").fillna(0) != 0))
unique("domain_unique", "dns", "distinct DNS domains",
       "Sysmon 22, distinct registrable domain (PTR lookups excluded)", ev.is_dns, "reg_domain")

# ------------------------------------------------------------------------ file -------
count("file_create_count", "file", "files created", "Sysmon 11", ev.is_file)
count("exe_create_count", "file", "executables or DLLs created",
      "Sysmon 11 with an .exe/.dll/.sys/.scr/.com target", ev.is_file & tf.str.endswith(EXE_EXT))
count("script_create_count", "file", "script files created",
      "Sysmon 11 with a .ps1/.vbs/.js/.bat/.cmd/.hta target", ev.is_file & tf.str.endswith(SCRIPT_EXT))
count("archive_create_count", "file", "archive files created",
      "Sysmon 11 with a .zip/.rar/.7z/.tar/.gz/.cab/.b64 target",
      ev.is_file & tf.str.endswith(ARCHIVE_EXT))
count("temp_create_count", "file", "files created under a temp path",
      "Sysmon 11 whose target path contains \\temp\\",
      ev.is_file & tf.str.contains(re.escape(BS) + "temp" + re.escape(BS), regex=True))

# -------------------------------------------------------------------- registry -------
count("reg_count", "registry", "registry modifications", "Sysmon 12/13/14", ev.is_reg)
count("run_key_count", "registry", "writes to a Run autostart key",
      "Sysmon 12/13/14 whose target path contains CurrentVersion\\Run",
      ev.is_reg & rp.str.contains("currentversion" + re.escape(BS) + "run", regex=True))
count("svc_key_count", "registry", "writes under CurrentControlSet\\Services",
      "Sysmon 12/13/14 whose target path contains CurrentControlSet\\Services",
      ev.is_reg & rp.str.contains("currentcontrolset" + re.escape(BS) + "services", regex=True))
unique("reg_path_unique", "registry", "distinct registry paths written",
       "Sysmon 12/13/14, distinct target object", ev.is_reg, "reg_path")

# ------------------------------------------------------------------- injection -------
count("image_load_count", "injection", "modules loaded by the user's processes",
      "Sysmon 7", ev.is_imgload)
count("proc_access_count", "injection", "process handles opened into another process",
      "Sysmon 10", ev.is_pacc)
count("lsass_acc_count", "injection", "LSASS process accesses",
      "Sysmon 10 whose target image is lsass.exe", ev.is_pacc & ti.str.endswith("lsass.exe"))
count("lsass_hi_count", "injection", "high-privilege LSASS accesses",
      "Sysmon 10 into lsass.exe with a credential-theft GrantedAccess mask",
      ev.is_pacc & ti.str.endswith("lsass.exe") &
      ev["GrantedAccess"].fillna("").isin(["0x1FFFFF", "0x1010", "0x143a", "0x1F3FFF", "0x1410"]))
count("remote_thread_count", "injection", "remote threads created in another process",
      "Sysmon 8", ev.is_rthread)
count("rthread_ext_count", "injection", "remote-thread injections excluding antivirus",
      "Sysmon 8 whose target image is not a Defender component",
      ev.is_rthread & ~ti.str.contains("defender", regex=False))

# -------------------------------------------------------------- authentication -------
count("logon_ok_count", "authentication", "successful logons", "Security 4624", ev.f_logon_ok)
count("logon_fail_count", "authentication", "failed logons", "Security 4625", ev.EventID == 4625)
count("lt2_count", "authentication", "console logons (type 2)",
      "Security 4624 with LogonType 2", ev.f_logon_ok & (ev.logon_type == 2))
count("lt3_count", "authentication", "network logons (type 3)",
      "Security 4624 with LogonType 3", ev.f_logon_ok & (ev.logon_type == 3))
count("lt5_count", "authentication", "service logons (type 5)",
      "Security 4624 with LogonType 5", ev.f_logon_ok & (ev.logon_type == 5))
count("lt10_count", "authentication", "remote-interactive (RDP) logons",
      "Security 4624 with LogonType 10", ev.f_logon_ok & (ev.logon_type == 10))
count("ext_src_count", "authentication", "logons from an external address",
      "Security 4624 whose source IP is outside RFC1918", ev.f_logon_ok & is_ext_src)
count("priv_count", "authentication", "special-privilege assignments",
      "Security 4672", ev.EventID == 4672)
count("explicit_count", "authentication", "explicit-credential logons",
      "Security 4648 (RunAs)", ev.EventID == 4648)
count("tgt_count", "authentication", "Kerberos TGT requests", "Security 4768", ev.EventID == 4768)
count("tgs_count", "authentication", "Kerberos service-ticket requests",
      "Security 4769", ev.EventID == 4769)
count("krb_fail_count", "authentication", "Kerberos pre-authentication failures",
      "Security 4771", ev.EventID == 4771)
count("ntlm_count", "authentication", "NTLM credential validations", "Security 4776", ev.EventID == 4776)
count("ntlm_fail_count", "authentication", "failed NTLM credential validations",
      "Security 4776 with a non-zero Status",
      (ev.EventID == 4776) & (ev["Status"].astype("string") != "0x0"))
count("logoff_count", "authentication", "logoffs", "Security 4634", ev.EventID == 4634)
count("unlock_count", "authentication", "workstation unlocks", "Security 4801", ev.EventID == 4801)
count("lock_count", "authentication", "workstation locks", "Security 4800", ev.EventID == 4800)
unique("src_ip_unique", "authentication", "distinct authentication source IPs",
       "Security 4624, distinct source address", ev.f_logon_ok, "src_ip")
unique("workstation_unique", "authentication", "distinct workstation names in logons",
       "Security 4624, distinct WorkstationName", ev.f_logon_ok, "workstation")
unique("logon_type_unique", "authentication", "distinct logon types used",
       "Security 4624, distinct LogonType", ev.f_logon_ok, "logon_type")

# ------------------------------------------------------------ directory change -------
count("acct_mgmt_count", "directory change", "account-management operations",
      "Security 4720/4722/4723/4724/4725/4726/4738/4740/4767/4781",
      ev.EventID.isin([4720, 4722, 4723, 4724, 4725, 4726, 4738, 4740, 4767, 4781]))
count("group_mgmt_count", "directory change", "group-membership changes",
      "Security 4727-4757 group add/remove family",
      ev.EventID.isin([4727, 4728, 4729, 4731, 4732, 4733, 4735, 4737, 4754, 4755, 4756, 4757]))
count("svc_install_count", "directory change", "service installations",
      "Security 4697 / 7045", ev.EventID.isin([4697, 7045]))
count("task_count", "directory change", "scheduled-task registrations",
      "Security 4698/4699/4700/4702", ev.EventID.isin([4698, 4699, 4700, 4702]))
count("logclear_count", "directory change", "event-log clears",
      "Security 1102 / 104", ev.EventID.isin([1102, 104]))

# ---------------------------------------------------------------------- spread -------
unique("computer_unique", "spread", "distinct hosts touched",
       "any attributed event, distinct Computer", ALL, "computer")

# ---- derived look-ups, so there is exactly one source of truth for names -------------
FEATS         = [r["feature"] for r in FEATURE_REGISTRY]
FEATURE_TEXT  = {r["feature"]: r["meaning"] for r in FEATURE_REGISTRY}
FEATURE_GROUP = {r["feature"]: r["group"] for r in FEATURE_REGISTRY}
FEATURE_HOW   = {r["feature"]: r["computed_from"] for r in FEATURE_REGISTRY}


def feat_text(f):
    return FEATURE_TEXT.get(f, f.replace("_count", "").replace("_", " "))


assert len(FEATS) == len(set(FEATS)), "duplicate feature name in the registry"
print(f"{len(FEATS)} window features declared "
      f"({sum(r['kind'] == 'count' for r in FEATURE_REGISTRY)} counts, "
      f"{sum(r['kind'] == 'unique' for r in FEATURE_REGISTRY)} distinct-value counts)")
print()
print("THE FEATURE REGISTRY - every window feature, and exactly how it is computed")
with pd.option_context("display.max_rows", 90, "display.max_colwidth", 78):
    display(pd.DataFrame(FEATURE_REGISTRY)[["group", "feature", "kind", "meaning",
                                            "computed_from"]])
```


::: {#4c80a167 .cell .code execution_count="18" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:37.943812Z\",\"iopub.status.busy\":\"2026-08-25T09:00:37.943412Z\",\"iopub.status.idle\":\"2026-08-25T09:00:38.115870Z\",\"shell.execute_reply\":\"2026-08-25T09:00:38.114114Z\"}"}
``` python
# ---- command-line signature ---------------------------------------------------------
CMDSIG_IMGS = SHELLS | SCRIPT_HOSTS | DISCOVERY | LOLBIN | ADMIN_TOOL | TRANSFER | REMOTE_EXEC
TERMINATORS = {"-command", "-c", "-encodedcommand", "-enc", "-e", "-ec", "-file", "/c", "/k"}
FLAG_RE = re.compile(r"(?:^|\s)([-/][A-Za-z][A-Za-z0-9_?-]*)")


def cmd_signature(img_base, cmd):
    """image + its flag habit; argument VALUES are discarded so the signature is stable."""
    if not img_base or img_base not in CMDSIG_IMGS or not isinstance(cmd, str):
        return None
    flags = [f.lower() for f in FLAG_RE.findall(cmd)]
    if img_base in SHELLS:
        keep = []
        for f in flags:
            keep.append(f)
            if f in TERMINATORS:      # everything past this point is script content, not habit
                break
        flags = keep
    else:
        flags = sorted(set(flags))[:8]
    return img_base + "|" + " ".join(flags)


_pairs = ev.loc[ev.is_proc, ["image_base", "cmd_low"]].drop_duplicates()
_sigmap = {(a, b): cmd_signature(a, b)
           for a, b in zip(_pairs.image_base.fillna(""), _pairs.cmd_low.fillna(""))}
ev["cmd_sig"] = pd.NA
ev.loc[ev.is_proc, "cmd_sig"] = [_sigmap.get((a, b)) for a, b in
                                 zip(ev.loc[ev.is_proc, "image_base"].fillna(""),
                                     ev.loc[ev.is_proc, "cmd_low"].fillna(""))]
ev["cmd_sig"] = ev["cmd_sig"].astype("string")

# ---- composite authentication keys ---------------------------------------------------
ev["auth_path"] = pd.NA
_m = ev.f_logon_ok & ev.src_ip.notna()
ev.loc[_m, "auth_path"] = ev.loc[_m, "src_ip"].astype(str) + ">" + ev.loc[_m, "computer"].astype(str)
ev["auth_path"] = ev["auth_path"].astype("string")

ev["logon_host_type"] = pd.NA
_m = ev.f_logon_ok & ev.computer.notna()
ev.loc[_m, "logon_host_type"] = (ev.loc[_m, "computer"].astype(str) + "/" +
                                 ev.loc[_m, "logon_type"].astype("Int64").astype(str))
ev["logon_host_type"] = ev["logon_host_type"].astype("string")
ev["logon_type_s"] = ev["logon_type"].astype("Int64").astype("string")
ev["dst_port_s"]   = ev["dst_port"].astype("Int64").astype("string")

print("example command-line signatures learned for charlie.brown (baseline days):")
_x = ev[(ev.user == "charlie.brown") & ev.cmd_sig.notna() & ev.date.isin(TRAIN_DATES)]
for s in sorted(_x.cmd_sig.unique()):
    print("   ", s)
```


::: {#159cab60 .cell .markdown}
### 11.3 Window aggregation {#113-window-aggregation}

Flags are summed, categorical dimensions are counted distinctly, and the
result is reindexed onto the complete grid so that **every** window -
including the empty ones - carries a full feature vector.
:::

::: {#931d9485 .cell .code execution_count="19" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:38.120312Z\",\"iopub.status.busy\":\"2026-08-25T09:00:38.119906Z\",\"iopub.status.idle\":\"2026-08-25T09:00:38.781525Z\",\"shell.execute_reply\":\"2026-08-25T09:00:38.780481Z\"}"}
``` python
# Walk the registry once. `count` features sum their mask; `unique` features count
# distinct values among the events their mask selects. Nothing else defines a feature.
g = ev.groupby(["user", "win"], observed=True)
agg = pd.DataFrame(index=g.size().index)
for r in FEATURE_REGISTRY:
    m = "_m_" + r["feature"]
    if r["kind"] == "count":
        agg[r["feature"]] = g[m].sum()
    else:
        sub = ev[ev[m] & ev[r["value"]].notna()]
        agg[r["feature"]] = sub.groupby(["user", "win"], observed=True)[r["value"]].nunique()
agg = agg.fillna(0).reset_index()
assert list(agg.columns) == ["user", "win"] + FEATS

# left-join onto the complete grid, then zero-fill: this is the step that guarantees an
# empty window becomes a zero vector instead of disappearing
W = grid.merge(agg, on=["user", "win"], how="left")
W[FEATS] = W[FEATS].fillna(0)
W["wid"] = np.arange(len(W))            # stable row id used later to look a window back up

cov = W[W.has_telemetry]
print(f"10-minute feature frame: {W.shape[0]:,} windows x {len(FEATS)} numeric features")
print(f"  with sensor coverage            : {len(cov):,}")
print(f"    of which at least one event   : {(cov.event_count > 0).sum():,} "
      f"({(cov.event_count > 0).mean():.1%})")
print(f"    of which empty (real idleness): {(cov.event_count == 0).sum():,} "
      f"({(cov.event_count == 0).mean():.1%})   <- kept, they are behaviour")
print(f"  outside sensor coverage         : {int((~W.has_telemetry).sum()):,}"
      "   <- excluded from baseline and scoring")
print()
print("a slice of the window table, for one user's first hour:")
W[["user", "date", "hour", "win", "has_telemetry", "event_count", "proc_count", "proc_unique",
   "logon_ok_count", "net_conn_count", "dns_count", "reg_count"]].head(8)
```


::: {#d48955c8 .cell .code execution_count="20" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:38.786345Z\",\"iopub.status.busy\":\"2026-08-25T09:00:38.785927Z\",\"iopub.status.idle\":\"2026-08-25T09:00:39.587141Z\",\"shell.execute_reply\":\"2026-08-25T09:00:39.585727Z\"}"}
``` python
# ---- categorical behaviour dimensions (the "what", not the "how much") --------------
HIGH_TRUST_NET = {
    "chrome.exe","firefox.exe","msedge.exe","iexplore.exe","teams.exe","ms-teams.exe","slack.exe",
    "zoom.exe","cpthost.exe","webex.exe","ciscocollabhost.exe","outlook.exe","onedrive.exe",
    "googledrivefs.exe","dropbox.exe","code.exe","postman.exe","sublime_text.exe","dbeaver.exe",
    "pbidesktop.exe","tableau.exe","excel.exe","winword.exe","powerpnt.exe","acrobat.exe",
    "zsatray.exe","selfservice.exe","searchapp.exe","explorer.exe","mstsc.exe","msra.exe",
    "searchindexer.exe","spotify.exe","notepad++.exe","psql.exe","sqlcmd.exe","git.exe","ssh.exe",
    "vs_installer.exe","chromesetup.exe","runtimebroker.exe","sihost.exe","taskhostw.exe",
    "dllhost.exe","svchost.exe","system","msmpeng.exe","mpcmdrun.exe","osqueryd.exe"}
SUSPICIOUS_DIR = (re.escape(BS) + "(windows" + re.escape(BS) + "temp|programdata|users" +
                  re.escape(BS) + "public|perflogs|appdata" + re.escape(BS) + "local" +
                  re.escape(BS) + "temp)" + re.escape(BS))
INTERACTIVE_TYPES = {"2", "10", "11", "12"}
USERDIR_RE  = "c:" + re.escape(BS) + "users" + re.escape(BS) + "[^" + re.escape(BS) + "]+" + re.escape(BS)

ITEM_DEF = [
    ("process",         lambda e: e.is_proc,    "image"),
    ("cmd_sig",         lambda e: e.is_proc,    "cmd_sig"),
    ("pair",            lambda e: e.is_proc,    "pair"),
    ("src_ip",          lambda e: e.f_logon_ok, "src_ip"),
    ("auth_path",       lambda e: e.f_logon_ok, "auth_path"),
    ("logon_host_type", lambda e: e.f_logon_ok, "logon_host_type"),
    ("logon_type",      lambda e: e.f_logon_ok, "logon_type_s"),
    ("dst_ip",          lambda e: e.is_net,     "dst_ip"),
    ("dst_port",        lambda e: e.is_net,     "dst_port_s"),
    ("domain",          lambda e: e.is_dns,     "reg_domain"),
    ("computer",        lambda e: pd.Series(True, index=e.index), "computer"),
]
ITEM_LABEL = {
    "process": "executable", "cmd_sig": "command-line style", "pair": "parent -> child",
    "src_ip": "authentication source IP", "auth_path": "authentication path (source -> host)",
    "logon_host_type": "host / logon-type", "logon_type": "logon type",
    "dst_ip": "destination IP", "dst_port": "destination port", "domain": "DNS domain",
    "computer": "host touched",
}


def build_items(e):
    trusted = e["image_base"].fillna("").isin(HIGH_TRUST_NET)
    parts = []
    for itype, maskf, col in ITEM_DEF:
        m = maskf(e) & e[col].notna()
        if not m.any():
            continue
        parts.append(pd.DataFrame({
            "user": e.loc[m, "user"].to_numpy(), "win": e.loc[m, "win"].to_numpy(),
            "date": e.loc[m, "date"].to_numpy(), "itype": itype,
            "value": e.loc[m, col].astype(str).to_numpy(),
            "trusted": trusted[m].to_numpy()}))
    it = pd.concat(parts, ignore_index=True)
    it["trusted"] = it["trusted"].astype(bool)
    # keep one row per (user, window, dimension, value); prefer the least-trusted context
    it = it.sort_values("trusted").drop_duplicates(["user", "win", "itype", "value"], keep="first")
    it["is_public"]   = it.itype.isin(["src_ip", "dst_ip"]) & ~it.value.str.match(PRIV_PAT).fillna(False)
    it["susp_dir"]    = (it.itype == "process") & it.value.str.contains(SUSPICIOUS_DIR, regex=True)
    it["sens_port"]   = (it.itype == "dst_port") & it.value.isin([str(p) for p in SENSITIVE_PORTS])
    it["interactive"] = ((it.itype == "logon_host_type") &
                         it.value.str.split("/").str[-1].isin(INTERACTIVE_TYPES))
    # C:\Users\<name>\... is the same software for everyone - canonicalise for GLOBAL rarity only
    it["gvalue"] = it.value.str.replace(USERDIR_RE, "c:" + BS + BS + "users" + BS + BS + "*" + BS + BS,
                                        regex=True)
    return it.reset_index(drop=True)


ITEMS = build_items(ev)
print(f"categorical behaviour observations: {len(ITEMS):,}")
summ = (ITEMS.groupby("itype")
        .agg(observations=("value", "size"), distinct_values=("value", "nunique"))
        .assign(label=lambda d: [ITEM_LABEL[i] for i in d.index])
        .sort_values("observations", ascending=False))
summ[["label", "observations", "distinct_values"]]
```


::: {#ecc9f4df .cell .markdown}

------------------------------------------------------------------------

## 12. Feature Validation {#12-feature-validation}

Before anything is modelled: are these features usable? Three checks.

1.  **Sparsity** - a feature that is zero in \>99.9% of *training*
    windows carries almost no distributional information. Such features
    are not discarded (they are exactly the ones that matter when they
    fire) but they are routed to the **activation** signal in section 17
    rather than to the z-score signal, because a z-score against an
    all-zero baseline is meaningless.
2.  **Redundancy** - highly correlated pairs are reported so the fusion
    does not silently double-count.
3.  **Leakage** - training statistics must be computable without
    touching days 8-12.
:::

::: {#9faa02d2 .cell .code execution_count="21" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:39.590726Z\",\"iopub.status.busy\":\"2026-08-25T09:00:39.590356Z\",\"iopub.status.idle\":\"2026-08-25T09:00:39.843823Z\",\"shell.execute_reply\":\"2026-08-25T09:00:39.842177Z\"}"}
``` python
Wtr = W[W.is_train & W.has_telemetry]
nz = (Wtr[FEATS] > 0).mean().sort_values(ascending=False)
val = pd.DataFrame({
    "nonzero_rate_train": nz,
    "train_mean": Wtr[FEATS].mean().reindex(nz.index),
    "train_p95": Wtr[FEATS].quantile(0.95).reindex(nz.index),
    "train_max": Wtr[FEATS].max().reindex(nz.index),
    "test_max": W[~W.is_train & W.has_telemetry][FEATS].max().reindex(nz.index),
})
DENSE_FEATURES  = list(nz[nz >= 0.001].index)
SPARSE_FEATURES = list(nz[nz < 0.001].index)
print(f"{len(DENSE_FEATURES)} features carry a usable training distribution (nonzero in >=0.1% of windows)")
print(f"{len(SPARSE_FEATURES)} features are effectively never seen in training -> routed to the")
print("   'behavioural activation' signal instead of the z-score signal:")
print("   " + textwrap.fill(", ".join(SPARSE_FEATURES), 96, subsequent_indent="   "))
print()
print("top / bottom of the feature validation table")
display(pd.concat([val.head(12), val.tail(10)]).round(3))

print()
print("FEATURE DICTIONARY - what every window feature means and how dense it is in the baseline")
FEATURE_DICT = (pd.DataFrame(FEATURE_REGISTRY)[["group", "feature", "kind", "meaning"]]
    .assign(nonzero_in_baseline=lambda d: [f"{nz[f]:.1%}" for f in d.feature],
            baseline_p95=lambda d: [round(float(Wtr[f].quantile(0.95)), 2) for f in d.feature],
            baseline_max=lambda d: [float(Wtr[f].max()) for f in d.feature],
            routed_to=lambda d: ["z-score" if f in DENSE_FEATURES else "activation"
                                 for f in d.feature])
    .sort_values(["group", "feature"]).reset_index(drop=True))
with pd.option_context("display.max_rows", 90):
    display(FEATURE_DICT)

corr = Wtr[DENSE_FEATURES].corr().abs()
corr = corr.where(np.triu(np.ones(corr.shape), 1).astype(bool))
pairs = corr.stack().sort_values(ascending=False).head(10)
print()
print("most redundant feature pairs in the training data (|r|):")
for (a, b), v in pairs.items():
    print(f"  {v:.3f}   {a:24s} ~ {b}")
```


::: {#b0e7bd7a .cell .code execution_count="22" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:39.848153Z\",\"iopub.status.busy\":\"2026-08-25T09:00:39.847478Z\",\"iopub.status.idle\":\"2026-08-25T09:00:40.739836Z\",\"shell.execute_reply\":\"2026-08-25T09:00:40.738427Z\"}"}
``` python
fig = plt.figure(figsize=(13.5, 4.2))
gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.15, 1.5], wspace=0.32)

# distribution of window activity
ax = fig.add_subplot(gs[0, 0])
vals = Wtr.event_count.clip(upper=120)
ax.hist(vals, bins=40, color=CAT[0], alpha=0.85)
ax.set_yscale("log")
finish(ax, "Events per 10-min window", "baseline days only; 31% of windows are empty",
       xlabel="events in window", ylabel="windows (log)")

# a handful of representative feature distributions
ax = fig.add_subplot(gs[0, 1])
show = ["proc_count", "net_conn_count", "dns_count", "logon_ok_count"]
for i, f in enumerate(show):
    v = Wtr[f].clip(upper=40)
    ax.plot(np.sort(v), np.linspace(0, 1, len(v)), color=CAT[i], label=f.replace("_count", ""))
finish(ax, "Feature CDFs (baseline)", "heavy zero mass is the dominant property",
       xlabel="value", ylabel="cumulative share")
ax.legend(loc="lower right")

# correlation heatmap on a readable subset
ax = fig.add_subplot(gs[0, 2])
sub = ["event_count", "proc_count", "proc_unique", "pair_unique", "net_conn_count",
       "dst_ip_unique", "dns_count", "domain_unique", "logon_ok_count", "tgs_count",
       "reg_count", "image_load_count"]
cm = Wtr[sub].corr().values
im = ax.imshow(cm, cmap=BLUES, vmin=0, vmax=1)
ax.set_xticks(range(len(sub))); ax.set_xticklabels([s.replace("_count", "") for s in sub],
                                                   rotation=55, ha="right", fontsize=7.5)
ax.set_yticks(range(len(sub))); ax.set_yticklabels([s.replace("_count", "") for s in sub], fontsize=7.5)
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03); cb.outline.set_visible(False)
cb.ax.tick_params(labelsize=7.5, color=MUTED)
ax.set_title("Feature correlation (baseline)", loc="left", color=INK, fontsize=11)
plt.show()
```



------------------------------------------------------------------------

## 13. Training Data Construction {#13-training-data-construction}

The split is by **local date**, applied identically to the numeric
frame, the categorical item frame and the event table. The assertions
are the leakage guard.
:::

::: {#2dbac4fb .cell .code execution_count="23" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:40.742993Z\",\"iopub.status.busy\":\"2026-08-25T09:00:40.742650Z\",\"iopub.status.idle\":\"2026-08-25T09:00:40.798855Z\",\"shell.execute_reply\":\"2026-08-25T09:00:40.797623Z\"}"}
``` python
TRAIN_W = W[W.is_train & W.has_telemetry].copy()
TEST_W  = W[~W.is_train & W.has_telemetry].copy()

# leakage guards
assert set(TRAIN_W.date) <= set(TRAIN_DATES) and set(TEST_W.date) <= set(TEST_DATES)
assert TRAIN_W.win.max() < TEST_W.win.min(), "training windows must strictly precede test windows"

print(f"training windows : {len(TRAIN_W):,}   ({TRAIN_W.date.min()} .. {TRAIN_W.date.max()})")
print(f"test windows     : {len(TEST_W):,}   ({TEST_W.date.min()} .. {TEST_W.date.max()})")
print(f"training events  : {int(TRAIN_W.event_count.sum()):,}")
print(f"test events      : {int(TEST_W.event_count.sum()):,}")
print(f"last training window : {TRAIN_W.win.max()}")
print(f"first test window    : {TEST_W.win.min()}   <- strictly after, no overlap")
print()
cells = TRAIN_W.groupby(["user", "hour"]).size()
allzero = int((TRAIN_W.groupby(["user", "hour"]).event_count.sum() == 0).sum())
print(f"user x hour baseline cells : {len(cells)}")
print(f"observations per cell      : {sorted(int(v) for v in cells.unique())}")
print(f"cells that are ENTIRELY empty in training : {allzero}")
print()
print("  -> an all-empty user x hour cell is a real behavioural fact ('this person is never")
print("     active then'), so it is kept. Section 14 stops its zero dispersion from producing")
print("     an infinite z-score by shrinking the scale toward the user's all-hours dispersion.")
```



------------------------------------------------------------------------

## 14. User x Hour Baseline Creation {#14-user-x-hour-baseline-creation}

A baseline cell is `(user, hour)` and is learned from up to 42
ten-minute observations. It has three parts.

### (a) Robust numeric statistics

Counts are modelled in **log1p space**, where the multiplicative bursts
typical of Windows telemetry become roughly additive. For each feature
we store `median`, `MAD`, `P5/P25/P75/P95`, `max` and the non-zero rate.
`mean +/- sd` is deliberately **not** the scale: a single busy window
inside 42 observations would inflate `sd` enough to hide a genuine
spike.

With only 42 observations a cell\'s MAD is often exactly 0, which would
make any non-zero value look infinitely anomalous. The scale is
therefore shrunk:

    scale = max( 1.4826 * MAD(user,hour) ,  0.6 * 1.4826 * MAD(user, all hours) ,  0.35 )

-   the **first** term is the cell\'s own dispersion when it has one,
-   the **second** borrows the user\'s own all-hours dispersion
    (empirical-Bayes shrinkage - still user-specific, never global),
-   the **third** is an absolute floor that stops an all-zero cell from
    producing an infinite z.

### (b) Behavioural inventories

Per user, the set of every executable, command-line style,
parent-\>child pair, authentication source, authentication path,
host/logon-type, destination IP, destination port and DNS domain
observed in the 7 baseline days - plus a **corpus-wide** frequency table
so that \"new to this user\" and \"never seen anywhere\" can be weighted
differently.

### (c) Event-ID rarity

Per user and corpus-wide training frequency of each Event ID, used to
score events that are structurally rare rather than merely voluminous.
:::

::: {#19d84341 .cell .code execution_count="24" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:40.803122Z\",\"iopub.status.busy\":\"2026-08-25T09:00:40.802728Z\",\"iopub.status.idle\":\"2026-08-25T09:00:41.152916Z\",\"shell.execute_reply\":\"2026-08-25T09:00:41.151668Z\"}"}
``` python
STAT_FEATURES = [c for c in FEATS if c in DENSE_FEATURES or c in [
    "encoded_count", "lsass_hi_count", "rthread_ext_count", "acct_mgmt_count", "group_mgmt_count",
    "svc_install_count", "task_count", "logclear_count", "script_ext_net_count",
    "script_sens_port_count", "remote_spawn_count", "archive_create_count"]]
# Counts are modelled in log1p space: Windows telemetry bursts multiplicatively, and log1p
# turns "3x more than usual" into a constant offset regardless of the user's normal volume.
LOGW = pd.DataFrame(np.log1p(W[STAT_FEATURES].to_numpy(float)), columns=STAT_FEATURES)
LOGW["user"] = W.user.to_numpy(); LOGW["hour"] = W.hour.to_numpy()
LOGW["date"] = W.date.to_numpy()
LOGW["has_tel"] = W.has_telemetry.to_numpy(dtype=bool)


def fit_numeric_baseline(train_dates):
    """Robust per-(user, hour) statistics, plus per-user fallbacks used for scale shrinkage."""
    t = LOGW[LOGW.date.isin(train_dates) & LOGW["has_tel"]]
    g = t.groupby(["user", "hour"])[STAT_FEATURES]
    med_h = g.median()
    mad_h = t.set_index(["user", "hour"])[STAT_FEATURES].sub(med_h).abs().groupby(level=[0, 1]).median()
    med_u = t.groupby("user")[STAT_FEATURES].median()
    mad_u = t.set_index("user")[STAT_FEATURES].sub(med_u).abs().groupby(level=0).median()
    return {"med_h": med_h, "mad_h": mad_h, "med_u": med_u, "mad_u": mad_u,
            "p05_h": g.quantile(0.05), "p25_h": g.quantile(0.25), "p75_h": g.quantile(0.75),
            "p95_h": g.quantile(0.95), "max_h": g.max(), "n": t.groupby(["user", "hour"]).size()}


def fit_inventories(train_dates):
    tr = ITEMS[ITEMS.date.isin(train_dates)]
    known = tr[["user", "itype", "value"]].drop_duplicates()
    known["known"] = True
    gcnt = tr.groupby(["itype", "gvalue"]).size().rename("gcnt").reset_index()
    return known, gcnt


def fit_eid_rarity(train_dates):
    tr = ev[ev.date.isin(train_dates)]
    return (tr.groupby(["user", "EventID"]).size().rename("ucnt").reset_index(),
            tr.groupby("user").size().rename("utot").reset_index(),
            tr.groupby("EventID").size().rename("gcnt").reset_index(),
            len(tr))


def fit_activation(train_dates):
    """Per-user maximum of each feature. Where that maximum is 0, the user has NEVER
    exercised that capability in any baseline hour - so any non-zero value later is a
    first occurrence, which the z-score cannot express but section 17 can."""
    return W[W.date.isin(train_dates) & W.has_telemetry].groupby("user")[ACT_FEATURES].max()


ACT_WEIGHTS = {
    "encoded_count": 2.0, "hidden_ps_count": 0.8, "scripthost_count": 1.5, "discovery_count": 1.2,
    "lolbin_count": 1.2, "admin_count": 1.2, "transfer_count": 1.0, "temp_proc_count": 1.5,
    "remoteexec_count": 0.8, "lsass_acc_count": 1.5, "lsass_hi_count": 2.5, "rthread_ext_count": 2.5,
    "remote_thread_count": 1.0, "exe_create_count": 1.0, "script_create_count": 1.2,
    "archive_create_count": 1.2, "temp_create_count": 1.0, "run_key_count": 1.5, "svc_key_count": 1.0,
    "acct_mgmt_count": 2.5, "group_mgmt_count": 2.5, "svc_install_count": 2.5, "task_count": 2.0,
    "logclear_count": 3.0, "explicit_count": 1.2, "ext_src_count": 2.0, "sens_port_count": 0.8,
    "srv_lookup_count": 0.5, "dns_fail_count": 0.5, "krb_fail_count": 0.8, "ntlm_fail_count": 0.8,
    "lt10_count": 0.8, "lt2_count": 0.6, "script_net_count": 0.8, "script_ext_net_count": 1.5,
    "script_sens_port_count": 1.5, "remote_spawn_count": 1.5,
}
ACT_FEATURES = [c for c in ACT_WEIGHTS if c in W.columns]


def fit_baseline(train_dates):
    known, gcnt = fit_inventories(train_dates)
    ucnt, utot, egcnt, gtot = fit_eid_rarity(train_dates)
    return {"num": fit_numeric_baseline(train_dates), "known": known, "gcnt": gcnt,
            "eid_ucnt": ucnt, "eid_utot": utot, "eid_gcnt": egcnt, "eid_gtot": gtot,
            "act_max": fit_activation(train_dates), "train_dates": list(train_dates)}


BASELINE = fit_baseline(TRAIN_DATES)
print(f"baseline fitted on {len(TRAIN_DATES)} days")
print(f"  numeric cells        : {len(BASELINE['num']['med_h'])}  (user x hour)")
print(f"  features per cell    : {len(STAT_FEATURES)}")
print(f"  behavioural entries  : {len(BASELINE['known']):,} distinct (user, dimension, value) triples")
print(f"  corpus rarity table  : {len(BASELINE['gcnt']):,} distinct (dimension, value) pairs")
```

::: {.output .stream .stdout}
    baseline fitted on 7 days
      numeric cells        : 192  (user x hour)
      features per cell    : 57
      behavioural entries  : 2,127 distinct (user, dimension, value) triples
      corpus rarity table  : 688 distinct (dimension, value) pairs
:::
:::

::: {#3cc12f52 .cell .code execution_count="25" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:41.156393Z\",\"iopub.status.busy\":\"2026-08-25T09:00:41.156004Z\",\"iopub.status.idle\":\"2026-08-25T09:00:41.367584Z\",\"shell.execute_reply\":\"2026-08-25T09:00:41.365654Z\"}"}
``` python
# ---- the baseline as a tidy table (the deliverable shape from the brief) -------------
num = BASELINE["num"]
tidy = []
for stat, frame in [("median", num["med_h"]), ("mad", num["mad_h"]), ("p05", num["p05_h"]),
                    ("p25", num["p25_h"]), ("p75", num["p75_h"]), ("p95", num["p95_h"]),
                    ("max", num["max_h"])]:
    t = frame.stack().rename(stat)
    t.index.names = ["user", "hour", "feature"]
    tidy.append(t)
BASELINE_TABLE = pd.concat(tidy, axis=1).reset_index()
# stored in log1p space for the model; expose the natural-scale value for humans
for c in ["median", "p05", "p25", "p75", "p95", "max"]:
    BASELINE_TABLE[c + "_events"] = np.expm1(BASELINE_TABLE[c]).round(2)
BASELINE_TABLE = BASELINE_TABLE.merge(obs, on=["user", "hour"], how="left")

print(f"baseline table: {len(BASELINE_TABLE):,} rows "
      f"({len(PRINCIPALS)} users x 24 hours x {len(STAT_FEATURES)} features)")
print()
print("example - charlie.brown, hour 03 (the hour his compromise begins in):")
display(BASELINE_TABLE[(BASELINE_TABLE.user == "charlie.brown") & (BASELINE_TABLE.hour == 3) &
                       BASELINE_TABLE.feature.isin(["event_count", "proc_count", "proc_unique",
                                                    "logon_ok_count", "net_conn_count", "dns_count"])]
        [["user", "hour", "feature", "n_obs", "median_events", "p75_events", "p95_events",
          "max_events", "mad"]].round(3))

print("behavioural inventory sizes per principal (baseline days):")
inv_sizes = (BASELINE["known"].groupby(["user", "itype"]).size().unstack(fill_value=0))
display(inv_sizes[["process", "cmd_sig", "pair", "src_ip", "auth_path", "logon_host_type",
                   "dst_ip", "dst_port", "domain", "computer"]])

# ---------------------------------------------------------------- 14.3 tables ------
def hourly_profile(user, features, stat="median"):
    """One user's 24-hour behavioural fingerprint: rows = hour, columns = feature."""
    t = BASELINE_TABLE[(BASELINE_TABLE.user == user) & BASELINE_TABLE.feature.isin(features)]
    piv = t.pivot(index="hour", columns="feature", values=stat + "_events")[features]
    piv.insert(0, "n_obs", t.groupby("hour").n_obs.first())
    return piv.round(2)


PROFILE_FEATURES = ["event_count", "proc_count", "proc_unique", "logon_ok_count",
                    "net_conn_count", "dst_ip_unique", "dns_count", "reg_count"]

print("=" * 96)
print("BASELINE PROFILE - charlie.brown, all 24 UTC hours (median per 10-minute window)")
print("=" * 96)
display(hourly_profile("charlie.brown", PROFILE_FEATURES, "median"))

print("Same user, same hours, the P95 upper edge of normal:")
display(hourly_profile("charlie.brown", PROFILE_FEATURES, "p95"))

print("=" * 96)
print("WHAT EACH PRINCIPAL NORMALLY RUNS - top baseline executables (this is what novelty is judged against)")
print("=" * 96)
_tp = (ev[ev.is_proc & ev.date.isin(TRAIN_DATES)]
       .groupby(["user", "image_base"]).size().rename("n").reset_index()
       .sort_values(["user", "n"], ascending=[True, False]))
with pd.option_context("display.max_colwidth", 140):
    display(pd.DataFrame({
        "distinct executables": _tp.groupby("user").size(),
        "top 8 by volume": _tp.groupby("user").head(8).groupby("user")
            .apply(lambda d: ", ".join(f"{r.image_base}({r.n})" for _, r in d.iterrows())),
    }))

print("AUTHENTICATION FOOTPRINT - where each principal normally logs on from, and onto")
_au = ev[ev.f_logon_ok & ev.date.isin(TRAIN_DATES)]
with pd.option_context("display.max_colwidth", 140):
    display(pd.DataFrame({
        "hosts logged onto": _au.groupby("user").computer.apply(
            lambda s: ", ".join(sorted(s.dropna().unique()))),
        "logon types": _au.groupby("user").logon_type.apply(
            lambda s: ", ".join(str(int(v)) for v in sorted(s.dropna().unique()))),
        "distinct source IPs": _au.groupby("user").src_ip.nunique(),
    }))
```

------------------------------------------------------------------------

## 15. Baseline Visualisation {#15-baseline-visualisation}
:::

::: {#eede5bf4 .cell .code execution_count="26" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:41.371391Z\",\"iopub.status.busy\":\"2026-08-25T09:00:41.371027Z\",\"iopub.status.idle\":\"2026-08-25T09:00:42.440110Z\",\"shell.execute_reply\":\"2026-08-25T09:00:42.438588Z\"}"}
``` python
fig = plt.figure(figsize=(13.5, 8.4))
gs = fig.add_gridspec(2, 2, height_ratios=[1.05, 1], hspace=0.5, wspace=0.25)

# (1) user x hour activity heatmap - the baseline the model actually learns
ax = fig.add_subplot(gs[0, :])
hm = (TRAIN_W.groupby(["user", "hour"]).event_count.mean()
      .unstack(fill_value=0).reindex(PRINCIPALS))
im = ax.imshow(hm.values, aspect="auto", cmap=BLUES)
ax.set_yticks(range(len(hm))); ax.set_yticklabels(hm.index, fontsize=9)
ax.set_xticks(range(0, 24)); ax.set_xticklabels(range(24), fontsize=8)
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.012); cb.outline.set_visible(False)
cb.set_label("mean events / 10-min window", fontsize=8, color=INK2)
cb.ax.tick_params(labelsize=7.5)
ax.set_title("Baseline activity profile - mean events per 10-minute window, by user and hour",
             loc="left", color=INK, pad=24)
ax.text(0, 1.02, f"{TRAIN_DATES[0]} .. {TRAIN_DATES[-1]} only - the surface every scored window "
                 "is compared against", transform=ax.transAxes, color=MUTED, fontsize=8.5)
ax.set_xlabel(f"hour of day ({TZ})")

# (2) the 42 observations behind one cell
ax = fig.add_subplot(gs[1, 0])
u, h = "charlie.brown", 3
cell = TRAIN_W[(TRAIN_W.user == u) & (TRAIN_W.hour == h)].sort_values("win")
ax.scatter(range(len(cell)), cell.event_count.values, s=26, color=CAT[0],
           edgecolor=SURFACE, linewidth=1.4, zorder=3)
row = BASELINE_TABLE[(BASELINE_TABLE.user == u) & (BASELINE_TABLE.hour == h) &
                     (BASELINE_TABLE.feature == "event_count")].iloc[0]
ax.axhline(row.median_events, color=CAT[1], lw=1.6, zorder=2)
ax.axhspan(row.p05_events, row.p95_events, color=CAT[1], alpha=0.12, zorder=1)
ax.text(1, row.median_events + 0.4, f"median {row.median_events:.0f}",
        color=CAT[1], fontsize=8, va="bottom")
finish(ax, f"The {len(cell)} observations behind '{u} + hour {h:02d}'",
       f"{WINDOWS_PER_HOUR} windows/hour x {len(cell) // WINDOWS_PER_HOUR} covered baseline days; "
       "band = P5-P95",
       xlabel=f"observation ({TRAIN_DATES[0][5:]} -> {TRAIN_DATES[-1][5:]})",
       ylabel="events in window")

# (3) how much each user varies hour to hour
ax = fig.add_subplot(gs[1, 1])
prof = TRAIN_W.groupby(["user", "hour"]).event_count.mean().unstack()
for i, uu in enumerate(PRINCIPALS):
    ax.plot(prof.columns, prof.loc[uu].values, color=CAT[i % 8], lw=1.6, label=uu)
finish(ax, "Per-user hourly shape", "why a global baseline would not work",
       xlabel=f"hour ({TZ})", ylabel="mean events / window")
ax.set_xticks(range(0, 24, 3))
ax.legend(ncols=2, loc="upper left", fontsize=7.5)
plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/fc7224816064b39b1b34db1fa03a50f25c83edea.png)
:::
:::

::: {#c3c7d4d9 .cell .code execution_count="27" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:42.444171Z\",\"iopub.status.busy\":\"2026-08-25T09:00:42.443814Z\",\"iopub.status.idle\":\"2026-08-25T09:00:43.182507Z\",\"shell.execute_reply\":\"2026-08-25T09:00:43.181400Z\"}"}
``` python
fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.7))

# inventory sizes - how much behavioural vocabulary each principal has
ax = axes[0]
iv = inv_sizes[["process", "cmd_sig", "pair", "dst_ip", "domain"]].reindex(PRINCIPALS)
bottom = np.zeros(len(iv))
for i, c in enumerate(iv.columns):
    ax.bar(range(len(iv)), iv[c].values, bottom=bottom, color=CAT[i], width=0.7,
           label=ITEM_LABEL[c], linewidth=1.6, edgecolor=SURFACE)
    bottom += iv[c].values
ax.set_xticks(range(len(iv))); ax.set_xticklabels(iv.index, rotation=45, ha="right", fontsize=8)
finish(ax, "Behavioural vocabulary learned", "distinct baseline values per dimension",
       ylabel="distinct values")
ax.legend(fontsize=7, loc="upper left")

# empty-window share per user
ax = axes[1]
empt = TRAIN_W.groupby("user").apply(lambda d: (d.event_count == 0).mean()).reindex(PRINCIPALS)
ax.barh(range(len(empt)), empt.values, color=CAT[0], height=0.65)
ax.set_yticks(range(len(empt))); ax.set_yticklabels(empt.index, fontsize=8)
ax.xaxis.set_major_formatter(mpl.ticker.PercentFormatter(1.0))
finish(ax, "Share of baseline windows that are empty",
       "inactivity is a modelled feature, not missing data",
       xlabel="empty windows", xgrid=True)

# scale-floor diagnostic: how many cells have MAD == 0
ax = axes[2]
mad0 = (num["mad_h"] == 0).mean(axis=0).sort_values(ascending=False)
pick = ["event_count", "proc_count", "net_conn_count", "dns_count", "reg_count",
        "logon_ok_count", "tgs_count", "logon_fail_count"]
vals = [mad0[p] for p in pick]
ax.barh(range(len(pick)), vals, color=CAT[3], height=0.65)
ax.set_yticks(range(len(pick))); ax.set_yticklabels([p.replace("_count", "") for p in pick], fontsize=8)
ax.xaxis.set_major_formatter(mpl.ticker.PercentFormatter(1.0))
finish(ax, "user x hour cells with MAD = 0", "why the scale needs shrinkage + a floor",
       xlabel="share of cells", xgrid=True)
plt.tight_layout(); plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/c8b0107ad831f2bcda28c8ff7deddbc67b718636.png)
:::
:::

::: {#041882e6 .cell .markdown}

------------------------------------------------------------------------

## 16. Test Feature Extraction & the Scoring Engine {#16-test-feature-extraction--the-scoring-engine}

Test windows go through **exactly the same** pipeline as training
windows - same flags, same aggregation, same categorical extraction -
and are compared against `user + hour` only, never against a global
model, never against the user\'s other hours, never against day 8
itself.

### Leave-one-day-out scoring of the baseline period

To choose a threshold we need to know what score a *normal* window
produces. Scoring the training days against a baseline that already
contains them would give an artificially clean answer (every executable
would already be \"known\", every count already inside its own median).
So each baseline day is scored against a baseline re-fitted on the
**other days of the baseline period**. That yields one honest \"normal\"
score for every covered baseline window, and that set is the null
distribution section 18 reads the alert threshold off.

Five signals are computed. They answer different questions and fail in
different ways, which is why they are fused rather than replaced by one
another.

  -----------------------------------------------------------------------
  Signal                  Question                Strength
  ----------------------- ----------------------- -----------------------
  `s_stat`                *Is there more of       volume spikes
                          something than this     
                          user normally does at   
                          this hour?*             

  `s_nov`                 *Is this user doing     new tools, hosts,
                          something they have     destinations
                          never done?*            

  `s_act`                 *Has a whole class of   first LSASS access,
                          behaviour switched on   first service install
                          for the first time?*    

  `s_rare`                *Did an event type fire account creation, log
                          that is structurally    clearing
                          rare in this            
                          environment?*           

  `s_ml`                  *Does the joint         multivariate shape
                          deviation vector look   
                          unlike any training     
                          window?*                
  -----------------------------------------------------------------------
:::

::: {#64ed40d4 .cell .code execution_count="28" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:43.185710Z\",\"iopub.status.busy\":\"2026-08-25T09:00:43.185372Z\",\"iopub.status.idle\":\"2026-08-25T09:00:46.353184Z\",\"shell.execute_reply\":\"2026-08-25T09:00:46.351477Z\"}"}
``` python
BASE_W = {"process": 1.0, "cmd_sig": 0.9, "pair": 0.7, "src_ip": 1.0, "auth_path": 1.0,
          "logon_host_type": 1.1, "logon_type": 0.6, "dst_ip": 0.5, "dst_port": 0.2,
          "domain": 0.4, "computer": 0.5}
GNOV_W = {"process": 1.0, "cmd_sig": 0.5, "pair": 0.5, "src_ip": 1.0, "auth_path": 0.4,
          "logon_host_type": 0.4, "logon_type": 0.0, "dst_ip": 0.8, "dst_port": 0.2,
          "domain": 1.5, "computer": 0.3}


def novelty_frame(bl, score_dates):
    """Every categorical value in the scored windows that this user never showed in baseline."""
    d = ITEMS[ITEMS.date.isin(score_dates)].merge(bl["known"], on=["user", "itype", "value"], how="left")
    d = d.merge(bl["gcnt"], on=["itype", "gvalue"], how="left")
    d["known"] = d["known"].fillna(False).astype(bool)
    d["gcnt"] = d["gcnt"].fillna(0).astype(float)
    d = d[~d.known].copy()

    w = d.itype.map(BASE_W).astype(float)
    w = w + (d.gcnt == 0).astype(float) * d.itype.map(GNOV_W).astype(float)   # never seen anywhere
    w = w + d.susp_dir.astype(float) * 1.0                                    # ran from a staging dir
    w = w + (d.is_public & (d.itype == "src_ip")).astype(float) * 2.5         # auth from the internet
    w = w + (d.is_public & (d.itype == "dst_ip") & (d.gcnt == 0)).astype(float) * 2.0
    w = w + d.sens_port.astype(float) * 0.8                                   # infrastructure port
    w = w + d.interactive.astype(float) * 0.8                                 # console/RDP on a new host
    # browsers and collaboration clients churn through destinations by design - damp that novelty
    w = np.where(d.trusted & d.itype.isin(["dst_ip", "domain"]), w * 0.06, w)
    d["w"] = w
    return d


def rarity_frame(bl, score_dates):
    """Event IDs that are rare for this user AND rare across the whole baseline corpus."""
    sc = (ev[ev.date.isin(score_dates)].groupby(["user", "win", "EventID"]).size()
          .rename("n").reset_index())
    sc = (sc.merge(bl["eid_ucnt"], on=["user", "EventID"], how="left")
            .merge(bl["eid_utot"], on="user", how="left")
            .merge(bl["eid_gcnt"], on="EventID", how="left"))
    sc["ucnt"] = sc.ucnt.fillna(0).astype(float)
    sc["gcnt"] = sc.gcnt.fillna(0).astype(float)
    s_u = -np.log10((sc.ucnt + 0.5) / (sc.utot + 1.0))          # surprise for this user
    s_g = -np.log10((sc.gcnt + 0.5) / (bl["eid_gtot"] + 1.0))   # surprise for the environment
    sc["w"] = np.clip(s_u - 3.0, 0, None) * 0.6 + np.clip(s_g - 4.0, 0, None) * 1.2
    return sc[sc.w > 0].copy()


def activation_matrix(bl, idx):
    """Features whose baseline maximum is 0 for this user and which are non-zero now."""
    sub = W.loc[idx]
    bm = bl["act_max"].reindex(sub.user).to_numpy(float)
    X = sub[ACT_FEATURES].to_numpy(float)
    fired = (X > 0) & (np.nan_to_num(bm) == 0)
    wvec = np.array([ACT_WEIGHTS[c] for c in ACT_FEATURES])[None, :]
    return fired * wvec * (1 + 0.3 * np.log1p(X))


def robust_z(bl, idx):
    """(log1p(x) - median) / shrunk-scale, per user x hour, only for upward deviations."""
    num = bl["num"]
    sub = LOGW.loc[idx]
    key = pd.MultiIndex.from_arrays([sub.user, sub.hour])
    X   = sub[STAT_FEATURES].to_numpy(float)
    med = np.nan_to_num(num["med_h"].reindex(key).to_numpy(float))
    mad = np.nan_to_num(num["mad_h"].reindex(key).to_numpy(float))
    madu = np.nan_to_num(num["mad_u"].reindex(sub.user).to_numpy(float))
    p95 = np.nan_to_num(num["p95_h"].reindex(key).to_numpy(float))
    scale = np.maximum.reduce([1.4826 * mad, 0.6 * 1.4826 * madu, np.full_like(X, 0.35)])
    z = (X - med) / scale
    return np.where(X > p95, z, np.minimum(z, 0))    # only exceeding the cell's P95 can be positive


def combine_stat(sev):
    """Top-3 severity, geometrically damped: broad mild elevation must not imitate a real spike."""
    srt = -np.sort(-sev, axis=1)
    raw = srt[:, 0] + 0.5 * srt[:, 1] + 0.25 * srt[:, 2]
    return 1 - np.exp(-raw / K_STAT), raw


def score_block(bl, score_dates):
    """Score every covered window of `score_dates` against the baseline `bl`.

    Windows outside the sensor's capture range are skipped entirely - scoring them would
    turn "the log was not being written" into "this user did nothing", which is not a fact
    the model is entitled to assert."""
    idx = W.index[W.date.isin(score_dates) & W.has_telemetry]
    z   = robust_z(bl, idx)
    sev = np.clip((z - Z0) / (Z1 - Z0), 0, 1)
    s_stat, stat_raw = combine_stat(sev)
    nv  = novelty_frame(bl, score_dates)
    rf  = rarity_frame(bl, score_dates)
    actm = activation_matrix(bl, idx)

    out = W.loc[idx, ["wid", "user", "win", "date", "hour", "is_train", "event_count"]].copy()
    key = pd.MultiIndex.from_arrays([out.user, out.win])
    out["nov"]  = nv.groupby(["user", "win"])["w"].sum().reindex(key).to_numpy()
    out["rare"] = rf.groupby(["user", "win"])["w"].sum().reindex(key).to_numpy()
    out[["nov", "rare"]] = out[["nov", "rare"]].fillna(0)
    out["act"]    = actm.sum(axis=1)
    out["s_stat"] = s_stat
    out["s_nov"]  = 1 - np.exp(-out.nov / K_NOV)
    out["s_rare"] = 1 - np.exp(-out.rare / K_RARE)
    out["s_act"]  = 1 - np.exp(-out.act / K_ACT)
    return out.reset_index(drop=True), {"z": z, "sev": sev, "nov": nv, "rare": rf, "act": actm}


# ---- leave-one-day-out over the baseline period ------------------------------------
print("scoring the baseline period leave-one-day-out ...")
tr_parts, tr_z, tr_act = [], [], []
for d in TRAIN_DATES:
    bl_d = fit_baseline([x for x in TRAIN_DATES if x != d])
    o, dbg = score_block(bl_d, [d])
    tr_parts.append(o); tr_z.append(dbg["z"]); tr_act.append(dbg["act"])
    print(f"   fold holding out {d}: {len(o):,} windows scored")
TR = pd.concat(tr_parts, ignore_index=True)
Z_TR   = np.vstack(tr_z)
ACT_TR = np.vstack(tr_act)

# ---- the real thing: days 8-12 against the full 7-day baseline ---------------------
TE, DBG = score_block(BASELINE, TEST_DATES)
Z_TE, SEV_TE, NOV_TE, RARE_TE, ACT_TE = DBG["z"], DBG["sev"], DBG["nov"], DBG["rare"], DBG["act"]
print(f"\ntest windows scored: {len(TE):,}")
print(TE[["s_stat", "s_nov", "s_rare", "s_act"]].describe(percentiles=[.5, .9, .99]).round(3))
```



::: {#bbab1431 .cell .markdown}
### 16.2 Machine-learning comparison {#162-machine-learning-comparison}

The brief asks that a statistical baseline be built first and that ML be
adopted only if it **adds** value. The three standard unsupervised
detectors are fitted on the leave-one-day-out deviation matrix (each row
is a window\'s per-feature robust z, i.e. already normalised for *that
user at that hour*) and scored on the test days. Section 20 measures
whether any of them earns its place.
:::

::: {#25951368 .cell .code execution_count="29" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:46.356826Z\",\"iopub.status.busy\":\"2026-08-25T09:00:46.356442Z\",\"iopub.status.idle\":\"2026-08-25T09:00:51.282239Z\",\"shell.execute_reply\":\"2026-08-25T09:00:51.280949Z\"}"}
``` python
Xtr, Xte = np.nan_to_num(Z_TR), np.nan_to_num(Z_TE)


def to_train_percentile(train_scores, test_scores):
    q = np.sort(train_scores)
    return (np.searchsorted(q, train_scores) / len(q),
            np.searchsorted(q, test_scores) / len(q))


ml_models = {}
iso = IsolationForest(n_estimators=500, max_samples=512, random_state=RANDOM_STATE).fit(Xtr)
ml_models["IsolationForest"] = to_train_percentile(-iso.score_samples(Xtr), -iso.score_samples(Xte))

lof = LocalOutlierFactor(n_neighbors=35, novelty=True).fit(Xtr)
ml_models["LocalOutlierFactor"] = to_train_percentile(-lof.score_samples(Xtr), -lof.score_samples(Xte))

_sub = Xtr[np.random.RandomState(RANDOM_STATE).choice(len(Xtr), 4000, replace=False)]
oc = OneClassSVM(kernel="rbf", gamma="scale", nu=0.02).fit(_sub)
ml_models["OneClassSVM"] = to_train_percentile(-oc.decision_function(Xtr), -oc.decision_function(Xte))

# the fused model uses IsolationForest: it is the only one of the three that is cheap to refit,
# deterministic, and stable on a matrix this sparse. Only the extreme upper tail is allowed to speak.
TR["ml_pct"], TE["ml_pct"] = ml_models["IsolationForest"]
for d_ in (TR, TE):
    d_["s_ml"] = np.clip((d_["ml_pct"] - 0.995) / 0.005, 0, 1)
print("fitted:", ", ".join(ml_models))
print(f"IsolationForest: {(TE.s_ml > 0).sum()} test windows above the training 99.5th percentile")
```

::: {.output .stream .stdout}
    fitted: IsolationForest, LocalOutlierFactor, OneClassSVM
    IsolationForest: 32 test windows above the training 99.5th percentile
:::
:::

::: {#d8d89be2 .cell .markdown}

------------------------------------------------------------------------

## 17. Anomaly Scoring - how the five signals behave {#17-anomaly-scoring---how-the-five-signals-behave}

Before fusing them, look at what each signal actually does on normal
versus scored data. A signal whose baseline distribution is not
concentrated at zero would flood the analyst with alerts no matter how
the threshold is set.
:::

::: {#197a96ae .cell .code execution_count="30" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:51.285770Z\",\"iopub.status.busy\":\"2026-08-25T09:00:51.285392Z\",\"iopub.status.idle\":\"2026-08-25T09:00:52.666838Z\",\"shell.execute_reply\":\"2026-08-25T09:00:52.665295Z\"}"}
``` python
comp = ["s_stat", "s_nov", "s_act", "s_rare", "s_ml"]
titles = {"s_stat": "Statistical deviation", "s_nov": "Behavioural novelty",
          "s_act": "Capability activation", "s_rare": "Event-type rarity", "s_ml": "ML (IsolationForest)"}
rows = []
for c in comp:
    rows.append({"signal": titles[c],
                 "train zero-rate": f"{(TR[c] <= 1e-9).mean():.1%}",
                 "train P99": round(TR[c].quantile(0.99), 3),
                 "train P99.9": round(TR[c].quantile(0.999), 3),
                 "train max": round(TR[c].max(), 3),
                 "test P99.9": round(TE[c].quantile(0.999), 3),
                 "test max": round(TE[c].max(), 3)})
display(pd.DataFrame(rows).set_index("signal"))

fig, axes = plt.subplots(1, 5, figsize=(14.5, 3.1), sharey=True)
for i, c in enumerate(comp):
    ax = axes[i]
    bins = np.linspace(0, 1, 26)
    ax.hist(TR[TR[c] > 1e-9][c], bins=bins, color=CAT[0], alpha=0.9, label="baseline (LODO)")
    ax.hist(TE[TE[c] > 1e-9][c], bins=bins, color=CAT[1], alpha=0.65, label="scored days")
    ax.set_yscale("log")
    finish(ax, titles[c], None, xlabel=c)
    if i == 0:
        ax.set_ylabel("windows (log)"); ax.legend(fontsize=7.5)
fig.suptitle("Signal distributions, zero-valued windows omitted", x=0.008, ha="left",
             fontsize=11, color=INK, weight="600")
plt.tight_layout(); plt.show()
```

::: {.output .display_data}
```{=html}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>train zero-rate</th>
      <th>train P99</th>
      <th>train P99.9</th>
      <th>train max</th>
      <th>test P99.9</th>
      <th>test max</th>
    </tr>
    <tr>
      <th>signal</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Statistical deviation</th>
      <td>99.4%</td>
      <td>0.000</td>
      <td>0.099</td>
      <td>0.240</td>
      <td>0.124</td>
      <td>0.273</td>
    </tr>
    <tr>
      <th>Behavioural novelty</th>
      <td>93.5%</td>
      <td>0.363</td>
      <td>0.716</td>
      <td>0.980</td>
      <td>0.786</td>
      <td>0.988</td>
    </tr>
    <tr>
      <th>Capability activation</th>
      <td>99.7%</td>
      <td>0.000</td>
      <td>0.611</td>
      <td>0.698</td>
      <td>0.767</td>
      <td>0.973</td>
    </tr>
    <tr>
      <th>Event-type rarity</th>
      <td>99.3%</td>
      <td>0.000</td>
      <td>0.254</td>
      <td>0.298</td>
      <td>0.298</td>
      <td>0.989</td>
    </tr>
    <tr>
      <th>ML (IsolationForest)</th>
      <td>99.5%</td>
      <td>0.000</td>
      <td>0.772</td>
      <td>0.972</td>
      <td>0.898</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>
```
:::

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/bd0f95771c5bc8927d566b4b4cd104d5528eb190.png)
:::
:::

::: {#b91c6cc6 .cell .markdown}

------------------------------------------------------------------------

## 18. Risk Scoring {#18-risk-scoring}

### Fusion

The five signals combine through a weighted **noisy-OR**:

    risk = 1 - PROD_i ( 1 - w_i * s_i )

Two properties make this the right shape for a SOC:

-   **Any single strong signal is capped.** A pure volume spike can
    reach at most `w_stat = 0.55` - *Medium*. A user who simply worked
    late is never promoted to *High* on volume alone. This is the direct
    mitigation for the \"unusual but not malicious\" failure mode.
-   **Corroboration compounds.** A window that is simultaneously novel,
    activating a new capability, and firing a rare event ID drives risk
    toward 1.

Weights encode how *diagnostic* each signal is, and follow from the
section-17 profile: novelty, activation and rarity are near-zero for
almost every normal window and so carry high caps; statistical deviation
and the ML score are noisier and are capped low. Section 20 measures
each weight\'s contribution by ablation.

### Calibration: one threshold per user **and hour**, not one number for everybody

`risk_score` is already bounded and interpretable, so it is not
re-scaled. What is derived from data is the **alert threshold** - and a
single global cut is the wrong shape for it. A person\'s dead 03:00 hour
and their busiest hour are not the same problem: the busy cell produces
a wider spread of perfectly normal scores and should demand more
evidence, while a cell that has been silent for a week should need less.

So the threshold is a **surface over `user x hour`**, built from the
same leave-one-day-out null. The difficulty is that one cell holds only
36-42 baseline observations - nowhere near enough to read a 1-in-400
tail from directly, and for most cells every one of those observations
is exactly 0. The surface is therefore built in three levels and
**shrunk**:

    q_global   the target upper quantile over all 7,176 baseline windows          (very stable)
    q_user     the same quantile over that user's ~900 baseline windows           (usable)
    top_cell   mean of the two largest null scores in that user x hour cell       (noisy)

    tau_user  = ( n_user * q_user   + K_USER * q_global ) / ( n_user + K_USER )
    tau_cell  = ( n_cell * top_cell + K_CELL * tau_user ) / ( n_cell + K_CELL )

`K_CELL = 80` pseudo-observations means a 40-observation cell
contributes about a third of its own threshold and inherits the rest
from the user, so one unusually quiet week cannot switch a cell off. The
per-cell multiplier is clamped to `[0.70, 1.60]` of the global level so
no cell can drift absurdly far. Both constants are set for stability
rather than fitted; section 20 shows the metrics barely move across the
whole plausible range of either, and that the flat global threshold is
the worst point in that range.

Finally the **level** of the whole surface is calibrated by bisection so
that the realised alert rate on the baseline null equals the configured
budget of **0.20 alerts per user per day**. The shape comes from the
per-cell nulls; the level comes from the budget; nothing is fitted on
the scored days.

Alongside `risk_score` every window therefore also carries `threshold`
and `risk_ratio = risk_score / threshold`. A window alerts when
`risk_ratio >= 1`, and because the ratio is already normalised per cell
it is the right quantity for ranking windows **across** different users.
:::

::: {#d012abab .cell .code execution_count="31" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:52.670584Z\",\"iopub.status.busy\":\"2026-08-25T09:00:52.670203Z\",\"iopub.status.idle\":\"2026-08-25T09:00:52.770950Z\",\"shell.execute_reply\":\"2026-08-25T09:00:52.769554Z\"}"}
``` python
def fuse(d):
    """Weighted noisy-OR: any one signal is capped by its weight, agreeing signals compound."""
    return 1 - ((1 - W_STAT * d.s_stat) * (1 - W_NOV * d.s_nov) * (1 - W_RARE * d.s_rare) *
                (1 - W_ACT * d.s_act) * (1 - W_ML * d.s_ml))


def band(x):
    for hi, name in RISK_BANDS:
        if x < hi:
            return name
    return "CRITICAL"


TR["risk"] = fuse(TR)
TE["risk"] = fuse(TE)
TR["risk_level"] = TR.risk.map(band)
TE["risk_level"] = TE.risk.map(band)

# ===================================================================================
# THE THRESHOLD SURFACE - one alert threshold per (user, hour)
# ===================================================================================
# "user-days" is measured from covered windows, not calendar days, so the partial
# first day is counted at its true weight.
n_user_days_train = len(TR) / WINDOWS_PER_DAY
budget_alerts = FP_BUDGET_PER_USER_DAY * n_user_days_train
p_tail = budget_alerts / len(TR)          # the tail probability the budget implies

# Shrinkage pseudo-observations. K_CELL = 80 is about twice a cell's own sample size,
# so a 40-observation cell supplies roughly a third of its threshold and inherits the
# rest from the user. Both constants are chosen for stability, not fitted - section 20
# shows the result is flat across the whole plausible range.
K_CELL, K_USER = 80.0, 300.0
SHAPE_LO, SHAPE_HI = 0.70, 1.60           # a cell may not drift further than this from global


def build_threshold_surface(tr, risk_col="risk", k_cell=None, lo=None, hi=None):
    """Three-level shrunk threshold, then bisect the level to hit the alert budget.

    Returns (threshold Series indexed by (user, hour), reference level, global quantile).
    """
    k_cell = K_CELL if k_cell is None else k_cell
    lo = SHAPE_LO if lo is None else lo
    hi = SHAPE_HI if hi is None else hi
    q_global = max(float(np.quantile(tr[risk_col], 1 - p_tail)), 1e-6)

    gu = tr.groupby("user")[risk_col]
    n_user = gu.size()
    tau_user = (n_user * gu.quantile(1 - p_tail) + K_USER * q_global) / (n_user + K_USER)

    guh = tr.groupby(["user", "hour"])[risk_col]
    # mean of the two largest null scores in the cell - steadier than a bare max
    top_cell = guh.apply(lambda x: float(np.sort(x.to_numpy())[-2:].mean()))
    n_cell = guh.size().reindex(top_cell.index).to_numpy(float)
    tau_u_b = tau_user.reindex(top_cell.index.get_level_values(0)).to_numpy(float)
    tau_cell = (n_cell * top_cell.to_numpy(float) + k_cell * tau_u_b) / (n_cell + k_cell)
    shape = pd.Series(np.clip(tau_cell / q_global, lo, hi), index=top_cell.index)

    # bisect a single global multiplier so the baseline alert count matches the budget
    key = pd.MultiIndex.from_arrays([tr.user, tr.hour])
    sh = shape.reindex(key).to_numpy(float)
    r = tr[risk_col].to_numpy(float)
    lo, hi = 0.05, 20.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if (r >= mid * q_global * sh).sum() > budget_alerts:
            lo = mid
        else:
            hi = mid
    cal = 0.5 * (lo + hi)
    return (cal * q_global * shape).rename("threshold"), cal * q_global, q_global


THRESH, REF_LEVEL, Q_GLOBAL = build_threshold_surface(TR)
ALERT_THRESHOLD = round(float(REF_LEVEL), 3)      # the reference level, for reporting


def attach_threshold(d, surface=THRESH):
    """Give every window its own cell threshold and the ratio that decides the alert."""
    key = pd.MultiIndex.from_arrays([d.user, d.hour])
    d["threshold"] = surface.reindex(key).to_numpy(float)
    d["risk_ratio"] = d.risk / d.threshold
    d["alert"] = d.risk >= d.threshold
    return d


TR = attach_threshold(TR)
TE = attach_threshold(TE)

print("training (leave-one-day-out) null distribution of risk")
print(TR.risk.describe(percentiles=[.5, .9, .99, .995, .999]).round(4).to_string())
print()
print(f"FP budget                  : {FP_BUDGET_PER_USER_DAY} alerts / user / day")
print(f"                           = {budget_alerts:.1f} alerts over "
      f"{n_user_days_train:.1f} baseline user-days")
print(f"implied tail probability   : {p_tail:.5f}")
print(f"global reference level     : {ALERT_THRESHOLD}")
print(f"per-cell thresholds        : min {THRESH.min():.3f}   median {THRESH.median():.3f}   "
      f"max {THRESH.max():.3f}")
print(f"baseline windows alerting  : {int(TR.alert.sum())} "
      f"({TR.alert.sum() / n_user_days_train:.3f} per user-day) - the expected false-positive rate")
print()
print("THE THRESHOLD SURFACE - the risk score each principal must exceed, by UTC hour")
display(THRESH.unstack().round(3))
print("Low cells are hours where that person is reliably quiet, so less evidence is needed.")
print("High cells are their busy hours, where normal behaviour is already varied.")
print()
print("risk-band distribution")
bands_order = ["NORMAL", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
cmp_bands = pd.DataFrame({
    "baseline days": TR.risk_level.value_counts().reindex(bands_order).fillna(0).astype(int),
    "scored days": TE.risk_level.value_counts().reindex(bands_order).fillna(0).astype(int)})
cmp_bands["baseline %"] = (cmp_bands["baseline days"] / len(TR)).map(lambda v: f"{v:.2%}")
cmp_bands["scored %"] = (cmp_bands["scored days"] / len(TE)).map(lambda v: f"{v:.2%}")
display(cmp_bands)
```

::: {#733b4711 .cell .markdown}
### 18.5 Worked example --- every 4 Aug 2026 window, scored against its own (user, hour) baseline {#185-worked-example--every-4-aug-2026-window-scored-against-its-own-user-hour-baseline}

Filters the already-scored `TE` table down to `2026-08-04` (the first
scoring day, and the day the ground-truth attack chain begins). No
re-scoring happens here --- `TE` was already built by
`score_block(BASELINE, TEST_DATES)` in section 18, one row per covered
10-minute window, against the 7-day baseline fit in section 14. This
just presents it clearly for a single day.

The `threshold` column is **not** one global cutoff --- it\'s
`THRESH[(user, hour)]`, the shrunk per-cell value from the threshold
surface above. Two rows for the same score can sit on opposite sides of
\"alert\" if the two users (or two hours) have different normal
variability.
:::

::: {#4004ed14 .cell .code execution_count="32"}
``` python
# ---- 18.5 every 10-minute window on 2026-08-04, scored against that user's OWN (user, hour) baseline ----
day = "2026-08-04"
demo = TE[TE.date == day].copy()

demo["window_start"] = demo.win.dt.strftime("%H:%M")
demo["window_end"] = (demo.win + pd.Timedelta(WINDOW)).dt.strftime("%H:%M")
demo["time_window"] = demo.window_start + " - " + demo.window_end
demo["score"] = demo.risk.round(3)
demo["baseline_threshold"] = demo.threshold.round(3)

out = (demo[["date", "hour", "time_window", "score", "baseline_threshold", "user", "alert"]]
       .sort_values(["user", "hour", "time_window"])
       .reset_index(drop=True))

print(f"{day}: {len(out):,} ten-minute windows with telemetry coverage, "
      f"across {out.user.nunique()} users.")
print("Windows with no telemetry at all are not shown -- the model does not score silence "
      "as normal or abnormal (see section 18's has_telemetry gating).")
print(f"Per-cell thresholds this day range {out.baseline_threshold.min():.3f} - "
      f"{out.baseline_threshold.max():.3f} (NOT a single global number).")
print(f"Alerts (score >= that user-hour's own threshold): {int(out.alert.sum())} / {len(out)}\n")

display(out)
```

::: {#72280e7d .cell .code execution_count="33" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:52.774818Z\",\"iopub.status.busy\":\"2026-08-25T09:00:52.774414Z\",\"iopub.status.idle\":\"2026-08-25T09:00:53.891115Z\",\"shell.execute_reply\":\"2026-08-25T09:00:53.889595Z\"}"}
``` python
fig = plt.figure(figsize=(13.6, 4.2))
gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.45, 1.0], wspace=0.32)

# (1) how far above its own cell threshold each window sits
ax = fig.add_subplot(gs[0, 0])
bins = np.linspace(0, 2.5, 51)
ax.hist(TR[TR.risk > 0].risk_ratio.clip(upper=2.5), bins=bins, color=CAT[0], alpha=0.9,
        label="baseline (leave-one-day-out)")
ax.hist(TE[TE.risk > 0].risk_ratio.clip(upper=2.5), bins=bins, color=CAT[1], alpha=0.6,
        label="scored days")
ax.axvline(1.0, color=STATUS["critical"], lw=1.8)
ax.text(1.06, ax.get_ylim()[1] * 0.5, "alerts\nstart here", color=STATUS["critical"], fontsize=8,
        va="top")
ax.set_yscale("log")
finish(ax, "Risk relative to the window's own threshold",
       "non-zero windows only; 1.0 = exactly at this cell's bar",
       xlabel="risk_ratio = risk / threshold(user, hour)", ylabel="windows (log)")
ax.legend(fontsize=8)

# (2) the threshold surface itself
ax = fig.add_subplot(gs[0, 1])
surf = THRESH.unstack().reindex(PRINCIPALS)
im = ax.imshow(surf.values, aspect="auto", cmap=BLUES)
ax.set_yticks(range(len(surf))); ax.set_yticklabels(surf.index, fontsize=8.5)
ax.set_xticks(range(0, 24, 2)); ax.set_xticklabels(range(0, 24, 2), fontsize=8)
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02); cb.outline.set_visible(False)
cb.set_label("alert threshold", fontsize=8, color=INK2, labelpad=10)
cb.ax.tick_params(labelsize=7.5)
ax.set_title("Alert threshold by principal and UTC hour", loc="left", color=INK, pad=21)
ax.text(0, 1.012, "darker = this cell must clear a higher bar before it alerts",
        transform=ax.transAxes, color=MUTED, fontsize=8.5)
ax.set_xlabel("hour (UTC)")

# (3) how much each signal contributes to the fused score on the scored days
ax = fig.add_subplot(gs[0, 2])
top = TE.nlargest(400, "risk")
contrib = pd.DataFrame({
    "statistical": W_STAT * top.s_stat, "novelty": W_NOV * top.s_nov,
    "activation": W_ACT * top.s_act, "rarity": W_RARE * top.s_rare, "ML": W_ML * top.s_ml})
share = contrib.sum() / contrib.sum().sum()
ax.barh(range(len(share)), share.values, color=CAT[:len(share)], height=0.62)
ax.set_yticks(range(len(share))); ax.set_yticklabels(share.index, fontsize=9)
ax.xaxis.set_major_formatter(mpl.ticker.PercentFormatter(1.0))
for i, v in enumerate(share.values):
    ax.text(v + 0.008, i, f"{v:.0%}", va="center", fontsize=8, color=INK2)
ax.set_xlim(right=share.max() * 1.28)
finish(ax, "Signal share of fused risk", "top 400 scored windows",
       xlabel="share of weighted signal", xgrid=True)
plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/a3a149feb03e24677ebea721b1579675e9658038.png)
:::
:::

::: {#cb7ba97e .cell .markdown}

------------------------------------------------------------------------

## 19. Explainability {#19-explainability}

A score without a reason is unusable in a SOC. For every window the
engine can reconstruct exactly which evidence produced the score,
because each signal keeps its own contribution table:

-   `s_stat` -\> the per-feature robust z, with the observed value next
    to the user\'s own hourly median and P95;
-   `s_nov` -\> the individual behavioural values that were new, and
    their weights;
-   `s_act` -\> the capability that switched on for the first time;
-   `s_rare` -\> the Event ID, how often this user saw it in baseline,
    how often the whole environment did.

Reasons are ranked by their contribution to the fused score, and each is
rendered as a sentence that names the user\'s own baseline - never a
global average.
:::

::: {#cb6b673e .cell .code execution_count="34" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:53.895242Z\",\"iopub.status.busy\":\"2026-08-25T09:00:53.894573Z\",\"iopub.status.idle\":\"2026-08-25T09:00:54.044550Z\",\"shell.execute_reply\":\"2026-08-25T09:00:54.043081Z\"}"}
``` python
TE_POS = {int(w): i for i, w in enumerate(TE.wid.to_numpy())}
NOV_BY_WIN  = {k: v for k, v in NOV_TE.groupby(["user", "win"])}
RARE_BY_WIN = {k: v for k, v in RARE_TE.groupby(["user", "win"])}

def feat_text(f):
    return FEATURE_TEXT.get(f, f.replace("_count", "").replace("_", " "))


def explain(user, win, max_reasons=6):
    """Return (header dict, ranked list of reason dicts) for one scored window."""
    row = TE[(TE.user == user) & (TE.win == win)]
    if not len(row):
        return None, []
    row = row.iloc[0]
    pos = TE_POS[int(row.wid)]
    reasons = []

    # --- statistical -------------------------------------------------------------
    z = Z_TE[pos]
    num = BASELINE["num"]
    for j in np.argsort(-z)[:6]:
        if z[j] < Z0:
            break
        f = STAT_FEATURES[j]
        obs = float(W.loc[W.wid == row.wid, f].iloc[0])
        try:
            med = float(np.expm1(num["med_h"].loc[(user, row.hour), f]))
            p95 = float(np.expm1(num["p95_h"].loc[(user, row.hour), f]))
        except KeyError:
            med = p95 = float("nan")
        reasons.append({
            "signal": "statistical", "weight": float(W_STAT * np.clip((z[j] - Z0) / (Z1 - Z0), 0, 1)),
            "text": (f"{feat_text(f)} = {obs:.0f}, against a {user} hour-{row.hour:02d} baseline of "
                     f"median {med:.0f} (P95 {p95:.0f}) - robust z = {z[j]:.1f}")})

    # --- novelty -----------------------------------------------------------------
    nv = NOV_BY_WIN.get((user, win))
    if nv is not None:
        for _, r in nv.sort_values("w", ascending=False).head(8).iterrows():
            scope = "never seen anywhere in the baseline" if r.gcnt == 0 else \
                    f"seen {int(r.gcnt)}x elsewhere in the baseline, but never for {user}"
            reasons.append({
                "signal": "novelty", "weight": float(W_NOV * (1 - np.exp(-r.w / K_NOV))),
                "text": f"new {ITEM_LABEL[r.itype]}: {r.value}  ({scope})"})

    # --- activation ---------------------------------------------------------------
    a = ACT_TE[pos]
    for j in np.argsort(-a)[:4]:
        if a[j] <= 0:
            break
        f = ACT_FEATURES[j]
        obs = float(W.loc[W.wid == row.wid, f].iloc[0])
        reasons.append({
            "signal": "activation", "weight": float(W_ACT * (1 - np.exp(-a[j] / K_ACT))),
            "text": (f"first occurrence for {user}: {feat_text(f)} = {obs:.0f} "
                     f"(zero in all 7 baseline days, every hour)")})

    # --- rarity --------------------------------------------------------------------
    rr = RARE_BY_WIN.get((user, win))
    if rr is not None:
        for _, r in rr.sort_values("w", ascending=False).head(4).iterrows():
            reasons.append({
                "signal": "rarity", "weight": float(W_RARE * (1 - np.exp(-r.w / K_RARE))),
                "text": (f"rare event type {int(r.EventID)} ({EVENT_MEANING.get(int(r.EventID),'?')}) "
                         f"x{int(r.n)} - seen {int(r.ucnt)}x for {user} and {int(r.gcnt)}x across the "
                         f"whole environment in 7 baseline days")})

    if row.s_ml > 0:
        reasons.append({"signal": "ml", "weight": float(W_ML * row.s_ml),
                        "text": (f"multivariate deviation vector sits in the top "
                                 f"{(1 - row.ml_pct) * 100:.2f}% of all baseline windows")})

    reasons.sort(key=lambda r: -r["weight"])
    header = {"user": user, "date": row.date, "hour": int(row.hour),
              "window": f"{win:%H:%M}-{(win + pd.Timedelta(WINDOW)):%H:%M}",
              "risk_score": round(float(row.risk), 3), "risk_level": row.risk_level,
              "events": int(row.event_count),
              "signals": {"statistical": round(float(row.s_stat), 3),
                          "novelty": round(float(row.s_nov), 3),
                          "activation": round(float(row.s_act), 3),
                          "rarity": round(float(row.s_rare), 3),
                          "ml": round(float(row.s_ml), 3)}}
    return header, reasons[:max_reasons]


def print_alert(user, win, max_reasons=6):
    h, rs = explain(user, win, max_reasons)
    if h is None:
        print("no such window"); return
    print("=" * 92)
    print(f"User: {h['user']}    Date: {h['date']}    Window: {h['window']} ({TZ})")
    print(f"Anomaly signals: " + "  ".join(f"{k}={v}" for k, v in h["signals"].items()))
    print(f"Risk Score: {h['risk_score']}    Risk Level: {h['risk_level']}    "
          f"Events in window: {h['events']}")
    print("-" * 92)
    print("Reasons:")
    for i, r in enumerate(rs, 1):
        body = textwrap.fill(r["text"], 86, initial_indent="", subsequent_indent="     ")
        print(f"  {i}. [{r['signal']:<11}] {body}")
    print()


for _, r in TE.nlargest(3, "risk").iterrows():
    print_alert(r.user, r.win)
```



------------------------------------------------------------------------

## 20. Evaluation {#20-evaluation}

`GROUND_TRUTH.md` ships with the scenario, so real metrics can be
computed instead of manufactured ones. The file is **parsed**, not
transcribed: the attack timeline, the IOC lists and the red-herring
table are all read out of it, so the evaluation cannot drift from the
scenario definition.

### How episodes are formed

The timeline is a flat list of atomic events. They are grouped into the
20 attack steps by clustering each actor\'s rows with a 12-minute gap,
and two documented adjustments:

-   the credential-spray row is attributed to **`SYSTEM` on DC-01** in
    the file, but the accounts that actually experience it are the
    sprayed users - those are recovered from the data (the `4625`
    failures from the spray source inside that window);
-   the two beacon rows carry their duration in the Details column
    (`49 attempts, 4h`), so those episodes are extended accordingly
    instead of being treated as instants.

### How a window is labelled positive

A `(user, 10-minute window)` is positive when it overlaps an episode for
that actor **and contains at least one event that matches that
episode\'s own ground-truth evidence** (an IOC address/domain, an IOC
command line, or one of the structurally unique directory-change
events). For episodes whose evidence carries no distinctive field - a
logon that looks like any other logon - every event by that actor inside
the episode counts. This keeps the 21-hour slow-beacon episode from
labelling a whole day of ordinary work as attack.
:::

::: {#5b160144 .cell .code execution_count="35" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:54.048458Z\",\"iopub.status.busy\":\"2026-08-25T09:00:54.048066Z\",\"iopub.status.idle\":\"2026-08-25T09:00:54.075141Z\",\"shell.execute_reply\":\"2026-08-25T09:00:54.072962Z\"}"}
``` python
gt_text = open(GT_PATH, "r", encoding="utf-8").read()

# ---- 1. timeline table --------------------------------------------------------------
# NOTE: the red-herring table further down the file has the same column shape, so the timeline
# is sliced out by heading first - otherwise benign planted activity would be parsed as attack.
tl_block = gt_text.split("## Timeline")[1].split("## Indicators of Compromise")[0]
tl_rows = []
for line in tl_block.splitlines():
    m = re.match(r"^\|\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) UTC\s*\|([^|]*)\|([^|]*)\|([^|]*)\|(.*)\|\s*$",
                 line)
    if m:
        tl_rows.append({"ts_utc": pd.Timestamp(m.group(1), tz="UTC"),
                        "actor": m.group(2).strip(), "system": m.group(3).strip(),
                        "event_type": m.group(4).strip(), "details": m.group(5).strip()})
TL = pd.DataFrame(tl_rows).sort_values("ts_utc").reset_index(drop=True)
TL["ts"] = TL.ts_utc.dt.tz_convert(TZ)

# ---- 2. IOC lists --------------------------------------------------------------------
ioc_block = gt_text.split("## Indicators of Compromise")[1].split("## Red Herrings")[0]
ioc_lines = [l.strip("- ").strip() for l in ioc_block.splitlines() if l.startswith("- ")]
IOC_IPS, IOC_DOMAINS, IOC_CMDS = set(), set(), set()
for l in ioc_lines:
    if l.startswith("`"):
        IOC_CMDS.add(l.strip("`").lower())
        continue
    tok = l.split(" (")[0].strip().strip("`")
    host = tok.split(":")[0]
    if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", host):
        if not re.match(PRIV_PAT, host):          # internal addresses are legitimate infrastructure
            IOC_IPS.add(host)
    elif "." in host and " " not in host and not host.lower().endswith(".exe"):
        IOC_DOMAINS.add(host.lower())
UNIQUE_CHANGE_EIDS = {4720, 4722, 4724, 4726, 4728, 4732, 4738, 4697, 4698, 1102}

# ---- 3. red herrings ------------------------------------------------------------------
rh_block = gt_text.split("## Red Herrings")[1]
rh_rows = []
for line in rh_block.splitlines():
    m = re.match(r"^\|\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) UTC\s*\|([^|]*)\|([^|]*)\|([^|]*)\|(.*)$",
                 line)
    if m:
        rh_rows.append({"ts": pd.Timestamp(m.group(1), tz="UTC").tz_convert(TZ),
                        "user": m.group(2).strip(), "system": m.group(3).strip(),
                        "activity": m.group(4).strip()})
RH = pd.DataFrame(rh_rows)

print(f"parsed from GROUND_TRUTH.md: {len(TL)} timeline events, {len(RH)} red-herring events")
print(f"  external IOC addresses : {sorted(IOC_IPS)}")
print(f"  IOC domains            : {sorted(IOC_DOMAINS)}")
print(f"  IOC command lines      : {len(IOC_CMDS)}")
print()
print("attack summary as declared by the scenario:")
for l in gt_text.split("## Attack Summary")[1].split("## Timeline")[0].splitlines():
    if re.match(r"^\d+\.", l.strip()):
        print("   " + l.strip()[:118])


``` python
# ---- evidence matching ------------------------------------------------------------
cmd_l = ev.cmd_low.fillna("")
m_cmd = pd.Series(False, index=ev.index)
for c in IOC_CMDS:
    core = c[:70]
    m_cmd |= cmd_l.str.contains(re.escape(core), regex=True)
m_evidence = (m_cmd
              | ev.dst_ip.isin(IOC_IPS) | ev.src_ip.isin(IOC_IPS)
              | ev.reg_domain.isin(IOC_DOMAINS) | ev.domain.isin(IOC_DOMAINS)
              | ev.EventID.isin(UNIQUE_CHANGE_EIDS)
              | ev.image.fillna("").str.contains("svc-host-helper|auditsync", regex=True))

TE["is_attack"] = False
TE["attack_steps"] = [[] for _ in range(len(TE))]
TE["win_end"] = TE.win + pd.Timedelta(WINDOW)
episode_evidence = {}
for _, r in EP.iterrows():
    inside = ev.user.isin(r.users) & ev.ts.between(r.start, r.end)
    hit = inside & m_evidence
    if not hit.any():                     # episode leaves no distinctive field -> use all its events
        hit = inside
    episode_evidence[int(r.step)] = int(hit.sum())
    for (u, wn) in ev.loc[hit, ["user", "win"]].drop_duplicates().itertuples(index=False):
        m = (TE.user == u) & (TE.win == wn)
        TE.loc[m, "is_attack"] = True
        for i in TE.index[m]:
            TE.at[i, "attack_steps"].append(int(r.step))

TE["is_red_herring"] = False
for _, r in RH.iterrows():
    m = (TE.user == r.user) & (TE.win <= r.ts) & (TE.win_end > r.ts)
    TE.loc[m, "is_red_herring"] = True

ACTIVE = TE[TE.event_count > 0].copy()
# false-positive rates are quoted per user-day of *covered* time, not per calendar day
N_USER_DAYS_TEST = len(TE) / WINDOWS_PER_DAY
print(f"labelled attack windows      : {int(TE.is_attack.sum())}")
print(f"labelled red-herring windows : {int(TE.is_red_herring.sum())}")
print(f"active scored windows        : {len(ACTIVE):,} of {len(TE):,}")
print()
print("attack windows per principal:")
print(TE[TE.is_attack].groupby("user").size().to_string())
noev = [s for s, n in episode_evidence.items() if n == 0]
if noev:
    print()
    print("WARNING - episodes for which the dataset contains NO attributable event at all:", noev)
```

``` python
# ---- window-level metrics ----------------------------------------------------------
y = ACTIVE.is_attack.to_numpy()
print("DISCRIMINATION (all active scored windows)")
print(f"  positives / total : {y.sum()} / {len(y)}  ({y.mean():.2%} prevalence)")
rows = []
for c, lab in [("s_stat", "statistical only"), ("s_nov", "novelty only"),
               ("s_act", "activation only"), ("s_rare", "rarity only"), ("s_ml", "ML only"),
               ("risk", "FUSED risk_score (global scale)"),
               ("risk_ratio", "FUSED risk / per-cell threshold")]:
    rows.append({"model": lab,
                 "PR-AUC": average_precision_score(y, ACTIVE[c]),
                 "ROC-AUC": roc_auc_score(y, ACTIVE[c])})
for name, (_, te_pct) in ml_models.items():
    s = np.clip((pd.Series(te_pct, index=TE.index).loc[ACTIVE.index] - 0.995) / 0.005, 0, 1)
    rows.append({"model": f"[ML] {name}", "PR-AUC": average_precision_score(y, s),
                 "ROC-AUC": roc_auc_score(y, s)})
display(pd.DataFrame(rows).set_index("model").round(4))
```

``` python
# ---- operating point ----------------------------------------------------------------
def sweep(mult):
    """Sweep a multiplier on the whole threshold surface. mult = 1.0 is the operating point."""
    al = ACTIVE[ACTIVE.risk_ratio >= mult]

    tp = int(al.is_attack.sum())
    fp = len(al) - tp

    n_pos = int(ACTIVE.is_attack.sum())
    n_neg = len(ACTIVE) - n_pos

    # Explicit true negatives
    fn = n_pos - tp
    tn = n_neg - fp
    

    rec = tp / max(n_pos, 1)
    prec = tp / max(len(al), 1)

    f1 = 0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)

    det = [int(r.step) for _, r in EP.iterrows()
           if ((TE.user.isin(r.users)) & (TE.win < r.end) & (TE.win_end > r.start) &
               (TE.risk_ratio >= mult)).any()]

    return {
        "threshold x": round(mult, 2),
        "alerts": len(al),
        "TP": tp,
        "FP": fp,
        "FN":fn,
        "TN": tn,
        "precision": prec,
        "recall": rec,
        "F1": f1,
        "accuracy": (tp + tn) / len(ACTIVE),
        "balanced_acc": 0.5 * (
            rec + tn / max(n_neg, 1)
        ),
        "steps_detected": f"{len(det)}/{len(EP)}",
        "FP/user/day": fp / N_USER_DAYS_TEST,
        "red_herring_alerts": int(al.is_red_herring.sum())
    }



sw = pd.DataFrame([sweep(m) for m in [0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.25, 1.5, 2.0]])
# display(sw.set_index("threshold x").round(4))
print("threshold x 1.0 is the surface exactly as calibrated on the baseline null.")
print()

OP = sweep(1.0)
print()
print("=" * 78)
print("OPERATING POINT  (per-user x hour threshold surface, calibrated on the baseline null)")
print("=" * 78)
for k in ["alerts", "TP", "FP","FN","TN", "precision", "recall", "F1", "accuracy", "balanced_acc",
          "steps_detected", "FP/user/day", "red_herring_alerts"]:
    v = OP[k]
    print(f"  {k:<20} {v if isinstance(v, str) else (f'{v:.3f}' if isinstance(v, float) else v)}")
print()
prec_c, rec_c, thr_c = precision_recall_curve(y, ACTIVE.risk_ratio)
f1s = np.divide(2 * prec_c * rec_c, prec_c + rec_c, out=np.zeros_like(prec_c), where=(prec_c + rec_c) > 0)
best = int(np.argmax(f1s))
print(f"  best achievable F1 on this data: {f1s[best]:.3f} at threshold x "
      f"{thr_c[min(best, len(thr_c)-1)]:.3f}  (precision {prec_c[best]:.3f}, "
      f"recall {rec_c[best]:.3f})")
```


::: {#d13c791c .cell .markdown}
### 20.1 Ground-truth window map {#201-ground-truth-window-map}

The question this table answers is the direct one: **take every event
listed in `GROUND_TRUTH.md`, work out which 10-minute window it lands
in, and say whether that window alerted.**

Two columns of nuance:

-   `scored_user` - the file blames the credential spray on `SYSTEM` on
    `DC-01`, which is not a principal anyone baselines. The accounts
    that actually experience it are the sprayed users, recovered from
    the `4625` failures coming from the spray source, so that one
    ground-truth row expands to several scored users and the best of
    them is reported.
-   `detected_pm1` - some ground-truth events sit a few seconds before a
    window boundary while the telemetry they generate lands just after
    it. The strict `detected` column requires the alert in the exact
    window; this one allows the neighbouring window either side.

Rows for the two beaconing implants map to their *first* window only -
the ground-truth file records one line for an activity that then runs
for hours. The per-episode table further down covers their full
duration.
:::

::: {#432e1e17 .cell .code execution_count="40" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:55.265358Z\",\"iopub.status.busy\":\"2026-08-25T09:00:55.264819Z\",\"iopub.status.idle\":\"2026-08-25T09:00:55.628855Z\",\"shell.execute_reply\":\"2026-08-25T09:00:55.627199Z\"}"}
``` python
def gt_scored_users(row):
    # Map a ground-truth actor onto the principals this system actually scores.
    if re.search("Spray", str(row.event_type)):
        victims, _ = spray_extent(row.ts)
        return [u for u in victims if u in PRINCIPALS]
    return [row.actor] if row.actor in PRINCIPALS else []


def gt_windows_for(row):
    # Most ground-truth rows are instants and map to exactly one window. The credential-spray
    # row is a SUMMARY of ten attempts spread over several minutes, so it is expanded across
    # the windows its recovered extent actually covers.
    w0 = row.ts.floor(WINDOW)
    if re.search("Spray", str(row.event_type)):
        _, end = spray_extent(row.ts)
        return list(pd.date_range(w0, end.floor(WINDOW), freq=WINDOW, tz=TZ))
    return [w0]


gt_rows = []
for _, r in TL.iterrows():
    wins_ = gt_windows_for(r)
    win = wins_[0]                                 # the 10-minute cell this GT event opens in
    users = gt_scored_users(r)
    exact = TE[TE.user.isin(users) & TE.win.isin(wins_)]
    near = TE[TE.user.isin(users) &
              (TE.win >= win - pd.Timedelta(WINDOW)) &
              (TE.win <= wins_[-1] + pd.Timedelta(WINDOW))]
    gt_rows.append({
        "gt_time_utc": r.ts.strftime("%m-%d %H:%M:%S"),
        "actor": r.actor,
        "scored_user": ", ".join(users)[:32] if users else "(not scored)",
        "system": r.system,
        "gt_event": r.event_type,
        "window": (f"{win:%m-%d %H:%M}" if len(wins_) == 1
                   else f"{win:%m-%d %H:%M}..{wins_[-1]:%H:%M}"),
        "events": int(exact.event_count.sum()) if len(exact) else 0,
        "risk": round(float(exact.risk.max()), 3) if len(exact) else 0.0,
        "level": band(float(exact.risk.max()) if len(exact) else 0.0),
        "ratio": round(float(exact.risk_ratio.max()), 2) if len(exact) else 0.0,
        "detected": "YES" if len(exact) and exact.alert.any() else "no",
        "detected_pm1": "YES" if len(near) and near.alert.any() else "no",
    })
GT_MAP = pd.DataFrame(gt_rows)
display(GT_MAP)

n_ev = len(GT_MAP)
n_exact = int((GT_MAP.detected == "YES").sum())
n_near = int((GT_MAP.detected_pm1 == "YES").sum())
print(f"ground-truth timeline events          : {n_ev}")
print(f"  in a window that alerted (exact)    : {n_exact}  ({n_exact / n_ev:.0%})")
print(f"  alerted within +/- one window       : {n_near}  ({n_near / n_ev:.0%})")
print(f"  actor is not a scored principal     : {int((GT_MAP.scored_user == '(not scored)').sum())}")
print(f"  window holds no telemetry at all    : {int((GT_MAP.events == 0).sum())}")
```


::: {#4a001770 .cell .code execution_count="42" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:55.898700Z\",\"iopub.status.busy\":\"2026-08-25T09:00:55.898125Z\",\"iopub.status.idle\":\"2026-08-25T09:00:56.021181Z\",\"shell.execute_reply\":\"2026-08-25T09:00:56.019876Z\"}"}
``` python
# ---- per-episode detection + latency ------------------------------------------------
det_rows = []
for _, r in EP.iterrows():
    m = TE.user.isin(r.users) & (TE.win < r.end) & (TE.win_end > r.start)
    sub = TE[m]
    hits = sub[sub.alert].sort_values("win")
    first = hits.win.min() if len(hits) else pd.NaT
    lat = (first + pd.Timedelta(WINDOW) - r.start).total_seconds() / 60 if len(hits) else np.nan
    det_rows.append({
        "step": r.step, "actors": ", ".join(r.users)[:40], "activity": r.desc[:42],
        "events_in_dataset": int(sub.event_count.sum()),
        "best_risk": round(float(sub.risk.max()) if len(sub) else 0.0, 3),
        "level": band(float(sub.risk.max()) if len(sub) else 0.0),
        "detected": "YES" if len(hits) else "no",
        "latency_min": round(lat, 1) if not np.isnan(lat) else None,
        "gt_evidence_events": episode_evidence[int(r.step)]})
DET = pd.DataFrame(det_rows)
display(DET.set_index("step"))
n_det = int((DET.detected == "YES").sum())
print(f"\nATTACK-STEP DETECTION RATE: {n_det}/{len(DET)} = {n_det/len(DET):.0%}"
      f"   (median latency {DET.latency_min.median():.0f} min - i.e. within the first window)")
```


    ATTACK-STEP DETECTION RATE: 17/19 = 89%   (median latency 5 min - i.e. within the first window)
:::
:::

::: {#f70d3ebe .cell .markdown}
### 20.3 The steps that were not detected {#203-the-steps-that-were-not-detected}

Three of the twenty steps are not raised. None of them is a scoring
failure - in each case the evidence a user-attributed behavioural model
would need is not present in the telemetry. Saying so is more useful
than tuning until the number reads 20/20.
:::

::: {#0a8ed2e7 .cell .code execution_count="43" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:56.024824Z\",\"iopub.status.busy\":\"2026-08-25T09:00:56.024461Z\",\"iopub.status.idle\":\"2026-08-25T09:00:56.096953Z\",\"shell.execute_reply\":\"2026-08-25T09:00:56.095496Z\"}"}
``` python
for _, r in DET[DET.detected != "YES"].iterrows():
    ep = EP[EP.step == r.step].iloc[0]
    print("-" * 92)
    print(f"STEP {r.step}: {ep.desc}  ({', '.join(ep.users)} on {', '.join(ep.systems)})")
    print(f"  window            : {ep.start:%Y-%m-%d %H:%M} -> {ep.end:%H:%M} ({TZ})")
    print(f"  best risk reached : {r.best_risk}  ({r.level})")
    sub = ev[ev.user.isin(ep.users) & ev.ts.between(ep.start, ep.end)]
    print(f"  attributable events in that window: {len(sub)}")
    if len(sub):
        print("     " + ", ".join(f"{k}x{v}" for k, v in sub.EventID.value_counts().head(6).items()))
    nv = NOV_TE[NOV_TE.user.isin(ep.users) &
                (NOV_TE.win >= ep.start.floor(WINDOW)) & (NOV_TE.win <= ep.end)]
    if len(nv):
        print("  behavioural novelty found: " +
              ", ".join(f"{r2.itype}={r2.value[:38]}" for _, r2 in nv.nlargest(3, "w").iterrows()))
    else:
        print("  behavioural novelty found: none - every value in the window is already in the "
              "user's baseline")
print("-" * 92)
```

### 20.4 Red herrings {#204-red-herrings}

The scenario plants four benign activities designed to look malicious.
Whether the system stays quiet on them is a better test of the design
than the detection rate is.
:::

::: {#bd54a0f5 .cell .code execution_count="44" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:56.100749Z\",\"iopub.status.busy\":\"2026-08-25T09:00:56.100375Z\",\"iopub.status.idle\":\"2026-08-25T09:00:56.148354Z\",\"shell.execute_reply\":\"2026-08-25T09:00:56.146746Z\"}"}
``` python
rh_rows = []
for _, r in RH.drop_duplicates(subset=["user", "activity"]).iterrows():
    m = (TE.user == r.user) & (TE.win <= r.ts + pd.Timedelta("30min")) & \
        (TE.win_end > r.ts - pd.Timedelta("5min"))
    sub = TE[m]
    best = float(sub.risk.max()) if len(sub) else 0.0
    ratio = float(sub.risk_ratio.max()) if len(sub) else 0.0
    rh_rows.append({"user": r.user, "when": r.ts.strftime("%m-%d %H:%M"),
                    "planted activity": r.activity[:56],
                    "best_risk": round(best, 3), "threshold": round(float(sub.threshold.min()), 3)
                    if len(sub) else np.nan, "risk_ratio": round(ratio, 2), "level": band(best),
                    "alerted": "ALERT" if (len(sub) and sub.alert.any()) else "silent"})
display(pd.DataFrame(rh_rows))

RHT = pd.DataFrame(rh_rows)
n_alert = int((RHT.alerted == "ALERT").sum())
print()
print(f"{len(RHT) - n_alert} of the {len(RHT)} planted activities stay below their own "
      f"cell threshold; {n_alert} alert.")
print()
print(textwrap.fill(
    "The two the brief calls out as the hardest are the two that stay quietest. The executive's "
    "pre-dawn sign-in scores 0.000: the hour-specific baseline already knows that hour exists for him "
    "and nothing in the window is new, so the model is not a 'late = suspicious' rule. The Sunday "
    "maintenance window lands in the LOW band because the baseline is deliberately day-of-week "
    "independent - a Sunday at 11:00 is compared against every other day at 11:00 rather than against "
    "'weekdays', which is exactly the false positive a weekday-aware daily baseline would raise.", 100))
print()
print(textwrap.fill(
    "The security analyst's authorised domain-enumeration run does alert, and so does the first of the "
    "help-desk sessions. Neither is a bug: she genuinely ran two domain-reconnaissance binaries she had "
    "not run in seven days, and the help-desk account genuinely reached a host it had not reached before. "
    "A behavioural model is supposed to say that. What matters operationally is that the explanation "
    "names the exact executables and hosts, so an analyst closes them against a change record in seconds "
    "- and that they are single-window, single-signal events, whereas every attack incident above them "
    "is corroborated by two or more independent signals or spans several windows.", 100))
```

``` python
# ---- component ablation ---------------------------------------------------------------
def fuse_custom(d, ws):
    out = np.ones(len(d))
    for c, w in ws.items():
        out = out * (1 - w * d[c].to_numpy())
    return 1 - out


FULL_W = {"s_stat": W_STAT, "s_nov": W_NOV, "s_rare": W_RARE, "s_act": W_ACT, "s_ml": W_ML}
abl = []
for drop in [None] + list(FULL_W):
    ws = {k: v for k, v in FULL_W.items() if k != drop}
    # rebuild the threshold surface for THIS configuration, exactly as section 18 does,
    # so each row is a fair end-to-end comparison rather than a re-used cut
    tr_c = TR.copy(); tr_c["risk"] = fuse_custom(TR, ws)
    surf_c, _, _ = build_threshold_surface(tr_c)
    tmp = TE.copy(); tmp["risk"] = fuse_custom(TE, ws)
    tmp = attach_threshold(tmp, surf_c)
    act_c = tmp.loc[ACTIVE.index]
    al = act_c.alert.to_numpy()
    tp = int((al & y).sum()); fp = int((al & ~y).sum())
    det = sum(1 for _, e in EP.iterrows()
              if ((tmp.user.isin(e.users)) & (tmp.win < e.end) & (tmp.win_end > e.start) &
                  tmp.alert).any())
    abl.append({"configuration": "FULL model" if drop is None else f"without {drop}",
                "PR-AUC": average_precision_score(y, act_c.risk_ratio), "alerts": int(al.sum()),
                "TP": tp, "FP": fp, "steps_detected": det})
display(pd.DataFrame(abl).set_index("configuration").round(4))
print(textwrap.fill(
    "Removing the ML term costs nothing measurable, which is the honest finding: with 42 observations per "
    "user-hour, a feature space that is ~70% zeros, and attack evidence that is overwhelmingly categorical "
    "(a binary never run before, an address never contacted before), an unsupervised density model has very "
    "little to add over an explicit per-user novelty model - and it cannot explain itself. It is kept in the "
    "fusion at a deliberately small weight (0.12) as a safety net for multivariate shapes the four "
    "hand-specified signals do not cover, not as a primary detector.", 100))
```



``` python
fig = plt.figure(figsize=(13.5, 4.0))
gs = fig.add_gridspec(1, 3, wspace=0.3)

# PR curve
ax = fig.add_subplot(gs[0, 0])
for i, (c, lab) in enumerate([("risk_ratio", "fused, per-cell threshold"),
                              ("risk", "fused, global scale"),
                              ("s_nov", "novelty only"), ("s_act", "activation only")]):
    p, rr, _ = precision_recall_curve(y, ACTIVE[c])
    ax.plot(rr, p, color=CAT[i], label=f"{lab} (AP {average_precision_score(y, ACTIVE[c]):.3f})",
            lw=2.0 if c == "risk_ratio" else 1.4)
ax.axhline(y.mean(), color=MUTED, lw=1.0)
ax.text(0.98, y.mean() + 0.025, f"prevalence {y.mean():.1%}", color=MUTED, fontsize=8, ha="right")
finish(ax, "Precision-Recall", "the metric that matters at 2% prevalence",
       xlabel="recall", ylabel="precision")
ax.set_ylim(0, 1.03); ax.legend(loc="lower left", fontsize=8)

# ROC
ax = fig.add_subplot(gs[0, 1])
for i, (c, lab) in enumerate([("risk_ratio", "fused, per-cell threshold"),
                              ("risk", "fused, global scale"),
                              ("s_nov", "novelty only"), ("s_act", "activation only")]):
    fpr, tpr, _ = roc_curve(y, ACTIVE[c])
    ax.plot(fpr, tpr, color=CAT[i], label=f"{lab} ({roc_auc_score(y, ACTIVE[c]):.3f})",
            lw=2.0 if c == "risk_ratio" else 1.4)
ax.plot([0, 1], [0, 1], color=AXIS, lw=1.0)
finish(ax, "ROC", "shown for completeness; PR is the operative curve",
       xlabel="false-positive rate", ylabel="true-positive rate")
ax.legend(loc="lower right", fontsize=8)

# precision / recall / alert volume vs threshold
ax = fig.add_subplot(gs[0, 2])
ths = np.linspace(0.4, 2.2, 50)
sws = [sweep(t) for t in ths]
ax.plot(ths, [s["precision"] for s in sws], color=CAT[0], label="precision")
ax.plot(ths, [s["recall"] for s in sws], color=CAT[1], label="recall")
ax.plot(ths, [s["FP/user/day"] for s in sws], color=CAT[3], label="FP / user / day")
ax.axvline(1.0, color=STATUS["critical"], lw=1.6)
ax.text(1.04, 0.28, "calibrated operating point", color=STATUS["critical"], fontsize=8,
        rotation=90, va="bottom")
finish(ax, "Operating characteristics",
       "the surface was calibrated on baseline data only",
       xlabel="multiplier on the threshold surface")
ax.set_ylim(0, 1.05); ax.legend(loc="center left", fontsize=8)
plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/d331c3fc1eb1c2a12303bde4e4abba049ba35b9b.png)
:::
:::

::: {#736cd7f2 .cell .markdown}

------------------------------------------------------------------------

## 21. Visualisation {#21-visualisation}
:::

::: {#a16ea804 .cell .code execution_count="48" execution="{\"iopub.execute_input\":\"2026-08-25T09:00:59.667559Z\",\"iopub.status.busy\":\"2026-08-25T09:00:59.667192Z\",\"iopub.status.idle\":\"2026-08-25T09:01:00.896718Z\",\"shell.execute_reply\":\"2026-08-25T09:01:00.895614Z\"}"}
``` python
BAND_COLOR = {"NORMAL": "#cde2fb", "LOW": CAT[0], "MEDIUM": STATUS["warning"],
              "HIGH": STATUS["serious"], "CRITICAL": STATUS["critical"]}

fig, axes = plt.subplots(len(PRINCIPALS), 1, figsize=(13.6, 1.5 * len(PRINCIPALS)), sharex=True)
day_edges = [pd.Timestamp(d + " 00:00", tz=TZ) for d in TEST_DATES] + \
            [pd.Timestamp(TEST_DATES[-1] + " 23:50", tz=TZ) + pd.Timedelta(WINDOW)]

for i, u in enumerate(PRINCIPALS):
    ax = axes[i]
    d = TE[TE.user == u].sort_values("win")
    # attack episodes for this principal
    for _, e in EP.iterrows():
        if u in e.users:
            ax.axvspan(e.start, e.end, color=STATUS["critical"], alpha=0.10, lw=0, zorder=0)
    # red herrings
    for _, r in RH.iterrows():
        if r.user == u:
            ax.axvspan(r.ts - pd.Timedelta("5min"), r.ts + pd.Timedelta("30min"),
                       color=CAT[2], alpha=0.16, lw=0, zorder=0)
    ax.plot(d.win, d.risk, color=CAT[0], lw=1.0, zorder=2)
    hi = d[d.alert]
    ax.scatter(hi.win, hi.risk, s=16, color=STATUS["critical"], zorder=3,
               edgecolor=SURFACE, linewidth=0.8)
    # this principal's own threshold, which steps with the hour of day
    ax.step(d.win, d.threshold, color=MUTED, lw=0.8, where="post", zorder=1)
    for de in day_edges:
        ax.axvline(de, color=GRID, lw=0.8, zorder=0)
    ax.set_ylim(0, 1.05); ax.set_yticks([0, 0.5, 1])
    ax.set_ylabel(u, rotation=0, ha="right", va="center", fontsize=9, color=INK, labelpad=8)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis="y"); ax.grid(axis="x", visible=False)

axes[-1].xaxis.set_major_locator(mpl.dates.DayLocator(tz=TZ))
axes[-1].xaxis.set_major_formatter(mpl.dates.DateFormatter("%b %d", tz=TZ))
axes[-1].set_xlabel(f"scoring period ({TZ})")
fig.tight_layout(rect=[0, 0, 1, 0.955])
fig.suptitle("Risk score over the scoring period, per principal", x=0.012, y=0.995,
             ha="left", fontsize=12, color=INK, weight="600")
fig.text(0.012, 0.966, "red band = ground-truth attack episode    green band = planted benign "
                       "red herring    grey step line = that principal's own hourly threshold    "
                       "dots = alerts", ha="left", color=MUTED, fontsize=8.5)
plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/8e2f60f4839601bc9b0e48baed00ee23b3e52180.png)
:::
:::

::: {#dbbdbbd1 .cell .code execution_count="49" execution="{\"iopub.execute_input\":\"2026-08-25T09:01:00.900599Z\",\"iopub.status.busy\":\"2026-08-25T09:01:00.900284Z\",\"iopub.status.idle\":\"2026-08-25T09:01:02.173617Z\",\"shell.execute_reply\":\"2026-08-25T09:01:02.172092Z\"}"}
``` python
fig = plt.figure(figsize=(13.6, 8.0))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], hspace=0.55, wspace=0.28)

# (1) top anomalous users
ax = fig.add_subplot(gs[0, 0])
byu = (TE.groupby("user")
       .agg(alerts=("alert", "sum"), peak=("risk", "max"))
       .reindex(PRINCIPALS).sort_values("alerts"))
ax.barh(range(len(byu)), byu.alerts.values,
        color=[BAND_COLOR[band(p)] for p in byu.peak.values], height=0.66)
for i, (a, p) in enumerate(zip(byu.alerts.values, byu.peak.values)):
    ax.text(a + 0.6, i, f"peak {p:.2f}", va="center", fontsize=8, color=INK2)
ax.set_yticks(range(len(byu))); ax.set_yticklabels(byu.index, fontsize=9)
ax.set_xlim(right=byu.alerts.max() * 1.35)
finish(ax, "Alerting windows per principal", "bar colour = that principal's peak risk band",
       xlabel="alerting 10-minute windows", xgrid=True)
ax.legend(handles=[Patch(color=BAND_COLOR[b], label=b) for b in ["MEDIUM", "HIGH", "CRITICAL"]],
          loc="lower right", ncols=3, fontsize=7.5)

# (2) top anomalous windows
ax = fig.add_subplot(gs[0, 1])
tw = TE.nlargest(12, "risk").sort_values("risk")
labels = [f"{r.user.split('.')[0]}  {r.win:%m-%d %H:%M}" for _, r in tw.iterrows()]
left = np.zeros(len(tw))
for i, (c, w, lab) in enumerate([("s_nov", W_NOV, "novelty"), ("s_act", W_ACT, "activation"),
                                 ("s_rare", W_RARE, "rarity"), ("s_stat", W_STAT, "statistical"),
                                 ("s_ml", W_ML, "ML")]):
    vals = (w * tw[c]).to_numpy()
    ax.barh(range(len(tw)), vals, left=left, color=CAT[i], height=0.66, label=lab,
            linewidth=1.4, edgecolor=SURFACE)
    left += vals
ax.set_yticks(range(len(tw))); ax.set_yticklabels(labels, fontsize=8)
finish(ax, "Top 12 windows - what drove the score", "weighted signal contributions, stacked",
       xlabel="weighted signal", xgrid=True)
ax.legend(ncols=5, fontsize=7.5, loc="upper center", bbox_to_anchor=(0.5, -0.16))

# (3) normal vs anomalous behavioural profile
ax = fig.add_subplot(gs[1, 0])
show = ["proc_unique", "pair_unique", "discovery_count", "lolbin_count", "admin_count",
        "script_sens_port_count", "remote_spawn_count", "lt10_count", "logon_fail_count",
        "acct_mgmt_count", "svc_install_count", "temp_proc_count"]
norm = W[W.is_train & W.has_telemetry][show].mean()
anom = W.loc[W.wid.isin(TE[TE.alert].wid), show].mean()
xx = np.arange(len(show))
ax.bar(xx - 0.2, norm.values, width=0.38, color=CAT[0], label="baseline windows (mean)")
ax.bar(xx + 0.2, anom.values, width=0.38, color=STATUS["critical"], label="alerting windows (mean)")
ax.set_xticks(xx); ax.set_xticklabels([s.replace("_count", "") for s in show],
                                       rotation=45, ha="right", fontsize=8)
ax.set_yscale("symlog", linthresh=0.01)
finish(ax, "Normal vs alerting behaviour", "per-window means, symlog scale", ylabel="mean per window")
ax.legend(fontsize=8)

# (4) which behavioural dimensions produced the novelty that mattered
ax = fig.add_subplot(gs[1, 1])
alert_wins = set(map(tuple, TE.loc[TE.alert, ["user", "win"]].to_numpy()))
nv = NOV_TE[[tuple(x) in alert_wins for x in NOV_TE[["user", "win"]].to_numpy()]]
bydim = nv.groupby("itype").w.sum().sort_values()
ax.barh(range(len(bydim)), bydim.values, color=CAT[1], height=0.66)
SHORT_LABEL = {"process": "executable", "cmd_sig": "command-line style", "pair": "parent -> child",
               "src_ip": "auth source IP", "auth_path": "auth path (src -> host)",
               "logon_host_type": "host / logon-type", "logon_type": "logon type",
               "dst_ip": "destination IP", "dst_port": "destination port", "domain": "DNS domain",
               "computer": "host touched"}
ax.set_yticks(range(len(bydim)))
ax.set_yticklabels([SHORT_LABEL[i] for i in bydim.index], fontsize=8)
finish(ax, "Where the novelty came from", "total novelty weight inside alerting windows",
       xlabel="novelty weight", xgrid=True)
plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/56f8400f138dc2ac15ce922da7a6d29a4e772566.png)
:::
:::

::: {#c0eacd45 .cell .code execution_count="50" execution="{\"iopub.execute_input\":\"2026-08-25T09:01:02.177714Z\",\"iopub.status.busy\":\"2026-08-25T09:01:02.177341Z\",\"iopub.status.idle\":\"2026-08-25T09:01:02.888352Z\",\"shell.execute_reply\":\"2026-08-25T09:01:02.886714Z\"}"}
``` python
# ---- one alert, fully unpacked --------------------------------------------------------
peak = TE.nlargest(1, "risk").iloc[0]
h, rs = explain(peak.user, peak.win, max_reasons=7)

fig, (axl, axr) = plt.subplots(1, 2, figsize=(13.6, 3.9), gridspec_kw={"width_ratios": [1, 1.9]})

sig = h["signals"]
caps = {"statistical": W_STAT, "novelty": W_NOV, "activation": W_ACT, "rarity": W_RARE, "ml": W_ML}
names = list(sig)
vals = [caps[k] * sig[k] for k in names]
axl.barh(range(len(names)), vals, color=CAT[:len(names)], height=0.62)
for i, (k, v) in enumerate(zip(names, vals)):
    axl.text(v + 0.01, i, f"{sig[k]:.2f}", va="center", fontsize=8, color=INK2)
axl.set_yticks(range(len(names))); axl.set_yticklabels(names, fontsize=9)
axl.set_xlim(0, 1.0)
finish(axl, f"Signal contributions  (risk {h['risk_score']}, {h['risk_level']})",
       f"{h['user']}  {h['date']}  {h['window']}", xlabel="weighted contribution", xgrid=True)

axr.axis("off")
axr.text(0, 1.0, "Why this window scored", fontsize=11, color=INK, weight="600", va="top")
yy = 0.86
for i, r in enumerate(rs, 1):
    axr.text(0, yy, f"{i}.", fontsize=9, color=MUTED, va="top")
    axr.text(0.035, yy, textwrap.fill(r["text"], 74), fontsize=8.6, color=INK2, va="top")
    yy -= 0.075 + 0.055 * (len(textwrap.wrap(r["text"], 74)) - 1)
plt.tight_layout(); plt.show()
```

::: {.output .display_data}
![](vertopal_8464e877aec649b39c894c1bf5c20fd0/49bb58a01aeb2f157d9f9d0a46086808652e03b8.png)
:::
:::

::: {#b8ccb3bd .cell .markdown}

------------------------------------------------------------------------

## 22. Results {#22-results}

### Alerts, and the incidents they roll up into

A stream of alerting windows is not a stream of things for an analyst to
look at. Consecutive or nearby alerting windows for the same principal
are the same activity, so they are grouped into **incidents**. The gap
tolerance is **90 minutes**, chosen because a slow C2 implant beacons on
an interval measured in tens of minutes - a 30-minute tolerance would
shatter one 21-hour implant into two dozen separate tickets. This is
what the queue actually looks like.
:::

::: {#fd237d79 .cell .code execution_count="51" execution="{\"iopub.execute_input\":\"2026-08-25T09:01:02.892415Z\",\"iopub.status.busy\":\"2026-08-25T09:01:02.891775Z\",\"iopub.status.idle\":\"2026-08-25T09:01:02.948735Z\",\"shell.execute_reply\":\"2026-08-25T09:01:02.947260Z\"}"}
``` python
INCIDENT_GAP = pd.Timedelta("90min")   # a slow implant beacons every ~40 min by design
ALERTS = TE[TE.alert].sort_values(["user", "win"]).copy()
ALERTS["gap"] = ALERTS.groupby("user").win.diff()
ALERTS["new_incident"] = (ALERTS.gap.isna()) | (ALERTS.gap > INCIDENT_GAP)
ALERTS["incident_id"] = ALERTS.new_incident.cumsum()

INC = (ALERTS.groupby("incident_id")
       .agg(user=("user", "first"), start=("win", "min"), end=("win_end", "max"),
            windows=("win", "size"), peak_risk=("risk", "max"), events=("event_count", "sum"),
            is_attack=("is_attack", "any"), is_rh=("is_red_herring", "any"),
            steps=("attack_steps", lambda s: sorted({x for l in s for x in l})))
       .sort_values("peak_risk", ascending=False).reset_index(drop=True))
INC["level"] = INC.peak_risk.map(band)
INC["verdict"] = np.where(INC.is_attack, "ground-truth attack",
                          np.where(INC.is_rh, "planted red herring", "not in ground truth"))
INC.insert(0, "incident", ["INC-%03d" % (i + 1) for i in range(len(INC))])

n_user_days_test = len(TE) / WINDOWS_PER_DAY
print(f"{len(ALERTS)} alerting windows  ->  {len(INC)} incidents "
      f"over {n_user_days_test:.1f} user-days ({len(PRINCIPALS)} principals x "
      f"{n_user_days_test / len(PRINCIPALS):.1f} days)")
print(f"   = {len(INC) / n_user_days_test:.2f} incidents per user per day")
print()
display(INC.assign(start=INC.start.dt.strftime("%m-%d %H:%M"), end=INC.end.dt.strftime("%m-%d %H:%M"),
                   peak_risk=INC.peak_risk.round(3),
                   steps=INC.steps.map(lambda s: ",".join(map(str, s)) if s else "-"))
        [["incident", "user", "start", "end", "windows", "events", "peak_risk", "level",
          "steps", "verdict"]])
```



``` python
# ---- the attack story, reconstructed from alerts alone ---------------------------------
print("=" * 92)
print("KILL-CHAIN VIEW - what an analyst would have seen, in order")
print("=" * 92)
story = INC[INC.is_attack].sort_values("start")
for _, inc in story.iterrows():
    steps = ", ".join(f"step {s}" for s in inc.steps) if inc.steps else ""
    desc = "; ".join(EP[EP.step.isin(inc.steps)].desc.tolist())[:70] if inc.steps else ""
    print(f"{inc.start:%m-%d %H:%M}  {inc.user:<14} {inc.level:<9} risk {inc.peak_risk:.2f}   "
          f"{desc}  [{steps}]")

print()
print("-" * 92)
print("UNBASELINED PRINCIPALS - activity that could not be scored (reported, never silently dropped)")
print("-" * 92)
lowd = raw[raw.in_scope & raw.attr_user.isin(LOW_DATA) & raw.date.isin(TEST_DATES)]
if len(lowd):
    t = (lowd.groupby(["attr_user", "date"]).size().rename("events").reset_index()
         .pivot(index="attr_user", columns="date", values="events").fillna(0).astype(int))
    display(t)
    print("  These accounts have no usable user x hour baseline (see section 09), so no risk score is")
    print("  produced for them. They appear almost exclusively as failed-authentication targets and are")
    print("  surfaced here for manual review instead.")
else:
    print("  none active during the scoring period")
```

``` python
print("=" * 92)
print("SUMMARY")
print("=" * 92)
print(f"""
Corpus                 {len(raw):,} events, {len(ALL_DATES)} UTC days, {raw.Computer.nunique()} hosts, {raw.EventID.nunique()} Event IDs
Attributed             {int(raw.attr_user.notna().sum()):,} events ({raw.attr_user.notna().mean():.0%}) - {int((raw.attr_method=='B_5156_proc_lifetime').sum()):,} of them by process-lifetime correlation
Scored principals      {len(PRINCIPALS)} ({', '.join(PRINCIPALS)})
Windows                {len(W):,} = {len(PRINCIPALS)} users x {len(ALL_DATES)} days x {WINDOWS_PER_DAY} windows
                       {int(W.has_telemetry.sum()):,} inside sensor coverage; empty windows retained
Features               {len(FEATS)} numeric per window + {len(ITEM_DEF)} categorical behaviour dimensions
Baseline               {len(BASELINE['num']['med_h'])} user x hour cells, {'/'.join(str(int(v)) for v in sorted(obs.n_obs.unique()))} observations each
                       fitted on {TRAIN_DATES[0]} .. {TRAIN_DATES[-1]} only

Threshold              per user x hour surface, {THRESH.min():.2f}-{THRESH.max():.2f}
                       (reference level {ALERT_THRESHOLD}), calibrated on the leave-one-day-out
                       baseline null at a {FP_BUDGET_PER_USER_DAY} alert/user/day budget

PR-AUC                 {average_precision_score(y, ACTIVE.risk):.3f}   (prevalence {y.mean():.2%})
ROC-AUC                {roc_auc_score(y, ACTIVE.risk):.3f}
Precision / Recall     {OP['precision']:.3f} / {OP['recall']:.3f}   (F1 {OP['F1']:.3f})
Accuracy / balanced    {OP['accuracy']:.4f} / {OP['balanced_acc']:.4f}
Attack steps detected  {n_det}/{len(EP)}  - the {len(EP)-n_det} misses are evidence gaps, itemised in 20.3
False positives        {OP['FP']} windows over {N_USER_DAYS_TEST:.0f} user-days = {OP['FP/user/day']:.2f} per user per day
Analyst queue          {len(INC)} incidents ({len(INC)/N_USER_DAYS_TEST:.2f} per user per day)
GT window map          {int((core.detected=='YES').sum())}/{len(core)} core ground-truth windows alerted ({hit}/{len(GTW)} counting the spray fan-out)
""")
```


``` python
import pickle

BASELINE_TABLE.to_parquet(os.path.join(OUT_DIR, "baseline_user_hour.parquet"), index=False)
BASELINE["known"].to_parquet(os.path.join(OUT_DIR, "baseline_inventories.parquet"), index=False)
BASELINE["gcnt"].to_parquet(os.path.join(OUT_DIR, "baseline_global_rarity.parquet"), index=False)
BASELINE["eid_ucnt"].to_parquet(os.path.join(OUT_DIR, "baseline_eventid_rarity.parquet"), index=False)
BASELINE["act_max"].reset_index().to_parquet(os.path.join(OUT_DIR, "baseline_activation.parquet"),
                                             index=False)
THRESH.reset_index().to_parquet(os.path.join(OUT_DIR, "threshold_surface.parquet"), index=False)
W.to_parquet(os.path.join(OUT_DIR, "window_features.parquet"), index=False)
ev[EVENT_TABLE_COLS].to_parquet(os.path.join(OUT_DIR, "attributed_events.parquet"), index=False)
TE.drop(columns=["attack_steps"]).to_parquet(os.path.join(OUT_DIR, "scored_test_windows.parquet"),
                                             index=False)
TR.to_parquet(os.path.join(OUT_DIR, "scored_baseline_windows_lodo.parquet"), index=False)
(INC.assign(steps=INC.steps.map(lambda s: ",".join(map(str, s))))
    .to_csv(os.path.join(OUT_DIR, "incidents.csv"), index=False))
ALERTS.drop(columns=["attack_steps"]).to_csv(os.path.join(OUT_DIR, "alerts.csv"), index=False)
DET.to_csv(os.path.join(OUT_DIR, "attack_step_detection.csv"), index=False)

MODEL = {
    "config": {"local_tz": TZ, "window": WINDOW, "train_dates": TRAIN_DATES,
               "principals": PRINCIPALS, "stat_features": STAT_FEATURES,
               "act_features": ACT_FEATURES, "act_weights": ACT_WEIGHTS,
               "item_def": [d[0] for d in ITEM_DEF], "base_w": BASE_W, "gnov_w": GNOV_W,
               "Z0": Z0, "Z1": Z1, "K_STAT": K_STAT, "K_NOV": K_NOV, "K_RARE": K_RARE,
               "K_ACT": K_ACT, "weights": FULL_W, "alert_threshold": ALERT_THRESHOLD,
               "risk_bands": RISK_BANDS},
    "numeric_baseline": BASELINE["num"],
    "threshold_surface": THRESH,
    "isolation_forest": iso,
}
with open(os.path.join(OUT_DIR, "model.pkl"), "wb") as fh:
    pickle.dump(MODEL, fh)

for f in sorted(os.listdir(OUT_DIR)):
    print(f"  {f:<44} {os.path.getsize(os.path.join(OUT_DIR, f)) / 1024:9.1f} KB")
print(f"\nartifacts written to {OUT_DIR}")
```


------------------------------------------------------------------------
