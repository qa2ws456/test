# Stage 4 - feature extraction. Direct port of the notebook's section 11
# (taxonomy, the 71-feature registry, command-line signatures, categorical
# behaviour items). Feature NAMES and semantics are identical to the notebook
# so baseline_output/ artifacts apply unchanged.

from __future__ import annotations
import re
from typing import Optional

import numpy as np
import pandas as pd

# =====================================================================================
# 11.1 taxonomy (generic Windows security knowledge)
# =====================================================================================
SHELLS       = {"powershell.exe", "pwsh.exe", "cmd.exe"}
SCRIPT_HOSTS = {"wscript.exe", "cscript.exe", "mshta.exe", "jscript.exe"}
DISCOVERY    = {"whoami.exe", "systeminfo.exe", "net.exe", "net1.exe", "nltest.exe", "dsquery.exe",
                "nbtstat.exe", "arp.exe", "route.exe", "quser.exe", "qwinsta.exe", "tasklist.exe",
                "netstat.exe", "ipconfig.exe", "hostname.exe", "wmic.exe", "setspn.exe", "adfind.exe"}
LOLBIN       = {"certutil.exe", "bitsadmin.exe", "regsvr32.exe", "rundll32.exe", "mshta.exe",
                "installutil.exe", "msbuild.exe", "cmstp.exe", "odbcconf.exe", "wmic.exe",
                "forfiles.exe", "pcalua.exe", "msiexec.exe", "curl.exe", "wget.exe",
                "esentutl.exe", "expand.exe", "extrac32.exe"}
ADMIN_TOOL   = {"sc.exe", "schtasks.exe", "at.exe", "reg.exe", "wevtutil.exe", "vssadmin.exe",
                "bcdedit.exe", "wbadmin.exe", "netsh.exe", "takeown.exe", "icacls.exe", "cacls.exe",
                "gpupdate.exe", "dsadd.exe", "ntdsutil.exe"}
REMOTE_EXEC  = {"psexec.exe", "psexec64.exe", "paexec.exe", "winrs.exe", "wmic.exe", "mstsc.exe",
                "putty.exe", "ssh.exe", "plink.exe"}
TRANSFER     = {"robocopy.exe", "xcopy.exe", "certutil.exe", "curl.exe", "wget.exe", "ftp.exe",
                "7z.exe", "winrar.exe", "rar.exe", "makecab.exe"}
SCRIPT_LOLBIN  = SHELLS | SCRIPT_HOSTS | LOLBIN | DISCOVERY | ADMIN_TOOL | TRANSFER
REMOTE_PARENTS = {"svchost.exe", "services.exe", "wmiprvse.exe", "winrshost.exe",
                  "wsmprovhost.exe", "psexesvc.exe", "taskeng.exe", "schtasks.exe"}

ARCHIVE_EXT = (".zip", ".rar", ".7z", ".tar", ".gz", ".cab", ".b64")
SCRIPT_EXT  = (".ps1", ".vbs", ".js", ".bat", ".cmd", ".hta", ".psm1", ".wsf")
EXE_EXT     = (".exe", ".dll", ".sys", ".scr", ".com")
SENSITIVE_PORTS = {135, 139, 445, 1433, 3306, 5432, 3389, 5985, 5986, 22, 23, 21, 5900}
PRIV_PAT = r"^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|127\.)"

HIGH_TRUST_NET = {"chrome.exe", "firefox.exe", "msedge.exe", "iexplore.exe", "teams.exe", "ms-teams.exe",
                  "slack.exe", "zoom.exe", "cpthost.exe", "webex.exe", "ciscocollabhost.exe",
                  "outlook.exe", "onedrive.exe", "googledrivefs.exe", "dropbox.exe", "code.exe",
                  "postman.exe", "sublime_text.exe", "dbeaver.exe", "pbidesktop.exe", "tableau.exe",
                  "excel.exe", "winword.exe", "powerpnt.exe", "acrobat.exe", "zsatray.exe",
                  "selfservice.exe", "searchapp.exe", "explorer.exe", "mstsc.exe", "msra.exe",
                  "searchindexer.exe", "spotify.exe", "notepad++.exe", "psql.exe", "sqlcmd.exe",
                  "git.exe", "ssh.exe", "vs_installer.exe", "chromesetup.exe", "runtimebroker.exe",
                  "sihost.exe", "taskhostw.exe", "dllhost.exe", "svchost.exe", "system",
                  "msmpeng.exe", "mpcmdrun.exe", "osqueryd.exe"}
BS = "\\"
SUSPICIOUS_DIR = re.escape(BS) + r"(?:windows" + re.escape(BS) + r"temp|programdata|users" + \
                 re.escape(BS) + r"public|perflogs|appdata" + re.escape(BS) + r"local" + \
                 re.escape(BS) + r"temp)" + re.escape(BS)
USERDIR_RE = "c:" + re.escape(BS) + r"users" + re.escape(BS) + "[^" + re.escape(BS) + "]+" + re.escape(BS)
INTERACTIVE_TYPES = {"2", "10", "11", "12"}

_DEV_RE = re.compile(r"^\\device\\harddiskvolume\d+\\")

# =====================================================================================
# derived columns (notebook 09.2) on a single (user, window) frame
# =====================================================================================
def prepare(df: pd.DataFrame) -> pd.DataFrame:
    e = df.copy()
    # guarantee every column the feature rules read exists (streaming frames are sparse)
    for c in ("Image", "ParentImage", "CommandLine", "DestinationIp", "DestinationPort",
              "IpAddress", "LogonType", "WorkstationName", "QueryName", "QueryStatus",
              "TargetFilename", "TargetObject", "TargetImage", "GrantedAccess", "Status",
              "SourceImage", "ProcessGuid", "ProcessId"):
        if c not in e.columns:
            e[c] = pd.NA
    low = lambda s: s.astype("string").str.lower()

    e["image"] = low(e["Image"])
    if e["image"].notna().any():
        e["image"] = e["image"].str.replace(_DEV_RE, lambda m: "c:" + BS, regex=True)
    m810 = e.EventID.isin([8, 10])
    if m810.any():
        e.loc[m810, "image"] = low(e.loc[m810, "SourceImage"])
    e["image_base"]   = e["image"].str.rsplit(BS, n=1).str[-1]
    e["parent_image"] = low(e["ParentImage"])
    e["parent_base"]  = e["parent_image"].str.rsplit(BS, n=1).str[-1]
    e["pair"] = e["parent_base"].fillna("") + ">" + e["image_base"].fillna("")
    e["cmd_low"] = low(e["CommandLine"])

    e["dst_ip"]   = e["DestinationIp"].astype("string")
    e["dst_port"] = pd.to_numeric(e["DestinationPort"], errors="coerce")
    m5156 = e.EventID == 5156
    if m5156.any():
        e.loc[m5156, "dst_ip"]   = e.loc[m5156, "DestAddress"].astype("string")
        e.loc[m5156, "dst_port"] = pd.to_numeric(e.loc[m5156, "DestPort"], errors="coerce")
    e["dst_port_s"] = e["dst_port"].astype("Int64").astype("string")
    e["dst_pair"]   = e["dst_ip"].fillna("") + ":" + e["dst_port_s"].fillna("")

    def clean_ip(s):
        s = s.astype("string").str.replace("::ffff:", "", regex=False)
        return s.where(~s.isin(["-", "::1", "127.0.0.1", "0.0.0.0", "<NA>", pd.NA]), pd.NA) \
             .where(s.notna(), pd.NA)
    e["src_ip"] = clean_ip(e["IpAddress"])
    e["logon_type"]  = pd.to_numeric(e["LogonType"], errors="coerce")
    e["logon_type_s"] = e["logon_type"].astype("Int64").astype("string")
    e["workstation"] = e["WorkstationName"].astype("string").where(
        lambda s: (s != "-") & s.notna(), pd.NA)
    e["computer"] = e["Computer"].astype("string").str.replace(".corp.local", "", regex=False)

    e["domain"] = low(e["QueryName"])

    def registrable(d):
        if pd.isna(d): return pd.NA
        d = str(d)
        if d.endswith(".in-addr.arpa") or d.endswith(".ip6.arpa"): return pd.NA
        p = d.strip(".").split(".")
        if len(p) <= 2: return d
        if p[-2] in ("co", "com", "net", "org", "gov", "ac") and len(p[-1]) == 2:
            return ".".join(p[-3:])
        return ".".join(p[-2:])
    e["reg_domain"] = e["domain"].map(registrable)

    e["target_file"] = low(e["TargetFilename"])
    e["reg_path"]    = low(e["TargetObject"])

    # command-line signature (notebook cell 30)
    e["cmd_sig"] = pd.NA
    mp = e.loc[e.EventID == 1, ["image_base", "cmd_low"]].drop_duplicates()
    sigmap = {(a, b): cmd_signature(a, b) for a, b in
              zip(mp.image_base.fillna(""), mp.cmd_low.fillna(""))}
    e.loc[e.EventID == 1, "cmd_sig"] = [
        sigmap.get((a, b)) for a, b in
        zip(e.loc[e.EventID == 1, "image_base"].fillna(""),
            e.loc[e.EventID == 1, "cmd_low"].fillna(""))]

    # composite auth keys
    e["auth_path"] = pd.NA
    m = (e.EventID == 4624) & e.src_ip.notna()
    e.loc[m, "auth_path"] = e.loc[m, "src_ip"].astype(str) + ">" + e.loc[m, "computer"].astype(str)
    e["logon_host_type"] = pd.NA
    m = (e.EventID == 4624) & e.computer.notna()
    e.loc[m, "logon_host_type"] = (e.loc[m, "computer"].astype(str) + "/" +
                                   e.loc[m, "logon_type"].astype("Int64").astype(str))
    return e


CMDSIG_IMGS  = SHELLS | SCRIPT_HOSTS | DISCOVERY | LOLBIN | ADMIN_TOOL | TRANSFER | REMOTE_EXEC
TERMINATORS  = {"-command", "-c", "-encodedcommand", "-enc", "-e", "-ec", "-file", "/c", "/k"}
FLAG_RE = re.compile(r"(?:^|\s)([-/][A-Za-z][A-Za-z0-9_?-]*)")


def cmd_signature(img_base, cmd) -> Optional[str]:
    if not img_base or img_base not in CMDSIG_IMGS or not isinstance(cmd, str):
        return None
    flags = [f.lower() for f in FLAG_RE.findall(cmd)]
    if img_base in SHELLS:
        keep = []
        for f in flags:
            keep.append(f)
            if f in TERMINATORS:
                break
        flags = keep
    else:
        flags = sorted(set(flags))[:8]
    return img_base + "|" + " ".join(flags)


# =====================================================================================
# 11.2 the feature registry - identical names/semantics to the notebook
# =====================================================================================
def build_features(e: pd.DataFrame) -> dict:
    """All 71 numeric features for ONE (user, window) prepared frame."""
    ib = e["image_base"].fillna("")
    pb = e["parent_base"].fillna("")
    cl = e["cmd_low"].fillna("")
    tf = e["target_file"].fillna("")
    rp = e["reg_path"].fillna("")
    ti = e["TargetImage"].astype("string").fillna("").str.lower()

    is_proc    = e.EventID == 1
    is_net     = e.EventID.isin([3, 5156])
    is_dns     = e.EventID == 22
    is_file    = e.EventID == 11
    is_reg     = e.EventID.isin([12, 13, 14])
    is_imgload = e.EventID == 7
    is_pacc    = e.EventID == 10
    is_rthread = e.EventID == 8
    f_logon_ok = e.EventID == 4624

    is_ext_dst = e["dst_ip"].notna() & ~e["dst_ip"].fillna("").str.match(PRIV_PAT)
    is_ext_src = e["src_ip"].notna() & ~e["src_ip"].fillna("").str.match(PRIV_PAT)
    is_sens_pt = e["dst_port"].isin(SENSITIVE_PORTS)
    is_script  = ib.isin(SCRIPT_LOLBIN)

    f = {}
    f["event_count"] = float(len(e))
    # ---- process ----
    f["proc_count"]       = float(is_proc.sum())
    f["ps_count"]         = float((is_proc & ib.isin({"powershell.exe", "pwsh.exe"})).sum())
    f["cmd_count"]        = float((is_proc & (ib == "cmd.exe")).sum())
    f["scripthost_count"] = float((is_proc & ib.isin(SCRIPT_HOSTS)).sum())
    f["discovery_count"]  = float((is_proc & ib.isin(DISCOVERY)).sum())
    f["lolbin_count"]     = float((is_proc & ib.isin(LOLBIN)).sum())
    f["admin_count"]      = float((is_proc & ib.isin(ADMIN_TOOL)).sum())
    f["remoteexec_count"] = float((is_proc & ib.isin(REMOTE_EXEC)).sum())
    f["transfer_count"]   = float((is_proc & ib.isin(TRANSFER)).sum())
    f["temp_proc_count"]  = float((is_proc & e["image"].fillna("").str.contains(
        r"(?:" + re.escape(BS) + r"temp" + re.escape(BS) + r"|" + re.escape(BS) + r"appdata" +
        re.escape(BS) + r")", regex=True)).sum())
    f["encoded_count"]    = float((is_proc & cl.str.contains(
        r"-enc|frombase64|encodedcommand", regex=True)).sum())
    f["hidden_ps_count"]  = float((is_proc & cl.str.contains(
        r"-w\s+hidden|-windowstyle\s+hidden|-noprofile|-nop\b", regex=True)).sum())
    f["remote_spawn_count"] = float((is_proc & pb.isin(REMOTE_PARENTS) & is_script).sum())
    f["proc_unique"]   = float(e.loc[is_proc, "image"].nunique())
    f["parent_unique"] = float(e.loc[is_proc, "parent_image"].nunique())
    f["pair_unique"]   = float(e.loc[is_proc, "pair"].nunique())
    # ---- network ----
    f["net_conn_count"]     = float(is_net.sum())
    f["ext_dst_count"]      = float((is_net & is_ext_dst).sum())
    f["sens_port_count"]    = float((is_net & is_sens_pt).sum())
    f["script_net_count"]   = float((is_net & is_script).sum())
    f["script_ext_net_count"]     = float((is_net & is_script & is_ext_dst).sum())
    f["script_sens_port_count"]   = float((is_net & is_script & is_sens_pt).sum())
    f["dst_ip_unique"]   = float(e.loc[is_net, "dst_ip"].nunique())
    f["dst_port_unique"] = float(e.loc[is_net, "dst_port"].nunique())
    f["dst_pair_unique"] = float(e.loc[is_net, "dst_pair"].nunique())
    # ---- dns ----
    f["dns_count"] = float(is_dns.sum())
    f["srv_lookup_count"] = float((is_dns & e["domain"].fillna("").str.startswith("_")).sum())
    f["dns_fail_count"] = float((is_dns & (pd.to_numeric(e.get("QueryStatus"), errors="coerce")
                                           .fillna(0) != 0)).sum())
    f["domain_unique"] = float(e.loc[is_dns, "reg_domain"].nunique())
    # ---- file ----
    f["file_create_count"]    = float(is_file.sum())
    f["exe_create_count"]     = float((is_file & tf.str.endswith(EXE_EXT)).sum())
    f["script_create_count"]  = float((is_file & tf.str.endswith(SCRIPT_EXT)).sum())
    f["archive_create_count"] = float((is_file & tf.str.endswith(ARCHIVE_EXT)).sum())
    f["temp_create_count"]    = float((is_file & tf.str.contains(
        re.escape(BS) + "temp" + re.escape(BS), regex=True)).sum())
    # ---- registry ----
    f["reg_count"] = float(is_reg.sum())
    f["run_key_count"] = float((is_reg & rp.str.contains(
        "currentversion" + re.escape(BS) + "run", regex=True)).sum())
    f["svc_key_count"] = float((is_reg & rp.str.contains(
        "currentcontrolset" + re.escape(BS) + "services", regex=True)).sum())
    f["reg_path_unique"] = float(e.loc[is_reg, "reg_path"].nunique())
    # ---- injection ----
    f["image_load_count"]    = float(is_imgload.sum())
    f["proc_access_count"]   = float(is_pacc.sum())
    f["lsass_acc_count"]     = float((is_pacc & ti.str.endswith("lsass.exe")).sum())
    f["lsass_hi_count"]      = float((is_pacc & ti.str.endswith("lsass.exe") &
                                     e["GrantedAccess"].astype("string").fillna("")
                                     .isin(["0x1FFFFF", "0x1010", "0x143a", "0x1F3FFF", "0x1410"])).sum())
    f["remote_thread_count"] = float(is_rthread.sum())
    f["rthread_ext_count"]   = float((is_rthread & ~ti.str.contains("defender", regex=False)).sum())
    # ---- authentication ----
    f["logon_ok_count"]   = float(f_logon_ok.sum())
    f["logon_fail_count"] = float((e.EventID == 4625).sum())
    f["lt2_count"]  = float((f_logon_ok & (e.logon_type == 2)).sum())
    f["lt3_count"]  = float((f_logon_ok & (e.logon_type == 3)).sum())
    f["lt5_count"]  = float((f_logon_ok & (e.logon_type == 5)).sum())
    f["lt10_count"] = float((f_logon_ok & (e.logon_type == 10)).sum())
    f["ext_src_count"] = float((f_logon_ok & is_ext_src).sum())
    f["priv_count"]     = float((e.EventID == 4672).sum())
    f["explicit_count"] = float((e.EventID == 4648).sum())
    f["tgt_count"]      = float((e.EventID == 4768).sum())
    f["tgs_count"]      = float((e.EventID == 4769).sum())
    f["krb_fail_count"] = float((e.EventID == 4771).sum())
    f["ntlm_count"]     = float((e.EventID == 4776).sum())
    f["ntlm_fail_count"] = float(((e.EventID == 4776) &
                                  (e["Status"].astype("string") != "0x0")).sum())
    f["logoff_count"]  = float((e.EventID == 4634).sum())
    f["unlock_count"]  = float((e.EventID == 4801).sum())
    f["lock_count"]    = float((e.EventID == 4800).sum())
    f["src_ip_unique"] = float(e.loc[f_logon_ok, "src_ip"].nunique())
    f["workstation_unique"] = float(e.loc[f_logon_ok, "workstation"].nunique())
    f["logon_type_unique"]  = float(e.loc[f_logon_ok, "logon_type"].nunique())
    # ---- directory change ----
    f["acct_mgmt_count"]  = float(e.EventID.isin([4720, 4722, 4723, 4724, 4725, 4726,
                                                  4738, 4740, 4767, 4781]).sum())
    f["group_mgmt_count"] = float(e.EventID.isin([4727, 4728, 4729, 4731, 4732, 4733, 4735, 4737,
                                                  4754, 4755, 4756, 4757]).sum())
    f["svc_install_count"] = float(e.EventID.isin([4697, 7045]).sum())
    f["task_count"]        = float(e.EventID.isin([4698, 4699, 4700, 4702]).sum())
    f["logclear_count"]    = float(e.EventID.isin([1102, 104]).sum())
    # ---- spread ----
    f["computer_unique"] = float(e["computer"].nunique())
    return f


FEATURE_ORDER = None   # filled by baseline_store from model.pkl if present

# =====================================================================================
# categorical behaviour items (notebook cell 33)
# =====================================================================================
ITEM_DEF = [
    ("process",         lambda e: e.EventID == 1,  "image"),
    ("cmd_sig",         lambda e: e.EventID == 1,  "cmd_sig"),
    ("pair",            lambda e: e.EventID == 1,  "pair"),
    ("src_ip",          lambda e: e.EventID == 4624, "src_ip"),
    ("auth_path",       lambda e: e.EventID == 4624, "auth_path"),
    ("logon_host_type", lambda e: e.EventID == 4624, "logon_host_type"),
    ("logon_type",      lambda e: e.EventID == 4624, "logon_type_s"),
    ("dst_ip",          lambda e: e.EventID.isin([3, 5156]), "dst_ip"),
    ("dst_port",        lambda e: e.EventID.isin([3, 5156]), "dst_port_s"),
    ("domain",          lambda e: e.EventID == 22, "reg_domain"),
    ("computer",        lambda e: pd.Series(True, index=e.index), "computer"),
]
ITEM_LABEL = {
    "process": "executable", "cmd_sig": "command-line style", "pair": "parent -> child",
    "src_ip": "authentication source IP", "auth_path": "authentication path (source -> host)",
    "logon_host_type": "host / logon-type", "logon_type": "logon type",
    "dst_ip": "destination IP", "dst_port": "destination port", "domain": "DNS domain",
    "computer": "host touched",
}


def build_items(e: pd.DataFrame) -> pd.DataFrame:
    """One row per (itype, value) in this window, with context flags."""
    trusted = e["image_base"].fillna("").isin(HIGH_TRUST_NET)
    parts = []
    for itype, maskf, col in ITEM_DEF:
        m = maskf(e) & e[col].notna()
        if not m.any():
            continue
        parts.append(pd.DataFrame({
            "itype": itype,
            "value": e.loc[m, col].astype(str).to_numpy(),
            "trusted": trusted[m].to_numpy()}))
    if not parts:
        return pd.DataFrame(columns=["itype", "value", "trusted", "is_public",
                                     "susp_dir", "sens_port", "interactive", "gvalue"])
    it = pd.concat(parts, ignore_index=True)
    it["trusted"] = it.trusted.astype(bool)
    it = it.sort_values("trusted").drop_duplicates(["itype", "value"], keep="first")
    it["is_public"]   = it.itype.isin(["src_ip", "dst_ip"]) & ~it.value.str.match(PRIV_PAT).fillna(False)
    it["susp_dir"]    = (it.itype == "process") & it.value.str.contains(SUSPICIOUS_DIR, regex=True)
    it["sens_port"]   = (it.itype == "dst_port") & it.value.isin([str(p) for p in SENSITIVE_PORTS])
    it["interactive"] = ((it.itype == "logon_host_type") &
                         it.value.str.split("/").str[-1].isin(INTERACTIVE_TYPES))
    it["gvalue"] = it.value.str.replace(USERDIR_RE, "c:" + BS + BS + "users" + BS + BS + "*" + BS + BS,
                                        regex=True)
    return it.reset_index(drop=True)
