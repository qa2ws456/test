# Stage 3 - tumbling 10-minute windows keyed by EVENT time (not consumer time).
# Events are buffered per window; a window is sealed once the watermark
# (max event time seen - grace) has passed its end. Windows are clock-aligned
# exactly like the notebook's dt.floor("10min").

from __future__ import annotations
from collections import defaultdict
from typing import Optional

import pandas as pd


class Windower:
    def __init__(self, minutes: int = 10, grace_seconds: int = 120):
        self.freq = f"{minutes}min"
        self.grace = pd.Timedelta(seconds=grace_seconds)
        self.buckets: dict[pd.Timestamp, list] = defaultdict(list)
        self.watermark: Optional[pd.Timestamp] = None
        self.sealed_count = 0

    def add(self, ev: dict) -> None:
        w = ev["_ts"].floor(self.freq)
        self.buckets[w].append(ev)
        wm = ev["_ts"] - self.grace
        if self.watermark is None or wm > self.watermark:
            self.watermark = wm

    def seal_ready(self) -> list[tuple[pd.Timestamp, list]]:
        """Return [(window_start, events)] for every window whose end <= watermark."""
        out = []
        if self.watermark is None:
            return out
        for w in sorted(list(self.buckets)):
            if w + pd.Timedelta(self.freq) <= self.watermark:
                out.append((w, self.buckets.pop(w)))
                self.sealed_count += 1
        return out

    def flush_all(self) -> list[tuple[pd.Timestamp, list]]:
        """Force-seal everything still buffered (shutdown / end of mock input)."""
        out = [(w, self.buckets.pop(w)) for w in sorted(self.buckets)]
        self.sealed_count += len(out)
        return out

    @property
    def buffered_windows(self) -> int:
        return len(self.buckets)
