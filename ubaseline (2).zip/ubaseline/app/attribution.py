# Stage 2 - attribute each event to a user principal. Streaming port of the
# notebook's tiers, plus the ProcessGuid fallback the notebook never needed
# offline (100% User coverage in the synthetic corpus):
#
#   A1  Sysmon User / SourceUser present                      -> direct
#   A2  Security actor field present (per-Event-ID map)       -> direct
#   B1  ProcessGuid in the live process table                 -> user of the
#       process-start event (works for ANY Sysmon EID)
#   B2  Security 5156: (Computer, PID, event time) inside a
#       known process lifetime (notebook cell 19 logic)       -> that user
#   C   nothing works                                         -> unattributed (metric)
#
# The process table is maintained in event-time order from Sysmon 1 (start,
# carries User + ProcessGuid + PID) and Sysmon 5 (end, ProcessGuid).

from __future__ import annotations
import re
import time as _time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

SECURITY_ACTOR_FIELD = {
    4624: "TargetUserName", 4625: "TargetUserName", 4634: "TargetUserName", 4647: "TargetUserName",
    4768: "TargetUserName", 4769: "TargetUserName", 4770: "TargetUserName", 4771: "TargetUserName",
    4776: "TargetUserName", 4800: "TargetUserName", 4801: "TargetUserName",
    4688: "SubjectUserName", 4689: "SubjectUserName", 4672: "SubjectUserName",
    4648: "SubjectUserName", 4720: "SubjectUserName", 4722: "SubjectUserName",
    4724: "SubjectUserName", 4726: "SubjectUserName", 4738: "SubjectUserName",
    4740: "SubjectUserName", 4728: "SubjectUserName", 4732: "SubjectUserName",
    4756: "SubjectUserName", 4697: "SubjectUserName", 4698: "SubjectUserName",
    1102: "SubjectUserName",
}
SYSMON_ACTOR_FIELD = {
    1: "User", 2: "User", 3: "User", 5: "User", 6: "User", 7: "User", 11: "User",
    12: "User", 13: "User", 14: "User", 15: "User", 17: "User", 18: "User",
    22: "User", 23: "User", 25: "User",
    8: "SourceUser", 10: "SourceUser",
}


@dataclass
class _Proc:
    guid: str
    host: str
    pid: Optional[int]
    user: Optional[str]
    image: Optional[str]
    start: pd.Timestamp
    end: Optional[pd.Timestamp] = None


class Attributor:
    def __init__(self, cfg):
        self.builtin = set(cfg.builtin) if cfg.builtin else {
            "SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "ANONYMOUS LOGON", "-"}
        doms = "|".join(re.escape(d) for d in (cfg.strip_domains or ["CORP"]))
        self._strip_re = re.compile(rf"^(?:{doms})\\", re.IGNORECASE)
        self.ttl = pd.Timedelta(minutes=cfg.proc_ttl_min if cfg.proc_ttl_min else 240)
        self.guid2proc: dict[str, _Proc] = {}
        self.hostpid2guids: dict[tuple, list[str]] = defaultdict(list)
        self.stats = {"A1_sysmon": 0, "A2_security": 0, "B1_procguid": 0,
                      "B2_5156_lifetime": 0, "C_unattributed": 0, "total": 0}
        self._last_gc = _time.time()

    # ---- helpers --------------------------------------------------------------
    def strip_domain(self, s: str) -> str:
        return self._strip_re.sub("", str(s)).strip()

    def is_person_like(self, u: Optional[str]) -> bool:
        if u is None or u != u:                      # None / NaN
            return False
        u = str(u)
        if u in self.builtin or u.endswith("$") or u.startswith(("DWM-", "UMFD-")):
            return False
        return True

    def _gc(self, now: pd.Timestamp):
        if _time.time() - self._last_gc < 60:
            return
        self._last_gc = _time.time()
        dead = [g for g, p in self.guid2proc.items()
                if p.end is not None and now - p.end > self.ttl]
        for g in dead:
            p = self.guid2proc.pop(g)
            k = (p.host, p.pid)
            if k in self.hostpid2guids:
                self.hostpid2guids[k] = [x for x in self.hostpid2guids[k] if x != g]
                if not self.hostpid2guids[k]:
                    self.hostpid2guids.pop(k, None)

    # ---- process table maintenance ---------------------------------------------
    def _update_process_table(self, ev: dict, ts, eid: int, host: str):
        if eid == 1 and ev.get("ProcessGuid"):
            guid = str(ev["ProcessGuid"])
            try:
                pid = None
                if ev.get("ProcessId"):
                    s = str(ev["ProcessId"])
                    pid = int(s, 16) if s.lower().startswith("0x") else int(s)
            except (TypeError, ValueError):
                pid = None
            p = _Proc(guid=guid, host=host, pid=pid,
                      user=ev.get("_direct_user"), image=ev.get("Image"),
                      start=ts)
            self.guid2proc[guid] = p
            if pid is not None:
                self.hostpid2guids[(host, pid)].append(guid)
        elif eid == 5 and ev.get("ProcessGuid"):
            p = self.guid2proc.get(str(ev["ProcessGuid"]))
            if p is not None:
                p.end = ts

    # ---- main -----------------------------------------------------------------
    def observe_and_attribute(self, ev: dict) -> Optional[str]:
        """Return the attributed user and keep the process tables current."""
        self.stats["total"] += 1
        ts = ev["_ts"]
        eid = ev["EventID"]
        host = str(ev.get("Computer", ""))

        # -- tier A1 / A2: direct field (runs FIRST so EID 1's own user is known
        #    when the process row is created) ------------------------------------
        fld = SYSMON_ACTOR_FIELD.get(eid) if "Sysmon" in str(ev.get("Channel", "")) \
            else SECURITY_ACTOR_FIELD.get(eid)
        if fld and ev.get(fld) not in (None, "", "-"):
            u = self.strip_domain(ev[fld])
            ev["_direct_user"] = u
            ev["attr_method"] = "A1_sysmon" if fld in ("User", "SourceUser") else "A2_security"
            self.stats[ev["attr_method"]] += 1
            ev["attr_user"] = u
            self._update_process_table(ev, ts, eid, host)
            return u

        # -- no direct identity: maintain table, then fall back through it -------
        self._update_process_table(ev, ts, eid, host)

        # -- tier B1: ProcessGuid lookup (the fallback missing offline) ----------

        if ev.get("ProcessGuid"):
            p = self.guid2proc.get(str(ev["ProcessGuid"]))
            if p is not None and p.user:
                ev["attr_method"] = "B1_procguid"
                self.stats["B1_procguid"] += 1
                ev["attr_user"] = p.user
                if not ev.get("Image") and p.image:
                    ev["Image"] = p.image               # e.g. 5156-style rows
                return p.user

        # -- tier B2: 5156 lifetime lookup (notebook cell 19) --------------------
        if eid == 5156:
            try:
                pid = int(str(ev.get("ProcessID", "")))
            except (TypeError, ValueError):
                pid = None
            if pid is not None:
                for g in reversed(self.hostpid2guids.get((host, pid), [])):
                    p = self.guid2proc.get(g)
                    if p is not None and p.start <= ts and (p.end is None or ts <= p.end):
                        if p.user:
                            ev["attr_method"] = "B2_5156_lifetime"
                            self.stats["B2_5156_lifetime"] += 1
                            if not ev.get("Image") and p.image:
                                ev["Image"] = p.image
                            ev["attr_user"] = p.user
                            return p.user
                        break

        # -- tier C ---------------------------------------------------------------
        ev["attr_method"] = "C_unattributed"
        self.stats["C_unattributed"] += 1
        ev["attr_user"] = None
        return None
