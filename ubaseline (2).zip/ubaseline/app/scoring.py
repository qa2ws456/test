# Stage 6 - score one (user, hour, window) against that user's hour-of-day
# baseline. Port of notebook sections 16-19: robust z with shrinkage + P95 gate,
# novelty with context bonuses, Event-ID rarity, capability activation, optional
# IsolationForest, noisy-OR fusion, per-(user,hour) threshold, ranked reasons.

from __future__ import annotations
import logging
import math

import numpy as np
import pandas as pd

from .features import ITEM_LABEL, PRIV_PAT

log = logging.getLogger("ubaseline.scoring")

BASE_W = {"process": 1.0, "cmd_sig": 0.9, "pair": 0.7, "src_ip": 1.0, "auth_path": 1.0,
          "logon_host_type": 1.1, "logon_type": 0.6, "dst_ip": 0.5, "dst_port": 0.2,
          "domain": 0.4, "computer": 0.5}
GNOV_W = {"process": 1.0, "cmd_sig": 0.5, "pair": 0.5, "src_ip": 1.0, "auth_path": 0.4,
          "logon_host_type": 0.4, "logon_type": 0.0, "dst_ip": 0.8, "dst_port": 0.2,
          "domain": 1.5, "computer": 0.3}

RISK_BANDS = [(0.25, "NORMAL"), (0.45, "LOW"), (0.60, "MEDIUM"), (0.80, "HIGH"), (1.01, "CRITICAL")]


def band(x: float) -> str:
    for hi, name in RISK_BANDS:
        if x < hi:
            return name
    return "CRITICAL"


def score_window(store, user: str, hour: int, feats: dict, items: pd.DataFrame,
                 eid_counts: dict) -> dict | None:
    """Return the result dict for one scored window, or None if unscoreable."""
    Z0, Z1 = float(store.const("z0")), float(store.const("z1"))
    K_STAT = float(store.const("k_stat")); K_NOV = float(store.const("k_nov"))
    K_RARE = float(store.const("k_rare")); K_ACT = float(store.const("k_act"))
    W_STAT = float(store.const("w_stat")); W_NOV = float(store.const("w_nov"))
    W_RARE = float(store.const("w_rare")); W_ACT = float(store.const("w_act"))
    W_ML   = float(store.const("w_ml"))

    reasons = []

    # ---------------- s_stat: robust z vs the user's OWN hour cell --------------
    s_stat = 0.0
    z = None
    cell = store.cell(user, hour)
    if cell is not None and store.stat_features:
        med, mad, madu, p95 = cell
        X = np.array([math.log1p(feats.get(f, 0.0)) for f in store.stat_features])
        scale = np.maximum.reduce([1.4826 * np.nan_to_num(mad),
                                   0.6 * 1.4826 * np.nan_to_num(madu),
                                   np.full_like(X, 0.35)])
        z = (X - np.nan_to_num(med)) / scale
        z = np.where(X > np.nan_to_num(p95), z, np.minimum(z, 0))
        sev = np.clip((z - Z0) / (Z1 - Z0), 0, 1)
        srt = -np.sort(-sev)
        raw = srt[0] + 0.5 * srt[1] + 0.25 * srt[2]
        s_stat = 1 - math.exp(-raw / K_STAT)
        for j in np.argsort(-z)[:6]:
            if z[j] < Z0:
                break
            f = store.stat_features[j]
            reasons.append({"signal": "statistical", "weight": W_STAT * float(sev[j]),
                            "text": f"{f} = {feats.get(f, 0.0):.0f}, against {user} hour-{hour:02d} "
                                    f"baseline - robust z = {z[j]:.1f}"})

    # ---------------- s_nov: values this user never showed ----------------------
    s_nov = 0.0
    nov_w_total = 0.0
    if items is not None and len(items):
        rows = []
        for r in items.itertuples():
            if (user, r.itype, r.value) in store.known:
                continue
            gcnt = store.gcnt.get((r.itype, r.gvalue), 0.0)
            w = BASE_W.get(r.itype, 0.5) + (GNOV_W.get(r.itype, 0.5) if gcnt == 0 else 0.0)
            if getattr(r, "susp_dir", False):   w += 1.0
            if getattr(r, "is_public", False) and r.itype == "src_ip": w += 2.5
            if getattr(r, "is_public", False) and r.itype == "dst_ip" and gcnt == 0: w += 2.0
            if getattr(r, "sens_port", False):  w += 0.8
            if getattr(r, "interactive", False): w += 0.8
            if r.trusted and r.itype in ("dst_ip", "domain"): w *= 0.06
            rows.append((w, r.itype, r.value, gcnt))
        nov_w_total = sum(w for w, *_ in rows)
        s_nov = 1 - math.exp(-nov_w_total / K_NOV)
        for w, itype, value, gcnt in sorted(rows, reverse=True)[:8]:
            scope = ("never seen anywhere in the baseline" if gcnt == 0 else
                     f"seen {int(gcnt)}x elsewhere, never for {user}")
            reasons.append({"signal": "novelty", "weight": W_NOV * (1 - math.exp(-w / K_NOV)),
                            "text": f"new {ITEM_LABEL.get(itype, itype)}: {value}  ({scope})"})

    # ---------------- s_rare: Event-ID rarity ------------------------------------
    s_rare = 0.0
    rare_w_total = 0.0
    for (eid, n) in eid_counts.items():
        ucnt = store.eid_ucnt.get((user, eid), 0.0)
        utot = store.eid_utot.get(user, 1.0)
        gcnt = store.eid_gcnt.get(eid, 0.0)
        gtot = store.eid_gtot if store.eid_gtot > 0 else 1.0
        s_u = -math.log10((ucnt + 0.5) / (utot + 1.0))
        s_g = -math.log10((gcnt + 0.5) / (gtot + 1.0))
        w = max(0.0, s_u - 3.0) * 0.6 + max(0.0, s_g - 4.0) * 1.2
        if w > 0:
            rare_w_total += w
            reasons.append({"signal": "rarity", "weight": W_RARE * (1 - math.exp(-w / K_RARE)),
                            "text": f"rare event type {eid} x{int(n)} - seen {int(ucnt)}x for {user} "
                                    f"and {int(gcnt)}x environment-wide in baseline"})
    s_rare = 1 - math.exp(-rare_w_total / K_RARE)

    # ---------------- s_act: capability switched on for the first time -----------
    s_act = 0.0
    act_row = store.act_max_row(user)
    if act_row is not None and store.act_features:
        act_total = 0.0
        for f in store.act_features:
            x = feats.get(f, 0.0)
            bm = float(act_row.get(f, 0.0)) if hasattr(act_row, "get") else 0.0
            if x > 0 and bm == 0:
                w = store.act_weights.get(f, 1.0)
                contrib = w * (1 + 0.3 * math.log1p(x))
                act_total += contrib
                reasons.append({"signal": "activation", "weight": W_ACT * (1 - math.exp(-contrib / K_ACT)),
                                "text": f"first occurrence for {user}: {f} = {x:.0f} "
                                        f"(zero in every baseline hour)"})
        s_act = 1 - math.exp(-act_total / K_ACT)

    # ---------------- s_ml: IsolationForest on the ROBUST-Z vector (optional) ---
    # The notebook trains the forest on Z_TR (per-feature robust z, cell 26), so the
    # API must feed it the same representation - not raw log1p counts. The z vector
    # is already computed above; reuse it. W_ML (~0.12) makes this a tiebreaker, so
    # the decision_function -> [0,1] mapping is deliberately conservative.
    s_ml = 0.0
    if (store.iso is not None and cell is not None and store.stat_features and z is not None):
        try:
            score = float(store.iso.decision_function(z.reshape(1, -1))[0])
            s_ml = float(np.clip(-score / 0.5, 0, 1)) * 0.5
        except Exception as exc:                                  # pragma: no cover
            log.debug("iso forest scoring skipped: %s", exc)

    # ---------------- fuse --------------------------------------------------------
    risk = 1 - ((1 - W_STAT * s_stat) * (1 - W_NOV * s_nov) * (1 - W_RARE * s_rare) *
                (1 - W_ACT * s_act) * (1 - W_ML * s_ml))
    thr = store.threshold(user, hour)
    reasons.sort(key=lambda r: -r["weight"])
    return {
        "user": user, "hour": hour,
        "signals": {"statistical": round(s_stat, 4), "novelty": round(s_nov, 4),
                    "rarity": round(s_rare, 4), "activation": round(s_act, 4),
                    "ml": round(s_ml, 4)},
        "novelty_weight": round(nov_w_total, 3),
        "risk_score": round(float(risk), 4),
        "risk_level": band(float(risk)),
        "threshold": round(thr, 4),
        "risk_ratio": round(float(risk) / thr, 3) if thr > 0 else None,
        "alert": bool(risk >= thr),
        "reasons": reasons[:6],
    }
