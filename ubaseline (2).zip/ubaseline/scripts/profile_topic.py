# Onboarding profiler: point it at the live topic (or a JSONL file) and get the
# per-Event-ID field-availability table - the streaming version of your
# profile_report.txt. Run BEFORE trusting attribution on a new environment:
#   python3 scripts/profile_topic.py --brokers kafka:9092 --topic win-events --minutes 10
#   python3 scripts/profile_topic.py --file events.jsonl --limit 200000

from __future__ import annotations
import argparse
import json
import sys
from collections import Counter, defaultdict

sys.path.insert(0, ".")
from app.normalize import normalize
from app.attribution import SECURITY_ACTOR_FIELD, SYSMON_ACTOR_FIELD


def rows_from_kafka(brokers, topic, minutes):
    from confluent_kafka import Consumer
    import time as t
    c = Consumer({"bootstrap.servers": brokers, "group.id": "profiler-temp",
                  "auto.offset.reset": "latest"})
    c.subscribe([topic])
    end = t.time() + minutes * 60
    try:
        while t.time() < end:
            for m in c.consume(num_messages=2000, timeout=1.0):
                if m.error():
                    continue
                try:
                    yield json.loads(m.value())
                except json.JSONDecodeError:
                    pass
    finally:
        c.close()


def rows_from_file(path, limit):
    with open(path) as fh:
        for i, line in enumerate(fh):
            if i >= limit:
                break
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--brokers"); ap.add_argument("--topic")
    ap.add_argument("--file"); ap.add_argument("--limit", type=int, default=200_000)
    ap.add_argument("--minutes", type=int, default=10)
    a = ap.parse_args()

    rows = rows_from_kafka(a.brokers, a.topic, a.minutes) if a.brokers \
        else rows_from_file(a.file, a.limit)
    cnt = Counter(); fields = defaultdict(Counter); actor_cov = defaultdict(lambda: [0, 0])
    n = 0
    for raw in rows:
        ev = normalize(raw)
        if ev is None:
            continue
        n += 1
        eid = ev["EventID"]
        cnt[eid] += 1
        for k, v in ev.items():
            if v not in (None, "", "-"):
                fields[eid][k] += 1
        fld = SYSMON_ACTOR_FIELD.get(eid) if "Sysmon" in str(ev.get("Channel", "")) \
            else SECURITY_ACTOR_FIELD.get(eid)
        if fld:
            actor_cov[eid][1] += 1
            if ev.get(fld) not in (None, "", "-"):
                actor_cov[eid][0] += 1

    print(f"\n{ n:,} usable events, {len(cnt)} Event IDs\n")
    print(f"{'EID':>6} {'count':>9} {'actor_field':<20} {'coverage':>9}   top fields")
    for eid, c in cnt.most_common():
        fld = SYSMON_ACTOR_FIELD.get(eid) or SECURITY_ACTOR_FIELD.get(eid) or "-"
        cov = f"{actor_cov[eid][0] / actor_cov[eid][1]:.0%}" if actor_cov[eid][1] else "-"
        top = ", ".join(f"{k}" for k, _ in fields[eid].most_common(6))
        print(f"{eid:>6} {c:>9,} {fld:<20} {cov:>9}   {top}")
    print("\nEvent IDs with an actor field below 100% coverage need the ProcessGuid "
          "fallback or explicit handling - see app/attribution.py tiers.")


if __name__ == "__main__":
    main()
