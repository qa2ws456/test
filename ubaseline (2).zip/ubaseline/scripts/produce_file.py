# Stream an events.jsonl file into a Kafka topic - lets you run the FULL loop
# (Kafka -> 10-min windows -> scoring -> ClickHouse) on your laptop.
#
#   pip install confluent-kafka
#   python scripts/produce_file.py localhost:9092 win-events C:\\path\\to\\events.jsonl
#
# Events are keyed by Computer so per-host order is preserved (see DEPLOYMENT.md 5).
# Start the consumer FIRST (it reads from 'latest'), then run this producer.

import json
import sys

from confluent_kafka import Producer

brokers = sys.argv[1] if len(sys.argv) > 1 else "localhost:9092"
topic   = sys.argv[2] if len(sys.argv) > 2 else "win-events"
path    = sys.argv[3] if len(sys.argv) > 3 else "events.jsonl"

p = Producer({"bootstrap.servers": brokers})
n = bad = 0
with open(path, encoding="utf-8") as fh:
    for line in fh:
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            bad += 1
            continue
        key = str(obj.get("Computer", ""))[:250]
        p.produce(topic, key=key.encode(), value=line.encode("utf-8"))
        n += 1
        if n % 20000 == 0:
            p.poll(0)
            print(f"   {n:,} events produced ...")
p.flush()
print(f"done: {n:,} events -> {topic} on {brokers} ({bad} malformed skipped)")
