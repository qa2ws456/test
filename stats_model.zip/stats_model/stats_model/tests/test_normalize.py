"""Tests for identity and value normalisation.

The first test class is the important one. The username split it guards against is
the bug that silently halves every baseline, and it produces plausible-looking
numbers while doing so - which is why it needs a test rather than a comment.
"""

from __future__ import annotations

from stats_model.normalize import (
    bucket_ip,
    canon_user,
    dir_class,
    dirname_ext,
    ip_class,
    norm_cmdline,
    normalize_field,
    registrable_domain,
    split_privileges,
)


class TestCanonUser:
    def test_security_and_sysmon_shapes_agree(self):
        """The whole point: both sources must map to one key.

        Security writes a bare name (verified: 0 of 30 domain-qualified).
        Sysmon writes DOMAIN\\user (verified: 11 of 11 domain-qualified).
        """
        assert canon_user("charlie.brown") == "charlie.brown"
        assert canon_user("CORP\\charlie.brown") == "charlie.brown"
        assert canon_user("charlie.brown@corp.local") == "charlie.brown"
        assert canon_user("CORP\\Charlie.Brown") == "charlie.brown"

    def test_forward_slash_separator(self):
        assert canon_user("CORP/charlie.brown") == "charlie.brown"

    def test_drops_service_identities(self):
        for value in (
            "NT AUTHORITY\\SYSTEM",
            "NT AUTHORITY\\LOCAL SERVICE",
            "NT AUTHORITY\\NETWORK SERVICE",
            "SYSTEM",
            "LOCAL SERVICE",
            "ANONYMOUS LOGON",
        ):
            assert canon_user(value) is None, value

    def test_drops_machine_accounts(self):
        assert canon_user("PC-001$") is None
        assert canon_user("CORP\\DC-01$") is None

    def test_drops_window_manager_accounts(self):
        assert canon_user("Window Manager\\DWM-1") is None
        assert canon_user("Font Driver Host\\UMFD-0") is None
        assert canon_user("dwm-2") is None

    def test_drops_placeholders(self):
        assert canon_user("-") is None
        assert canon_user("") is None
        assert canon_user(None) is None
        assert canon_user("   ") is None

    def test_strips_braces(self):
        assert canon_user("{CORP\\alice.smith}") == "alice.smith"


class TestDirClass:
    def test_temp_is_distinguished(self):
        """dir_class=temp is the signal that survives the attacker renaming the binary."""
        assert dir_class("C:\\Windows\\Temp\\svc-host-helper.exe") == "temp"
        assert dir_class("C:\\Users\\bob\\AppData\\Local\\Temp\\x.exe") == "temp"

    def test_system_and_program_files(self):
        assert dir_class("C:\\Windows\\System32\\cmd.exe") == "system32"
        assert dir_class("C:\\Program Files\\Google\\Chrome\\chrome.exe") == "program_files"
        assert dir_class("C:\\Windows\\explorer.exe") == "windows"

    def test_appdata_and_downloads(self):
        assert dir_class("C:\\Users\\a\\AppData\\Roaming\\sync.exe") == "appdata"
        assert dir_class("C:\\Users\\a\\Downloads\\setup.exe") == "downloads"

    def test_device_path_prefix_is_stripped(self):
        """5156 renders Application as a device path."""
        got = dir_class("\\device\\harddiskvolume1\\windows\\system32\\svchost.exe")
        assert got == "system32"


class TestNormCmdline:
    def test_encoded_command_becomes_stable_token(self):
        raw = (
            "powershell.exe -NoProfile -EncodedCommand QwBvAG0AcAByAGUAcwBzAC0AQQByAGMAaABpAHYAZQA="
        )
        assert "B64" in norm_cmdline(raw)
        assert "qwbvag0" not in norm_cmdline(raw)

    def test_two_runs_with_different_params_collapse(self):
        """The whole point: baseline command lines are parameterised per user, so
        the raw string is effectively a nonce. The skeleton must repeat."""
        a = norm_cmdline("cmd.exe /c dir C:\\Users\\alice\\Documents\\q1.xlsx")
        b = norm_cmdline("cmd.exe /c dir C:\\Users\\bob\\Documents\\q4.xlsx")
        assert a == b

    def test_numbers_and_guids_collapse(self):
        a = norm_cmdline("app.exe --id 41235 --run 7")
        b = norm_cmdline("app.exe --id 99 --run 12")
        assert a == b

    def test_unc_paths_collapse(self):
        a = norm_cmdline("robocopy \\\\FILE-01\\Claims C:\\Temp\\stage /E")
        b = norm_cmdline("robocopy \\\\FILE-02\\Payroll C:\\Temp\\other /E")
        assert a == b

    def test_distinct_commands_stay_distinct(self):
        assert norm_cmdline("whoami /all") != norm_cmdline("systeminfo")


class TestNetwork:
    def test_private_keeps_24(self):
        """Segments are 10.10.10.0/24 and 10.10.20.0/24, so a /24 is meaningful."""
        assert bucket_ip("10.10.20.30") == "10.10.20.0/24"
        assert bucket_ip("10.10.10.23") == "10.10.10.0/24"

    def test_public_collapses_to_16(self):
        assert bucket_ip("198.51.100.83") == "198.51.0.0/16"

    def test_ipv4_mapped_ipv6_is_unwrapped(self):
        """4624 renders IPv4 as ::ffff:x.x.x.x."""
        assert bucket_ip("::ffff:10.10.10.23") == "10.10.10.0/24"
        assert ip_class("::ffff:203.0.113.47") == "public"

    def test_ip_class(self):
        assert ip_class("10.10.10.1") == "internal"
        assert ip_class("203.0.113.47") == "public"
        assert ip_class("127.0.0.1") == "loopback"
        assert ip_class("-") is None

    def test_registrable_domain(self):
        assert registrable_domain("a1b2.cdn-metrics-edge.net") == "cdn-metrics-edge.net"
        assert registrable_domain("cdn-metrics-edge.net") == "cdn-metrics-edge.net"
        assert registrable_domain("www.example.co.uk") == "example.co.uk"

    def test_internal_names_kept_whole(self):
        assert registrable_domain("dc-01.corp.local") == "dc-01.corp.local"

    def test_srv_records_kept_whole(self):
        """The _ldap._tcp prefix IS the meaning; collapsing it loses the signal."""
        assert (
            registrable_domain("_ldap._tcp.dc._msdcs.corp.local")
            == "_ldap._tcp.dc._msdcs.corp.local"
        )


class TestMultiValue:
    def test_privilege_list_is_split(self):
        raw = "SeBackupPrivilege\n\tSeRestorePrivilege\n\tSeDebugPrivilege"
        assert split_privileges(raw) == [
            "SeBackupPrivilege",
            "SeDebugPrivilege",
            "SeRestorePrivilege",
        ]

    def test_privilege_field_fans_out_to_tokens(self):
        tokens = normalize_field("PrivilegeList", "SeDebugPrivilege\n\tSeLoadDriverPrivilege")
        assert ("Privilege", "SeDebugPrivilege") in tokens
        assert ("Privilege", "SeLoadDriverPrivilege") in tokens


class TestNormalizeField:
    def test_path_field_yields_basename_and_dir_class(self):
        tokens = normalize_field("Image", "C:\\Windows\\Temp\\svc-host-helper.exe")
        assert ("Image", "svc-host-helper.exe") in tokens
        assert ("Image_dir", "temp") in tokens

    def test_ip_field_yields_bucket_and_class(self):
        tokens = normalize_field("DestinationIp", "198.51.100.83")
        assert ("DestinationIp", "198.51.0.0/16") in tokens
        assert ("DestinationIp_class", "public") in tokens

    def test_empty_values_produce_nothing(self):
        assert normalize_field("IpAddress", "-") == []
        assert normalize_field("Image", "") == []
        assert normalize_field("Image", None) == []

    def test_target_filename_collapses_to_dir_and_ext(self):
        assert dirname_ext("C:\\Windows\\Temp\\q3-claims.zip") == "temp|.zip"
        a = normalize_field("TargetFilename", "C:\\Users\\a\\Documents\\x.xlsx")
        b = normalize_field("TargetFilename", "C:\\Users\\b\\Documents\\y.xlsx")
        assert a == b
