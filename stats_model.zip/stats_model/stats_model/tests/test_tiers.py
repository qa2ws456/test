"""Tests for the three scoring tiers, using synthetic events.

Synthetic rather than generated data, deliberately: these assert the *statistics*,
and a hand-built series is the only way to know what the answer should be. The
generated corpus tests coverage, which is a different question.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest

from stats_model import config, features, ingest, tier_a, tier_b, tier_c
from stats_model.identity import IdentityResolver

IST = timezone(timedelta(hours=5, minutes=30))


def make_event(
    event_id: int,
    *,
    day: int = 1,
    hour: int = 9,
    minute: int = 0,
    host: str = "PC-003",
    user: str = "CORP\\charlie.brown",
    **data: str,
) -> ingest.ParsedEvent:
    """Build one ParsedEvent through the real JSON parser, so the shape is honest.

    The identity field is chosen from ``config.USER_FIELD`` rather than hardcoded,
    because it genuinely differs per event: 4624 uses ``TargetUserName``, 4672 and
    4720 use ``SubjectUserName``, Sysmon uses ``User``, and Sysmon 8/10 use
    ``SourceUser``. Hardcoding one of them silently produces unattributed events.
    """
    ts = datetime(2026, 8, day, hour, minute, tzinfo=IST)
    field_name = config.USER_FIELD.get(event_id, ("User",))[0]
    bare = user.split("\\")[-1]
    identity = {field_name: user if field_name in ("User", "SourceUser") else bare}
    payload = {
        "@timestamp": ts.isoformat(),
        "host": {"name": host},
        "winlog": {
            "event_id": event_id,
            "channel": "Security" if event_id > 1000 else "Microsoft-Windows-Sysmon/Operational",
            "record_id": f"{event_id}-{day}-{hour}-{minute}",
            "event_data": {**identity, **data},
        },
    }
    event = ingest.parse_line(json.dumps(payload))
    assert event is not None
    return event


def to_records(events: list[ingest.ParsedEvent]) -> list[features.FeatureRecord]:
    resolver = IdentityResolver()
    return features.extract_all(resolver.resolve_all(events))


# ---------------------------------------------------------------------------
# Tier A
# ---------------------------------------------------------------------------


class TestTierA:
    def _baseline_records(self, n: int = 40):
        """n boring process events from one image, enough to clear the support gate."""
        return to_records(
            [
                make_event(
                    1,
                    day=1,
                    hour=9,
                    minute=i % 60,
                    Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                    ParentImage="C:\\Windows\\explorer.exe",
                    CommandLine="chrome.exe --profile-directory=Default",
                    IntegrityLevel="Medium",
                )
                for i in range(n)
            ]
        )

    def test_unseen_event_id_scores_high_without_field_evidence(self):
        """The near-zero-FP class: 4720 never appears in baseline activity."""
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        new = to_records([make_event(4720, day=8, TargetUserName="svc-audit-sync")])
        score = baseline.score(new[0])
        assert not score.event_id_seen
        assert score.confidence == "high"
        assert score.score >= config.D1_BONUS
        assert any("unseen_event_id" in r for r in score.reasons)

    def test_first_seen_user_is_a_finding(self):
        """An account acting with no history must score, not return nothing."""
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        stranger = to_records(
            [
                make_event(
                    1, day=8, user="CORP\\svc-audit-sync", Image="C:\\Windows\\System32\\net.exe"
                )
            ]
        )
        score = baseline.score(stranger[0])
        assert score.confidence == "high"
        assert score.reasons == ("first_seen_user",)

    def test_novel_image_is_flagged(self):
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        new = to_records(
            [
                make_event(
                    1,
                    day=8,
                    hour=3,
                    Image="C:\\Windows\\Temp\\svc-host-helper.exe",
                    ParentImage="C:\\Windows\\explorer.exe",
                    CommandLine="svc-host-helper.exe --dump-auth",
                    IntegrityLevel="High",
                )
            ]
        )
        score = baseline.score(new[0])
        novel = {v.field for v in score.novel_fields}
        assert "Image" in novel
        assert "Image_dir" in novel  # temp, the generalising signal
        assert score.confidence == "high"  # >= 2 corroborating fields

    def test_familiar_event_scores_low(self):
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        same = to_records(
            [
                make_event(
                    1,
                    day=8,
                    hour=9,
                    Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                    ParentImage="C:\\Windows\\explorer.exe",
                    CommandLine="chrome.exe --profile-directory=Default",
                    IntegrityLevel="Medium",
                )
            ]
        )
        score = baseline.score(same[0])
        assert score.novel_fields == ()
        assert score.confidence == "none"

    def test_support_gate_blocks_thin_cells(self):
        """With n=3, "unseen" is not a claim the data supports."""
        thin = to_records(
            [
                make_event(
                    4648,
                    day=d,
                    TargetServerName="FILE-01",
                    ProcessName="C:\\Windows\\System32\\taskhostw.exe",
                )
                for d in (1, 2, 3)
            ]
        )
        baseline = tier_a.EventBaseline().fit(thin)
        new = to_records(
            [
                make_event(
                    4648,
                    day=8,
                    TargetServerName="DC-01",
                    ProcessName="C:\\Windows\\Temp\\psexec.exe",
                )
            ]
        )
        score = baseline.score(new[0])
        statuses = {v.status for v in score.verdicts}
        assert statuses == {"insufficient_support"}
        assert score.confidence == "none"

    def test_single_novel_field_is_not_high_confidence(self):
        """One novel field is a lead, not an alert - the rh-01 lesson."""
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        # only the hour differs; Image/Parent/CommandLine/IntegrityLevel all known
        new = to_records(
            [
                make_event(
                    1,
                    day=8,
                    hour=3,
                    Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                    ParentImage="C:\\Windows\\explorer.exe",
                    CommandLine="chrome.exe --profile-directory=Default",
                    IntegrityLevel="Medium",
                )
            ]
        )
        score = baseline.score(new[0])
        assert len(score.novel_fields) == 1
        assert score.confidence != "high"

    def test_dedup_collapses_a_beacon(self):
        """~48 identical beats must not become 48 alerts."""
        baseline = tier_a.EventBaseline().fit(self._baseline_records())
        beats = to_records(
            [
                make_event(
                    3,
                    day=8,
                    hour=10 + (i * 5) // 60,
                    minute=(i * 5) % 60,
                    DestinationIp="198.51.100.83",
                    DestinationPort="443",
                    DestinationHostname="cdn-metrics-edge.net",
                    Image="C:\\Windows\\System32\\rundll32.exe",
                )
                for i in range(48)
            ]
        )
        scores = baseline.score_all(beats)
        assert sum(1 for s in scores if s.is_alert) > 40
        kept = tier_a.deduplicate(scores, window_minutes=60)
        assert len(kept) <= 5

    def test_fan_out_finds_a_spray(self):
        """Per-user this is six isolated failures; grouped it is one campaign."""
        targets = [
            "alice.smith",
            "bob.miller",
            "diana.prince",
            "ethan.hayes",
            "frank.dsouza",
            "grace.lin",
        ]
        baseline = tier_a.EventBaseline()
        for user in targets:
            recs = to_records(
                [
                    make_event(
                        4624,
                        day=1,
                        hour=9,
                        minute=i,
                        user=f"CORP\\{user}",
                        IpAddress="10.10.10.21",
                        WorkstationName="PC-001",
                        LogonType="2",
                        LogonProcessName="User32",
                    )
                    for i in range(25)
                ]
            )
            baseline.fit(recs)

        sprayed = []
        for i, user in enumerate(targets):
            sprayed += to_records(
                [
                    make_event(
                        4625,
                        day=8,
                        hour=4,
                        minute=5 + i,
                        user=f"CORP\\{user}",
                        IpAddress="203.0.113.47",
                        WorkstationName="-",
                        LogonType="3",
                        Status="0xc000006d",
                    )
                ]
            )
        scores = baseline.score_all(sprayed)
        groups = tier_a.fan_out(scores, min_users=3)
        assert groups, "expected a fan-out group for the shared source address"
        top = groups[0]
        assert top.n_users == 6
        assert top.event_id == 4625


# ---------------------------------------------------------------------------
# Tier B
# ---------------------------------------------------------------------------


class TestTierB:
    def test_robust_z_ignores_a_single_outlier(self):
        """Hawkes bursts are legitimate; mean/sigma would be dragged by them."""
        history = [10.0, 11.0, 9.0, 10.0, 200.0, 10.0, 11.0]
        assert tier_b.robust_z(11.0, history) < 2.0
        assert tier_b.robust_z(400.0, history) > 20.0

    def test_beacon_cv_separates_periodic_from_bursty(self):
        base = datetime(2026, 8, 8, 10, 0, tzinfo=IST)
        periodic = [base + timedelta(minutes=5 * i) for i in range(12)]
        cv = tier_b.interarrival_cv(periodic)
        assert cv is not None and cv < 0.05

        bursty = [base + timedelta(seconds=s) for s in (0, 2, 5, 9, 1200, 1205, 3600)]
        cv_bursty = tier_b.interarrival_cv(bursty)
        assert cv_bursty is not None and cv_bursty > 1.0

    def test_cv_needs_enough_points(self):
        base = datetime(2026, 8, 8, 10, 0, tzinfo=IST)
        few = [base + timedelta(minutes=45 * i) for i in range(3)]
        assert tier_b.interarrival_cv(few) is None

    def test_cardinality_spike_is_detected(self):
        """The sweep signature: 2 destinations a day becomes 8 in one hour."""
        baseline_records = []
        for day in range(1, 8):
            for i in range(12):
                baseline_records += to_records(
                    [
                        make_event(
                            3,
                            day=day,
                            hour=10,
                            minute=i * 5,
                            DestinationIp="10.10.20.20" if i % 2 else "10.10.20.40",
                            DestinationPort="445",
                            Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                        )
                    ]
                )
        hours = tier_b.build_hours(baseline_records)
        baseline = tier_b.HourBaseline().fit(hours)

        sweep = []
        for i, octet in enumerate([10, 20, 30, 40, 50, 60, 70, 80]):
            sweep += to_records(
                [
                    make_event(
                        3,
                        day=8,
                        hour=10,
                        minute=i * 2,
                        DestinationIp=f"10.10.20.{octet}",
                        DestinationPort=str(1433 + i),
                        Image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
                    )
                ]
            )
        test_hours = tier_b.build_hours(sweep)
        score = baseline.score(next(iter(test_hours.values())))
        assert score.score >= config.TIER_B_ALERT_SCORE
        # A fixed-rate probe sweep is also periodic, so 'regularity' may carry the
        # score. What must be true is that the cardinality evidence is recorded.
        assert any("cardinality_spike" in r for r in score.reasons)
        assert score.components["cardinality"] >= config.ROBUST_Z_CUT

    def test_unoccupied_hour_fires_without_novel_values(self):
        """B5 needs no novel value, so it still fires if the attacker reuses a known IP."""
        baseline_records = []
        for day in range(1, 8):
            baseline_records += to_records(
                [
                    make_event(
                        1,
                        day=day,
                        hour=9,
                        minute=i,
                        Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                    )
                    for i in range(10)
                ]
            )
        baseline = tier_b.HourBaseline().fit(tier_b.build_hours(baseline_records))

        night = to_records(
            [
                make_event(
                    1,
                    day=8,
                    hour=3,
                    minute=10,
                    Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                )
            ]
        )
        hours = tier_b.build_hours(night)
        score = baseline.score(next(iter(hours.values())))
        assert score.driver == "occupancy"
        assert any("never_occupied" in r for r in score.reasons)


# ---------------------------------------------------------------------------
# Tier C and the drift layer
# ---------------------------------------------------------------------------


class TestDriftStatistics:
    def test_cusum_is_silent_on_a_stable_series(self):
        """AC5: zero alarms across the baseline window, or the score is too noisy."""
        stable = [10.0, 9.5, 10.5, 10.0, 9.8, 10.2, 10.1]
        alarms = tier_c.cusum(stable, mu=10.0, sigma=0.5)
        assert alarms == []

    def test_cusum_catches_a_sustained_small_shift(self):
        """The whole point: no single day crosses a threshold, but it persists."""
        drifting = [10.0] * 3 + [11.0] * 12  # +2 sigma, sustained
        alarms = tier_c.cusum(drifting, mu=10.0, sigma=0.5)
        assert alarms, "expected CUSUM to accumulate a sustained +2 sigma shift"
        assert alarms[0].direction == "up"
        # and it should not fire on the very first shifted day
        assert alarms[0].index > 3

    def test_cusum_ignores_a_single_spike(self):
        spiky = [10.0, 10.0, 10.0, 14.0, 10.0, 10.0, 10.0]
        assert tier_c.cusum(spiky, mu=10.0, sigma=1.0, k=0.5, h=5.0) == []

    def test_cusum_detects_going_quiet(self):
        """A user going silent matters: host offline, agent stopped, logs suppressed."""
        quiet = [10.0] * 3 + [8.0] * 12
        alarms = tier_c.cusum(quiet, mu=10.0, sigma=0.5)
        assert alarms and alarms[0].direction == "down"

    def test_psi_is_zero_for_identical_distributions(self):
        table = {"2": 90, "3": 10}
        assert tier_c.psi(table, dict(table)) == pytest.approx(0.0, abs=1e-9)

    def test_psi_catches_a_mix_shift_with_no_novel_values(self):
        """Tier A sees nothing here - no value is new, only the proportions moved."""
        baseline = {"2": 90, "3": 10}
        recent = {"2": 50, "3": 50}
        value = tier_c.psi(baseline, recent)
        assert value > config.PSI_SIGNIFICANT

    def test_psi_moderate_band(self):
        value = tier_c.psi({"2": 90, "3": 10}, {"2": 75, "3": 25})
        assert config.PSI_MODERATE <= value < config.PSI_SIGNIFICANT

    def test_trend_slope_signs(self):
        assert tier_c.trend_slope([1.0, 2.0, 3.0, 4.0, 5.0]) == pytest.approx(1.0)
        assert tier_c.trend_slope([5.0, 4.0, 3.0, 2.0, 1.0]) == pytest.approx(-1.0)
        assert tier_c.trend_slope([3.0, 3.0, 3.0, 3.0]) == pytest.approx(0.0)

    def test_trend_needs_minimum_days(self):
        assert tier_c.trend_slope([1.0, 5.0]) == 0.0

    def test_ewma_smooths(self):
        series = tier_c.ewma_series([0.0, 10.0, 0.0, 10.0], alpha=0.3)
        assert max(series) < 6.0  # spikes are damped
        assert len(series) == 4


class TestTierC:
    def test_weekend_activity_fires_on_presence_not_volume(self):
        """atk-d4-01: a normal hour on a day the user is never active.

        2 weekend samples cannot support a z-score, so the detector must use a
        presence test against a baseline weekend median of ~0.
        """
        records = []
        # Weekdays Aug 5-7 2026 are Wed-Fri; Aug 1-2 and 8-9 are weekends.
        for day in (3, 4, 5, 6, 7):  # Mon-Fri
            records += to_records(
                [
                    make_event(
                        1,
                        day=day,
                        hour=10,
                        minute=i,
                        Image="C:\\Program Files\\Google\\Chrome\\chrome.exe",
                    )
                    for i in range(30)
                ]
            )
        days = tier_c.build_days(records)
        baseline = tier_c.DayBaseline().fit(days, records)

        saturday = to_records(
            [
                make_event(1, day=8, hour=12, minute=i, Image="C:\\Windows\\System32\\robocopy.exe")
                for i in range(6)
            ]
        )
        weekend_days = tier_c.build_days(saturday)
        features_obj = next(iter(weekend_days.values()))
        assert features_obj.day_class == "weekend"
        score = baseline.score(features_obj)
        assert score.driver == "day_class"
        assert any("weekend_activity" in r for r in score.reasons)

    def test_whole_day_cv_catches_a_slow_beacon(self):
        """45-minute interval: 1-2 beats an hour defeats tier B, ~28 a day does not."""
        beats = []
        for i in range(28):
            total = 45 * i
            beats += to_records(
                [
                    make_event(
                        3,
                        day=8,
                        hour=(total // 60) % 24,
                        minute=total % 60,
                        DestinationIp="198.51.100.164",
                        DestinationPort="443",
                        DestinationHostname="telemetry-eu-sync.net",
                        Image="C:\\Windows\\System32\\rundll32.exe",
                    )
                ]
            )
        days = tier_c.build_days(beats)
        features_obj = next(iter(days.values()))
        assert features_obj.best_cv is not None
        assert features_obj.best_cv < config.BEACON_CV_MAX
        assert features_obj.beacon_beats >= 20

    def test_environment_drift_is_distinguished_from_attack_drift(self):
        """Many users, same novel values -> refit, do not alert."""
        from datetime import date as _date

        from stats_model.tier_c import DriftReport, environment_drift

        def report(user: str) -> DriftReport:
            return DriftReport(
                user=user,
                days=(_date(2026, 8, 8),),
                scores=(9.0,),
                novelty_rate=(0.4,),
                ewma=(9.0,),
                ewma_alarm_days=(),
                cusum_alarms=((_date(2026, 8, 8), "up", 6.0),),
                slope=1.0,
                psi=(),
                mu=1.0,
                sigma=1.0,
            )

        users = ["a", "b", "c", "d"]
        reports = [report(u) for u in users]

        shared = {u: {"Image=newagent.exe", "Image_dir=program_files"} for u in users}
        assert environment_drift(reports, shared) is True

        distinct = {u: {f"Image=tool-{u}.exe"} for u in users}
        assert environment_drift(reports, distinct) is False


class TestFeatureTokens:
    """Regression guards for the two features that caused a 77 alerts/user/day
    false-positive rate on the first real evaluation run."""

    def test_dow_is_not_a_scored_token(self):
        """With a 7-day fit window there is one sample per weekday, so the first
        unseen weekday makes `dow` novel for every event in the day. Measured: 774
        of 774 held-out high-confidence alerts carried a novel dow."""
        rec = to_records([make_event(1, day=8, Image="C:\\Windows\\System32\\cmd.exe")])[0]
        fields = {f for f, _ in rec.tokens}
        assert "dow" not in fields
        assert "daypart" in fields          # 5 vs 2 samples - the supportable resolution
        assert "hour" in fields

    def test_registry_details_is_not_a_feature(self):
        """Sysmon 13 Details is registry value data, near-unique per write. It
        produced 518 of 774 held-out false positives on its own; TargetObject -
        the key being written - is the actual signal."""
        assert "Details" not in config.FEATURE_FIELDS[13]
        assert "TargetObject" in config.FEATURE_FIELDS[13]
