"""Functional tests against a real generated corpus.

The unit tests assert the *statistics* on synthetic series. These assert the
*behaviour* on real EvidenceForge output: that each attack step is detected by the
mechanism the documentation claims, and that the documented blind spots really are
blind.

Set ``EFORGE_CORPUS`` to a directory containing ``data.json`` (from
``scripts/winlog_xml_to_jsonl.py --tz Asia/Kolkata``) and ``GROUND_TRUTH.json``.
Without it the whole module skips.

    EFORGE_CORPUS=/path/to/output python -m pytest stats_model/tests/test_functional.py -v

Generate one with::

    uv run eforge generate scenarios/stats-baseline-detection/scenario-dev.yaml -o out
    python scripts/winlog_xml_to_jsonl.py out/data -o out/data.json --tz Asia/Kolkata
"""

from __future__ import annotations

import os
from datetime import date
from pathlib import Path

import pytest

from stats_model import config, features, ingest, tier_a, tier_b, tier_c

CORPUS = os.environ.get("EFORGE_CORPUS")
pytestmark = pytest.mark.skipif(
    not CORPUS or not (Path(CORPUS) / "data.json").exists(),
    reason="set EFORGE_CORPUS to a directory containing data.json + GROUND_TRUTH.json",
)

FIT_END = date(2026, 8, 4)          # 7-day fit window: 2026-07-29 .. 08-04
ATTACKER = "charlie.brown"
ADMIN = "nina.kapoor"
C2_DOMAIN = "cdn-metrics-edge.net"
C2_PREFIX = "198.51.100."   # both beacon destinations live in this /24
SPRAY_SOURCE = "203.0.113.47"


@pytest.fixture(scope="module")
def corpus():
    """Load once; the fit/score split is shared by every test in the module."""
    records, resolver = features.build(ingest.load_events(Path(CORPUS) / "data.json"))
    fit = [r for r in records if r.day <= FIT_END]
    test = [r for r in records if r.day > FIT_END]
    baseline = tier_a.EventBaseline().fit(fit)
    scores = baseline.score_all(test)
    return {
        "records": records, "fit": fit, "test": test,
        "baseline": baseline, "scores": scores, "resolver": resolver,
    }


def tokens(record) -> dict[str, str]:
    return dict(record.tokens)


# ---------------------------------------------------------------------------
# Pipeline sanity
# ---------------------------------------------------------------------------


class TestPipeline:
    def test_corpus_spans_fit_and_score_windows(self, corpus):
        days = {r.day for r in corpus["records"]}
        assert min(days) <= FIT_END < max(days)
        assert len(corpus["fit"]) > 0 and len(corpus["test"]) > 0

    def test_attribution_rate_is_about_nine_percent(self, corpus):
        """Documented figure. A large move means identity resolution changed and
        every downstream number needs re-checking."""
        stats = corpus["resolver"].stats
        total = sum(stats.values())
        resolved = sum(n for (_, method), n in stats.items() if method != "unresolved")
        assert 0.05 < resolved / total < 0.15, f"attribution {resolved / total:.1%}"

    def test_timestamps_are_local_not_utc(self, corpus):
        """The hour feature is meaningless if the adapter's --tz was skipped."""
        sample = corpus["records"][0].event.ts
        assert sample.tzinfo is not None
        assert sample.utcoffset().total_seconds() != 0, "corpus looks like raw UTC"

    def test_excluded_events_never_reach_the_model(self, corpus):
        """5156 has no username field and was 56% of raw volume."""
        seen = {r.event_id for r in corpus["records"]}
        assert seen.isdisjoint(config.EXCLUDED_EVENTS)


# ---------------------------------------------------------------------------
# Tier A - the claims in docs/detection/README.md, one test each
# ---------------------------------------------------------------------------


class TestTierAClaims:
    def _d1(self, corpus, event_id: int):
        return [
            s for s in corpus["scores"]
            if s.record.event_id == event_id and not s.event_id_seen
        ]

    @pytest.mark.parametrize(
        ("event_id", "user", "step"),
        [
            (4720, ADMIN, "atk-d2-02 backdoor account created"),
            (4728, ADMIN, "atk-d2-03 Domain Admins add"),
            (4697, ADMIN, "atk-d2-05 service install"),
            (4698, ATTACKER, "atk-d2-06 scheduled task"),
            (1102, ADMIN, "atk-d4-03 security log cleared"),
        ],
    )
    def test_structural_event_ids_fire_high_confidence(self, corpus, event_id, user, step):
        """The near-zero-FP class: event types baseline activity never produces."""
        hits = self._d1(corpus, event_id)
        assert hits, f"{step}: no unseen-event-ID hit for {event_id}"
        assert any(h.user == user for h in hits), f"{step}: not attributed to {user}"
        assert all(h.confidence == "high" for h in hits)
        assert any("rare_in_population" in r for h in hits for r in h.reasons)

    def test_common_event_id_new_to_a_user_is_downgraded(self, corpus):
        """4801 (unlock) happens routinely. A user who simply had no unlock in the
        7-day window is not a finding - this fired as a false positive before the
        population gate was added."""
        hits = self._d1(corpus, 4801)
        if not hits:
            pytest.skip("no unseen 4801 in this corpus")
        assert all("rare_in_population" not in r for h in hits for r in h.reasons)
        assert all("seen for" in r for h in hits for r in h.reasons)

    def test_lsass_access_by_a_human_is_the_only_high_confidence_one(self, corpus):
        """atk-d1-05. Baseline LSASS access is entirely NT AUTHORITY\\*, so it never
        reaches a user profile; a human-owned one has no baseline support at all."""
        lsass = [
            s for s in corpus["scores"]
            if s.record.event_id in (8, 10)
            and "lsass.exe" in tokens(s.record).get("TargetImage", "")
        ]
        assert lsass, "no human-attributed LSASS access found"
        assert {s.user for s in lsass} == {ATTACKER}
        assert all(s.confidence == "high" for s in lsass)

    def test_benign_process_access_does_not_alert(self, corpus):
        """The other side of the same claim: routine Sysmon 10 must stay quiet."""
        benign = [
            s for s in corpus["scores"]
            if s.record.event_id == 10
            and tokens(s.record).get("TargetImage") in ("runtimebroker.exe", "explorer.exe")
        ]
        assert benign, "expected routine ProcessAccess in the corpus"
        assert not any(s.confidence == "high" for s in benign)

    def test_temp_directory_class_is_flagged(self, corpus):
        """dir_class is the feature that survives the attacker renaming the binary."""
        temp = [
            s for s in corpus["scores"]
            for v in s.novel_fields
            if v.field.endswith("_dir") and v.value == "temp"
        ]
        assert temp, "no C:\\Windows\\Temp image flagged"


class TestFanOut:
    def test_password_spray_is_found_by_shared_source(self, corpus):
        """atk-d1-03. Per-user this is six isolated failures; the shared indicator
        is what makes it one campaign."""
        groups = tier_a.fan_out(corpus["scores"])
        spray = [
            g for g in groups
            if g.event_id == 4625 and SPRAY_SOURCE in g.value
        ]
        assert spray, f"no fan-out group for {SPRAY_SOURCE}"
        assert spray[0].n_users >= 3
        assert ATTACKER not in spray[0].users      # the attacker is not a target

    def test_structural_fields_do_not_form_groups(self, corpus):
        """"Six users all had LogonType=3" is a tautology, not a campaign."""
        groups = tier_a.fan_out(corpus["scores"])
        assert all(g.field in config.FAN_OUT_FIELDS for g in groups)
        assert not any(g.field in ("LogonType", "Status", "hour", "daypart") for g in groups)


class TestDeduplication:
    def test_beacon_alerts_are_collapsed(self, corpus):
        """atk-d3-03 emits one alert per beat; the analyst must not get ~48.

        Filtered on the raw ``DestinationIp``, not ``DestinationHostname``:
        EvidenceForge leaves the hostname empty on Sysmon Event 3, so the C2 domain
        reaches the model through Event 22 (``QueryName``) instead. Getting this
        wrong is why an earlier version of this test silently skipped.
        """

        def is_beacon(score) -> bool:
            return (
                score.record.event_id == 3
                and (score.record.event.get("DestinationIp") or "").startswith(C2_PREFIX)
            )

        beacon = [s for s in corpus["scores"] if is_beacon(s)]
        assert beacon, "no beacon connections attributed in this corpus"
        assert len(beacon) >= 20, f"expected the full beat train, got {len(beacon)}"

        kept = [s for s in tier_a.deduplicate(corpus["scores"]) if is_beacon(s)]
        assert len(kept) < len(beacon), "dedup collapsed nothing"

        # The real invariant dedup promises: at most one alert per user per hour
        # for the same (event, field, value). Asserting a ratio instead would be
        # arbitrary - a 21-hour slow beacon legitimately spans 21 hourly buckets.
        per_hour: dict[tuple[str, date, int], int] = {}
        for score in kept:
            key = (score.user, score.record.day, score.record.hour)
            per_hour[key] = per_hour.get(key, 0) + 1
        assert max(per_hour.values()) == 1, f"duplicate alerts within an hour: {per_hour}"

    def test_long_beacon_still_costs_one_alert_per_hour(self, corpus):
        """Known limit, worth pinning: hourly dedup does not collapse a campaign.

        atk-d3-04 runs for 21 hours, so it survives as ~21 alerts - one per bucket.
        Collapsing those into a single campaign alert needs the fusion layer, which
        v1 deliberately does not build.
        """
        kept = [
            s for s in tier_a.deduplicate(corpus["scores"])
            if s.record.event_id == 3
            and (s.record.event.get("DestinationIp") or "").startswith(C2_PREFIX)
            and s.user == "diana.prince"
        ]
        assert len(kept) > 10, "expected the slow beacon to persist across many hours"

    def test_beacon_is_detected_through_destination_ip(self, corpus):
        """The mechanism claim for atk-d3-03 / atk-d3-04: an include-listed process
        owns the connection, so every beat is user-attributed."""
        beats = [
            s for s in corpus["scores"]
            if s.record.event_id == 3
            and (s.record.event.get("DestinationIp") or "").startswith(C2_PREFIX)
        ]
        assert {s.user for s in beats} == {ATTACKER, "diana.prince"}
        assert all(
            tokens(s.record).get("Image") in ("rundll32.exe", "certutil.exe") for s in beats
        )
        assert any("DestinationIp" in {v.field for v in s.novel_fields} for s in beats)


# ---------------------------------------------------------------------------
# Documented blind spots - these must stay blind, or the docs are wrong
# ---------------------------------------------------------------------------


class TestDocumentedBlindSpots:
    def test_authored_dns_query_is_service_attributed(self, corpus):
        """atk-d3-05. A storyline `dns_query` renders under the DNS Client service,
        so it never reaches a per-user baseline. Verified: the 16:20 SRV and C2
        lookups both carry NT AUTHORITY\\LOCAL SERVICE."""
        raw = ingest.load_events(Path(CORPUS) / "data.json")
        at_1620 = [
            e for e in raw
            if e.event_id == 22
            and e.day == date(2026, 8, 7)
            and e.hour == 16
            and "msdcs" in (e.get("QueryName") or "")
        ]
        assert at_1620, "expected the authored SRV lookup in the corpus"
        assert all("NT AUTHORITY" in (e.get("User") or "") for e in at_1620)

    def test_connection_prerequisite_dns_is_user_attributed(self, corpus):
        """The other half, which the docs understated: DNS owned by a user-mode
        process *is* attributable. The beacon's lookups carry the real user."""
        dns = [
            r for r in corpus["records"]
            if r.event_id == 22 and tokens(r).get("QueryName") == C2_DOMAIN
        ]
        assert dns, "expected beacon DNS in the corpus"
        assert ATTACKER in {r.user for r in dns}

    def test_sysmon_3_carries_no_byte_counters(self, corpus):
        """atk-d4-02. A 40 MB exfiltration is indistinguishable from a 1 KB one;
        volume detection needs Zeek or eCAR, not Security+Sysmon."""
        raw = ingest.load_events(Path(CORPUS) / "data.json")
        sample = next(e for e in raw if e.event_id == 3)
        assert not {"SentBytes", "ReceivedBytes", "BytesSent"} & set(sample.data)


# ---------------------------------------------------------------------------
# Tier B and tier C
# ---------------------------------------------------------------------------


class TestTierB:
    def test_sweep_hour_shows_cardinality_evidence(self, corpus):
        """atk-d3-01: distinct destinations jump inside one hour."""
        fit_hours = tier_b.build_hours(corpus["fit"], corpus["baseline"].score_all(corpus["fit"]))
        baseline = tier_b.HourBaseline().fit(fit_hours)
        hours = tier_b.build_hours(corpus["test"], corpus["scores"])
        scored = baseline.score_all(hours)
        sweep = [
            h for h in scored
            if h.user == ATTACKER and h.features.day == date(2026, 8, 7) and h.is_alert
        ]
        assert sweep, "no tier B alert for the sweep day"
        assert any(
            "cardinality_spike" in r or "periodic" in r
            for h in sweep for r in h.reasons
        )

    def test_quiet_hours_are_represented_as_zero(self, corpus):
        """A user with no events in an hour they normally occupy is a signal;
        the fit must backfill zeros rather than skip the cell."""
        fit_hours = tier_b.build_hours(corpus["fit"])
        baseline = tier_b.HourBaseline().fit(fit_hours)
        cell = baseline.history[ATTACKER][3].get("n_total", [])
        assert cell, "expected explicit history for a quiet hour"


class TestTierC:
    @pytest.fixture(scope="class")
    def daily(self, corpus):
        fit_scores = corpus["baseline"].score_all(corpus["fit"])
        fit_hours = tier_b.build_hours(corpus["fit"], fit_scores)
        hour_baseline = tier_b.HourBaseline().fit(fit_hours)
        fit_days = tier_c.build_days(corpus["fit"], fit_scores, hour_baseline.score_all(fit_hours))
        day_baseline = tier_c.DayBaseline().fit(fit_days, corpus["fit"])
        all_scores = corpus["baseline"].score_all(corpus["records"])
        all_hours = tier_b.build_hours(corpus["records"], all_scores)
        all_days = tier_c.build_days(
            corpus["records"], all_scores, hour_baseline.score_all(all_hours)
        )
        return day_baseline, day_baseline.score_all(all_days), corpus["records"]

    def test_weekend_activity_fires_the_presence_test(self, daily):
        """atk-d4-01: 12:30 is a normal hour; the *day* is what is abnormal."""
        _, scores, _ = daily
        saturday = [
            d for d in scores
            if d.user == ATTACKER and d.features.day == date(2026, 8, 8)
        ]
        assert saturday, "no daily score for the weekend attack day"
        assert saturday[0].features.day_class == "weekend"
        assert saturday[0].is_alert

    def test_cusum_is_silent_across_every_baseline_day(self, daily):
        """AC5. An alarm inside the training window is by definition a false
        positive - this failed with a fixed h before per-user calibration."""
        baseline, scores, records = daily
        offenders = []
        for user in sorted({d.user for d in scores}):
            report = baseline.drift(user, scores, records)
            for day, direction, _magnitude in report.cusum_alarms:
                if day.isoformat() in baseline.fit_days:
                    offenders.append((user, day.isoformat(), direction))
        assert not offenders, f"CUSUM alarmed on baseline days: {offenders}"

    def test_drift_fires_on_the_attack_window(self, daily):
        """The campaign must move the accumulator once scoring days begin."""
        baseline, scores, records = daily
        report = baseline.drift(ATTACKER, scores, records)
        assert report.cusum_alarms, "no CUSUM alarm for the attacker"
        assert min(day for day, _, _ in report.cusum_alarms) > FIT_END
        assert report.slope > 0

    def test_novelty_rate_separates_baseline_from_attack_days(self, daily):
        """D-1 is the interpretable drift summary and should be near zero while
        the environment is in control."""
        baseline, scores, records = daily
        report = baseline.drift(ATTACKER, scores, records)
        fit_rate = [
            rate for day, rate in zip(report.days, report.novelty_rate, strict=True)
            if day.isoformat() in baseline.fit_days
        ]
        test_rate = [
            rate for day, rate in zip(report.days, report.novelty_rate, strict=True)
            if day.isoformat() not in baseline.fit_days
        ]
        assert max(fit_rate) < max(test_rate)


# ---------------------------------------------------------------------------
# Infrastructure guarantees
# ---------------------------------------------------------------------------


class TestReproducibility:
    def test_scoring_is_deterministic(self, corpus):
        """AC7. Same input and config must give byte-identical output."""
        again = tier_a.EventBaseline().fit(corpus["fit"]).score_all(corpus["test"])
        a = [(s.user, s.record.event_id, round(s.score, 6), s.confidence) for s in corpus["scores"]]
        b = [(s.user, s.record.event_id, round(s.score, 6), s.confidence) for s in again]
        assert a == b

    def test_baseline_survives_a_save_load_round_trip(self, corpus, tmp_path):
        path = tmp_path / "tier_a.json"
        corpus["baseline"].save(path)
        restored = tier_a.EventBaseline.load(path)
        sample = corpus["test"][:400]
        before = [round(corpus["baseline"].score(r).score, 6) for r in sample]
        after = [round(restored.score(r).score, 6) for r in sample]
        assert before == after

    def test_load_refuses_a_mismatched_config(self, corpus, tmp_path, monkeypatch):
        """Scoring against a baseline fitted with different feature definitions is
        the classic silent failure; it must be loud instead."""
        path = tmp_path / "tier_a.json"
        corpus["baseline"].save(path)
        monkeypatch.setattr(config, "config_hash", lambda: "deadbeefdeadbeef")
        with pytest.raises(ValueError, match="config"):
            tier_a.EventBaseline.load(path)
