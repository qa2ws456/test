"""Turn an attributed event into scoring tokens.

A token is a ``(field, value)`` pair. Tokens come from two places:

* **Configured fields** - ``FEATURE_FIELDS[event_id]``, each passed through
  :func:`normalize.normalize_field`, which may fan one raw field out into
  several tokens (an image path yields a basename *and* a directory class).

* **Derived time fields** - ``hour``, ``dow`` and ``daypart``. These are not in
  the event data; they come from the local timestamp.

``daypart`` deserves a note, because it is the cheapest high-value token in the
whole model. The original notebook derived ``hour`` but nothing about the weekday,
which makes weekend activity invisible: 12:30 on a Saturday is a completely normal
*hour*. ``atk-d4-01`` in the dataset is built on exactly that blind spot. With only
7 fit days, per-weekday counts are too sparse to support a claim (one sample per
weekday), whereas weekday-vs-weekend has 5 samples against 2.

This module is pure: same input, same output, no state. That is what makes tier A
scoring reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass

from . import config
from .identity import Attribution
from .ingest import ParsedEvent
from .normalize import normalize_field


@dataclass(frozen=True, slots=True)
class FeatureRecord:
    """One event, attributed and tokenised, ready for any of the three tiers."""

    event: ParsedEvent
    user: str
    tokens: tuple[tuple[str, str], ...]

    # convenience passthroughs so the tiers do not reach through .event
    @property
    def event_id(self) -> int:
        return self.event.event_id

    @property
    def day(self):  # noqa: ANN201 - datetime.date
        return self.event.day

    @property
    def hour(self) -> int:
        return self.event.hour

    @property
    def host(self) -> str:
        return self.event.host

    def token_map(self) -> dict[str, str]:
        """Tokens as a dict. Loses duplicates (multi-value Privilege), so it is
        for display only - scoring iterates ``tokens`` directly."""
        return dict(self.tokens)


def extract(event: ParsedEvent, attribution: Attribution) -> FeatureRecord | None:
    """Build a :class:`FeatureRecord`, or None if this event is not scored.

    Three reasons to skip: the event ID is not in scope, the event closes a
    session (state only, never scored), or no user could be attributed.
    """
    if event.event_id in config.SESSION_CLOSE_EVENTS:
        return None
    if event.event_id not in config.SCORED_EVENTS:
        return None
    if not attribution.resolved:
        return None

    tokens: list[tuple[str, str]] = []
    for field_name in config.FEATURE_FIELDS.get(event.event_id, ()):
        tokens.extend(normalize_field(field_name, event.get(field_name)))

    # Derived temporal tokens. Emitted for every event so that an event type with
    # no configured fields (1102, 4800, 4801) still carries timing context.
    #
    # `dow` is deliberately NOT scored. With a 7-day fit window there is exactly
    # one sample per weekday, so the first Tuesday after the window makes `dow=1`
    # novel for *every event in the day* - measured: 774 of 774 high-confidence
    # alerts on the held-out day carried a novel `dow`, which then satisfied the
    # two-field corroboration gate and produced 77 alerts/user/day. `daypart` has
    # 5 weekday samples against 2 weekend ones and is the resolution the data
    # supports. Weekday context belongs in tier C's day_class, not here.
    tokens.append(("hour", str(event.hour)))
    tokens.append(("daypart", event.daypart))

    user = attribution.user
    assert user is not None  # narrowed by .resolved
    return FeatureRecord(event=event, user=user, tokens=tuple(tokens))


def extract_all(
    pairs: list[tuple[ParsedEvent, Attribution]],
) -> list[FeatureRecord]:
    """Tokenise a batch, dropping unscored events."""
    records = []
    for event, attribution in pairs:
        record = extract(event, attribution)
        if record is not None:
            records.append(record)
    return records


def build(events: list[ParsedEvent]) -> tuple[list[FeatureRecord], object]:
    """Convenience: resolve identities and tokenise in one call.

    Returns the records plus the resolver, so callers can print its attribution
    report - which is the first thing to check after a load.
    """
    from .identity import IdentityResolver

    resolver = IdentityResolver()
    pairs = resolver.resolve_all(events)
    return extract_all(pairs), resolver
