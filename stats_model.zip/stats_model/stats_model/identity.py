"""Map each event to the user who caused it.

Four strategies, tried in order:

1. **direct** - the event ID's configured user field (``TargetUserName`` for 4624,
   ``SubjectUserName`` for 4672, ``User`` for Sysmon, ``SourceUser`` for Sysmon
   8/10). Precedence within an event matters: 4688 carries
   ``TargetUserName="-"``, so a single-field lookup returns nothing instead of
   falling through to ``SubjectUserName``.
2. **session** - same host and ``LogonId``/``TargetLogonId`` as a prior successful
   logon or process create.
3. **process** - same host and image basename as a process whose owner is known.
4. **unresolved** - dropped. Roughly 91% of events land here, almost all of them
   SYSTEM, service or machine-account activity.

That 91% is the cost of a per-user model, and it is worth being explicit about it
rather than discovering it later. It buys one thing in exchange: because the
*baseline* for a human-owned LSASS access is empty, such an access scores at
maximum. A per-host model has to separate the attack from 107 benign SYSTEM
accesses statistically; the per-user model gets it for free.

This stage is **stateful and order-dependent**. Feed events chronologically
(:func:`ingest.load_events` does that by default) or session inheritance breaks.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from . import config
from .ingest import ParsedEvent
from .normalize import basename, canon_user, is_empty


@dataclass(frozen=True, slots=True)
class Attribution:
    """Who caused an event, and how confident we are in that mapping."""

    user: str | None
    method: str  # direct | session | process | unresolved
    logon_id: str | None = None

    @property
    def resolved(self) -> bool:
        return self.user is not None


_UNRESOLVED = Attribution(user=None, method="unresolved")

_LOGON_ID_FIELDS = ("TargetLogonId", "SubjectLogonId", "LogonId")
_SESSION_LEARNING_EVENTS = frozenset({4624, 4648, 4672, 4688, 1})
_IMAGE_FIELDS = ("Image", "NewProcessName", "SourceImage", "ProcessName")


class IdentityResolver:
    """Resolves events to users, learning sessions and process owners as it goes."""

    def __init__(self) -> None:
        # (host, logon_id) -> user
        self._sessions: dict[tuple[str, str], str] = {}
        # (host, image_basename) -> user
        self._processes: dict[tuple[str, str], str] = {}
        self.stats: Counter[tuple[int, str]] = Counter()

    # -- public ------------------------------------------------------------

    def resolve(self, event: ParsedEvent) -> Attribution:
        """Attribute one event, then update the session/process tables from it."""
        logon_id = self._logon_id(event)
        attribution = self._attribute(event, logon_id)
        self._learn(event, attribution, logon_id)
        self.stats[(event.event_id, attribution.method)] += 1
        return attribution

    def resolve_all(self, events: list[ParsedEvent]) -> list[tuple[ParsedEvent, Attribution]]:
        """Attribute a chronological batch."""
        return [(event, self.resolve(event)) for event in events]

    def report(self) -> str:
        """Per-event-ID attribution breakdown, for verifying a load."""
        lines = [f"{'event':>6}  {'method':<12}  count"]
        for (event_id, method), count in sorted(self.stats.items()):
            lines.append(f"{event_id:>6}  {method:<12}  {count}")
        total = sum(self.stats.values())
        resolved = sum(n for (_, m), n in self.stats.items() if m != "unresolved")
        pct = (100.0 * resolved / total) if total else 0.0
        lines.append("")
        lines.append(f"resolved to a human user: {resolved} / {total}  ({pct:.1f}%)")
        return "\n".join(lines)

    # -- internals ---------------------------------------------------------

    @staticmethod
    def _logon_id(event: ParsedEvent) -> str | None:
        """First populated logon-ID-like field.

        0x3e7 (SYSTEM), 0x3e4 (NETWORK SERVICE) and 0x3e5 (LOCAL SERVICE) are
        well-known machine sessions. They appear on every host, so inheriting a
        user through them would attribute unrelated activity across the estate.
        """
        for field_name in _LOGON_ID_FIELDS:
            value = event.get(field_name)
            if not is_empty(value):
                text = str(value).strip().lower()
                if text in {"0x0", "0x3e7", "0x3e4", "0x3e5"}:
                    continue
                return text
        return None

    def _attribute(self, event: ParsedEvent, logon_id: str | None) -> Attribution:
        # 1. the configured field, in precedence order
        for field_name in config.USER_FIELD.get(event.event_id, ()):
            user = canon_user(event.get(field_name))
            if user:
                return Attribution(user=user, method="direct", logon_id=logon_id)

        # 1b. Sysmon writes User even on events not listed above
        for field_name in ("User", "SourceUser"):
            user = canon_user(event.get(field_name))
            if user:
                return Attribution(user=user, method="direct", logon_id=logon_id)

        # 2. inherit from a known session on this host
        if logon_id:
            user = self._sessions.get((event.host, logon_id))
            if user:
                return Attribution(user=user, method="session", logon_id=logon_id)

        # 3. inherit from a known process on this host
        for field_name in _IMAGE_FIELDS:
            image = basename(event.get(field_name))
            if image:
                user = self._processes.get((event.host, image))
                if user:
                    return Attribution(user=user, method="process", logon_id=logon_id)

        return _UNRESOLVED

    def _learn(self, event: ParsedEvent, attribution: Attribution, logon_id: str | None) -> None:
        """Record session and process ownership so later events can inherit it."""
        if event.event_id in config.SESSION_CLOSE_EVENTS and logon_id:
            self._sessions.pop((event.host, logon_id), None)
            return

        if not attribution.resolved:
            return
        user = attribution.user
        assert user is not None  # narrowed by .resolved

        if logon_id and event.event_id in _SESSION_LEARNING_EVENTS:
            self._sessions[(event.host, logon_id)] = user

        # Only process-creation events establish ownership of an image. Learning
        # from, say, a network connection would let a service-owned image claim
        # a user.
        if event.event_id in (1, 4688):
            for field_name in ("Image", "NewProcessName"):
                image = basename(event.get(field_name))
                if image:
                    self._processes[(event.host, image)] = user
                    break
