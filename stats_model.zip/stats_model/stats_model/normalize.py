"""Value normalisation - the layer that decides what "the same value" means.

Two jobs:

1. **Identity canonicalisation** (`canon_user`). Security events write a bare
   ``charlie.brown``; Sysmon writes ``CORP\\charlie.brown``. Verified on real
   output: 0 of 30 Security usernames were domain-qualified, 11 of 11 Sysmon
   usernames were. Without canonicalisation every user gets two baseline keys and
   each is fitted on half their data - a bug that produces plausible-looking
   numbers, which is the worst kind.

2. **Feature normalisation**. Three fields are near-unique per event and would
   score every new event as novel: ``CommandLine`` (EvidenceForge parameterises
   baseline command lines per user by design), ``TargetFilename`` (per-user
   document names), and ``DestinationIp`` (large external pools). A feature that
   never repeats contributes noise, not signal.

Normalise for *scoring*. Always keep the raw value on the alert as evidence.
"""

from __future__ import annotations

import ipaddress
import re

from . import config

# ---------------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------------


def canon_user(raw: str | None) -> str | None:
    """Canonicalise any username shape to a bare lowercase local part.

    ``CORP\\Alice.Smith`` / ``alice.smith@corp.local`` / ``alice.smith`` -> ``alice.smith``

    Returns None for machine accounts, service identities and placeholders, which
    a per-user model cannot profile. That discards roughly 91% of events - see
    docs/detection/evidenceforge-field-mapping.md section 3c. It is the cost of
    the per-user framing, and it buys the LSASS discriminator in return.

    Stripping the domain is the safer direction than adding it: lossless for a
    single-domain environment, and it needs no knowledge of the NetBIOS short
    name. For multiple domains, key on (domain, local_part) rather than going
    back to comparing mixed shapes.
    """
    if not raw:
        return None
    user = str(raw).strip().strip("{}").lower().replace("/", "\\")
    if not user:
        return None

    if "@" in user:  # UPN: alice.smith@corp.local
        user = user.split("@", 1)[0]
    if "\\" in user:  # NetBIOS: corp\alice.smith
        domain, _, user = user.rpartition("\\")
        if domain in config.NOISE_DOMAINS:
            return None

    if user in config.NOISE_USERS:
        return None
    if config.MACHINE_ACCOUNT_RE.match(user):  # PC-001$, DC-01$
        return None
    if config.DWM_UMFD_RE.match(user):  # dwm-1, umfd-2
        return None
    return user


def is_empty(value: object) -> bool:
    """True when a field is absent or carries EvidenceForge's "not populated" marker."""
    if value is None:
        return True
    return str(value).strip().lower() in config.EMPTY_VALUES


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_DEVICE_PREFIX_RE = re.compile(r"^\\device\\harddiskvolume\d+", re.IGNORECASE)

_DIR_CLASSES: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\\windows\\temp\\", re.I), "temp"),
    (re.compile(r"\\temp\\|\\tmp\\", re.I), "temp"),
    (re.compile(r"\\appdata\\", re.I), "appdata"),
    (re.compile(r"\\users\\[^\\]+\\downloads\\", re.I), "downloads"),
    (re.compile(r"\\windows\\system32\\|\\windows\\syswow64\\", re.I), "system32"),
    (re.compile(r"\\windows\\", re.I), "windows"),
    (re.compile(r"\\program files( \(x86\))?\\", re.I), "program_files"),
    (re.compile(r"\\programdata\\", re.I), "programdata"),
    (re.compile(r"\\users\\", re.I), "userprofile"),
)


def basename(path: object) -> str | None:
    """Last path component, lowercased. Handles Windows, UNC and device paths."""
    if is_empty(path):
        return None
    text = _DEVICE_PREFIX_RE.sub("", str(path)).replace("/", "\\")
    name = text.rsplit("\\", 1)[-1].strip().lower()
    return name or None


def dir_class(path: object) -> str | None:
    """Coarse directory class for an image path.

    This is the feature that actually matters for the attack steps in the
    dataset. ``svc-host-helper.exe`` is a novel basename, but ``dir_class=temp``
    generalises: any binary running from ``C:\\Windows\\Temp`` is interesting
    regardless of its name, and it stays interesting when the attacker renames it.
    """
    if is_empty(path):
        return None
    text = _DEVICE_PREFIX_RE.sub("", str(path)).replace("/", "\\")
    if not text.endswith("\\"):
        text = text.rsplit("\\", 1)[0] + "\\" if "\\" in text else text
    for pattern, label in _DIR_CLASSES:
        if pattern.search(text):
            return label
    return "other"


def dirname_ext(path: object) -> str | None:
    """(directory, extension) for a target filename, as one token.

    ``C:\\Windows\\Temp\\q3-claims.zip`` -> ``temp|.zip``

    Per-user document names are near-unique, so the full path is a useless
    feature. The directory class plus extension is the part that repeats.
    """
    if is_empty(path):
        return None
    text = str(path).replace("/", "\\")
    cls = dir_class(text) or "other"
    name = text.rsplit("\\", 1)[-1]
    ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else "<none>"
    return f"{cls}|{ext}"


# ---------------------------------------------------------------------------
# Command lines
# ---------------------------------------------------------------------------

_CMD_RULES: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r'"[^"]*"'), '"S"'),  # quoted strings
    (re.compile(r"\\\\[^\s\"]+"), "UNC"),  # \\host\share
    (re.compile(r"[A-Za-z]:\\[^\s\"]+"), "PATH"),  # C:\dir\file
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I), "GUID"),
    (re.compile(r"\bhttps?://\S+", re.I), "URL"),
    (re.compile(r"\b[A-Za-z0-9+/]{24,}={0,2}"), "B64"),  # encoded blobs
    (re.compile(r"\b\d+\b"), "N"),
    (re.compile(r"\s+"), " "),
)


def norm_cmdline(cmd: object) -> str | None:
    """Collapse a command line to a stable skeleton.

    ``powershell.exe -NoProfile -EncodedCommand QwBvAG0...`` ->
    ``powershell.exe -noprofile -encodedcommand B64``

    The point is that the skeleton *repeats*. Raw command lines do not:
    EvidenceForge substitutes per-user project paths, document names, build
    configurations and Git branches into baseline commands, so the raw string is
    effectively a nonce and truncating it does not help.

    ``-encodedcommand B64`` then becomes a stable, rare token rather than a
    unique string - which is what makes atk-d3-02 detectable.
    """
    if is_empty(cmd):
        return None
    text = str(cmd).lower()
    for pattern, replacement in _CMD_RULES:
        text = pattern.sub(replacement, text)
    return text.strip()[:120] or None


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------


# RFC1918 plus CGNAT. Deliberately NOT ipaddress.is_private, which also covers the
# documentation ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24). Those are
# exactly what synthetic datasets use to stand in for public attacker
# infrastructure - the scenario's external addresses are 203.0.113.47 and
# 198.51.100.83 - so is_private would label the attacker "internal" and inverted
# the one network feature that matters here.
_RFC1918_NETS = tuple(
    ipaddress.ip_network(cidr)
    for cidr in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10")
)


def _is_internal(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    if addr.version != 4:
        return addr.is_private and not addr.is_global
    return any(addr in net for net in _RFC1918_NETS)


def _unwrap(value: object) -> str:
    """Strip the ::ffff: prefix Windows 4624 uses for IPv4 addresses."""
    text = str(value).strip()
    return text[7:] if text.startswith("::ffff:") else text


def ip_class(value: object) -> str | None:
    """Coarse locality class: internal / public / loopback / link_local.

    "internal" means RFC1918 or CGNAT, not ``ipaddress.is_private`` - see the note
    on :data:`_RFC1918_NETS`.
    """
    if is_empty(value):
        return None
    try:
        addr = ipaddress.ip_address(_unwrap(value))
    except ValueError:
        return None
    if addr.is_loopback:
        return "loopback"
    if addr.is_link_local:
        return "link_local"
    if addr.is_unspecified or addr.is_multicast:
        return "special"
    return "internal" if _is_internal(addr) else "public"


def bucket_ip(value: object) -> str | None:
    """Bucket an address so the feature repeats.

    Internal addresses keep their /24 - the scenario's segments are 10.10.10.0/24
    (workstations) and 10.10.20.0/24 (servers), so a workstation reaching a new
    server-VLAN address is exactly the sweep signal in atk-d3-01.

    Public addresses collapse to /16: external pools are large enough that a /32
    never repeats, and a /16 still separates "a new corner of the internet" from
    "the CDN we always use".
    """
    if is_empty(value):
        return None
    text = _unwrap(value)
    try:
        addr = ipaddress.ip_address(text)
    except ValueError:
        return str(text).lower() or None
    if addr.version != 4:
        return f"v6|{text.lower()}"
    octets = text.split(".")
    if _is_internal(addr) or addr.is_loopback or addr.is_link_local:
        return ".".join(octets[:3]) + ".0/24"
    return ".".join(octets[:2]) + ".0.0/16"


# A curated common subset, not the full Public Suffix List. Enough to stop
# "example.co.uk" collapsing to "co.uk"; extend as needed.
_MULTI_LABEL_SUFFIXES: frozenset[str] = frozenset(
    {
        "co.uk",
        "org.uk",
        "ac.uk",
        "gov.uk",
        "co.in",
        "net.in",
        "org.in",
        "co.jp",
        "com.au",
        "co.nz",
        "com.br",
        "com.cn",
        "co.za",
        "com.mx",
        "github.io",
        "herokuapp.com",
        "ngrok.io",
        "azurewebsites.net",
        "cloudfront.net",
        "amazonaws.com",
        "blob.core.windows.net",
    }
)


def registrable_domain(value: object) -> str | None:
    """Registrable domain (eTLD+1) of a hostname.

    ``a1b2.cdn-metrics-edge.net`` -> ``cdn-metrics-edge.net``

    CDN and service subdomains churn constantly, so the full hostname is a
    high-cardinality feature. The registrable domain is the part that identifies
    *who* you are talking to, and it is what makes a new C2 domain stand out.

    Internal names (single label, or ending in .local / .corp) are returned
    whole - there is no churn there and the full name is the signal.
    """
    if is_empty(value):
        return None
    host = str(value).strip().lower().rstrip(".")
    if not host or "|" in host:
        return host or None
    # DNS SRV/service records: keep the whole thing, the prefix is the meaning.
    if host.startswith("_"):
        return host
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    if host.endswith((".local", ".corp", ".internal", ".lan")):
        return host
    last_two = ".".join(labels[-2:])
    last_three = ".".join(labels[-3:])
    if last_two in _MULTI_LABEL_SUFFIXES and len(labels) >= 3:
        return last_three
    if last_three in _MULTI_LABEL_SUFFIXES and len(labels) >= 4:
        return ".".join(labels[-4:])
    return last_two


# ---------------------------------------------------------------------------
# Multi-value fields
# ---------------------------------------------------------------------------


def split_privileges(value: object) -> list[str]:
    """Split 4672's PrivilegeList into one token per privilege.

    The raw field is a tab-separated, newline-joined blob. As a single histogram
    key it is brittle: adding one privilege makes the whole value novel. Split,
    and ``SeLoadDriverPrivilege`` appearing for a user whose baseline shows only
    the standard admin set becomes a clean, specific signal.
    """
    if is_empty(value):
        return []
    text = str(value).replace("\t", "\n").replace(",", "\n")
    return sorted({p.strip() for p in text.split("\n") if p.strip()})


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------


def normalize_field(field: str, value: object) -> list[tuple[str, str]]:
    """Turn one raw ``(field, value)`` into zero or more scoring tokens.

    One raw field can produce several tokens: an image path yields both its
    basename and its directory class, and an address yields both its bucket and
    its locality class. Multi-value fields fan out to one token per element.
    """
    if is_empty(value):
        return []

    if field in config.MULTIVALUE_FIELDS:
        return [("Privilege", p) for p in split_privileges(value)]

    if field in config.PATH_FIELDS:
        tokens: list[tuple[str, str]] = []
        name = basename(value)
        if name:
            tokens.append((field, name))
        cls = dir_class(value)
        if cls:
            tokens.append((f"{field}_dir", cls))
        return tokens

    if field in config.COMMANDLINE_FIELDS:
        norm = norm_cmdline(value)
        return [(field, norm)] if norm else []

    if field in config.FILEPATH_FIELDS:
        token = dirname_ext(value)
        return [(field, token)] if token else []

    if field in config.IP_FIELDS:
        tokens = []
        bucket = bucket_ip(value)
        if bucket:
            tokens.append((field, bucket))
        cls = ip_class(value)
        if cls:
            tokens.append((f"{field}_class", cls))
        return tokens

    if field in config.HOSTNAME_FIELDS:
        domain = registrable_domain(value)
        return [(field, domain)] if domain else []

    return [(field, str(value).strip().lower())]
