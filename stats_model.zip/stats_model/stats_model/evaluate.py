"""Grade alerts against EvidenceForge's GROUND_TRUTH.json.

The point of this module is to make the coverage claims in docs/detection/README.md
*measurable* rather than argued. Where the measurement and the doc disagree, the
measurement wins.

Two things it insists on:

* **Red herrings are graded separately from baseline noise.** ``GROUND_TRUTH.json``
  marks them with ``ground_truth_section``, and conflating the two hides exactly
  the precision problem the red herrings exist to expose - ``rh-01`` is a security
  analyst running the same commands as the attacker's discovery step.
* **Recall is per attack *step*, not per alert.** Forty-eight alerts on one beacon
  is one detection, not forty-eight.
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

MATCH_TOLERANCE = timedelta(minutes=5)


@dataclass(frozen=True, slots=True)
class GroundTruthEvent:
    """One authored storyline or red-herring step."""

    record_id: str
    storyline_id: str
    kind: str
    ts: datetime
    actor: str
    system: str
    activity: str
    section: str  # "storyline" | "red_herring"
    emitted: bool
    related_users: frozenset[str] = frozenset()

    @property
    def is_attack(self) -> bool:
        return not self.section.startswith("red_herring")

    @property
    def candidate_users(self) -> frozenset[str]:
        """Accounts whose telemetry can carry this step.

        Usually just the actor. But a password spray is authored with
        ``actor: SYSTEM`` while every 4625/4776 it produces is attributed to a
        *target* account - matching on the actor alone scores it as a miss when it
        was in fact detected. Same for account-management steps, where the
        interesting evidence may sit on the target principal.
        """
        return frozenset({self.actor}) | self.related_users


def load_ground_truth(path: Path | str) -> list[GroundTruthEvent]:
    """Read GROUND_TRUTH.json (schema v2) into typed rows."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    out: list[GroundTruthEvent] = []
    for row in payload.get("events", []):
        stamp = row.get("time")
        if not stamp:
            continue
        try:
            ts = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        except ValueError:
            continue
        attributes = row.get("attributes") or {}
        related: set[str] = set()
        for key in ("target_accounts", "target_users"):
            value = attributes.get(key)
            if isinstance(value, list):
                related.update(str(v).split("\\")[-1].lower() for v in value)
        for key in ("target_username", "member_name", "success_account", "target_user"):
            value = attributes.get(key)
            if isinstance(value, str) and value:
                related.add(value.split("\\")[-1].lower())

        out.append(
            GroundTruthEvent(
                record_id=str(row.get("record_id") or ""),
                storyline_id=str(row.get("storyline_id") or ""),
                kind=str(row.get("kind") or ""),
                ts=ts,
                actor=str(row.get("actor") or "").split("\\")[-1].lower(),
                system=str(row.get("system") or ""),
                activity=str(row.get("activity") or ""),
                section=str(row.get("ground_truth_section") or "storyline"),
                emitted=bool(row.get("emitted", True)),
                related_users=frozenset(related),
            )
        )
    return out


@dataclass(frozen=True, slots=True)
class Alert:
    """Tier-agnostic alert, so one matcher grades all three approaches."""

    tier: str  # "A" | "B" | "C"
    user: str
    ts: datetime  # event time (A), hour start (B), day start (C)
    score: float
    confidence: str  # high | low
    reasons: tuple[str, ...]
    window: timedelta = MATCH_TOLERANCE

    def covers(self, when: datetime) -> bool:
        """Does this alert's time window contain the given instant?"""
        start = self.ts - (self.window if self.tier == "A" else timedelta(0))
        end = self.ts + self.window
        return start <= when <= end


def alerts_from_tier_a(scores, *, high_only: bool = False) -> list[Alert]:
    out = []
    for s in scores:
        if not s.is_alert:
            continue
        if high_only and s.confidence != "high":
            continue
        out.append(
            Alert(
                tier="A",
                user=s.user,
                ts=s.ts,
                score=s.score,
                confidence=s.confidence,
                reasons=s.reasons,
            )
        )
    return out


def alerts_from_tier_b(scores) -> list[Alert]:
    out = []
    for s in scores:
        if not s.is_alert:
            continue
        start = datetime.combine(s.features.day, datetime.min.time()).replace(hour=s.features.hour)
        out.append(
            Alert(
                tier="B",
                user=s.user,
                ts=start,
                score=s.score,
                confidence="high",
                reasons=s.reasons,
                window=timedelta(hours=1),
            )
        )
    return out


def alerts_from_tier_c(scores) -> list[Alert]:
    out = []
    for s in scores:
        if not s.is_alert:
            continue
        start = datetime.combine(s.features.day, datetime.min.time())
        out.append(
            Alert(
                tier="C",
                user=s.user,
                ts=start,
                score=s.score,
                confidence="high",
                reasons=s.reasons,
                window=timedelta(days=1),
            )
        )
    return out


@dataclass
class StepResult:
    """Whether one authored step was detected, and by what."""

    storyline_id: str
    section: str
    actor: str
    system: str
    activity: str
    ts: datetime
    tiers: set[str]
    best_score: float = 0.0
    high_confidence: bool = False
    sample_reasons: tuple[str, ...] = ()

    @property
    def detected(self) -> bool:
        return bool(self.tiers)

    @property
    def precise(self) -> bool:
        """Detected by tier A, i.e. pinned to the event within minutes.

        Tier B and C alerts cover an hour or a whole day, so they legitimately
        match every step that user took in that window. Counting those as equal to
        an event-level detection would overstate the model: on a day the analyst is
        already investigating, "the day was flagged" is coverage, not precision.
        """
        return "A" in self.tiers

    @property
    def window_only(self) -> bool:
        return self.detected and not self.precise


def match(ground_truth: list[GroundTruthEvent], alerts: list[Alert]) -> dict[str, StepResult]:
    """Join alerts to authored steps.

    An alert matches a step when the users agree and the alert's window contains
    the step's timestamp. Steps are keyed by ``storyline_id`` so a multi-event step
    counts once - detecting the process but not the logon is still detection.
    """
    by_user: dict[str, list[Alert]] = defaultdict(list)
    for alert in alerts:
        by_user[alert.user].append(alert)

    results: dict[str, StepResult] = {}
    for event in ground_truth:
        if not event.emitted:
            continue
        result = results.get(event.storyline_id)
        if result is None:
            result = StepResult(
                storyline_id=event.storyline_id,
                section=event.section,
                actor=event.actor,
                system=event.system,
                activity=event.activity,
                ts=event.ts,
                tiers=set(),
            )
            results[event.storyline_id] = result

        # Local time: ground truth is UTC, alerts are local. Compare as instants.
        candidates = [a for user in event.candidate_users for a in by_user.get(user, [])]
        for alert in candidates:
            when = event.ts
            if alert.ts.tzinfo is not None and when.tzinfo is None:
                when = when.replace(tzinfo=alert.ts.tzinfo)
            elif alert.ts.tzinfo is None and when.tzinfo is not None:
                when = when.replace(tzinfo=None)
            if alert.covers(when):
                result.tiers.add(alert.tier)
                result.best_score = max(result.best_score, alert.score)
                if alert.confidence == "high":
                    result.high_confidence = True
                if not result.sample_reasons:
                    result.sample_reasons = alert.reasons
    return results


@dataclass
class Report:
    """Aggregate evaluation metrics."""

    attacks: list[StepResult]
    red_herrings: list[StepResult]
    alerts_per_user_day: dict[tuple[str, date], int]
    fit_days: set[str]

    @property
    def attack_recall(self) -> tuple[int, int]:
        return sum(1 for a in self.attacks if a.detected), len(self.attacks)

    @property
    def attack_precise(self) -> tuple[int, int]:
        return sum(1 for a in self.attacks if a.precise), len(self.attacks)

    @property
    def attack_high_confidence(self) -> tuple[int, int]:
        return sum(1 for a in self.attacks if a.high_confidence), len(self.attacks)

    @property
    def red_herring_alerts(self) -> tuple[int, int]:
        return sum(1 for r in self.red_herrings if r.detected), len(self.red_herrings)

    @property
    def red_herring_precise(self) -> tuple[int, int]:
        return sum(1 for r in self.red_herrings if r.precise), len(self.red_herrings)

    def baseline_alert_load(self) -> float:
        """Mean high-confidence alerts per user per day over the fit window.

        This is the analyst-load number, and the one that decides whether the
        detector is usable. Measured on the fit days, where by construction there
        are no attacks.
        """
        values = [
            count
            for (_user, day), count in self.alerts_per_user_day.items()
            if day.isoformat() in self.fit_days
        ]
        return sum(values) / len(values) if values else 0.0

    def render(self) -> str:
        det, total = self.attack_recall
        precise, _ = self.attack_precise
        hi, _ = self.attack_high_confidence
        rh_det, rh_total = self.red_herring_alerts
        window_only = sum(1 for a in self.attacks if a.window_only)
        lines = [
            "=" * 78,
            "EVALUATION",
            "=" * 78,
            f"  attack steps detected          : {det} / {total}",
            f"    of which event-precise (A)   : {precise} / {total}",
            f"    of which window-only (B/C)   : {window_only} / {total}  "
            f"(hour or day flagged, not the event)",
            f"  attack steps high-confidence   : {hi} / {total}",
            f"  red herrings flagged           : {rh_det} / {rh_total}   (lower is better)",
            f"  baseline alerts/user/day       : {self.baseline_alert_load():.2f}"
            f"   (held-out day, {len(self.fit_days)} fit days)",
            "",
            f"  {'step':<18}{'tiers':<9}{'score':>8}  {'detection':<12}activity",
            "  " + "-" * 74,
        ]
        for result in sorted(self.attacks, key=lambda r: r.ts):
            tiers = ",".join(sorted(result.tiers)) or "-"
            if result.precise:
                kind = "event" if result.high_confidence else "event(low)"
            elif result.detected:
                kind = "window"
            else:
                kind = "MISS"
            lines.append(
                f"  {result.storyline_id:<18}{tiers:<9}{result.best_score:>8.1f}  "
                f"{kind:<12}{result.activity[:38]}"
            )
        if self.red_herrings:
            lines.append("")
            lines.append("  red herrings (false-positive control set)")
            lines.append("  " + "-" * 74)
            for result in sorted(self.red_herrings, key=lambda r: r.ts):
                tiers = ",".join(sorted(result.tiers)) or "-"
                kind = "event" if result.precise else ("window" if result.detected else "-")
                lines.append(
                    f"  {result.storyline_id:<18}{tiers:<9}{result.best_score:>8.1f}  "
                    f"{kind:<12}{result.activity[:38]}"
                )
        return "\n".join(lines)


def evaluate(
    ground_truth_path: Path | str,
    alerts: list[Alert],
    fit_days: set[str] | None = None,
) -> Report:
    ground_truth = load_ground_truth(ground_truth_path)
    results = match(ground_truth, alerts)

    per_user_day: dict[tuple[str, date], int] = defaultdict(int)
    for alert in alerts:
        if alert.confidence == "high":
            per_user_day[(alert.user, alert.ts.date())] += 1

    return Report(
        attacks=[r for r in results.values() if not r.section.startswith("red_herring")],
        red_herrings=[r for r in results.values() if r.section.startswith("red_herring")],
        alerts_per_user_day=dict(per_user_day),
        fit_days=fit_days or set(),
    )
