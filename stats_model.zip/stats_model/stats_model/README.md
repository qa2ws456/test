# stats_model — code guide

A basic per-user statistical baseline detector for Windows Security + Sysmon logs.
Three scoring approaches, **one file each**, over a shared feature pipeline.

Design plan: [../docs/detection/implementation-plan.md](../docs/detection/implementation-plan.md).
Field-name evidence: [../docs/detection/evidenceforge-field-mapping.md](../docs/detection/evidenceforge-field-mapping.md).

---

## Files, in the order data flows through them

| File | Stage | What it does |
|---|---|---|
| [config.py](config.py) | — | Every tunable: which event IDs are scored, which field identifies the user, which fields become features, weights, gates, drift parameters. `config_hash()` is stamped into saved baselines |
| [normalize.py](normalize.py) | shared | Decides **what "the same value" means**. `canon_user` (the critical fix), plus normalisers for command lines, paths, addresses and hostnames |
| [ingest.py](ingest.py) | 1 | JSONL → `ParsedEvent`. Derives `hour` / `dow` / `daypart` from the **local** timestamp |
| [identity.py](identity.py) | 2 | Event → user. Four strategies: direct field → session → process → unresolved. Stateful, so feed events chronologically |
| [features.py](features.py) | 3 | Event + attribution → `FeatureRecord` (a tuple of `(field, value)` tokens). Pure function, no state |
| **[tier_a.py](tier_a.py)** | **A** | **Per event.** Frequency tables + surprisal. Gates, dedup, fan-out correlator |
| **[tier_b.py](tier_b.py)** | **B** | **Per hour.** Volume, cardinality, novelty roll-up, inter-arrival CV, occupancy |
| **[tier_c.py](tier_c.py)** | **C** | **Per day.** Daily vector, weekend presence test, plus the **drift layer**: EWMA, CUSUM, PSI, trend |
| [evaluate.py](evaluate.py) | grade | Joins alerts to `GROUND_TRUTH.json`; recall per attack step, red-herring FP rate, analyst load |
| [cli.py](cli.py) | driver | `fit` / `score` / `evaluate` |

B is an accumulator over A's per-event verdicts; C is an accumulator over B's.
That is why they share one feature pass — and it is what preserves the drill-down
from an alerting day to the events that caused it.

---

## Running it

```bash
# 0. generate a corpus (fast dev variant: ~20-30 min, ~300 MB)
uv run eforge generate scenarios/stats-baseline-detection/scenario-dev.yaml -o output-dev

# 1. XML -> JSONL, converted to local time (the hour feature depends on this)
python scripts/winlog_xml_to_jsonl.py output-dev/data -o data/data.json --tz Asia/Kolkata

# 2. score days after the fit window, printing the top alerts per tier
python -m stats_model.cli score data/data.json --fit-end 2026-08-04 --top 15

# 3. grade against ground truth
python -m stats_model.cli evaluate data/data.json --fit-end 2026-08-04 \
    --ground-truth output-dev/GROUND_TRUTH.json
```

The fit and scoring corpora come from **one** generation run, split by local date on
`--fit-end`. Separate runs have different RNG streams, so session IDs and
application choices would not line up.

Tests: `python -m pytest stats_model/tests/ -q`

---

## The three approaches

### Tier A — per event ([tier_a.py](tier_a.py))

Latency: none. Detects point anomalies. Carries 15 of the 20 attack steps.

The model is a frequency table: for each user, event ID and field, how often was
each value seen? Scoring asks two questions — has this user ever produced this
**event ID** (`A1`), and has this user ever produced this **value** (`A2`).

```python
p     = (count + ALPHA) / (n + ALPHA * (n_unique + 1))   # Laplace smoothing
bits  = -log2(p)
score = D1_BONUS * (event ID unseen) + sum of top-3 weighted field surprisals
```

Top-3 rather than all fields, so one strong signal is not diluted by a tail of
familiar ones.

Two gates do the real work:

- **support gate** — a field cannot claim "unseen" on `n < 20`. Seven fit days
  leaves many cells thin, and the events affected (4648, 4672, 4768) are the ones
  you most want to trust.
- **corroboration gate** — high confidence needs an unseen event ID, or ≥2 novel
  fields. One novel field is a lead. `rh-01` is a security analyst running the same
  `net group` / `nltest` commands as the attacker; no single-field rule separates
  them.

Then two post-processors:

- `deduplicate()` — `atk-d3-03` emits ~48 identical alerts, one per beacon beat.
  Collapses them.
- `fan_out()` — the nine-line substitute for a per-host baseline. Groups novel
  values across users within an hour. Per-user, a 6-account password spray is six
  unremarkable single failures; grouped, it is one source IP against six users.

### Tier B — per hour ([tier_b.py](tier_b.py))

Latency ≤ 1 hour. Detects bursts, sweeps, sprays, tight beacons, off-hours
occupancy — the things a single event cannot express.

Five feature families, scored by weighted **max** (one strong family should carry
the hour, not be averaged away):

| Family | Catches |
|---|---|
| volume `n_total`, `n_<event>` | rate spikes |
| cardinality `nuniq_<event>_<field>` | sweeps and sprays — weighted highest, since it is hard to inflate accidentally |
| novelty roll-up | converts tier A's alert storm into one ranked signal |
| regularity `interarrival_cv` | beacons: a 5-min beacon sits near 0.09, human bursts above 1.0 |
| occupancy | activity in an hour the user never occupies — needs no novel value at all |

`robust_z` uses median/MAD, not mean/σ. EvidenceForge models activity with a
Hawkes self-exciting process, so legitimate activity genuinely bursts — and those
bursts drag a mean/σ estimate around until nothing looks anomalous.

**The 7-sample problem:** 7 fit days gives 7 samples per `(user, hour_of_day)`.
That supports a median and MAD, not a p99. Hence a fixed `z > 6` cut, plus
`pool_dayparts()` for when you need a tail. The real fix is a longer fit window.

### Tier C — per day, plus drift ([tier_c.py](tier_c.py))

Latency ≤ 24 hours. Two jobs.

**Job 1 — daily comparison.** Same robust-z machinery, restricted to comparable
days. `day_class` is `weekday` / `weekend`: 7 fit days gives 5 weekday and 2
weekend samples, and per-weekday typing would give one sample per class, which is
not a distribution.

Two samples cannot support a z-score either, so weekend cells use a **presence
test**: the baseline weekend median is ~0 for non-IT personas, so "any activity at
all" is what the data supports. That is what detects `atk-d4-01` — a claims analyst
running collection tooling at 12:30 on a Saturday, an hour she works every weekday.

Also tracked: temporal shape (`active_hours`, `first_hour`, `last_hour`,
`hour_entropy`, `offhours_share`), breadth (`n_hosts`), and composition **shares**
— an attacker can hold the daily total flat while shifting the mix.

**Job 2 — the drift layer.** Drift means the deviation is too small for any single
day to cross a threshold, but it persists or grows. Threshold tests are the wrong
tool; accumulators are the right one.

| Function | Statistic | Catches |
|---|---|---|
| novelty rate | `novel_values / n_total` per day | the interpretable summary — build this first |
| `ewma_alarms` | EWMA + control limits | level shifts, ignoring single-day spikes |
| **`cusum`** | **two-sided CUSUM** | **sustained small shifts — the core drift detector** |
| `psi` | Population Stability Index | mix change with **no novel values at all** |
| `trend_slope` | OLS slope | campaign escalation |

`cusum` is the one that matters. It accumulates deviations in units of σ, ignoring
anything below `k = 0.5σ`, and fires when the running sum exceeds `h = 5`. That is
roughly ten consecutive days at +1σ or three at +2σ — the signature of
`atk-d3-04` (45-minute beacon) and of the `atk-d1-*` → `atk-d4-*` escalation.
It tracks downward drift too: a user going quiet means host offline, agent stopped,
or logs suppressed.

`psi` catches the one thing value-membership cannot see. A user whose `LogonType`
mix moves from 90/10 to 50/50 has produced **no novel value** — tier A sees
nothing, PSI sees it clearly.

`environment_drift()` separates a change in the environment from an attack:

|  | Attack drift | Environment drift |
|---|---|---|
| users affected | few | many at once |
| novel values | different per user | **the same** across users |

Without that check, a software rollout produces a slowly rising false-positive
curve that looks exactly like an attack. When it returns True, refit the baseline
rather than investigating.

---

## Two things to know before trusting output

**Only ~9% of events reach a per-user baseline.** Measured on the generated
corpus: 1,545 of 16,949 events in a 4-hour slice, or 20.8% excluding Security 5156
(which has no username field at all and was 56% of volume). The rest is SYSTEM,
service and machine-account activity, which a per-user model cannot profile.
`IdentityResolver.report()` prints this — check it after every load.

That is the cost of the per-user framing. What it buys: because the *baseline* for
a human-owned LSASS access is empty (measured: 107 benign accesses, all
`NT AUTHORITY\*`), such an access scores at maximum. A per-host model has to
separate the attack from those 107 statistically.

**These numbers will look better here than in production.** The baseline is fitted
on EvidenceForge's generated activity, which draws from finite YAML pools. Real
telemetry has a much heavier novelty tail — users install software, visit new
domains, open new paths continuously. Treat the results as an upper bound on recall
and a lower bound on false positives, and re-derive every threshold on real data.
The drift layer is most exposed: `CUSUM_K` and `CUSUM_H` are set from the
baseline's variance, and real variance is larger.

---

## Extending it

| Want to... | Change |
|---|---|
| add an event ID | `config.SECURITY_EVENTS` / `SYSMON_DETAILED`, `USER_FIELD`, `FEATURE_FIELDS` |
| change what a value means | `normalize.normalize_field` and its helpers |
| retune scoring | `config.FIELD_WEIGHT`, `MIN_SUPPORT`, `ROBUST_Z_CUT`, `CUSUM_*` |
| add a per-host baseline (v2) | `features.extract` already has `event.host`; add a scope key and reuse `tier_a.EventBaseline` unchanged |
| add conjunction features (v2) | emit extra tokens from `features.extract`, e.g. `("Image__DestinationPort", f"{img}|{port}")` — no scoring changes needed |

Both v2 items were deliberately deferred; see the plan's §9 for what they unlock.
Any change to a feature definition changes `config_hash()`, and `EventBaseline.load`
refuses a mismatched baseline rather than silently scoring against the wrong model.
