"""Approach B - score one feature vector per user per clock hour.

    latency: up to 1 hour
    detects: bursts, sweeps, sprays, tight beacons, off-hours occupancy
    misses:  sub-threshold slow activity, weekday context, cross-hour campaigns

Tier B answers the questions tier A structurally cannot: *how much*, *how many
distinct*, and *how regular*. A single 4625 is either a value the user has seen or
not; nine failures in 22 minutes score identically to one. Rate is a property of a
window, not an event.

It is an **accumulator over tier A**, not a separate system. The novelty family
(B3) consumes tier A's per-event verdicts directly, which is also how tier A's
duplicate-alert storm gets converted into one ranked signal: ``atk-d3-03``
produces ~12 identical tier A alerts per hour and one tier B hour.

The 7-sample problem
--------------------
Seven fit days gives **7 samples** per ``(user, hour_of_day)`` cell. That supports
a median and a MAD. It does not support a p99. So this tier uses a fixed robust-z
cut rather than an empirical quantile, and :func:`pool_dayparts` is provided for
when you need a tail. The real fix is a longer fit window.
"""

from __future__ import annotations

import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime

from . import config
from .features import FeatureRecord
from .tier_a import EventScore

# Which field identifies "the other end" for regularity analysis. A beacon is
# periodic contact with one destination, so the CV must be computed per
# destination - pooling all connections in an hour would hide it.
BEACON_GROUP_FIELD: dict[int, str] = {
    3: "DestinationIp",
    22: "QueryName",
    4624: "IpAddress",
    4625: "IpAddress",
}


# ---------------------------------------------------------------------------
# Statistics helpers
# ---------------------------------------------------------------------------


def robust_z(x: float, history: list[float]) -> float:
    """Median/MAD z-score.

    Mean and standard deviation are the wrong tools here. EvidenceForge models
    user activity with a Hawkes self-exciting process, so legitimate activity
    genuinely clusters into bursts - and those bursts drag a mean/sigma estimate
    around until nothing looks anomalous. The median is unmoved by them.

    1.4826 rescales MAD to be comparable with sigma for normally distributed data.
    """
    if not history:
        return 0.0
    med = statistics.median(history)
    mad = statistics.median([abs(h - med) for h in history])
    scale = 1.4826 * max(mad, config.MAD_FLOOR)
    return (x - med) / scale


def interarrival_cv(timestamps: list[datetime]) -> float | None:
    """Coefficient of variation of inter-arrival gaps. Low means machine-driven.

    A 5-minute beacon with jitter 0.15 lands near 0.09. Human browsing, generated
    by a Hawkes process, sits above 1.0 because it bursts then goes quiet. That gap
    is wide, stable, and needs no knowledge of the destination.

    Returns None below :data:`config.BEACON_MIN_EVENTS` - a CV from four points is
    not an estimate. This is precisely why the 45-minute beacon (1-2 beats per
    hour) needs tier C.
    """
    if len(timestamps) < config.BEACON_MIN_EVENTS:
        return None
    ordered = sorted(timestamps)
    gaps = [(b - a).total_seconds() for a, b in zip(ordered, ordered[1:], strict=False)]
    mean = statistics.fmean(gaps)
    if mean <= 0:
        return None
    return statistics.pstdev(gaps) / mean


def beacon_penalty(cv: float | None) -> float:
    """Turn a CV into a score contribution. Perfectly regular scores highest."""
    if cv is None or cv > config.BEACON_CV_MAX:
        return 0.0
    return 10.0 * (1.0 - cv / config.BEACON_CV_MAX)


# ---------------------------------------------------------------------------
# Hourly feature vector
# ---------------------------------------------------------------------------


@dataclass
class HourFeatures:
    """One user's activity in one clock hour."""

    user: str
    day: date
    hour: int

    n_total: int = 0
    n_by_event: dict[int, int] = field(default_factory=dict)
    # (event_id, field) -> set of distinct values, collapsed to counts on freeze
    nuniq: dict[str, int] = field(default_factory=dict)
    hosts: int = 0

    # from tier A
    novel_values: int = 0
    novel_event_ids: int = 0
    max_event_score: float = 0.0

    # regularity: best (lowest) CV over destination groups in this hour
    best_cv: float | None = None

    def vector(self) -> dict[str, float]:
        """Flatten to a named feature vector for baseline comparison."""
        out: dict[str, float] = {
            "n_total": float(self.n_total),
            "hosts": float(self.hosts),
            "novel_values": float(self.novel_values),
        }
        for event_id, count in self.n_by_event.items():
            out[f"n_{event_id}"] = float(count)
        for key, count in self.nuniq.items():
            out[f"nuniq_{key}"] = float(count)
        return out


def build_hours(
    records: list[FeatureRecord], scores: list[EventScore] | None = None
) -> dict[tuple[str, date, int], HourFeatures]:
    """Aggregate records (and optionally tier A verdicts) into hourly vectors."""
    by_key: dict[tuple[str, date, int], HourFeatures] = {}
    distinct: dict[tuple[str, date, int], dict[str, set[str]]] = defaultdict(
        lambda: defaultdict(set)
    )
    hosts: dict[tuple[str, date, int], set[str]] = defaultdict(set)
    stamps: dict[tuple[str, date, int], dict[tuple[int, str], list[datetime]]] = defaultdict(
        lambda: defaultdict(list)
    )

    for record in records:
        key = (record.user, record.day, record.hour)
        features = by_key.get(key)
        if features is None:
            features = HourFeatures(user=record.user, day=record.day, hour=record.hour)
            by_key[key] = features
        features.n_total += 1
        features.n_by_event[record.event_id] = features.n_by_event.get(record.event_id, 0) + 1
        hosts[key].add(record.host)

        for field_name, value in record.tokens:
            if field_name in ("hour", "dow", "daypart"):
                continue
            distinct[key][f"{record.event_id}_{field_name}"].add(value)

        group_field = BEACON_GROUP_FIELD.get(record.event_id)
        if group_field:
            for field_name, value in record.tokens:
                if field_name == group_field:
                    stamps[key][(record.event_id, value)].append(record.event.ts)
                    break

    if scores:
        for score in scores:
            key = (score.user, score.record.day, score.record.hour)
            features = by_key.get(key)
            if features is None:
                continue
            features.novel_values += len(score.novel_fields)
            if not score.event_id_seen:
                features.novel_event_ids += 1
            features.max_event_score = max(features.max_event_score, score.score)

    for key, features in by_key.items():
        features.nuniq = {name: len(values) for name, values in distinct[key].items()}
        features.hosts = len(hosts[key])
        cvs = [
            cv
            for group_stamps in stamps[key].values()
            if (cv := interarrival_cv(group_stamps)) is not None
        ]
        features.best_cv = min(cvs) if cvs else None

    return by_key


# ---------------------------------------------------------------------------
# Baseline and scoring
# ---------------------------------------------------------------------------


class HourBaseline:
    """Per ``(user, hour_of_day)`` distribution of hourly vectors."""

    def __init__(self) -> None:
        # user -> hour_of_day -> feature name -> list of daily values
        self.history: dict[str, dict[int, dict[str, list[float]]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(list))
        )
        # user -> set of hours ever active
        self.occupied: dict[str, set[int]] = defaultdict(set)
        self.fit_days: set[str] = set()

    def fit(self, hours: dict[tuple[str, date, int], HourFeatures]) -> HourBaseline:
        """Accumulate one sample per fit day per (user, hour_of_day) cell.

        Hours with no activity are *not* skipped implicitly: after the loop we
        backfill explicit zeros for every day the user was seen at all, so
        "normally silent at 03:00" is a real observation rather than missing data.
        """
        by_user_days: dict[str, set[date]] = defaultdict(set)
        for (user, day, _hour), features in hours.items():
            by_user_days[user].add(day)
            self.fit_days.add(day.isoformat())
            self.occupied[user].add(features.hour)
            for name, value in features.vector().items():
                self.history[user][features.hour][name].append(value)

        # Backfill zeros so a quiet hour counts as evidence of quietness.
        for user, days in by_user_days.items():
            for hour in range(24):
                seen = len(self.history[user][hour].get("n_total", []))
                missing = len(days) - seen
                if missing > 0:
                    self.history[user][hour]["n_total"].extend([0.0] * missing)
        return self

    def score(self, features: HourFeatures) -> HourScore:
        history = self.history.get(features.user, {})
        cell = history.get(features.hour, {})
        vector = features.vector()

        volume_z: list[tuple[str, float]] = []
        card_z: list[tuple[str, float]] = []
        for name, value in vector.items():
            past = cell.get(name, [])
            if not past:
                # A feature never seen in this cell before. Only meaningful if the
                # user has history in this hour at all, otherwise occupancy covers it.
                if cell.get("n_total") and value > 0:
                    (card_z if name.startswith("nuniq_") else volume_z).append(
                        (name, config.ROBUST_Z_CUT + 1.0)
                    )
                continue
            z = robust_z(value, past)
            if name.startswith("nuniq_"):
                card_z.append((name, z))
            else:
                volume_z.append((name, z))

        occupied = features.hour in self.occupied.get(features.user, set())
        novel_median = statistics.median(cell.get("novel_values", [0.0]) or [0.0])
        novelty_ratio = features.novel_values / (novel_median + 1.0)

        components: dict[str, float] = {
            "volume": config.W_VOLUME * max((z for _, z in volume_z), default=0.0),
            "cardinality": config.W_CARDINALITY * max((z for _, z in card_z), default=0.0),
            "novelty": config.W_NOVELTY * novelty_ratio,
            "regularity": config.W_REGULARITY * beacon_penalty(features.best_cv),
            "occupancy": config.W_OCCUPANCY * (0.0 if occupied else 5.0),
        }
        # Weighted max, not sum: one strong family should carry the hour rather
        # than being averaged away by four quiet ones.
        driver = max(components, key=lambda k: components[k])
        score = components[driver]

        reasons: list[str] = []
        if not occupied:
            reasons.append(f"hour_never_occupied:{features.hour}")
        for name, z in sorted(card_z, key=lambda t: -t[1])[:3]:
            if z >= config.ROBUST_Z_CUT:
                reasons.append(f"cardinality_spike:{name}={vector[name]:.0f}(z={z:.1f})")
        for name, z in sorted(volume_z, key=lambda t: -t[1])[:3]:
            if z >= config.ROBUST_Z_CUT:
                reasons.append(f"volume_spike:{name}={vector[name]:.0f}(z={z:.1f})")
        if features.best_cv is not None and features.best_cv <= config.BEACON_CV_MAX:
            reasons.append(f"periodic:cv={features.best_cv:.3f}")
        if features.novel_event_ids:
            reasons.append(f"novel_event_ids:{features.novel_event_ids}")

        return HourScore(
            features=features,
            score=score,
            driver=driver,
            components=components,
            reasons=tuple(reasons),
        )

    def score_all(self, hours: dict[tuple[str, date, int], HourFeatures]) -> list[HourScore]:
        return sorted(
            (self.score(f) for f in hours.values()),
            key=lambda s: (s.features.day, s.features.hour, s.features.user),
        )

    def pool_dayparts(self) -> dict[str, dict[str, list[float]]]:
        """Pool hours into work / evening / night bands per user.

        7 samples per hour-of-day is not enough for a tail; 35-70 per band is.
        Use this when you need a quantile rather than a fixed z cut.
        """
        bands = {"night": range(0, 7), "work": range(7, 19), "evening": range(19, 24)}
        pooled: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
        for user, hours in self.history.items():
            for hour, features in hours.items():
                band = next((b for b, rng in bands.items() if hour in rng), "work")
                for name, values in features.items():
                    pooled[f"{user}|{band}"][name].extend(values)
        return {k: dict(v) for k, v in pooled.items()}


@dataclass(frozen=True, slots=True)
class HourScore:
    """Tier B verdict for one ``(user, day, hour)``."""

    features: HourFeatures
    score: float
    driver: str  # which family carried the score
    components: dict[str, float]
    reasons: tuple[str, ...]

    @property
    def user(self) -> str:
        return self.features.user

    @property
    def is_alert(self) -> bool:
        return self.score >= config.TIER_B_ALERT_SCORE

    def explain(self) -> str:
        head = (
            f"{self.features.day.isoformat()} {self.features.hour:02d}:00  "
            f"user={self.user}  score={self.score:.1f}  driver={self.driver}\n"
            f"  n_total={self.features.n_total}  hosts={self.features.hosts}  "
            f"novel_values={self.features.novel_values}  "
            f"best_cv={self.features.best_cv if self.features.best_cv is not None else '-'}"
        )
        parts = "  ".join(f"{k}={v:.1f}" for k, v in sorted(self.components.items()))
        reasons = "\n".join(f"    - {r}" for r in self.reasons) or "    (none)"
        return f"{head}\n  components: {parts}\n  reasons:\n{reasons}"
