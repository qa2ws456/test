"""Read the winlogbeat-shaped JSONL produced by scripts/winlog_xml_to_jsonl.py.

One job: JSON line -> :class:`ParsedEvent`. No feature logic, no identity
resolution - those are separate stages so each can be tested alone.

The derived time fields (``day``, ``hour``, ``dow``, ``daypart``) are computed
here, once, from the *local* timestamp. That matters: the XML carries UTC, and
bucketing UTC hours for a non-UTC organisation puts a 09:00 IST login in hour 3
and inverts every off-hours rule. The adapter's ``--tz`` flag does the conversion;
this module just trusts the offset in the string.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ParsedEvent:
    """One Windows event, flattened, with derived time features."""

    ts: datetime  # timezone-aware, local
    day: date
    hour: int  # local hour, 0-23
    dow: int  # 0 = Monday .. 6 = Sunday
    daypart: str  # "weekday" | "weekend"
    event_id: int
    channel: str  # "Security" | Sysmon operational channel
    host: str  # short Computer name
    record_id: str
    data: dict[str, str] = field(default_factory=dict)  # full event_data, untouched

    @property
    def is_security(self) -> bool:
        return self.channel == "Security"

    def get(self, key: str) -> str | None:
        return self.data.get(key)


def parse_line(line: str) -> ParsedEvent | None:
    """Parse one JSONL record. Returns None for anything unusable.

    Being permissive here is deliberate: a single malformed line in a
    million-event corpus should not abort a fit.
    """
    line = line.strip()
    if not line:
        return None
    try:
        raw = json.loads(line)
    except json.JSONDecodeError:
        return None

    winlog = raw.get("winlog") or {}
    event_id = winlog.get("event_id")
    if not isinstance(event_id, int):
        return None

    stamp = raw.get("@timestamp")
    if not stamp:
        return None
    try:
        ts = datetime.fromisoformat(str(stamp))
    except ValueError:
        return None
    if ts.tzinfo is None:
        # An offset-naive timestamp means the adapter was bypassed. Refuse to
        # guess: silently assuming UTC is how the hour feature gets corrupted.
        return None

    host = (raw.get("host") or {}).get("name") or winlog.get("computer_name") or ""
    data = winlog.get("event_data") or {}
    if not isinstance(data, dict):
        data = {}

    return ParsedEvent(
        ts=ts,
        day=ts.date(),
        hour=ts.hour,
        dow=ts.weekday(),
        daypart="weekend" if ts.weekday() >= 5 else "weekday",
        event_id=event_id,
        channel=str(winlog.get("channel") or ""),
        host=str(host).split(".", 1)[0],
        record_id=str(winlog.get("record_id") or ""),
        data={str(k): str(v) for k, v in data.items()},
    )


def iter_events(path: Path | str) -> Iterator[ParsedEvent]:
    """Stream events from a JSONL file, skipping unparsable lines."""
    with Path(path).open(encoding="utf-8") as handle:
        for line in handle:
            event = parse_line(line)
            if event is not None:
                yield event


def load_events(path: Path | str, *, chronological: bool = True) -> list[ParsedEvent]:
    """Load all events into memory.

    ``chronological=True`` is the default because identity resolution is
    stateful - a logon must be seen before the events that inherit its session,
    and the adapter writes per-file rather than in global time order.

    Memory: the measured corpus is ~1.2 M events for 12 days (~540 k after
    excluding 5156), which is comfortable. Use :func:`iter_events` if that
    changes.
    """
    events = list(iter_events(path))
    if chronological:
        events.sort(key=lambda e: (e.ts, e.host, e.record_id))
    return events


def census(events: list[ParsedEvent]) -> dict[str, dict[str, int]]:
    """Counts by event ID, host and day - for sanity-checking a load.

    Should match the census printed by scripts/winlog_xml_to_jsonl.py. If it does
    not, something was dropped between the two stages and every downstream number
    is suspect.
    """
    from collections import Counter

    return {
        "event_id": dict(sorted(Counter(e.event_id for e in events).items())),
        "host": dict(sorted(Counter(e.host for e in events).items())),
        "day": dict(sorted(Counter(e.day.isoformat() for e in events).items())),
        "channel": dict(sorted(Counter(e.channel for e in events).items())),
    }
