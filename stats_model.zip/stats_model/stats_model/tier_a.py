"""Approach A - score every event independently against a per-user baseline.

    latency: none (the verdict is available on the event itself)
    detects: point anomalies - a value or an event ID this user has never produced
    misses:  anything about rate, breadth, sequence or trend

The model is a frequency table. For each user, event ID and field, count how often
each value was seen in the fit window. Scoring asks two questions:

    A1  has this user ever produced this event ID?
    A2  has this user ever produced this value for this field?

That is the whole model. Everything else here is about turning those two questions
into a rankable score without lying about confidence.

Why this tier carries most of the coverage
------------------------------------------
15 of the 20 attack steps in the dataset are point anomalies, and 8 of those are
*unseen event ID* hits with essentially no false positive risk, because
EvidenceForge never generates account-management or persistence events during
baseline activity. Measured examples: baseline 4648 is 100% ``SYSTEM`` -> ``svc-*``,
and baseline LSASS access is 100% ``NT AUTHORITY\\*`` across 107 records. So a
human subject on either is new by construction.

Two gates do the real work
--------------------------
Without them this tier produces confident nonsense:

* **support gate** - a 7-day window leaves many cells thin. A membership test on
  ``n=3`` reports "unseen" with full confidence, and the affected events (4648,
  4672, 4768) are the ones you most want to trust.
* **corroboration gate** - one novel field is a lead, not an alert. ``rh-01`` is a
  security analyst running the same ``net group`` / ``nltest`` commands as the
  attacker's discovery step; no single-field rule separates them.
"""

from __future__ import annotations

import json
import math
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

from . import config
from .features import FeatureRecord

# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------


@dataclass
class EventProfile:
    """Per-user, per-event-ID frequency tables."""

    n: int = 0
    # field -> value -> count
    fields: dict[str, dict[str, int]] = field(default_factory=lambda: defaultdict(dict))
    # field -> number of events where that field was populated (for coverage)
    populated: dict[str, int] = field(default_factory=dict)

    def observe(self, tokens: tuple[tuple[str, str], ...]) -> None:
        self.n += 1
        seen_fields: set[str] = set()
        for field_name, value in tokens:
            table = self.fields.setdefault(field_name, {})
            table[value] = table.get(value, 0) + 1
            seen_fields.add(field_name)
        for field_name in seen_fields:
            self.populated[field_name] = self.populated.get(field_name, 0) + 1

    def coverage(self, field_name: str) -> float:
        if self.n == 0:
            return 0.0
        return self.populated.get(field_name, 0) / self.n


@dataclass
class UserProfile:
    """Everything tier A knows about one user."""

    user: str
    events: dict[int, EventProfile] = field(default_factory=dict)
    total_events: int = 0
    days: set[str] = field(default_factory=set)

    def observe(self, record: FeatureRecord) -> None:
        profile = self.events.setdefault(record.event_id, EventProfile())
        profile.observe(record.tokens)
        self.total_events += 1
        self.days.add(record.day.isoformat())


class EventBaseline:
    """Tier A baseline: fit on a window, then score events one at a time."""

    def __init__(self, fit_start: date | None = None, fit_end: date | None = None) -> None:
        self.profiles: dict[str, UserProfile] = {}
        self.fit_start = fit_start
        self.fit_end = fit_end
        self.config_hash = config.config_hash()
        # event_id -> how many distinct users produced it during the fit window.
        # Used to tell "structurally absent from baseline" (4720, 1102) apart from
        # "merely rare for this user" (4800/4801).
        self.event_id_users: dict[int, int] = {}

    # -- fit ---------------------------------------------------------------

    def fit(self, records: list[FeatureRecord]) -> EventBaseline:
        """Accumulate frequency tables. Records should already be date-filtered."""
        for record in records:
            profile = self.profiles.setdefault(record.user, UserProfile(user=record.user))
            profile.observe(record)
        holders: dict[int, set[str]] = defaultdict(set)
        for user, profile in self.profiles.items():
            for event_id in profile.events:
                holders[event_id].add(user)
        self.event_id_users = {eid: len(users) for eid, users in holders.items()}

        days = sorted({d for p in self.profiles.values() for d in p.days})
        if days:
            self.fit_start = self.fit_start or date.fromisoformat(days[0])
            self.fit_end = self.fit_end or date.fromisoformat(days[-1])
        return self

    @property
    def fit_days(self) -> int:
        if self.fit_start and self.fit_end:
            return (self.fit_end - self.fit_start).days + 1
        return 0

    # -- persistence -------------------------------------------------------

    def save(self, path: Path | str) -> None:
        """Write the baseline plus the config hash that produced it.

        The hash is not decoration: scoring against a baseline fitted with
        different feature definitions is the classic silent failure in this kind
        of system, and :meth:`load` refuses it.
        """
        payload = {
            "config_hash": self.config_hash,
            "fit_start": self.fit_start.isoformat() if self.fit_start else None,
            "fit_end": self.fit_end.isoformat() if self.fit_end else None,
            "users": {
                user: {
                    "total_events": profile.total_events,
                    "days": sorted(profile.days),
                    "events": {
                        str(event_id): {
                            "n": ep.n,
                            "populated": ep.populated,
                            "fields": {f: dict(v) for f, v in ep.fields.items()},
                        }
                        for event_id, ep in sorted(profile.events.items())
                    },
                }
                for user, profile in sorted(self.profiles.items())
            },
        }
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    @classmethod
    def load(cls, path: Path | str, *, strict: bool = True) -> EventBaseline:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        stored = payload.get("config_hash")
        if strict and stored != config.config_hash():
            raise ValueError(
                f"baseline was fitted with config {stored}, current config is "
                f"{config.config_hash()}. Refit, or pass strict=False if you are "
                f"certain the feature definitions are compatible."
            )
        baseline = cls(
            fit_start=date.fromisoformat(payload["fit_start"])
            if payload.get("fit_start")
            else None,
            fit_end=date.fromisoformat(payload["fit_end"]) if payload.get("fit_end") else None,
        )
        baseline.config_hash = stored or baseline.config_hash
        for user, blob in payload.get("users", {}).items():
            profile = UserProfile(
                user=user,
                total_events=blob.get("total_events", 0),
                days=set(blob.get("days", [])),
            )
            for event_id_text, ev in blob.get("events", {}).items():
                ep = EventProfile(n=ev.get("n", 0), populated=dict(ev.get("populated", {})))
                for field_name, table in ev.get("fields", {}).items():
                    ep.fields[field_name] = dict(table)
                profile.events[int(event_id_text)] = ep
            baseline.profiles[user] = profile
        return baseline

    # -- scoring -----------------------------------------------------------

    def score(self, record: FeatureRecord) -> EventScore:
        profile = self.profiles.get(record.user)
        if profile is None:
            # A user with no baseline at all is itself a finding. The original
            # notebook returned no score here, which is backwards.
            return EventScore(
                record=record,
                score=config.FIRST_SEEN_SCORE,
                confidence="high",
                event_id_seen=False,
                baseline_n=0,
                verdicts=(),
                reasons=("first_seen_user",),
            )

        event_profile = profile.events.get(record.event_id)
        if event_profile is None or event_profile.n == 0:
            # A1: unseen event ID. Scored without needing any field evidence -
            # this is the near-zero-FP class.
            #
            # The tokens are still recorded as novel, with zero bits so the score
            # is not double-counted. Two reasons: the analyst needs to see *which*
            # values were involved, and the fan-out correlator groups on novel
            # values - without these, a password spray (every target's first 4625)
            # would be invisible to it.
            verdicts = tuple(
                FieldVerdict(
                    field=field_name,
                    value=value,
                    count=0,
                    n_unique=0,
                    n=0,
                    bits=0.0,
                    weight=config.FIELD_WEIGHT.get(field_name, config.DEFAULT_FIELD_WEIGHT),
                    status="unseen",
                )
                for field_name, value in record.tokens
            )
            # Is this event type structurally absent from baseline activity, or
            # just absent for this user? 4720/4728/4697/4698/1102 are never
            # produced by baseline activity, so any occurrence is new by
            # construction. 4800/4801 happen routinely - a user who simply had no
            # unlock in a 7-day window is not a finding.
            n_users = max(len(self.profiles), 1)
            holders = self.event_id_users.get(record.event_id, 0)
            structural = holders <= config.D1_POPULATION_FRACTION * n_users

            if structural:
                score = config.D1_BONUS + 4.0
                confidence = "high"
                reason = f"unseen_event_id:{record.event_id}(rare_in_population)"
            else:
                # Common event type, new for this user: a lead. Let the field
                # evidence decide, exactly as for a seen event ID.
                score = config.D1_BONUS
                novel_count = len([v for v in verdicts if v.field in config.FAN_OUT_FIELDS])
                confidence = (
                    "high" if novel_count >= config.MIN_CORROBORATING_FIELDS else "low"
                )
                reason = (
                    f"unseen_event_id:{record.event_id}"
                    f"(seen for {holders}/{n_users} users)"
                )

            return EventScore(
                record=record,
                score=score,
                confidence=confidence,
                event_id_seen=False,
                baseline_n=0,
                verdicts=verdicts,
                reasons=(reason,),
            )

        verdicts: list[FieldVerdict] = []
        for field_name, value in record.tokens:
            verdicts.append(self._judge(event_profile, field_name, value))

        scored = [v for v in verdicts if v.status in ("seen", "unseen")]
        scored.sort(key=lambda v: v.weighted_bits, reverse=True)
        total = sum(v.weighted_bits for v in scored[: config.TOP_K_FIELDS])

        novel = [v for v in verdicts if v.status == "unseen"]
        reasons = tuple(f"unseen:{v.field}={v.value}" for v in novel)

        if len(novel) >= config.MIN_CORROBORATING_FIELDS:
            confidence = "high"
        elif total >= config.TIER_A_ALERT_BITS:
            confidence = "low"
        else:
            confidence = "none"

        return EventScore(
            record=record,
            score=total,
            confidence=confidence,
            event_id_seen=True,
            baseline_n=event_profile.n,
            verdicts=tuple(verdicts),
            reasons=reasons,
        )

    @staticmethod
    def _judge(event_profile: EventProfile, field_name: str, value: str) -> FieldVerdict:
        table = event_profile.fields.get(field_name, {})
        n = event_profile.n
        count = table.get(value, 0)
        n_unique = len(table)
        weight = config.FIELD_WEIGHT.get(field_name, config.DEFAULT_FIELD_WEIGHT)

        # Support gate: too little history to make a claim either way.
        if n < config.MIN_SUPPORT or event_profile.coverage(field_name) < config.MIN_FIELD_COVERAGE:
            return FieldVerdict(
                field=field_name,
                value=value,
                count=count,
                n_unique=n_unique,
                n=n,
                bits=0.0,
                weight=weight,
                status="insufficient_support",
            )

        p = (count + config.ALPHA) / (n + config.ALPHA * (n_unique + 1))
        bits = -math.log2(p)
        return FieldVerdict(
            field=field_name,
            value=value,
            count=count,
            n_unique=n_unique,
            n=n,
            bits=bits,
            weight=weight,
            status="seen" if count > 0 else "unseen",
        )

    def score_all(self, records: list[FeatureRecord]) -> list[EventScore]:
        return [self.score(r) for r in records]


# ---------------------------------------------------------------------------
# Score objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class FieldVerdict:
    """What the baseline says about one ``(field, value)`` on one event."""

    field: str
    value: str
    count: int  # times this value was seen in the fit window
    n_unique: int  # distinct values seen for this field
    n: int  # events of this type for this user in the fit window
    bits: float  # surprisal
    weight: float
    status: str  # seen | unseen | insufficient_support

    @property
    def weighted_bits(self) -> float:
        return self.bits * self.weight

    @property
    def pct(self) -> float:
        return (100.0 * self.count / self.n) if self.n else 0.0


@dataclass(frozen=True, slots=True)
class EventScore:
    """Tier A verdict for one event."""

    record: FeatureRecord
    score: float
    confidence: str  # high | low | none
    event_id_seen: bool
    baseline_n: int
    verdicts: tuple[FieldVerdict, ...]
    reasons: tuple[str, ...]

    @property
    def user(self) -> str:
        return self.record.user

    @property
    def ts(self) -> datetime:
        return self.record.event.ts

    @property
    def novel_fields(self) -> tuple[FieldVerdict, ...]:
        return tuple(v for v in self.verdicts if v.status == "unseen")

    @property
    def is_alert(self) -> bool:
        return self.confidence in ("high", "low")

    def explain(self) -> str:
        """Human-readable drill-down. This is the notebook Cell 6 view."""
        head = (
            f"{self.ts.isoformat()}  user={self.user}  event={self.record.event_id}  "
            f"host={self.record.host}\n"
            f"  score={self.score:.1f} bits  confidence={self.confidence}  "
            f"baseline_n={self.baseline_n}"
        )
        if not self.verdicts:
            return head + f"\n  reasons: {', '.join(self.reasons) or '(none)'}"
        rows = [f"  {'field':<24}{'value':<34}{'status':<22}{'count':>6}{'pct':>8}{'bits':>7}"]
        for v in sorted(self.verdicts, key=lambda x: x.weighted_bits, reverse=True):
            rows.append(
                f"  {v.field:<24}{v.value[:33]:<34}{v.status:<22}"
                f"{v.count:>6}{v.pct:>7.1f}%{v.bits:>7.1f}"
            )
        return head + "\n" + "\n".join(rows)


# ---------------------------------------------------------------------------
# Post-processing: dedup and fan-out
# ---------------------------------------------------------------------------


def deduplicate(
    scores: list[EventScore], window_minutes: int = config.DEDUP_WINDOW_MINUTES
) -> list[EventScore]:
    """Collapse repeats of the same novelty within a time window.

    Without this, ``atk-d3-03`` alone emits ~48 identical alerts - one per beacon
    beat, all with the same score. Per-event scoring has no notion of "I already
    told you this"; in production that is what buries analysts.

    Keeps the first occurrence of each ``(user, event_id, field, value)`` per
    window, which is also the one with the most useful timestamp.
    """
    window = timedelta(minutes=window_minutes)
    last_seen: dict[tuple[str, int, str, str], datetime] = {}
    kept: list[EventScore] = []

    for score in sorted(scores, key=lambda s: s.ts):
        if not score.is_alert:
            continue
        novel = score.novel_fields
        keys = (
            [(score.user, score.record.event_id, v.field, v.value) for v in novel]
            if novel
            else [(score.user, score.record.event_id, "__event_id__", "")]
        )
        if all(key in last_seen and score.ts - last_seen[key] < window for key in keys):
            continue
        for key in keys:
            last_seen[key] = score.ts
        kept.append(score)
    return kept


@dataclass(frozen=True, slots=True)
class FanOut:
    """One novel value seen across several users in the same hour."""

    event_id: int
    field: str
    value: str
    users: tuple[str, ...]
    day: date
    hour: int

    @property
    def n_users(self) -> int:
        return len(self.users)


def fan_out(scores: list[EventScore], min_users: int = config.FAN_OUT_MIN_USERS) -> list[FanOut]:
    """Find novel values that appear across many users in one hour.

    This is the cheap substitute for a per-host baseline, and it is what makes
    password spray detectable at all. Per-user, ``atk-d1-03`` is six unremarkable
    single failures - one per targeted account. Grouped by the novel value, it is
    one source IP against six users inside 22 minutes.

    It also catches the management-software credential sweeps EvidenceForge
    generates in baseline, which makes those the natural calibration set for
    ``min_users``.
    """
    groups: dict[tuple[date, int, int, str, str], set[str]] = defaultdict(set)
    for score in scores:
        for verdict in score.novel_fields:
            # Only indicator-like fields. "Three users were active at 03:00" is a
            # time bucket and "six users all used LogonType=3" is a tautology -
            # neither is a shared indicator. Structural fields would otherwise swamp
            # the real groups, especially since an unseen-event-ID hit marks every
            # token novel.
            if verdict.field not in config.FAN_OUT_FIELDS:
                continue
            key = (
                score.record.day,
                score.record.hour,
                score.record.event_id,
                verdict.field,
                verdict.value,
            )
            groups[key].add(score.user)

    results = [
        FanOut(
            event_id=event_id,
            field=field_name,
            value=value,
            users=tuple(sorted(users)),
            day=day,
            hour=hour,
        )
        for (day, hour, event_id, field_name, value), users in groups.items()
        if len(users) >= min_users
    ]
    results.sort(key=lambda f: (-f.n_users, f.day, f.hour))
    return results
