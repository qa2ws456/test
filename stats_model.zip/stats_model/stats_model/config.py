"""Configuration for the per-user statistical baseline detector.

Everything tunable lives here so the three approaches (tier A / B / C) share one
definition of "what a feature is". If you change a feature definition you must
refit, which is why `config_hash()` exists and gets stamped into every saved
baseline.

Field names were verified against EvidenceForge's emitted output, not inferred
from documentation. Six of the names in the original notebook do not exist -
see docs/detection/evidenceforge-field-mapping.md for the evidence.
"""

from __future__ import annotations

import hashlib
import json
import re

# ---------------------------------------------------------------------------
# Which event IDs enter a baseline
# ---------------------------------------------------------------------------

SECURITY_EVENTS: frozenset[int] = frozenset(
    {
        1102,  # security log cleared (renders in UserData, not EventData)
        4624,  # successful logon
        4625,  # failed logon
        4648,  # explicit credential use
        4672,  # special privileges assigned
        4688,  # process created (Security-side counterpart of Sysmon 1)
        4697,  # service installed
        4698,  # scheduled task created
        4720,  # account created
        4726,  # account deleted
        4728,  # member added to global group
        4732,  # member added to local group
        4738,  # account changed
        4756,  # member added to universal group
        4768,  # kerberos TGT request
        4769,  # kerberos service ticket request
        4771,  # kerberos pre-auth failed
        4776,  # NTLM credential validation
        4800,  # workstation locked
        4801,  # workstation unlocked
    }
)

# Sysmon events that carry per-value features.
#   Event 2 is NOT emitted by EvidenceForge (implemented set is 1,3,5,7,8,10,11,12,13,22).
#   Events 8/10 are detailed here, not count-only: they carry SourceUser/TargetUser,
#   and "a human user's process touched lsass" is the single strongest signal in
#   the dataset (measured: 107 benign LSASS accesses, all NT AUTHORITY\\*).
SYSMON_DETAILED: frozenset[int] = frozenset({1, 3, 5, 7, 8, 10, 11, 12, 13, 22})

# Closing a session removes it from the identity table; it is not itself scored.
SESSION_CLOSE_EVENTS: frozenset[int] = frozenset({4634})

# 5156 (WFP connection permitted) is deliberately excluded. It has NO username
# field at all, and it was 56% of total volume in the measured corpus. Including
# it would push half the events into the "unresolved" bucket for nothing.
EXCLUDED_EVENTS: frozenset[int] = frozenset({5156, 4689})

SCORED_EVENTS: frozenset[int] = (SECURITY_EVENTS | SYSMON_DETAILED) - EXCLUDED_EVENTS


# ---------------------------------------------------------------------------
# How each event identifies its user
# ---------------------------------------------------------------------------
# Tuples give precedence: try each in order, take the first that canonicalises to
# a real account. Precedence matters - 4688 carries TargetUserName="-", and a
# single-field lookup returns None instead of falling through to SubjectUserName.

_TARGET = ("TargetUserName",)
_SUBJECT = ("SubjectUserName",)

USER_FIELD: dict[int, tuple[str, ...]] = {
    # The account the event happened *to*.
    4624: _TARGET,
    4625: _TARGET,
    4634: _TARGET,
    4768: _TARGET,
    4769: _TARGET,
    4771: _TARGET,
    4776: _TARGET,  # NOT Account_Name
    4800: _TARGET,
    4801: _TARGET,
    # The account that *performed* the action.
    1102: _SUBJECT,
    4648: _SUBJECT,  # subject is the actor; TargetUserName is the impersonated account
    4672: _SUBJECT,  # 4672 has no TargetUserName at all
    4688: _SUBJECT,
    4697: _SUBJECT,
    4698: _SUBJECT,
    4720: _SUBJECT,
    4726: _SUBJECT,
    4728: _SUBJECT,
    4732: _SUBJECT,
    4738: _SUBJECT,
    4756: _SUBJECT,
    # Sysmon: User is DOMAIN\\user; 8/10 use SourceUser.
    1: ("User",),
    3: ("User",),
    5: ("User",),
    7: ("User",),
    11: ("User",),
    12: ("User",),
    13: ("User",),
    22: ("User",),
    8: ("SourceUser", "User"),
    10: ("SourceUser", "User"),
}


# ---------------------------------------------------------------------------
# Which fields become frequency features
# ---------------------------------------------------------------------------

FEATURE_FIELDS: dict[int, tuple[str, ...]] = {
    # --- Security -----------------------------------------------------------
    4624: (
        "IpAddress",
        "WorkstationName",
        "LogonType",
        "LogonProcessName",
        "AuthenticationPackageName",
        "ElevatedToken",
    ),
    4625: ("IpAddress", "WorkstationName", "LogonType", "Status", "SubStatus", "FailureReason"),
    4648: ("TargetUserName", "TargetServerName", "ProcessName", "IpAddress"),
    4672: ("PrivilegeList",),  # NOT "Privileges"; split into tokens
    4688: ("NewProcessName", "ParentProcessName", "CommandLine", "TokenElevationType"),
    4697: ("ServiceName", "ServiceFileName", "ServiceAccount", "ServiceType"),
    4698: ("TaskName",),
    4720: ("TargetUserName",),
    4726: ("TargetUserName",),
    4728: ("TargetUserName", "MemberSid"),
    4732: ("TargetUserName", "MemberSid"),
    4738: ("TargetUserName",),
    4756: ("TargetUserName", "MemberSid"),
    4768: ("IpAddress", "ServiceName", "TicketEncryptionType", "Status", "PreAuthType"),
    4769: ("IpAddress", "ServiceName", "TicketEncryptionType", "Status"),
    4771: ("IpAddress", "Status"),
    4776: (
        "Workstation",
        "Status",
        "PackageName",
    ),  # NOT WorkstationName / AuthenticationPackageName
    4800: (),
    4801: (),
    1102: (),
    # --- Sysmon -------------------------------------------------------------
    1: ("Image", "ParentImage", "CommandLine", "IntegrityLevel"),
    3: ("DestinationIp", "DestinationPort", "DestinationHostname", "Image", "Initiated"),
    5: ("Image",),
    7: ("Image", "ImageLoaded", "Signed", "SignatureStatus"),
    8: ("SourceImage", "TargetImage", "StartModule", "StartFunction"),
    10: ("SourceImage", "TargetImage", "GrantedAccess"),
    11: ("Image", "TargetFilename"),
    12: ("Image", "TargetObject", "EventType"),
    # Details is the registry *value data* (counters, timestamps, blobs). It is
    # near-unique per write and produced 518 of 774 held-out false positives on its
    # own. TargetObject - the key being written - is the signal, e.g. a Run key.
    13: ("Image", "TargetObject"),
    22: ("QueryName", "Image"),
}

# Fields holding a filesystem path. Normalised to (basename, dir_class).
PATH_FIELDS: frozenset[str] = frozenset(
    {
        "Image",
        "ParentImage",
        "ImageLoaded",
        "ProcessName",
        "NewProcessName",
        "ParentProcessName",
        "SourceImage",
        "TargetImage",
        "ServiceFileName",
        "Application",
    }
)

# Fields whose raw value is near-unique per event and must be normalised before
# entering a histogram. Left unnormalised, these guarantee 100% novelty and a
# useless feature - EvidenceForge parameterises baseline command lines and file
# names per user by design.
COMMANDLINE_FIELDS: frozenset[str] = frozenset({"CommandLine", "ParentCommandLine", "Details"})
FILEPATH_FIELDS: frozenset[str] = frozenset({"TargetFilename", "TargetObject"})
IP_FIELDS: frozenset[str] = frozenset({"IpAddress", "DestinationIp", "SourceIp", "ClientAddress"})
HOSTNAME_FIELDS: frozenset[str] = frozenset({"DestinationHostname", "QueryName"})
MULTIVALUE_FIELDS: frozenset[str] = frozenset({"PrivilegeList"})


# ---------------------------------------------------------------------------
# Tier A scoring
# ---------------------------------------------------------------------------

ALPHA = 0.5  # Laplace smoothing constant
D1_BONUS = 6.0  # bits awarded when the user has never produced this event ID
TOP_K_FIELDS = 3  # sum only the k most surprising fields, so one strong
# signal is not diluted by a tail of familiar ones

# Not all novelty is equally interesting. Weights are judgement, and the honest
# way to set them is an ablation on labelled data - these are a starting point.
FIELD_WEIGHT: dict[str, float] = {
    "IpAddress": 1.0,
    "WorkstationName": 1.0,
    "TargetServerName": 1.0,
    "TargetImage": 1.0,
    "GrantedAccess": 0.9,
    "SourceImage": 0.9,
    "LogonType": 0.9,
    "Privilege": 0.9,
    "TicketEncryptionType": 0.9,
    "ServiceName": 0.8,
    "ServiceFileName": 0.9,
    "TaskName": 0.9,
    "Image": 0.8,
    "ParentImage": 0.8,
    "NewProcessName": 0.8,
    "ParentProcessName": 0.8,
    "DestinationIp": 0.8,
    "DestinationHostname": 0.8,
    "dir_class": 0.9,
    "DestinationPort": 0.7,
    "TargetObject": 0.7,
    "TargetUserName": 0.7,
    "CommandLine": 0.6,
    "TargetFilename": 0.5,
    "ImageLoaded": 0.5,
    "Status": 0.5,
    "SubStatus": 0.5,
    "QueryName": 0.5,
    "hour": 0.4,
    "daypart": 0.5,
    "dow": 0.3,
}
DEFAULT_FIELD_WEIGHT = 0.5

# Support gates. Below these a field cannot claim "unseen" - with a 7-day window
# many (user, event_id, field) cells are thin, and a membership test on n=3
# reports novelty with full confidence. Events affected (4648, 4672, 4768) are
# exactly the ones you most want to trust.
MIN_SUPPORT = 20  # events of this type for this user in the fit window
MIN_FIELD_COVERAGE = 0.6  # fraction of those events where the field was populated

# A high-confidence alert needs an unseen event ID, or this many novel fields.
# One novel field is a lead, not an alert: the red herrings in the dataset are
# built so that single-field novelty cannot separate them from real attacks.
MIN_CORROBORATING_FIELDS = 2
TIER_A_ALERT_BITS = 8.0  # score floor for a low-confidence alert

FIRST_SEEN_SCORE = 20.0  # a user with no baseline at all is itself a finding
DEDUP_WINDOW_MINUTES = 60  # collapse identical (user, event, field, value) alerts

FAN_OUT_MIN_USERS = 3  # one novel value across >= N users in an hour = campaign

# Fan-out only groups on *indicator-like* fields - values that identify a specific
# entity. Structural fields (LogonType, Status, IntegrityLevel, ...) have tiny value
# spaces, so "six users all had LogonType=3" is a tautology, not a campaign. This
# matters because an unseen-event-ID hit marks every token novel, which would
# otherwise flood fan-out with generic groups.
FAN_OUT_FIELDS: frozenset[str] = frozenset(
    {
        "IpAddress", "WorkstationName", "Workstation", "DestinationIp",
        "DestinationHostname", "QueryName", "TargetServerName", "TargetUserName",
        "Image", "ParentImage", "SourceImage", "TargetImage", "ImageLoaded",
        "ProcessName", "NewProcessName", "ParentProcessName", "ServiceName",
        "ServiceFileName", "TaskName", "TargetFilename", "TargetObject",
        "MemberSid", "CommandLine",
    }
)

# An unseen event ID is a strong signal only when the event type is structurally
# absent from baseline activity (4720, 4728, 4697, 4698, 1102). For a type that is
# merely rare - 4800/4801 workstation lock/unlock, 4776, 4648 - "this user has not
# done it yet" is a much weaker claim. Verified on the generated corpus: 4801 fired
# as a false positive for a non-attacker who simply had no unlock in the 7-day
# window. An event ID held by at most this fraction of users counts as structural.
D1_POPULATION_FRACTION = 0.15


# ---------------------------------------------------------------------------
# Tier B (hourly) and tier C (daily)
# ---------------------------------------------------------------------------

MAD_FLOOR = 0.5  # keeps robust_z finite when MAD == 0 (common in sparse cells)
ROBUST_Z_CUT = 6.0  # fixed cut; 7 fit samples cannot support an empirical p99

W_VOLUME = 1.0
W_CARDINALITY = 1.2  # harder to inflate accidentally than raw volume
W_NOVELTY = 1.0
W_REGULARITY = 1.5
W_OCCUPANCY = 2.0
W_SHAPE = 1.3  # tier C only: hardest to control while still working
W_DORMANT = 2.0

BEACON_CV_MAX = 0.25  # inter-arrival CV below this is machine-driven
BEACON_MIN_EVENTS = 6  # fewer than this cannot support a CV estimate

TIER_B_ALERT_SCORE = 6.0
TIER_C_ALERT_SCORE = 6.0

# Drift layer (tier C).
EWMA_ALPHA = 0.3
EWMA_L = 3.0
CUSUM_K = 0.5  # slack in sigmas: ignore drift smaller than this
CUSUM_H = 5.0  # decision interval; tune so baseline days give ZERO alarms
PSI_MIN_SUPPORT = 30  # PSI on a sparse field is noise
PSI_MODERATE = 0.10
PSI_SIGNIFICANT = 0.25
TREND_MIN_DAYS = 4  # OLS slope needs at least this many points

# Environment drift vs attack drift: if a drift alarm fires for more than this
# fraction of users in the same window AND their novel values overlap, it is a
# change in the estimate, not an attack. See docs plan section 6.4.
ENV_DRIFT_USER_FRACTION = 0.30


# ---------------------------------------------------------------------------
# Identity canonicalisation
# ---------------------------------------------------------------------------

NOISE_USERS: frozenset[str] = frozenset(
    {
        "system",
        "local service",
        "network service",
        "anonymous logon",
        "defaultapppool",
        "iusr",
        "-",
        "",
        "n/a",
    }
)
NOISE_DOMAINS: frozenset[str] = frozenset(
    {"nt authority", "nt service", "font driver host", "window manager", "iis apppool"}
)
MACHINE_ACCOUNT_RE = re.compile(r".*\$$")
DWM_UMFD_RE = re.compile(r"^(dwm|umfd|cdpuser)-\d+$", re.IGNORECASE)

# Values EvidenceForge writes for "field not populated".
EMPTY_VALUES: frozenset[str] = frozenset({"", "-", "n/a", "null", "none"})


def config_hash() -> str:
    """Stable hash of every setting that changes what a feature means.

    Stamped into saved baselines. Scoring against a baseline fitted with a
    different feature definition is the classic silent failure in this kind of
    system, so we make it detectable.
    """
    payload = {
        "scored_events": sorted(SCORED_EVENTS),
        "user_field": {str(k): list(v) for k, v in sorted(USER_FIELD.items())},
        "feature_fields": {str(k): list(v) for k, v in sorted(FEATURE_FIELDS.items())},
        "alpha": ALPHA,
        "d1_bonus": D1_BONUS,
        "top_k": TOP_K_FIELDS,
        "min_support": MIN_SUPPORT,
        "min_field_coverage": MIN_FIELD_COVERAGE,
        "field_weight": dict(sorted(FIELD_WEIGHT.items())),
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]
