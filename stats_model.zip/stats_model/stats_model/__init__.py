"""Per-user statistical baseline detector for Windows Security + Sysmon logs.

Three scoring approaches over one shared feature pipeline:

    tier_a  per event      no latency        point anomalies (unseen value / event ID)
    tier_b  per hour       <= 1 hour         bursts, sweeps, sprays, tight beacons
    tier_c  per day        <= 24 hours       work-pattern shift, slow drift, campaigns

B is an accumulator over A's per-event verdicts; C is an accumulator over B's. They
share one feature extraction pass, which is what keeps the drill-down path from an
alerting day down to the events that caused it.

Pipeline
--------
    ingest      JSONL  -> ParsedEvent          (no feature logic)
    identity    event  -> Attribution          (stateful, order-dependent)
    features    event  -> FeatureRecord        (pure; tokens incl. hour/dow/daypart)
    tier_a/b/c  fit, then score

Typical use::

    from stats_model import ingest, features, tier_a

    events = ingest.load_events("data/fit.json")
    records, resolver = features.build(events)
    print(resolver.report())              # check attribution before trusting anything

    baseline = tier_a.EventBaseline().fit(records)
    scores = baseline.score_all(test_records)

Or end to end via the CLI::

    python -m stats_model.cli fit   data/fit.json  -b baselines/
    python -m stats_model.cli score data/test.json -b baselines/ --top 25

See docs/detection/ for the design: implementation-plan.md for the model,
evidenceforge-field-mapping.md for why the field names are what they are.
"""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = [
    "config",
    "normalize",
    "ingest",
    "identity",
    "features",
    "tier_a",
    "tier_b",
    "tier_c",
    "evaluate",
]
