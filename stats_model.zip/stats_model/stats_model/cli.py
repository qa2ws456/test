"""Command line driver: fit, score, evaluate.

    # 1. fit baselines on the 7-day window
    python -m stats_model.cli fit data/data.json -b baselines/ --fit-end 2026-08-04

    # 2. score the remaining days
    python -m stats_model.cli score data/data.json -b baselines/ --fit-end 2026-08-04

    # 3. grade against ground truth
    python -m stats_model.cli evaluate data/data.json -b baselines/ \
        --fit-end 2026-08-04 --ground-truth output/GROUND_TRUTH.json

One JSONL file is used throughout and split by local date on ``--fit-end``, so the
fit and scoring corpora are guaranteed to come from the same generation run. That
matters: separate runs have different RNG streams, so session IDs and application
choices would not line up.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

import pdb

import json

from . import config, features, ingest, tier_a, tier_b, tier_c
from . import evaluate as evaluate_mod


def _split(records, fit_end: date):
    fit = [r for r in records if r.day <= fit_end]
    test = [r for r in records if r.day > fit_end]
    return fit, test


def _load(path: Path, *, quiet: bool = False):
    events = ingest.load_events(path)
    records, resolver = features.build(events)
    # import pdb
    # pdb.set_trace()
    if not quiet:
        census = ingest.census(events)
        print(f"loaded {len(events)} events -> {len(records)} attributed feature records")
        print(f"  days   : {', '.join(census['day'])}")
        total = sum(resolver.stats.values())
        resolved = sum(n for (_, m), n in resolver.stats.items() if m != "unresolved")
        pct = 100.0 * resolved / total if total else 0.0
        print(f"  users  : {len({r.user for r in records})}")
        print(
            f"  attribution: {resolved}/{total} ({pct:.1f}%) - the rest is SYSTEM/service/machine"
        )
    return records


def cmd_fit(args: argparse.Namespace) -> int:
    records = _load(args.input)
    fit, _ = _split(records, args.fit_end)
    if not fit:
        print(f"error: no records on or before {args.fit_end}", file=sys.stderr)
        return 1

    out = Path(args.baselines)
    out.mkdir(parents=True, exist_ok=True)

    print(f"\nfitting on {len(fit)} records up to {args.fit_end} ...")

    a = tier_a.EventBaseline().fit(fit)


     # pdb.set_trace()

    a.save(out / "tier_a.json")
    print(f"  tier A: {len(a.profiles)} users, {a.fit_days} days -> {out / 'tier_a.json'}")

    scores = a.score_all(fit)
    hours = tier_b.build_hours(fit, scores)

    path = Path(out / "tier_b.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(hours, indent=2, sort_keys=True), encoding="utf-8")

    pdb.set_trace()

    b = tier_b.HourBaseline().fit(hours)
    print(f"  tier B: {len(hours)} (user, day, hour) cells")

    days = tier_c.build_days(fit, scores, b.score_all(hours))
    tier_c.DayBaseline().fit(days, fit)
    print(f"  tier C: {len(days)} (user, day) cells")

    print(f"\nconfig hash {config.config_hash()} recorded in the baseline.")
    print("Tier B and C baselines are refitted at score time from the same window;")
    print("only tier A is persisted, because it is the expensive one.")
    return 0


def _fit_all(fit_records):
    """Fit all three tiers on the same window. Returns the three baselines."""
    a = tier_a.EventBaseline().fit(fit_records)
    fit_scores = a.score_all(fit_records)
    fit_hours = tier_b.build_hours(fit_records, fit_scores)
    b = tier_b.HourBaseline().fit(fit_hours)
    fit_hour_scores = b.score_all(fit_hours)
    fit_days = tier_c.build_days(fit_records, fit_scores, fit_hour_scores)
    c = tier_c.DayBaseline().fit(fit_days, fit_records)
    return a, b, c, fit_scores, fit_hour_scores, fit_days


def cmd_score(args: argparse.Namespace) -> int:
    records = _load(args.input)
    fit, test = _split(records, args.fit_end)
    if not test:
        print(f"error: no records after {args.fit_end}", file=sys.stderr)
        return 1
    print(f"\nfit={len(fit)} records   test={len(test)} records")

    a, b, c, _, _, _ = _fit_all(fit)

    # --- tier A ---------------------------------------------------------
    scores = a.score_all(test)
    alerts = tier_a.deduplicate(scores)
    high = [s for s in alerts if s.confidence == "high"]
    print("\n" + "=" * 78)
    print(
        f"TIER A - per event   {len(scores)} scored, {len(alerts)} alerts after dedup, "
        f"{len(high)} high-confidence"
    )
    print("=" * 78)
    for score in sorted(alerts, key=lambda s: -s.score)[: args.top]:
        print(score.explain())
        print()

    groups = tier_a.fan_out(scores)
    if groups:
        print("-" * 78)
        print("FAN-OUT  one novel value across several users in one hour")
        print("-" * 78)
        for group in groups[:10]:
            print(
                f"  {group.day} {group.hour:02d}:00  event {group.event_id}  "
                f"{group.field}={group.value}  users={group.n_users}: "
                f"{', '.join(group.users)}"
            )
        print()

    # --- tier B ---------------------------------------------------------
    hours = tier_b.build_hours(test, scores)
    hour_scores = b.score_all(hours)
    hour_alerts = [h for h in hour_scores if h.is_alert]
    print("=" * 78)
    print(f"TIER B - per hour   {len(hour_scores)} hours scored, {len(hour_alerts)} alerts")
    print("=" * 78)
    for hour_score in sorted(hour_alerts, key=lambda s: -s.score)[: args.top]:
        print(hour_score.explain())
        print()

    # --- tier C ---------------------------------------------------------
    days = tier_c.build_days(test, scores, hour_scores)
    day_scores = c.score_all(days)
    day_alerts = [d for d in day_scores if d.is_alert]
    print("=" * 78)
    print(f"TIER C - per day   {len(day_scores)} days scored, {len(day_alerts)} alerts")
    print("=" * 78)
    for day_score in sorted(day_alerts, key=lambda s: -s.score)[: args.top]:
        print(day_score.explain())
        print()

    # --- drift ----------------------------------------------------------
    # Drift needs the full series, fit days included, or CUSUM has no runway.
    all_scores = a.score_all(records)
    all_hours = tier_b.build_hours(records, all_scores)
    all_hour_scores = b.score_all(all_hours)
    all_days = tier_c.build_days(records, all_scores, all_hour_scores)
    all_day_scores = c.score_all(all_days)

    print("=" * 78)
    print("DRIFT LAYER - EWMA / CUSUM / PSI / trend, over the full series")
    print("=" * 78)
    users = sorted({d.user for d in all_day_scores})
    reports = [c.drift(user, all_day_scores, records) for user in users]
    for report in reports:
        if report.has_drift or abs(report.slope) > 0.5:
            print(report.explain())
            print()
    if not any(r.has_drift for r in reports):
        print("  no drift alarms")

    top_novel = {
        user: {f"{v.field}={v.value}" for s in all_scores if s.user == user for v in s.novel_fields}
        for user in users
    }
    if tier_c.environment_drift(reports, top_novel):
        print("\n  NOTE: drift looks population-wide with shared novel values.")
        print("  That is an environment change (rollout / patch / agent upgrade),")
        print("  not an attack. Refit the baseline rather than investigating.")
    return 0


def cmd_evaluate(args: argparse.Namespace) -> int:
    records = _load(args.input)
    fit, test = _split(records, args.fit_end)
    if not test:
        print(f"error: no records after {args.fit_end}", file=sys.stderr)
        return 1

    a, b, c, _, _, _ = _fit_all(fit)

    scores = a.score_all(test)
    deduped = tier_a.deduplicate(scores)
    hours = tier_b.build_hours(test, scores)
    hour_scores = b.score_all(hours)
    days = tier_c.build_days(test, scores, hour_scores)
    day_scores = c.score_all(days)

    alerts = (
        evaluate_mod.alerts_from_tier_a(deduped)
        + evaluate_mod.alerts_from_tier_b(hour_scores)
        + evaluate_mod.alerts_from_tier_c(day_scores)
    )

    # Analyst-load criterion. Scoring the fit window against a baseline fitted on
    # that same window measures training error, which is ~0 by construction and
    # tells you nothing. Hold out the last fit day instead: fit on days 1..N-1,
    # score day N, and count alerts there.
    holdout_day = max(r.day for r in fit)
    fit_core = [r for r in fit if r.day < holdout_day]
    holdout = [r for r in fit if r.day == holdout_day]
    if fit_core and holdout:
        a_core = tier_a.EventBaseline().fit(fit_core)
        holdout_alerts = tier_a.deduplicate(a_core.score_all(holdout))
        alerts += evaluate_mod.alerts_from_tier_a(holdout_alerts)
        print(
            f"  held-out calibration day: {holdout_day} "
            f"({len(fit_core)} fit records, {len(holdout)} held out)"
        )
        fit_days = {holdout_day.isoformat()}
    else:
        fit_days = {r.day.isoformat() for r in fit}
    report = evaluate_mod.evaluate(args.ground_truth, alerts, fit_days)
    print()
    print(report.render())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="stats_model",
        description="Per-user statistical baseline detector (tiers A / B / C).",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    def add_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("input", type=Path, help="JSONL from scripts/winlog_xml_to_jsonl.py")
        p.add_argument("-b", "--baselines", type=Path, default=Path("baselines"))
        p.add_argument(
            "--fit-end",
            type=lambda s: date.fromisoformat(s),
            required=True,
            help="last local date in the fit window, inclusive (e.g. 2026-08-04)",
        )

    p_fit = sub.add_parser("fit", help="fit baselines on the training window")
    add_common(p_fit)
    p_fit.set_defaults(func=cmd_fit)

    p_score = sub.add_parser("score", help="score the days after the fit window")
    add_common(p_score)
    p_score.add_argument("--top", type=int, default=10, help="alerts to print per tier")
    p_score.set_defaults(func=cmd_score)

    p_eval = sub.add_parser("evaluate", help="grade alerts against GROUND_TRUTH.json")
    add_common(p_eval)
    p_eval.add_argument("--ground-truth", type=Path, required=True)
    p_eval.set_defaults(func=cmd_evaluate)

    args = parser.parse_args(argv)
    return int(args.func(args))



if __name__ == "__main__":
    raise SystemExit(main())
