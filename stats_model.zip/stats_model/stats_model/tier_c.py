"""Approach C - score one feature vector per user per local day, plus drift.

    latency: up to 24 hours
    detects: work-pattern shifts, weekend activity, slow beacons, campaign trend,
             dormant-account reactivation
    misses:  short sharp events (one 1102 does not move a daily aggregate)

Tier C has two jobs, and they use different kinds of statistics.

**Job 1 - daily comparison.** The same robust-z machinery as tier B, at day scale,
but restricted to comparable days. Weekday-versus-weekend is the resolution the
data supports: 7 fit days gives 5 weekday samples and 2 weekend samples. Per-weekday
typing (Mon/Tue/...) would give one sample per class, which is not a distribution.

Two samples cannot support a z-score either, so weekend cells use a **presence
test** instead: the baseline weekend median is 0 for non-IT personas (EvidenceForge
applies 0.05-0.08x weekend multipliers and skips non-IT personas entirely), so
"any activity at all" is the statement the data supports. That is what detects
``atk-d4-01`` - a claims analyst running collection tooling at 12:30 on a Saturday,
an hour she works every weekday.

**Job 2 - drift.** Drift means the deviation is too small for any single day to
cross a threshold, but it persists or grows. Threshold tests are the wrong tool;
accumulators are the right one. Four elementary statistics, in
:class:`DriftMonitor`:

    D-1  daily novelty rate    - the interpretable summary
    D-2  EWMA + control limits - level shifts
    D-3  CUSUM                 - sustained small shifts  <- the core drift detector
    D-4  PSI                   - distribution shape change with no novel values
    D-5  trend slope           - escalation

CUSUM is the one that matters most. It accumulates sub-threshold deviations and
fires when the running sum crosses a decision interval, which is exactly the shape
of a low-and-slow beacon (``atk-d3-04``) and of the ``atk-d1-*`` -> ``atk-d4-*``
campaign escalation.

PSI is the one that catches what nothing else can: the same values appearing in
different proportions. A user whose ``LogonType`` mix moves from 90/10 to 50/50 has
produced no novel value at all, so tier A sees nothing.
"""

from __future__ import annotations

import math
import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date

from . import config
from .features import FeatureRecord
from .tier_a import EventScore
from .tier_b import HourScore, interarrival_cv, robust_z

WORK_HOURS = range(8, 19)  # fallback definition of "business hours"


# ---------------------------------------------------------------------------
# Daily feature vector
# ---------------------------------------------------------------------------


@dataclass
class DayFeatures:
    """One user's whole day."""

    user: str
    day: date
    day_class: str  # "weekday" | "weekend"

    n_total: int = 0
    n_by_event: dict[int, int] = field(default_factory=dict)
    nuniq: dict[str, int] = field(default_factory=dict)
    n_hosts: int = 0

    # temporal shape
    active_hours: int = 0
    first_hour: int | None = None
    last_hour: int | None = None
    hour_entropy: float = 0.0
    offhours_share: float = 0.0

    # roll-ups
    novel_values: int = 0
    novel_event_ids: int = 0
    max_event_score: float = 0.0
    alerting_hours: int = 0
    best_cv: float | None = None
    beacon_beats: int = 0

    def vector(self) -> dict[str, float]:
        out: dict[str, float] = {
            "n_total": float(self.n_total),
            "n_hosts": float(self.n_hosts),
            "active_hours": float(self.active_hours),
            "hour_entropy": self.hour_entropy,
            "offhours_share": self.offhours_share,
            "last_hour": float(self.last_hour if self.last_hour is not None else 0),
            "first_hour": float(self.first_hour if self.first_hour is not None else 0),
            "novel_values": float(self.novel_values),
        }
        for event_id, count in self.n_by_event.items():
            out[f"n_{event_id}"] = float(count)
            # Composition share, not just the count: an attacker can hold the
            # daily total flat while shifting the mix heavily.
            out[f"share_{event_id}"] = count / self.n_total if self.n_total else 0.0
        for key, count in self.nuniq.items():
            out[f"nuniq_{key}"] = float(count)
        return out


def _entropy(counts: list[int]) -> float:
    total = sum(counts)
    if total <= 0:
        return 0.0
    return -sum((c / total) * math.log2(c / total) for c in counts if c > 0)


def build_days(
    records: list[FeatureRecord],
    scores: list[EventScore] | None = None,
    hour_scores: list[HourScore] | None = None,
) -> dict[tuple[str, date], DayFeatures]:
    """Aggregate records into daily vectors, folding in tier A and tier B output."""
    by_key: dict[tuple[str, date], DayFeatures] = {}
    distinct: dict[tuple[str, date], dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    hosts: dict[tuple[str, date], set[str]] = defaultdict(set)
    hour_counts: dict[tuple[str, date], dict[int, int]] = defaultdict(lambda: defaultdict(int))
    stamps: dict[tuple[str, date], dict[tuple[int, str], list]] = defaultdict(
        lambda: defaultdict(list)
    )

    from .tier_b import BEACON_GROUP_FIELD

    for record in records:
        key = (record.user, record.day)
        features = by_key.get(key)
        if features is None:
            features = DayFeatures(user=record.user, day=record.day, day_class=record.event.daypart)
            by_key[key] = features
        features.n_total += 1
        features.n_by_event[record.event_id] = features.n_by_event.get(record.event_id, 0) + 1
        hosts[key].add(record.host)
        hour_counts[key][record.hour] += 1

        for field_name, value in record.tokens:
            if field_name in ("hour", "dow", "daypart"):
                continue
            distinct[key][f"{record.event_id}_{field_name}"].add(value)

        group_field = BEACON_GROUP_FIELD.get(record.event_id)
        if group_field:
            for field_name, value in record.tokens:
                if field_name == group_field:
                    stamps[key][(record.event_id, value)].append(record.event.ts)
                    break

    if scores:
        for score in scores:
            key = (score.user, score.record.day)
            features = by_key.get(key)
            if features is None:
                continue
            features.novel_values += len(score.novel_fields)
            if not score.event_id_seen:
                features.novel_event_ids += 1
            features.max_event_score = max(features.max_event_score, score.score)

    if hour_scores:
        for hour_score in hour_scores:
            key = (hour_score.user, hour_score.features.day)
            features = by_key.get(key)
            if features is not None and hour_score.is_alert:
                features.alerting_hours += 1

    for key, features in by_key.items():
        features.nuniq = {name: len(values) for name, values in distinct[key].items()}
        features.n_hosts = len(hosts[key])
        counts = hour_counts[key]
        active = sorted(counts)
        features.active_hours = len(active)
        features.first_hour = active[0] if active else None
        features.last_hour = active[-1] if active else None
        features.hour_entropy = _entropy(list(counts.values()))
        off = sum(n for h, n in counts.items() if h not in WORK_HOURS)
        features.offhours_share = off / features.n_total if features.n_total else 0.0

        # Whole-day CV, not per-hour. This is the point of tier C for beacons: a
        # 45-minute interval gives 1-2 beats an hour (never a stable estimate) but
        # ~28 a day (ample).
        best: float | None = None
        beats = 0
        for group_stamps in stamps[key].values():
            cv = interarrival_cv(group_stamps)
            if cv is not None and (best is None or cv < best):
                best = cv
                beats = len(group_stamps)
        features.best_cv = best
        features.beacon_beats = beats

    return by_key


# ---------------------------------------------------------------------------
# Drift statistics
# ---------------------------------------------------------------------------


def ewma_series(values: list[float], alpha: float = config.EWMA_ALPHA) -> list[float]:
    """Exponentially weighted moving average of a daily series."""
    out: list[float] = []
    z = values[0] if values else 0.0
    for x in values:
        z = alpha * x + (1.0 - alpha) * z
        out.append(z)
    return out


def ewma_alarms(
    values: list[float],
    mu: float,
    sigma: float,
    alpha: float = config.EWMA_ALPHA,
    n_sigma: float = config.EWMA_L,
) -> list[int]:
    """Indices where the smoothed series leaves its control band (D-2).

    The variance of the EWMA statistic shrinks toward ``alpha/(2-alpha)``, so the
    band is narrow after a few points - that is what makes it sensitive to a level
    shift while ignoring single-day spikes.
    """
    if not values or sigma <= 0:
        return []
    z = mu
    alarms: list[int] = []
    for i, x in enumerate(values):
        z = alpha * x + (1.0 - alpha) * z
        var = (alpha / (2.0 - alpha)) * (1.0 - (1.0 - alpha) ** (2 * (i + 1)))
        if abs(z - mu) > n_sigma * sigma * math.sqrt(var):
            alarms.append(i)
    return alarms


@dataclass(frozen=True, slots=True)
class CusumAlarm:
    index: int
    direction: str  # "up" | "down"
    magnitude: float


def cusum(
    values: list[float],
    mu: float,
    sigma: float,
    k: float = config.CUSUM_K,
    h: float = config.CUSUM_H,
) -> list[CusumAlarm]:
    """Two-sided CUSUM (D-3) - the core drift detector.

    Accumulates one-sided deviations in units of sigma, ignoring anything smaller
    than ``k``, and alarms when the running sum exceeds ``h``. With k=0.5 and h=5
    that is roughly ten consecutive days at +1 sigma, or three at +2 sigma - the
    signature of a slow campaign rather than a spike.

    ``h`` must be tuned so the fit window produces **zero** alarms. If it cannot
    be, the daily score is too noisy and the fix is a longer fit window, not a
    bigger h.

    The downward direction is tracked too: a user going quiet matters (host
    offline, agent stopped, logs being suppressed).
    """
    if sigma <= 0:
        sigma = 1.0
    s_hi = 0.0
    s_lo = 0.0
    alarms: list[CusumAlarm] = []
    for i, x in enumerate(values):
        d = (x - mu) / sigma
        s_hi = max(0.0, s_hi + d - k)
        s_lo = min(0.0, s_lo + d + k)
        if s_hi > h:
            alarms.append(CusumAlarm(index=i, direction="up", magnitude=s_hi))
            s_hi = s_lo = 0.0
        elif -s_lo > h:
            alarms.append(CusumAlarm(index=i, direction="down", magnitude=-s_lo))
            s_hi = s_lo = 0.0
    return alarms


def calibrate_h(
    baseline_values: list[float],
    mu: float,
    sigma: float,
    k: float = config.CUSUM_K,
    floor: float = config.CUSUM_H,
    margin: float = 1.5,
) -> float:
    """Choose a decision interval that produces no alarms on the in-control window.

    Setting control limits from the in-control period is standard SPC practice,
    and it is what the acceptance criterion "zero CUSUM alarms on baseline days"
    actually asks for. A fixed ``h`` cannot satisfy it across users: the composite
    daily score is a max of z-scores, so its variance differs by an order of
    magnitude between a quiet executive and a busy sysadmin.

    Measured example: with a fixed ``h=5`` the daily-score series for one user ran
    the accumulator to 6.1 on the last *fit* day - an alarm inside the training
    window, which is by definition a false positive.

    Returns the larger of ``floor`` and the worst baseline excursion times
    ``margin``, so a quiet user does not get an unusably tight limit.
    """
    if sigma <= 0:
        sigma = 1.0
    s_hi = 0.0
    s_lo = 0.0
    worst = 0.0
    for x in baseline_values:
        d = (x - mu) / sigma
        s_hi = max(0.0, s_hi + d - k)
        s_lo = min(0.0, s_lo + d + k)
        worst = max(worst, s_hi, -s_lo)
    return max(floor, worst * margin)


def psi(baseline_counts: dict[str, int], recent_counts: dict[str, int], eps: float = 1e-4) -> float:
    """Population Stability Index over a shared value vocabulary (D-4).

    Catches the one thing value-membership cannot see at all: the same values in
    different proportions. Conventional reading: < 0.10 stable, 0.10-0.25 moderate
    shift, > 0.25 significant.

    Apply only to high-support fields (``LogonType``, ``DestinationPort``,
    ``Image``, ``hour``). PSI on a sparse field is noise.
    """
    keys = set(baseline_counts) | set(recent_counts)
    if not keys:
        return 0.0
    b_total = sum(baseline_counts.values()) or 1
    r_total = sum(recent_counts.values()) or 1
    total = 0.0
    for key in keys:
        b = max(baseline_counts.get(key, 0) / b_total, eps)
        r = max(recent_counts.get(key, 0) / r_total, eps)
        total += (r - b) * math.log(r / b)
    return total


def trend_slope(values: list[float]) -> float:
    """OLS slope of a daily series (D-5). Positive means escalation."""
    n = len(values)
    if n < config.TREND_MIN_DAYS:
        return 0.0
    xs = list(range(n))
    mean_x = statistics.fmean(xs)
    mean_y = statistics.fmean(values)
    denom = sum((x - mean_x) ** 2 for x in xs)
    if denom == 0:
        return 0.0
    return sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, values, strict=True)) / denom


# ---------------------------------------------------------------------------
# Baseline and scoring
# ---------------------------------------------------------------------------


class DayBaseline:
    """Per ``(user, day_class)`` distribution of daily vectors, plus drift state."""

    def __init__(self) -> None:
        # user -> day_class -> feature -> list of daily values
        self.history: dict[str, dict[str, dict[str, list[float]]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(list))
        )
        # user -> event_id -> field -> value -> count  (for PSI)
        self.value_counts: dict[str, dict[str, dict[str, int]]] = defaultdict(
            lambda: defaultdict(dict)
        )
        self.active_days: dict[str, set[str]] = defaultdict(set)
        self.fit_days: set[str] = set()

    def fit(
        self,
        days: dict[tuple[str, date], DayFeatures],
        records: list[FeatureRecord] | None = None,
    ) -> DayBaseline:
        for (user, day), features in days.items():
            self.fit_days.add(day.isoformat())
            self.active_days[user].add(day.isoformat())
            for name, value in features.vector().items():
                self.history[user][features.day_class][name].append(value)

        # Value distributions for PSI, keyed the same way tier A keys its tables.
        if records:
            for record in records:
                for field_name, value in record.tokens:
                    key = f"{record.event_id}_{field_name}"
                    table = self.value_counts[record.user].setdefault(key, {})
                    table[value] = table.get(value, 0) + 1
        return self

    def score(self, features: DayFeatures) -> DayScore:
        cell = self.history.get(features.user, {}).get(features.day_class, {})
        vector = features.vector()

        volume_z: list[tuple[str, float]] = []
        card_z: list[tuple[str, float]] = []
        shape_z: list[tuple[str, float]] = []
        shape_names = {
            "active_hours",
            "hour_entropy",
            "offhours_share",
            "last_hour",
            "first_hour",
        }

        for name, value in vector.items():
            past = cell.get(name, [])
            if not past:
                continue
            z = robust_z(value, past)
            if name.startswith("nuniq_") or name == "n_hosts":
                card_z.append((name, z))
            elif name in shape_names:
                shape_z.append((name, abs(z)))
            else:
                volume_z.append((name, z))

        # Weekend presence test. Two samples cannot support a z-score, but they can
        # support "this user does essentially nothing at weekends" - and that is a
        # stronger statement than any quantile.
        weekend_flag = 0.0
        weekend_reason = ""
        if features.day_class == "weekend":
            past_totals = cell.get("n_total", [])
            baseline_median = statistics.median(past_totals) if past_totals else 0.0
            if baseline_median <= 1.0 and features.n_total > 0:
                weekend_flag = 8.0
                weekend_reason = (
                    f"weekend_activity:n_total={features.n_total} "
                    f"(baseline median {baseline_median:.0f})"
                )

        dormant = 0.0
        if not self.active_days.get(features.user) and features.n_total > 0:
            dormant = 5.0

        novel_median = statistics.median(cell.get("novel_values", [0.0]) or [0.0])
        novelty_ratio = features.novel_values / (novel_median + 1.0)

        from .tier_b import beacon_penalty

        components: dict[str, float] = {
            "volume": config.W_VOLUME * max((z for _, z in volume_z), default=0.0),
            "cardinality": config.W_CARDINALITY * max((z for _, z in card_z), default=0.0),
            "shape": config.W_SHAPE * max((z for _, z in shape_z), default=0.0),
            "novelty": config.W_NOVELTY * novelty_ratio,
            "regularity": config.W_REGULARITY * beacon_penalty(features.best_cv),
            "day_class": weekend_flag,
            "dormant": config.W_DORMANT * dormant,
        }
        driver = max(components, key=lambda k: components[k])
        score = components[driver]

        reasons: list[str] = []
        if weekend_reason:
            reasons.append(weekend_reason)
        if dormant:
            reasons.append("dormant_reactivation")
        for name, z in sorted(card_z, key=lambda t: -t[1])[:3]:
            if z >= config.ROBUST_Z_CUT:
                reasons.append(f"breadth:{name}={vector[name]:.0f}(z={z:.1f})")
        for name, z in sorted(shape_z, key=lambda t: -t[1])[:3]:
            if z >= config.ROBUST_Z_CUT:
                reasons.append(f"shape:{name}={vector[name]:.1f}(z={z:.1f})")
        for name, z in sorted(volume_z, key=lambda t: -t[1])[:3]:
            if z >= config.ROBUST_Z_CUT:
                reasons.append(f"volume:{name}={vector[name]:.0f}(z={z:.1f})")
        if features.best_cv is not None and features.best_cv <= config.BEACON_CV_MAX:
            reasons.append(f"periodic_day:cv={features.best_cv:.3f} beats={features.beacon_beats}")
        if features.novel_event_ids:
            reasons.append(f"novel_event_ids:{features.novel_event_ids}")

        return DayScore(
            features=features,
            score=score,
            driver=driver,
            components=components,
            reasons=tuple(reasons),
        )

    def score_all(self, days: dict[tuple[str, date], DayFeatures]) -> list[DayScore]:
        return sorted(
            (self.score(f) for f in days.values()),
            key=lambda s: (s.features.day, s.features.user),
        )

    # -- drift -------------------------------------------------------------

    def drift(
        self, user: str, day_scores: list[DayScore], records: list[FeatureRecord] | None = None
    ) -> DriftReport:
        """Run the drift layer over one user's scored days, in date order."""
        series = [s for s in day_scores if s.user == user]
        series.sort(key=lambda s: s.features.day)
        values = [s.score for s in series]
        days = [s.features.day for s in series]

        baseline_scores = [s.score for s in series if s.features.day.isoformat() in self.fit_days]
        reference = baseline_scores or values
        mu = statistics.median(reference) if reference else 0.0
        sigma = (
            statistics.median([abs(v - mu) for v in reference]) * 1.4826
            if len(reference) > 1
            else 1.0
        )
        sigma = max(sigma, config.MAD_FLOOR)

        # Calibrate the decision interval on the fit window so the in-control
        # period yields zero alarms, then apply it to the whole series.
        baseline_values = [
            s.score for s in series if s.features.day.isoformat() in self.fit_days
        ]
        h = calibrate_h(baseline_values or values, mu, sigma)

        novelty_rate = [
            (s.features.novel_values / s.features.n_total) if s.features.n_total else 0.0
            for s in series
        ]

        psi_findings: list[tuple[str, float]] = []
        if records:
            recent_days = {d.isoformat() for d in days if d.isoformat() not in self.fit_days}
            recent: dict[str, dict[str, int]] = defaultdict(dict)
            for record in records:
                if record.user != user or record.day.isoformat() not in recent_days:
                    continue
                for field_name, value in record.tokens:
                    key = f"{record.event_id}_{field_name}"
                    table = recent[key]
                    table[value] = table.get(value, 0) + 1
            for key, recent_table in recent.items():
                base_table = self.value_counts.get(user, {}).get(key, {})
                if sum(base_table.values()) < config.PSI_MIN_SUPPORT:
                    continue
                if sum(recent_table.values()) < config.PSI_MIN_SUPPORT:
                    continue
                value = psi(base_table, recent_table)
                if value >= config.PSI_MODERATE:
                    psi_findings.append((key, value))
            psi_findings.sort(key=lambda t: -t[1])

        return DriftReport(
            user=user,
            days=tuple(days),
            scores=tuple(values),
            novelty_rate=tuple(novelty_rate),
            ewma=tuple(ewma_series(values)),
            ewma_alarm_days=tuple(days[i] for i in ewma_alarms(values, mu, sigma)),
            cusum_alarms=tuple(
                (days[a.index], a.direction, a.magnitude)
                for a in cusum(values, mu, sigma, h=h)
            ),
            cusum_h=h,
            slope=trend_slope(values),
            psi=tuple(psi_findings[:8]),
            mu=mu,
            sigma=sigma,
        )


@dataclass(frozen=True, slots=True)
class DayScore:
    """Tier C verdict for one ``(user, day)``."""

    features: DayFeatures
    score: float
    driver: str
    components: dict[str, float]
    reasons: tuple[str, ...]

    @property
    def user(self) -> str:
        return self.features.user

    @property
    def is_alert(self) -> bool:
        return self.score >= config.TIER_C_ALERT_SCORE

    def explain(self) -> str:
        f = self.features
        head = (
            f"{f.day.isoformat()} ({f.day_class})  user={self.user}  "
            f"score={self.score:.1f}  driver={self.driver}\n"
            f"  n_total={f.n_total}  hosts={f.n_hosts}  active_hours={f.active_hours}  "
            f"first={f.first_hour} last={f.last_hour}  novel={f.novel_values}  "
            f"alerting_hours={f.alerting_hours}"
        )
        parts = "  ".join(f"{k}={v:.1f}" for k, v in sorted(self.components.items()))
        reasons = "\n".join(f"    - {r}" for r in self.reasons) or "    (none)"
        return f"{head}\n  components: {parts}\n  reasons:\n{reasons}"


@dataclass(frozen=True, slots=True)
class DriftReport:
    """Drift layer output for one user."""

    user: str
    days: tuple[date, ...]
    scores: tuple[float, ...]
    novelty_rate: tuple[float, ...]
    ewma: tuple[float, ...]
    ewma_alarm_days: tuple[date, ...]
    cusum_alarms: tuple[tuple[date, str, float], ...]
    slope: float
    psi: tuple[tuple[str, float], ...]
    mu: float
    sigma: float
    cusum_h: float = config.CUSUM_H

    @property
    def has_drift(self) -> bool:
        return bool(self.cusum_alarms or self.ewma_alarm_days) or any(
            value >= config.PSI_SIGNIFICANT for _, value in self.psi
        )

    def explain(self) -> str:
        lines = [
            f"drift  user={self.user}  mu={self.mu:.2f}  sigma={self.sigma:.2f}  "
            f"h={self.cusum_h:.1f}  slope={self.slope:+.3f}/day"
        ]
        for i, day in enumerate(self.days):
            lines.append(
                f"    {day.isoformat()}  score={self.scores[i]:6.2f}  "
                f"ewma={self.ewma[i]:6.2f}  novelty_rate={self.novelty_rate[i]:.3f}"
            )
        if self.cusum_alarms:
            for day, direction, magnitude in self.cusum_alarms:
                lines.append(
                    f"    CUSUM {direction} alarm on {day.isoformat()} (S={magnitude:.1f})"
                )
        if self.ewma_alarm_days:
            lines.append(
                "    EWMA alarms: " + ", ".join(d.isoformat() for d in self.ewma_alarm_days)
            )
        for key, value in self.psi:
            band = "significant" if value >= config.PSI_SIGNIFICANT else "moderate"
            lines.append(f"    PSI {key} = {value:.3f} ({band})")
        return "\n".join(lines)


def environment_drift(reports: list[DriftReport], top_novel_by_user: dict[str, set[str]]) -> bool:
    """Distinguish a change in the environment from an attack.

    A drift detector that ignores this produces a slowly rising false-positive
    curve that looks exactly like an attack. The separator is cheap:

        attack drift      - few users, *different* novel values each
        environment drift - many users at once, the *same* new values

    Returns True when drift looks population-wide, which should trigger a baseline
    refit rather than an alert.
    """
    if not reports:
        return False
    drifting = [r for r in reports if r.has_drift]
    if len(drifting) / len(reports) < config.ENV_DRIFT_USER_FRACTION:
        return False
    value_sets = [top_novel_by_user.get(r.user, set()) for r in drifting]
    value_sets = [s for s in value_sets if s]
    if len(value_sets) < 2:
        return False
    shared = set.intersection(*value_sets)
    union = set.union(*value_sets)
    return bool(union) and len(shared) / len(union) >= 0.5
