  # Stage 5 - load the notebook's baseline_output/ artifacts once, serve them to the
# scorer, hot-reload when the notebook retrains. Everything degrades gracefully:
# missing files disable their signal with a logged warning, never a crash.

from __future__ import annotations
import os
import pickle
import threading
import time
import logging

import numpy as np
import pandas as pd

log = logging.getLogger("ubaseline.baseline")


class BaselineStore:
    def __init__(self, cfg):
        self.dir = cfg.baseline_dir
        self._lock = threading.Lock()
        self._loaded_at = 0.0
        self._mtime = 0.0
        self.hot_reload_seconds = cfg.hot_reload_seconds
        self.defaults = dict(cfg.scoring_defaults)
        self._load()

    # ---------------------------------------------------------------- loading
    def _load(self):
        d = self.dir
        self.cfg = {}                      # from model.pkl["config"]
        self.num = {}                      # numeric baseline frames
        self.iso = None                    # fitted IsolationForest
        self.known: set[tuple] = set()     # (user, itype, value)
        self.gcnt: dict[tuple, float] = {} # (itype, gvalue)
        self.eid_ucnt: dict[tuple, float] = {}
        self.eid_utot: dict[str, float] = {}
        self.eid_gcnt: dict[int, float] = {}
        self.eid_gtot = 0.0
        self.act_max: pd.DataFrame | None = None
        self.thresholds: pd.Series | None = None   # (user, hour) -> threshold
        self.stat_features: list[str] = []
        self.act_features: list[str] = []
        self.act_weights: dict[str, float] = {}

        pkl = os.path.join(d, "model.pkl")
        if os.path.exists(pkl):
            self._mtime = os.path.getmtime(pkl)
            with open(pkl, "rb") as fh:
                m = pickle.load(fh)
            self.cfg = m.get("config", {})
            self.num = m.get("numeric_baseline", {})
            self.iso = m.get("isolation_forest")
            self._pkl_thresholds = None
        else:
            log.warning("model.pkl not found in %s - scoring uses config.yaml defaults", d)

        self.stat_features = list(self.cfg.get("stat_features", []))
        self.act_features = list(self.cfg.get("act_features", []))
        self.act_weights  = dict(self.cfg.get("act_weights", {}))

        def _parquet(name):
            p = os.path.join(d, name)
            return pd.read_parquet(p) if os.path.exists(p) else None

        inv = _parquet("baseline_inventories.parquet")
        if inv is not None:
            self.known = set(map(tuple, inv[["user", "itype", "value"]].drop_duplicates().to_numpy()))
        else:
            log.warning("baseline_inventories.parquet missing - novelty treats everything as new")

        g = _parquet("baseline_global_rarity.parquet")
        if g is not None:
            self.gcnt = {(r.itype, r.gvalue): float(r.gcnt) for r in g.itertuples()}

        e = _parquet("baseline_eventid_rarity.parquet")
        if e is not None:
            self.eid_ucnt = {(r.user, int(r.EventID)): float(r.ucnt) for r in e.itertuples()}
            # reconstruct the totals exactly (notebook did not export them):
            for (u, eid), c in self.eid_ucnt.items():
                self.eid_utot[u] = self.eid_utot.get(u, 0.0) + c
                self.eid_gcnt[eid] = self.eid_gcnt.get(eid, 0.0) + c
                self.eid_gtot += c

        a = _parquet("baseline_activation.parquet")
        if a is not None:
            a = a.set_index("user") if "user" in a.columns else a
            self.act_max = a

        if isinstance(self._pkl_thresholds, pd.Series):
            self.thresholds = self._pkl_thresholds      # from model.pkl["threshold_surface"]
        else:
            t = _parquet("threshold_surface.parquet")
            if t is not None:
                col = "threshold" if "threshold" in t.columns else t.columns[-1]
                key_cols = [c for c in ("user", "hour") if c in t.columns]
                self.thresholds = t.set_index(key_cols)[col] if key_cols else t[col]

        self.principals = set(self.cfg.get("principals", []))
        if "med_h" in self.num and len(self.num["med_h"]):
            self.principals |= {u for u, _ in self.num["med_h"].index}
        elif self.act_max is not None:
            self.principals |= set(self.act_max.index)
        self._loaded_at = time.time()
        log.info("baseline loaded: %d principals, %d known items, %d EID rows",
                 len(self.principals), len(self.known), len(self.eid_ucnt))

    def maybe_reload(self, force: bool = False):
        if not force and time.time() - self._loaded_at < self.hot_reload_seconds:
            return
        pkl = os.path.join(self.dir, "model.pkl")
        mt = os.path.getmtime(pkl) if os.path.exists(pkl) else 0
        if force or mt != self._mtime:
            log.info("baseline artifacts changed - reloading")
            with self._lock:
                self._load()

    # ---------------------------------------------------------------- queries
    def has_baseline(self, user: str) -> bool:
        return user in self.principals

    def const(self, name: str) -> float:
        """model.pkl config value, else config.yaml default.

        Accepts BOTH naming conventions:
          notebook save cell : Z0 Z1 K_STAT K_NOV K_RARE K_ACT + weights={"s_stat":...}
          config.yaml        : z0 z1 k_stat ... w_stat ...
        """
        if name in self.cfg:                        # exact (lowercase) match
            return float(self.cfg[name])
        up = name.upper()                           # notebook's uppercase form
        if up in self.cfg:
            return float(self.cfg[up])
        wmap = {"w_stat": "s_stat", "w_nov": "s_nov", "w_rare": "s_rare",
                "w_act": "s_act", "w_ml": "s_ml"}
        if name in wmap and isinstance(self.cfg.get("weights"), dict):
            return float(self.cfg["weights"][wmap[name]])
        return float(self.defaults.get(name))

    def cell(self, user: str, hour: int):
        """(med, mad, p95) arrays for the user's hour, ordered by stat_features."""
        if "med_h" not in self.num or not self.stat_features:
            return None
        try:
            med = self.num["med_h"].loc[(user, hour), self.stat_features].to_numpy(float)
            mad = self.num["mad_h"].loc[(user, hour), self.stat_features].to_numpy(float)
            p95 = self.num["p95_h"].loc[(user, hour), self.stat_features].to_numpy(float)
        except KeyError:
            return None
        madu = np.zeros(len(self.stat_features))
        if "mad_u" in self.num and user in self.num["mad_u"].index:
            madu = self.num["mad_u"].loc[user, self.stat_features].to_numpy(float)
        if madu.ndim > 1:                      # tolerate (user,hour)-indexed exports
            madu = np.nanmedian(madu, axis=0)
        return med, mad, madu, p95

    def act_max_row(self, user: str):
        if self.act_max is None or user not in self.act_max.index:
            return None
        return self.act_max.loc[user]

    def threshold(self, user: str, hour: int) -> float:
        if self.thresholds is not None:
            try:
                return float(self.thresholds.loc[(user, hour)])
            except (KeyError, TypeError):
                pass
        return float(self.const("alert_threshold"))
