# The auto-trainer: watches the features stored in ClickHouse (or the JSONL
# fallback) for users WITHOUT a baseline. When a user accumulates enough
# history (default: 7 distinct days and >= min_events events - the notebook's
# MIN_TRAIN_EVENTS rule), it fits that user's baseline with the SAME math as
# the notebook (robust per-(user,hour) statistics, behavioural inventories,
# EID rarity, activation maxima, and a LODO-scored threshold surface), merges
# the user into baseline_output/model.pkl, and the service hot-reloads it.

from __future__ import annotations
import logging
import os
import pickle
import threading
import time
from collections import Counter

import numpy as np
import pandas as pd

log = logging.getLogger("ubaseline.trainer")

K_USER, K_CELL = 300.0, 80.0          # notebook cell 28 shrinkage constants
SHAPE_LO, SHAPE_HI = 0.70, 1.60
CONST_KEYS = ("z0", "z1", "k_stat", "k_nov", "k_rare", "k_act",
              "w_stat", "w_nov", "w_rare", "w_act", "w_ml")


def _logw(uwins: pd.DataFrame, feats) -> pd.DataFrame:
    wide = pd.DataFrame([[float(r.get(f, 0.0)) for f in feats] for r in uwins.feats],
                        columns=feats)
    out = np.log1p(wide)
    out.index = pd.MultiIndex.from_arrays([uwins.user.to_numpy(), uwins.hour.to_numpy()],
                                          names=["user", "hour"])
    return out


def _cell_stats(logw_: pd.DataFrame):
    med_h = logw_.groupby(level=[0, 1]).median()
    mad_h = logw_.groupby(level=[0, 1]).apply(lambda g: (g - g.median()).abs().median())
    p95_h = logw_.groupby(level=[0, 1]).quantile(0.95)
    med_u = logw_.groupby(level=0).median()
    mad_u = logw_.groupby(level=0).apply(lambda g: (g - g.median()).abs().median())
    return med_h, mad_h, p95_h, med_u, mad_u


class _FitStore:
    """Duck-typed BaselineStore so scoring.score_window runs unchanged on a fit."""

    def __init__(self, stat_features, act_features, act_weights, consts,
                 known, gcnt, eid_ucnt, eid_utot, eid_gcnt, eid_gtot,
                 med_h, mad_h, p95_h, med_u, mad_u, act_max, flat):
        self.stat_features, self.act_features, self.act_weights = \
            stat_features, act_features, act_weights
        self._c = consts
        self.known, self.gcnt = known, gcnt
        self.eid_ucnt, self.eid_utot, self.eid_gcnt, self.eid_gtot = \
            eid_ucnt, eid_utot, eid_gcnt, eid_gtot
        self.med_h, self.mad_h, self.p95_h = med_h, mad_h, p95_h
        self._med_u, self._mad_u = med_u, mad_u
        self.act_max, self.flat = act_max, flat
        self.thresholds, self.iso = None, None

    def has_baseline(self, user): return True
    def const(self, name): return float(self._c[name])
    def act_max_row(self, user):
        return self.act_max.loc[user] if user in self.act_max.index else None
    def threshold(self, user, hour): return self.flat

    def cell(self, user, hour):
        try:
            madu = self._mad_u.loc[user].to_numpy(float) \
                if user in self._mad_u.index else np.zeros(len(self.stat_features))
            return (self.med_h.loc[(user, hour)].to_numpy(float),
                    self.mad_h.loc[(user, hour)].to_numpy(float),
                    madu,
                    self.p95_h.loc[(user, hour)].to_numpy(float))
        except KeyError:
            return None


def _empty_items():
    return pd.DataFrame(columns=["itype", "value", "gvalue", "trusted", "is_public",
                                 "susp_dir", "sens_port", "interactive"])


def fit_user(uwins: pd.DataFrame, uitems: pd.DataFrame | None, stat_features,
             act_features, act_weights, consts, flat_threshold):
    from .scoring import score_window
    user = uwins.user.iloc[0]

    # ---- numeric stats over all days ------------------------------------------
    logw_all = _logw(uwins, stat_features)
    med_h, mad_h, p95_h, med_u, mad_u = _cell_stats(logw_all)

    # ---- inventories + corpus rarity -------------------------------------------
    known, gcnt = set(), Counter()
    if uitems is not None and len(uitems):
        known = {(user, r.itype, r.value) for r in uitems.itertuples()}
        gcnt.update((r.itype, r.gvalue) for r in uitems.itertuples())

    # ---- EID rarity from stored per-window eid_counts ---------------------------
    ucnt: Counter = Counter()
    for r in uwins.feats:
        for eid, n in (r.get("eid_counts") or {}).items():
            ucnt[(user, int(eid))] += int(n)
    utot = {user: float(sum(v for (u, _), v in ucnt.items()))}
    gcnt_eid: Counter = Counter()
    for (_u, eid), v in ucnt.items():
        gcnt_eid[eid] += v
    gtot = float(sum(gcnt_eid.values()))

    # ---- activation maxima -------------------------------------------------------
    act_wide = pd.DataFrame([[float(r.get(f, 0.0)) for f in act_features] for r in uwins.feats],
                            columns=act_features)
    act_max = pd.DataFrame([act_wide.max()], index=[user])

    # ---- leave-one-day-out risks -> per-(user,hour) threshold surface -----------
    risk_rows: list[tuple[int, float]] = []      # (hour, risk)
    for d in sorted(uwins.date.unique()):
        tr, te = uwins[uwins.date != d], uwins[uwins.date == d]
        ltr = _logw(tr, stat_features)
        m_h, d_h, p_h, m_u, d_u = _cell_stats(ltr)
        store = _FitStore(stat_features, act_features, act_weights, consts,
                          known, dict(gcnt), dict(ucnt), utot, dict(gcnt_eid), gtot,
                          m_h, d_h, p_h, m_u, d_u, act_max, flat_threshold)
        for _, row in te.iterrows():
            items = _empty_items()
            if uitems is not None and len(uitems):
                sel = uitems[uitems.window_start == row.window_start]
                if len(sel):
                    items = sel
            eid_counts = {int(k): int(v) for k, v in (row.feats.get("eid_counts") or {}).items()}
            res = score_window(store, user, int(row.hour), row.feats, items, eid_counts)
            if res:
                risk_rows.append((int(row.hour), res["risk_score"]))

    thresholds = _threshold_surface(user, risk_rows, flat_threshold,
                                    consts["fp_budget_per_user_day"],
                                    sorted(uwins.hour.unique()))
    return {"user": user, "med_h": med_h, "mad_h": mad_h, "p95_h": p95_h,
            "med_u": med_u, "mad_u": mad_u, "known": known, "gcnt": dict(gcnt),
            "eid_ucnt": dict(ucnt), "eid_utot": utot, "eid_gcnt": dict(gcnt_eid),
            "eid_gtot": gtot, "act_max": act_max, "thresholds": thresholds}


def _threshold_surface(user, risk_rows, flat, budget_per_user_day, hours):
    """Notebook cell 28, per user: shrunk per-cell thresholds + bisection on the
    FP budget. Falls back to the flat threshold if the user never scored > 0."""
    idx = pd.MultiIndex.from_product([[user], sorted(int(h) for h in hours)],
                                     names=["user", "hour"])
    if not risk_rows or max(r for _, r in risk_rows) <= 0:
        return pd.Series(flat, index=idx)

    rr = pd.DataFrame(risk_rows, columns=["hour", "risk"])
    r = rr.risk.to_numpy(float)
    n_days = max(1.0, budget_per_user_day and len(r) / 144.0 * 144 / 144)  # placeholder
    budget = max(1.0, budget_per_user_day * max(1.0, len(r) / 144.0))
    p_tail = min(0.5, budget / len(r))
    q_global = max(float(np.quantile(r, 1 - p_tail)), 1e-6)
    tau_user = float(np.quantile(r, 1 - p_tail))

    thr = {}
    for h, g in rr.groupby("hour"):
        top2 = float(np.mean(np.sort(g.risk.to_numpy())[-2:])) if len(g) else 0.0
        tau_cell = (len(g) * top2 + K_CELL * tau_user) / (len(g) + K_CELL)
        thr[int(h)] = tau_cell

    shape = {h: float(np.clip(v / q_global, SHAPE_LO, SHAPE_HI)) for h, v in thr.items()}
    shape_arr = np.array([shape.get(int(h), 1.0) for h in rr.hour])
    lo, hi = 0.05, 20.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if (r >= mid * q_global * shape_arr).sum() > budget:
            lo = mid
        else:
            hi = mid
    level = 0.5 * (lo + hi)
    return pd.Series({(user, h): level * q_global * shape.get(h, 1.0) for h in
                      idx.get_level_values(1)}).reindex(idx).fillna(level * q_global)


def merge_and_save(baseline_dir: str, fitted: dict, stat_features, act_features):
    pkl = os.path.join(baseline_dir, "model.pkl")
    if os.path.exists(pkl):
        with open(pkl, "rb") as fh:
            model = pickle.load(fh)
    else:
        model = {"config": {"stat_features": list(stat_features),
                            "act_features": list(act_features), "act_weights": {},
                            "alert_threshold": 0.576, "principals": []},
                 "numeric_baseline": {}, "isolation_forest": None}
    cfg = model.setdefault("config", {})
    cfg["principals"] = sorted(set(cfg.get("principals", [])) | {fitted["user"]})

    num = model.setdefault("numeric_baseline", {})
    for key in ("med_h", "mad_h", "p95_h", "med_u", "mad_u"):
        old, new = num.get(key), fitted[key]
        num[key] = new if old is None or len(old) == 0 else \
            pd.concat([old, new]).sort_index()

    inv_p = os.path.join(baseline_dir, "baseline_inventories.parquet")
    inv = pd.read_parquet(inv_p) if os.path.exists(inv_p) else \
        pd.DataFrame(columns=["user", "itype", "value"])
    add = pd.DataFrame(sorted(fitted["known"]), columns=["user", "itype", "value"])
    if len(add):
        inv = pd.concat([inv, add], ignore_index=True).drop_duplicates()
    inv.to_parquet(inv_p, index=False)

    g_p = os.path.join(baseline_dir, "baseline_global_rarity.parquet")
    g = pd.read_parquet(g_p) if os.path.exists(g_p) else \
        pd.DataFrame(columns=["itype", "gvalue", "gcnt"])
    addg = pd.DataFrame([(k[0], k[1], v) for k, v in fitted["gcnt"].items()],
                        columns=["itype", "gvalue", "gcnt"])
    if len(addg):
        g = pd.concat([g, addg]).groupby(["itype", "gvalue"], as_index=False).gcnt.sum()
    g.to_parquet(g_p, index=False)

    e_p = os.path.join(baseline_dir, "baseline_eventid_rarity.parquet")
    e = pd.read_parquet(e_p) if os.path.exists(e_p) else \
        pd.DataFrame(columns=["user", "EventID", "ucnt"])
    adde = pd.DataFrame([(u, eid, v) for (u, eid), v in fitted["eid_ucnt"].items()],
                        columns=["user", "EventID", "ucnt"])
    if len(adde):
        e = pd.concat([e, adde]).groupby(["user", "EventID"], as_index=False).ucnt.sum()
    e.to_parquet(e_p, index=False)

    a_p = os.path.join(baseline_dir, "baseline_activation.parquet")
    a = pd.read_parquet(a_p) if os.path.exists(a_p) else pd.DataFrame()
    if len(a):
        if "user" not in a.columns:
            a = a.reset_index()                  # user stored as the index
        if "user" not in a.columns:              # index came back unnamed
            a = a.rename(columns={a.columns[0]: "user"})
    else:
        a = pd.DataFrame(columns=["user"])
    new_a = fitted["act_max"].reset_index()
    if "user" not in new_a.columns and "index" in new_a.columns:
        new_a = new_a.rename(columns={"index": "user"})
    a = pd.concat([a, new_a], ignore_index=True, sort=False)
    num_cols = [c for c in a.columns if c != "user"]
    a = (a.groupby("user", as_index=False)[num_cols].max()
         if num_cols else a.drop_duplicates("user"))
    a.to_parquet(a_p, index=False)

    old_ts = model.get("threshold_surface")
    ts = fitted["thresholds"] if not isinstance(old_ts, pd.Series) else \
        pd.concat([old_ts, fitted["thresholds"]])
    model["threshold_surface"] = ts.sort_index()
    ts.reset_index().to_parquet(os.path.join(baseline_dir, "threshold_surface.parquet"),
                                index=False)

    tmp = pkl + ".tmp"
    with open(tmp, "wb") as fh:
        pickle.dump(model, fh)
    os.replace(tmp, pkl)
    log.info("baseline merged: new principal %s -> %s", fitted["user"], pkl)


class Trainer:
    def __init__(self, cfg, store, sink):
        self.cfg, self.store, self.sink = cfg, store, sink
        t = cfg.raw.get("training", {})
        self.enabled = bool(t.get("enabled", True))
        self.min_days = int(t.get("min_days", 7))
        self.min_events = int(t.get("min_events", 200))
        # Baselines are for HUMANS. Service/machine/stale accounts must never be
        # auto-baselined even when they accumulate enough stored data.
        self.exclude_prefixes = tuple(t.get("exclude_prefixes", ["svc-", "sql-", "mnt-"]))
        self.exclude_names = set(t.get("exclude_names", []))
        self.check_hours = float(t.get("check_hours", 12))
        self._last = 0.0
        self._lock = threading.Lock()

    def _is_baseline_candidate(self, user: str) -> bool:
        u = str(user).lower()
        if u in self.exclude_names or u in {"new.user"}:
            return False
        if u.startswith(self.exclude_prefixes) or u.endswith("$") or "-" == u[-1:] and False:
            return False
        return True

    def candidates(self, win: pd.DataFrame) -> pd.DataFrame:
        have = set(self.store.principals)
        rows = []
        for user, g in win[win.feats.map(lambda f: f.get("event_count", 0) > 0)].groupby("user"):
            if user in have or not self._is_baseline_candidate(user):
                continue
            days = g.date.nunique()
            events = float(g.feats.map(lambda f: f.get("event_count", 0)).sum())
            rows.append({"user": user, "days": int(days), "events": events,
                         "ready": bool(days >= self.min_days and events >= self.min_events)})
        return pd.DataFrame(rows)

    def train_ready_users(self) -> dict:
        with self._lock:
            win = self.sink.query_features()
            if win is None or not len(win):
                return {"trained": [], "candidates": 0, "detail": []}
            cand = self.candidates(win)
            consts = {k: self.store.const(k) for k in CONST_KEYS}
            consts["fp_budget_per_user_day"] = float(
                self.cfg.raw.get("training", {}).get("fp_budget_per_user_day", 0.20))
            
            stat_features = list(self.store.stat_features)
            act_features = list(self.store.act_features)
            if not (stat_features and act_features):
                if not stat_features:
                    ok = {}
                    for fmap in win.feats:
                        if not isinstance(fmap, dict):
                            continue
                        for k, v in fmap.items():
                            if v is None:
                                ok.setdefault(k, True)
                                continue
                            try:
                                float(v)
                                good = True
                            except (TypeError, ValueError):
                                good = False
                            ok[k] = ok.get(k, True) and good
                    stat_features = sorted(k for k, g in ok.items() if g)
                    skipped = sorted(k for k, g in ok.items() if not g)
                    log.info("bootstrapped %d numeric feature(s); skipped non-numeric key(s): %s",
                             len(stat_features), skipped or "none")
                if not act_features:
                    from .features import ITEM_DEF
                    act_features = [name for name, _mask, _col in ITEM_DEF]
                log.info("no config row in baseline_meta: bootstrapping %d stat + %d act "
                         "feature(s) from stored windows",
                         len(stat_features), len(act_features))



            

            act_weights = dict(self.store.act_weights)
            flat = float(self.store.const("alert_threshold"))
            trained = []
            if len(cand) and cand.ready.any():
                from .baseline_ch import merge_user_to_ch
                for user in cand[cand.ready].user:
                    uw = win[win.user == user]
                    items = self.sink.query_items(user)
                    fitted = fit_user(uw, items, stat_features, act_features,
                                      act_weights, consts, flat)
                    if getattr(self.store, "ch_backed", False):
                        merge_user_to_ch(self.sink, fitted)          # baselines in ClickHouse
                    else:
                        merge_and_save(self.cfg.baseline_dir, fitted,
                                       stat_features, act_features)  # file artifacts
                    trained.append(user)
                self.store.maybe_reload(force=True)
            return {"trained": trained, "candidates": int(len(cand)),
                    "detail": cand.to_dict("records") if len(cand) else []}

    def maybe_train(self):
        if not self.enabled:
            return
        if time.time() - self._last < self.check_hours * 3600:
            return
        self._last = time.time()
        try:
            report = self.train_ready_users()
            if report.get("trained"):
                log.info("auto-trainer built baselines for: %s", report["trained"])
            elif report.get("candidates"):
                log.info("auto-trainer: %d candidate user(s), none ready (need %d days / %d events)",
                         report["candidates"], self.min_days, self.min_events)
        except Exception:
            log.exception("auto-trainer failed")
