# Optional REST shell around the running consumer: health, metrics, recent
# results, baseline inventory. Run alongside the consumer process:
#   uvicorn app.api:app --port 8080
# (the consumer and API share state via the Pipeline instance created here)

from __future__ import annotations
import json
import logging
import os
import threading
import time

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
import asyncio

from .config import Config
from .consumer import Pipeline

log = logging.getLogger("ubaseline.api")
cfg = Config.load(os.environ.get("UBASELINE_CONFIG", "config.yaml"))
pipe = Pipeline(cfg)

app = FastAPI(title="user-baseline scoring service", version="1.0")
from fastapi.middleware.cors import CORSMiddleware   # top of file if not present

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5500", "http://127.0.0.1:5500"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _start():
    if os.environ.get("UBASELINE_NO_CONSUMER") != "1":
        threading.Thread(target=_consume, daemon=True).start()


def _consume():
    time.sleep(1)
    if cfg.kafka_brokers:
        try:
            pipe.run_kafka()
        except Exception:
            log.exception("consumer thread died - API stays up")
    else:
        log.warning("no Kafka configured and UBASELINE_NO_CONSUMER!=1 - "
                    "API serves an idle pipeline (use POST /mock/run to score a file)")


# @app.get("/health")
@app.get("/api/health")
def health():
    return {"status": "ok",
            "kafka": bool(cfg.kafka_brokers),
            "clickhouse": bool(pipe.ch._client),
            "baselined_principals": len(pipe.store.principals),
            "counters": dict(pipe.counters)}


# @app.get("/metrics")
@app.get("/api/metrics")
def metrics():
    c = pipe.counters
    return {**dict(c),
            "attribution_rate": round((c.get("events_in", 0) -
                                       c.get("C_unattributed", 0) + pipe.attributor.stats["C_unattributed"])
                                      / max(1, pipe.attributor.stats["total"]), 4),
            "attribution_tiers": pipe.attributor.stats}


# @app.get("/baselines")
@app.get("/api/baselines")
def baselines():
    return {"principals": sorted(pipe.store.principals),
            "n_stat_features": len(pipe.store.stat_features),
            "n_act_features": len(pipe.store.act_features)}


# @app.get("/results")
@app.get("/api/results")
def results(user: str | None = None, alert_only: bool = False,
            limit: int = Query(50, le=1000)):
    rows = pipe.results
    if user:
        rows = [r for r in rows if r["user"] == user]
    if alert_only:
        rows = [r for r in rows if r["alert"]]
    return rows[-limit:]


# @app.get("/results/{user}/{window_start}")
@app.get("/api/results/{user}/{window_start}")
def one_result(user: str, window_start: str):
    for r in pipe.results:
        if r["user"] == user and r["window_start"].startswith(window_start):
            return r
    raise HTTPException(404, "window not found (only the last 5000 results are held)")



# @app.post("/score")
@app.post("/api/score")
def score(body: dict):
    """Score one or more 10-minute batches of raw events (JSONL records).

    Body: {"events": [ {...event...}, ... ]}
    Returns one result per (user, window) found in the batch. Events for users
    without a baseline are routed to ClickHouse (or its JSONL fallback) and
    reported under "held"."""
    events = body.get("events") or []
    if not events:
        raise HTTPException(400, "body must be {'events': [...]}"
                            )
    for raw in events:
        pipe.feed(raw)
    results = pipe.process_ready(flush=True)
    return {"n_events": len(events),
            "n_results": len(results),
            "alerts": sum(1 for r in results if r["alert"]),
            "held_for_baseline": pipe.counters.get("events_held_clickhouse", 0),
            "results": results}


# @app.post("/mock/run")
@app.post("/api/mock/run")
def mock_run(path: str):
    """Score a JSONL file end-to-end without Kafka. Body: {"path": "events.jsonl"}"""
    if not os.path.exists(path):
        raise HTTPException(404, f"file not found: {path}")
    pipe.run_mock(path)
    return {"counters": dict(pipe.counters), "n_results": len(pipe.results)}


# @app.get("/alerts")
@app.get("/api/alerts")
def alerts(limit: int = Query(200, le=1000)):
    """Past alerts from the ClickHouse audit table (falls back to in-memory)."""
    if pipe.ch._client is None:
        return {"source": "memory", "alerts": [r for r in pipe.results if r["alert"]][-limit:]}
    try:
        df = pipe.ch._query_df(
            f"SELECT user, window_start, hour, event_count, risk_score, risk_level, "
            f"threshold, risk_ratio, reasons FROM {pipe.ch.db}.window_results "
            f"WHERE alert = 1 ORDER BY risk_score DESC LIMIT {int(limit)}")
        if df is None or df.empty:
            return {"source": "clickhouse", "alerts": []}
        rows = []
        for r in df.to_dict("records"):
            try:
                reasons = json.loads(r.get("reasons") or "[]")
            except Exception:
                reasons = []
            ws = str(r["window_start"])
            rows.append({"user": r["user"], "window_start": ws,
                         "window": ws[11:16] + "-?",
                         "hour": int(r["hour"]), "event_count": int(r["event_count"]),
                         "risk_score": float(r["risk_score"]), "risk_level": r["risk_level"],
                         "threshold": float(r["threshold"]),
                         "risk_ratio": round(float(r["risk_score"]) / max(float(r["threshold"]), 1e-9), 2),
                         "alert": True, "reasons": reasons})
        return {"source": "clickhouse", "alerts": rows}
    except Exception as exc:
        raise HTTPException(500, f"clickhouse query failed: {exc}")


# @app.post("/train")
@app.post("/api/train")
def train():
    """Check stored (ClickHouse / fallback) features; build baselines for any user
    that now has >= training.min_days days and >= min_events events."""
    return pipe.trainer.train_ready_users()


@app.get("/", response_class=HTMLResponse)
def index():
    path = os.path.join(os.path.dirname(__file__), "..", "static", "index.html")
    with open(path, encoding="utf-8") as fh:
        return HTMLResponse(fh.read())


@app.websocket("/ws")
async def ws_results(ws: WebSocket):
    """Push new scoring results to the frontend every push_seconds (default 120s),
    with a heartbeat when nothing new sealed."""
    await ws.accept()
    push = int(cfg.api.get("push_seconds", 120))
    sent = 0
    await ws.send_json({"type": "hello",
                        "principals": sorted(pipe.store.principals),
                        "push_seconds": push})
    try:
        while True:
            await asyncio.sleep(push)
            fresh = pipe.results[sent:] if sent < len(pipe.results) else []
            sent = len(pipe.results)
            msg = {"type": "results", "data": fresh[-50:]} if fresh else \
                  {"type": "heartbeat", "counters": dict(pipe.counters),
                   "attribution": pipe.attributor.stats}
            await ws.send_json(msg)
    except WebSocketDisconnect:
        return
    except Exception:
        try:
            await ws.close()
        except Exception:
            pass
