# ClickHouse sink for events the model cannot score (and, optionally, every
# event). Falls back to local JSONL files when no cluster is configured, so the
# whole service runs end-to-end on a laptop.

from __future__ import annotations
import json
import logging
import os
import threading

import numpy as np
import pandas as pd
import time

log = logging.getLogger("ubaseline.clickhouse")

DDL = [
    """
    CREATE TABLE IF NOT EXISTS {db}.events (
        timestamp        DateTime64(6, 'UTC'),
        date             Date,
        window_start     DateTime64(3, 'UTC'),
        EventID          UInt32,
        Channel          LowCardinality(String),
        Computer         LowCardinality(String),
        user             LowCardinality(String),
        attr_method      LowCardinality(String),
        has_baseline     UInt8,
        payload          String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (timestamp, Computer, EventID)
    TTL date + INTERVAL 90 DAY
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_results (
        window_start     DateTime64(3, 'UTC'),
        date             Date,
        hour             UInt8,
        user             LowCardinality(String),
        event_count      UInt32,
        risk_score       Float32,
        risk_level       LowCardinality(String),
        threshold        Float32,
        risk_ratio       Float32,
        alert            UInt8,
        signals          String,
        reasons          String,
        scored_at        DateTime DEFAULT now()
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (window_start, user)
    TTL date + INTERVAL 180 DAY
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_features (
        window_start     DateTime64(3, 'UTC'),
        date             Date,
        hour             UInt8,
        user             LowCardinality(String),
        event_count      UInt32,
        features         String,
        eid_counts       String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (user, window_start)
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_items (
        window_start     DateTime64(3, 'UTC'),
        user             LowCardinality(String),
        itype            LowCardinality(String),
        value            String,
        gvalue           String,
        trusted          UInt8,
        is_public        UInt8,
        susp_dir         UInt8,
        sens_port        UInt8,
        interactive      UInt8
    ) ENGINE = MergeTree()
    ORDER BY (user, window_start, itype, value)
    """,
]


class ClickHouseSink:
    def __init__(self, cfg):
        self.cfg = cfg
        self.host = cfg.get("host", "")
        self.db = cfg.get("database", "ubaseline")
        self.mode = cfg.get("mode", "unbaselined")
        self.batch = int(cfg.get("batch_rows", 5000))
        self._client = None
        self._fallback_dir = "./clickhouse_fallback"
        self._lock = threading.Lock()
        if self.host:
            try:
                import clickhouse_connect
                self._client = clickhouse_connect.get_client(
                    host=self.host, port=int(cfg.get("port", 8123)),
                    username=cfg.get("user", "default"), password=cfg.get("password", ""))
                for ddl in DDL:
                    self._client.command(ddl.format(db=self.db))
                log.info("ClickHouse connected: %s/%s", self.host, self.db)
            except Exception as exc:
                log.error("ClickHouse unavailable (%s) - falling back to JSONL at %s",
                          exc, self._fallback_dir)
                self._client = None
        else:
            log.info("ClickHouse not configured - JSONL fallback at %s", self._fallback_dir)
        os.makedirs(self._fallback_dir, exist_ok=True)

    # ------------------------------------------------------------------
    def insert_events(self, rows: list[dict]):
        """rows: normalized+attributed event dicts (with _win, _user, _has_baseline)."""
        if not rows or self.mode == "none":
            return
        payload = [(r["_ts"].strftime("%Y-%m-%d %H:%M:%S.%f"), r["_ts"].date(),
                    r["_win"].strftime("%Y-%m-%d %H:%M:%S"), int(r["EventID"]),
                    str(r.get("Channel", ""))[:64], str(r.get("Computer", ""))[:64],
                    str(r.get("attr_user") or ""), str(r.get("attr_method", ""))[:32],
                    int(bool(r.get("_has_baseline"))),
                    json.dumps(r.get("_raw", {}), default=str))
                   for r in rows]
        if self._client is not None:
            try:
                self._client.insert(f"{self.db}.events", payload,
                                    column_names=["timestamp", "date", "window_start", "EventID",
                                                  "Channel", "Computer", "user", "attr_method",
                                                  "has_baseline", "payload"])
                return
            except Exception as exc:                              # pragma: no cover
                log.error("ClickHouse insert failed (%s) - JSONL fallback this batch", exc)
        self._write_fallback("events.jsonl", payload)

    def insert_result(self, res: dict, event_count: int):
        if self.mode == "none" or self._client is None:
            return
        try:
            self._client.insert(
                f"{self.db}.window_results",
                [(res["window_start"].strftime("%Y-%m-%d %H:%M:%S"), res["window_start"].date(),
                  int(res["hour"]), res["user"], int(event_count),
                  float(res["risk_score"]), res["risk_level"], float(res["threshold"]),
                  float(res["risk_ratio"] or 0.0), int(bool(res["alert"])),
                  json.dumps(res["signals"]), json.dumps(res["reasons"]))],
                column_names=["window_start", "date", "hour", "user", "event_count",
                              "risk_score", "risk_level", "threshold", "risk_ratio",
                              "alert", "signals", "reasons"])
        except Exception as exc:                                  # pragma: no cover
            log.error("ClickHouse result insert failed: %s", exc)

    # ---- feature store for unbaselined users (the auto-trainer reads this) -------
    def insert_features(self, user, win, feats: dict, items):
        """Store one window's extracted features + categorical items."""
        if self.mode == "none":
            return
        items_plain = []
        for r in (items.to_dict("records") if items is not None and len(items) else []):
            items_plain.append({k: bool(v) if isinstance(v, (bool, np.bool_)) else v
                                for k, v in r.items()})
        frow = [win.strftime("%Y-%m-%d %H:%M:%S"), win.date(), int(win.hour), user,
                int(feats.get("event_count", 0)),
                __import__("json").dumps(feats, default=str),
                __import__("json").dumps(feats.get("eid_counts", {}), default=str)]
        irows = [[win.strftime("%Y-%m-%d %H:%M:%S"), user, r.get("itype", ""),
                  str(r.get("value", ""))[:512], str(r.get("gvalue", ""))[:512],
                  int(bool(r.get("trusted"))), int(bool(r.get("is_public"))),
                  int(bool(r.get("susp_dir"))), int(bool(r.get("sens_port"))),
                  int(bool(r.get("interactive")))] for r in items_plain]
        if self._client is not None:
            try:
                self._client.insert(f"{self.db}.window_features", [frow],
                                    column_names=["window_start", "date", "hour", "user",
                                                  "event_count", "features", "eid_counts"])
                if irows:
                    self._client.insert(f"{self.db}.window_items", irows,
                                        column_names=["window_start", "user", "itype", "value",
                                                      "gvalue", "trusted", "is_public",
                                                      "susp_dir", "sens_port", "interactive"])
                return
            except Exception as exc:
                log.error("ClickHouse feature insert failed (%s) - JSONL fallback", exc)
        self._write_fallback("window_features.jsonl", [frow])
        if irows:
            self._write_fallback("window_items.jsonl", irows)

    def query_features(self):
        """All stored windows as a DataFrame with parsed feature dicts.
        Reads ClickHouse when configured, else the JSONL fallback files."""
        try:
            if self._client is not None:
                df = self._client.query_dataframe(
                    f"SELECT window_start, date, hour, user, features FROM {self.db}.window_features")
                df.columns = ["window_start", "date", "hour", "user", "features"]
            else:
                p = os.path.join(self._fallback_dir, "window_features.jsonl")
                if not os.path.exists(p):
                    return None
                rows = []
                with open(p) as fh:
                    for line in fh:
                        r = json.loads(line)
                        rows.append(r)
                df = pd.DataFrame(rows, columns=["window_start", "date", "hour", "user",
                                                 "event_count", "features", "eid_counts"])                        if len(rows[0]) == 7 else                      pd.DataFrame(rows, columns=["window_start", "date", "hour",
                                                 "user", "features"])
            df["feats"] = df.features.map(json.loads)
            df["window_start"] = pd.to_datetime(df.window_start, utc=True)
            df["date"] = df.window_start.dt.strftime("%Y-%m-%d")
            df["hour"] = df.hour.astype(int)
            return df.sort_values("window_start").reset_index(drop=True)
        except Exception:
            log.exception("query_features failed")
            return None

    def query_items(self, user: str):
        try:
            if self._client is not None:
                df = self._client.query_dataframe(
                    f"SELECT window_start, itype, value, gvalue, trusted, is_public, "
                    f"susp_dir, sens_port, interactive FROM {self.db}.window_items "
                    f"WHERE user = '{user}'")
            else:
                p = os.path.join(self._fallback_dir, "window_items.jsonl")
                if not os.path.exists(p):
                    return None
                rows = [json.loads(l) for l in open(p)]
                df = pd.DataFrame(rows, columns=["window_start", "user", "itype", "value",
                                                 "gvalue", "trusted", "is_public",
                                                 "susp_dir", "sens_port", "interactive"])
                df = df[df.user == user].drop(columns=["user"])
            if not len(df):
                return None
            df["window_start"] = pd.to_datetime(df.window_start, utc=True)
            for c in ("trusted", "is_public", "susp_dir", "sens_port", "interactive"):
                df[c] = df[c].astype(bool)
            return df.reset_index(drop=True)
        except Exception:
            log.exception("query_items failed")
            return None

    def _write_fallback(self, name, payload):
        with self._lock:
            with open(os.path.join(self._fallback_dir, name), "a") as fh:
                for row in payload:
                    fh.write(json.dumps(row, default=str) + "\n")
