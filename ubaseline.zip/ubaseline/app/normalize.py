# # Stage 1 - normalize a raw event (Kafka message value / JSONL line) into the flat
# # schema the notebook uses. Handles the shipper-dependent shapes:
# #   * flat top-level keys (winlogbeat-style: EventData already flattened)
# #   * nested {"Event": {"EventData": {...}, "System": {...}}}
# # The 1102 namespaced Subject* fields are folded onto their plain names.

# from __future__ import annotations
# import re
# from typing import Any, Optional

# _NS = "{http://manifests.microsoft.com/win/2004/08/windows/eventlog}"
# _NS_MAP = {_NS + k: k for k in ["SubjectUserName", "SubjectDomainName",
#                                 "SubjectLogonId", "SubjectUserSid"]}

# _KEEP = {
#     "timestamp", "EventID", "Channel", "Computer", "Provider", "EventRecordID",
#     "SubjectUserName", "SubjectDomainName", "SubjectLogonId",
#     "TargetUserName", "TargetDomainName", "TargetLogonId", "TargetSid",
#     "LogonType", "LogonGuid", "LogonProcessName", "AuthenticationPackageName",
#     "WorkstationName", "IpAddress", "IpPort", "Status", "SubStatus", "FailureReason",
#     "ElevatedToken", "PrivilegeList", "SessionId", "PackageName", "Workstation",
#     "NewProcessId", "NewProcessName", "ParentProcessName", "ProcessId", "ProcessName",
#     "CommandLine", "TokenElevationType", "TargetServerName", "ServiceName",
#     "MemberName", "SamAccountName", "ServiceFileName", "ServiceAccount", "TaskName",
#     "ProcessID", "Application", "Direction", "SourceAddress", "SourcePort",
#     "DestAddress", "DestPort", "Protocol",
#     "User", "ProcessGuid", "Image", "IntegrityLevel", "TerminalSessionId", "LogonId",
#     "ParentProcessGuid", "ParentProcessId", "ParentImage", "ParentUser", "OriginalFileName",
#     "Initiated", "SourceIp", "DestinationIp", "DestinationHostname",
#     "DestinationPort", "DestinationPortName", "QueryName", "QueryStatus",
#     "TargetFilename", "EventType", "TargetObject", "ImageLoaded", "Signed", "SignatureStatus",
#     "SourceProcessGuid", "SourceProcessGUID", "SourceProcessId", "SourceImage", "SourceUser",
#     "TargetProcessGuid", "TargetProcessGUID", "TargetProcessId", "TargetImage", "TargetUser",
#     "GrantedAccess", "StartModule", "StartFunction", "UtcTime",
# }

# _JSON_TS = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")


# def _pick_timestamp(e: dict) -> Optional[str]:
#     for k in ("timestamp", "@timestamp", "TimeCreated", "time"):
#         v = e.get(k)
#         if isinstance(v, str) and _JSON_TS.match(v):
#             return v
#     # nested winlogbeat style
#     v = e.get("Event", {}).get("System", {}).get("TimeCreated", {})
#     if isinstance(v, dict):
#         v = v.get("#attributes", {}).get("SystemTime") or v.get("SystemTime")
#     if isinstance(v, str) and _JSON_TS.match(v):
#         return v
#     v = e.get("UtcTime")   # "2026-07-28 18:30:45.868"
#     if isinstance(v, str) and _JSON_TS.match(v):
#         return v.replace(" ", "T") + ("Z" if not v.endswith("Z") else "")
#     return None


# def normalize(raw: dict) -> Optional[dict]:
#     """Return the flat event dict or None if the record carries no usable time/ID."""
#     if not isinstance(raw, dict):
#         return None
#     e: dict[str, Any] = {}

#     src = raw
#     if "Event" in raw and isinstance(raw["Event"], dict):          # nested XML-ish
#         evt = raw["Event"]
#         src = {**evt.get("System", {}), **evt.get("EventData", {}),
#                **evt.get("UserData", {}), **{k: v for k, v in raw.items() if k != "Event"}}
#     elif isinstance(raw.get("EventData"), dict):                   # half-flat shipper
#         src = {**raw, **raw["EventData"]}

#     for k, v in src.items():
#         if k in _NS_MAP:
#             e[_NS_MAP[k]] = v
#         elif k in _KEEP:
#             e[k] = v
#     # fold GUID casing duplicates
#     for alt, canon in (("SourceProcessGUID", "SourceProcessGuid"),
#                        ("TargetProcessGUID", "TargetProcessGuid")):
#         if alt in e:
#             e[canon] = e.pop(alt) if e.get(canon) is None else e[canon]
#             e.pop(alt, None)

#     ts = _pick_timestamp(src) or _pick_timestamp(e)
#     if ts is None or "EventID" not in e:
#         return None
#     e["timestamp"] = ts
#     try:
#         e["EventID"] = int(str(e["EventID"]).strip())
#     except (TypeError, ValueError):
#         return None
#     return e
# Stage 1 - normalize a raw event (Kafka message value / JSONL line) into the flat
# schema the notebook uses. Handles the shipper-dependent shapes:
#   * flat top-level keys (winlogbeat-style: EventData already flattened)
#   * nested {"Event": {"EventData": {...}, "System": {...}}}
# The 1102 namespaced Subject* fields are folded onto their plain names.

from __future__ import annotations
import re
from typing import Any, Optional
from .ecs_flatten import flatten_ecs

_NS = "{http://manifests.microsoft.com/win/2004/08/windows/eventlog}"
_NS_MAP = {_NS + k: k for k in ["SubjectUserName", "SubjectDomainName",
                                "SubjectLogonId", "SubjectUserSid"]}

_KEEP = {
    "timestamp", "EventID", "Channel", "Computer", "Provider", "EventRecordID",
    "SubjectUserName", "SubjectDomainName", "SubjectLogonId",
    "TargetUserName", "TargetDomainName", "TargetLogonId", "TargetSid",
    "LogonType", "LogonGuid", "LogonProcessName", "AuthenticationPackageName",
    "WorkstationName", "IpAddress", "IpPort", "Status", "SubStatus", "FailureReason",
    "ElevatedToken", "PrivilegeList", "SessionId", "PackageName", "Workstation",
    "NewProcessId", "NewProcessName", "ParentProcessName", "ProcessId", "ProcessName",
    "CommandLine", "TokenElevationType", "TargetServerName", "ServiceName",
    "MemberName", "SamAccountName", "ServiceFileName", "ServiceAccount", "TaskName",
    "ProcessID", "Application", "Direction", "SourceAddress", "SourcePort",
    "DestAddress", "DestPort", "Protocol",
    "User", "ProcessGuid", "Image", "IntegrityLevel", "TerminalSessionId", "LogonId",
    "ParentProcessGuid", "ParentProcessId", "ParentImage", "ParentUser", "OriginalFileName",
    "Initiated", "SourceIp", "DestinationIp", "DestinationHostname",
    "DestinationPort", "DestinationPortName", "QueryName", "QueryStatus",
    "TargetFilename", "EventType", "TargetObject", "ImageLoaded", "Signed", "SignatureStatus",
    "SourceProcessGuid", "SourceProcessGUID", "SourceProcessId", "SourceImage", "SourceUser",
    "TargetProcessGuid", "TargetProcessGUID", "TargetProcessId", "TargetImage", "TargetUser",
    "GrantedAccess", "StartModule", "StartFunction", "UtcTime",
}

_JSON_TS = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")


def _pick_timestamp(e: dict) -> Optional[str]:
    for k in ("timestamp", "@timestamp", "TimeCreated", "time"):
        v = e.get(k)
        if isinstance(v, str) and _JSON_TS.match(v):
            return v
    # nested winlogbeat style
    v = e.get("Event", {}).get("System", {}).get("TimeCreated", {})
    if isinstance(v, dict):
        v = v.get("#attributes", {}).get("SystemTime") or v.get("SystemTime")
    if isinstance(v, str) and _JSON_TS.match(v):
        return v
    v = e.get("UtcTime")   # "2026-07-28 18:30:45.868"
    if isinstance(v, str) and _JSON_TS.match(v):
        return v.replace(" ", "T") + ("Z" if not v.endswith("Z") else "")
    return None


def normalize(raw: dict, allowed_eids=None) -> Optional[dict]:
    """allowed_eids: optional set/None. None (default) accepts every Event ID;
    a set drops non-member Event IDs at ingest (cheapest possible point)."""
    """Return the flat event dict or None if the record carries no usable time/ID."""
    if not isinstance(raw, dict):
        return None
    e: dict[str, Any] = {}
    raw = flatten_ecs(raw)

    src = raw
    if "Event" in raw and isinstance(raw["Event"], dict):          # nested XML-ish
        evt = raw["Event"]
        src = {**evt.get("System", {}), **evt.get("EventData", {}),
               **evt.get("UserData", {}), **{k: v for k, v in raw.items() if k != "Event"}}
    elif isinstance(raw.get("EventData"), dict):                   # half-flat shipper
        src = {**raw, **raw["EventData"]}

    for k, v in src.items():
        if k in _NS_MAP:
            e[_NS_MAP[k]] = v
        elif k in _KEEP:
            e[k] = v
    # fold GUID casing duplicates
    for alt, canon in (("SourceProcessGUID", "SourceProcessGuid"),
                       ("TargetProcessGUID", "TargetProcessGuid")):
        if alt in e:
            e[canon] = e.pop(alt) if e.get(canon) is None else e[canon]
            e.pop(alt, None)

    ts = _pick_timestamp(src) or _pick_timestamp(e)
    if ts is None or "EventID" not in e:
        return None
    e["timestamp"] = ts
    try:
        e["EventID"] = int(str(e["EventID"]).strip())
    except (TypeError, ValueError):
        return None
    if allowed_eids is not None and e["EventID"] not in allowed_eids:
        return None                      # Event-ID whitelist: dropped at ingest
    return e

