"""
ecs_flatten.py - adapter for consuming an EXISTING Windows-log Kafka topic.

Why this exists: your project's `normalize.py` expects the FLAT record shape
(EventID / Channel / Computer / Provider / EventRecordID / Execution_* plus every
event-data field at TOP LEVEL). That shape was produced on the *shipping* side by the
javascript processor in `winlogbeat/winlogbeat.yml`. When someone else's shipper writes
to the topic, you cannot change their shipper - so you flatten on the read side instead.
This is a line-for-line port of that JS processor.

Drop this file next to normalize.py and call it as the FIRST thing that touches a record:

    from app.ecs_flatten import flatten_ecs
    ...
    ev = flatten_ecs(ev)          # before _KEEP / allowed_event_ids / _pick_timestamp

It is a no-op for records that are already flat, so it is safe to leave in place even if
some producers send your old shape and others send ECS.
"""
from __future__ import annotations

from typing import Any, MutableMapping

# winlog.* -> the flat names normalize.py keeps (same mapping as the JS processor)
_FLAT_FROM_WINLOG = {
    "event_id": "EventID",
    "channel": "Channel",
    "computer_name": "Computer",
    "provider_name": "Provider",
    "provider_guid": "ProviderGuid",
    "record_id": "EventRecordID",
    "opcode": "Opcode",
    "task": "Task",
    "keywords": "Keywords",
    "level": "Level",
}

# candidate timestamp fields, in the order the model should trust them
_TS_CANDIDATES = ("@timestamp", "event.created", "winlog.event_data.SystemTime",
                  "TimeCreated", "event.end", "timestamp")

_SENTINEL = object()


def _dig(rec: MutableMapping[str, Any], path: str) -> Any:
    """rec['winlog']['event_data'] style lookup; returns _SENTINEL when absent."""
    cur: Any = rec
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return _SENTINEL
    return cur


def _put(out: MutableMapping[str, Any], key: str, val: Any) -> None:
    # never overwrite a value the record already carries at top level
    if val is None or val is _SENTINEL or key in out:
        return
    if isinstance(val, (dict, list)):          # Keywords/EventData can arrive structured
        val = val if not isinstance(val, dict) else ", ".join(map(str, val.values()))
        if isinstance(val, list):
            val = ", ".join(map(str, val))
    out[key] = val


def flatten_ecs(rec: dict) -> dict:
    """Return a record with the fields normalize.py expects, copied up from ECS.

    Handles: Beats/Winlogbeat ECS (nested winlog.*), and the same shape after a
    JSON-stringified `event.original` XML envelope is left for the XML path
    (see NOTES.md at the bottom of this file's docstring block).
    """
    if not isinstance(rec, dict) or _dig(rec, "winlog") is _SENTINEL:
        return rec                                   # already flat (or foreign) -> untouched

    out: dict = dict(rec)

    for src, dst in _FLAT_FROM_WINLOG.items():
        _put(out, dst, _dig(out, f"winlog.{src}"))

    # Computer: beats prefers host.name (FQDN when set), like the JS processor did
    host = _dig(out, "host.name")
    if host is not _SENTINEL:
        out["Computer"] = host

    # process / thread ids
    _put(out, "Execution_ProcessID", _dig(out, "winlog.process.pid"))
    tid = _dig(out, "winlog.process.thread.id")
    if tid is _SENTINEL:
        tid = _dig(out, "winlog.thread_id")
    _put(out, "Execution_ThreadID", tid)

    # the key step: event_data -> TOP LEVEL (TargetUserName, SourceImage, LogonType, ...)
    data = _dig(out, "winlog.event_data")
    if isinstance(data, dict):
        for k, v in data.items():
            _put(out, k, v)
    # some shippers use winlog.event_data with a nested "Data" array of {Name,Value}
    arr = _dig(out, "winlog.event_data.Data")
    if isinstance(arr, list):
        for item in arr:
            if isinstance(item, dict) and "Name" in item:
                _put(out, str(item["Name"]), item.get("Value"))

    # timestamps
    for path in _TS_CANDIDATES:
        val = _dig(out, path)
        if val is not _SENTINEL and val:
            _put(out, "timestamp", val)
            _put(out, "TimeCreated_raw", val)
            break

    _put(out, "timestamp_parse_ok", True)
    _put(out, "source_file", "kafka")
    return out


# --------------------------------------------------------------------------- NOTES
# If a probe shows the payload is a *string* of Windows Event XML (common with nxlog /
# CLEF / some SIEM forwarders), this adapter will not help - that needs ElementTree on
# `System/TimeCreated@SystemTime`, `System/EventID`, `System/Security/@UserID`, and
# `EventData/Data/@Name`. Capture two raw messages first (EXTERNAL-KAFKA.md §2) before
# writing anything: the shape decides the code, not the other way round.
