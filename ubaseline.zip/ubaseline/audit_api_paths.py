#!/usr/bin/env python3
"""Find (and optionally rewrite) every reference to a bare API route path.

You are moving the REST endpoints from  /health  to  /api/health  etc. Editing
app/api.py alone leaves every CALLER broken, and the callers are scattered over
html, cmd, nginx conf, compose files and docs. This scans a tree and lists each
reference; --fix rewrites everything EXCEPT python files (your api.py is yours
to edit deliberately, not by regex).

    python audit_api_paths.py .              report only; exit 1 if refs remain
    python audit_api_paths.py . --fix        rewrite the safe file types
    python audit_api_paths.py . --routes health metrics alerts --fix
    python audit_api_paths.py . --prefix-ws  also move /ws to /api/ws

After --fix, run it again: "0 references" is your completion criterion.
"""
from __future__ import annotations
import argparse
import re
import sys
from pathlib import Path

ROUTES = ["health", "metrics", "alerts", "results", "baselines", "score", "debug/inject"]
SUFFIXES = {".html", ".htm", ".js", ".cmd", ".bat", ".ps1", ".sh", ".conf",
            ".yml", ".yaml", ".md", ".txt", ".json"}
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", "dist",
             "build", ".pytest_cache", "certs", "frontend_dashboard"}
PY_SUFFIXES = {".py"}

# "/alerts"  |  '/health'  |  /alerts?limit=  |  `/ws`  ->  leading slash + route
HIT = re.compile(r"""(?<![\w/.-])(?<!api)/(?P<route>health|metrics|alerts|results|baselines|score|debug/inject|ws)(?![\w-])""")
# nginx: location ~ ^/(health|metrics|...)
NGINX_ALT = re.compile(r"\^/\((?P<alts>health\|)")
FIXED_NGINX_ALT = re.compile(r"(\^)/\((health\|metrics\|alerts\|results\|baselines\|score\|debug/inject)")
FIXED_BARE = re.compile(r"""(?<![\w/.-])(?<!api)/(?P<route>health|metrics|alerts|results|baselines|score|debug/inject)(?![\w-])""")


def scan(root: Path, routes: list[str], want_ws: bool):
    pat = re.compile(r"""(?<![\w/.-])(?<!api)/(?P<route>""" + "|".join(re.escape(r) for r in routes) + r""")(?![\w-])""")
    hits = []
    here = Path(__file__).resolve()
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix not in SUFFIXES | PY_SUFFIXES:
            continue
        if SKIP_DIRS & set(p.parts) or p.resolve() == here or p.name.startswith("audit_api_paths"):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for n, line in enumerate(text.splitlines(), 1):
            for m in pat.finditer(line):
                if m.group("route") == "ws" and not want_ws:
                    continue
                if p.suffix not in PY_SUFFIXES:
                    kind = "caller"
                else:
                    stripped = line.lstrip()
                    kind = "py-ROUTE-DEF" if stripped.startswith(
                        ("@app.", "@router.", "@api.", "app = FastAPI")) else "py-other"
                hits.append((p, n, m.group("route"), kind, line.strip()[:120]))
    return hits


def fix(root: Path, routes: list[str], want_ws: bool):
    bare = re.compile(r"""(?<![\w/.-])(?<!api)/(?P<route>""" + "|".join(re.escape(r) for r in routes)
                      + (r"|ws" if want_ws else "") + r""")(?![\w-])""")
    alt = re.compile(r"(\^/)\((?:" + "|".join(re.escape(r) for r in routes) + r")(?:\|" + "|".join(re.escape(r) for r in routes) + r")*\)")
    changed = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix not in SUFFIXES or p.suffix in PY_SUFFIXES:
            continue
        if SKIP_DIRS & set(p.parts) or p.resolve() == Path(__file__).resolve() or p.name.startswith("audit_api_paths"):
            continue
        try:
            orig = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        new = bare.sub(lambda m: "/api/" + m.group("route"), orig)
        # nginx regex form: ^/(health|metrics|alerts|...)(/|$)  ->  ^/api/(health|...)
        def _alt(m):
            inner = m.group(0)[3:-1].split("|")
            keep = [r for r in inner if r in routes]
            return "^/api/(" + "|".join(keep) + ")"
        new = re.sub(r"\^/\((?:" + "|".join(re.escape(r) for r in routes) + r")(?:\|(?:\w+|/|\.)*)*\)", _alt, new)
        if new != orig:
            p.write_text(new, encoding="utf-8", newline="\n")
            changed.append(p)
    return changed


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--routes", nargs="*", default=ROUTES)
    ap.add_argument("--prefix-ws", action="store_true", help="treat /ws as a route to move too")
    ap.add_argument("--fix", action="store_true", help="rewrite non-python files")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    routes = [r.lstrip("/") for r in a.routes]

    if a.fix:
        ch = fix(root, routes, a.prefix_ws)
        print(f"--fix: rewrote {len(ch)} file(s)")
        for p in ch:
            print("   ", p.relative_to(root))
        print("\nnow re-run without --fix to confirm 0 references remain\n")

    hits = scan(root, routes, a.prefix_ws)
    by_file = {}
    for p, n, route, kind, line in hits:
        by_file.setdefault((str(p.relative_to(root)), kind), []).append((n, route, line))
    if not hits:
        print(f"CLEAN: no bare /{'|/'.join(routes)} references left in {root}")
        return 0
    print(f"{len(hits)} reference(s) still bare, in {len(by_file)} file(s):\n")
    for (f, kind), rows in by_file.items():
        tag = "  <- EDIT THIS FILE BY HAND (route definitions)" if kind == "py-ROUTE-DEF" else (
            "  (python, not auto-fixed)" if kind == "py-other" else "  (auto-fixable)")
        print(f"{f}{tag}")
        for n, route, line in rows:
            print(f"    {n:5d}  /{route:<13} {line}")
    print("\npython files are never rewritten: change the @app.get/@app.post decorators in")
    print("app/api.py yourself, then run:  python audit_api_paths.py .   -> must say CLEAN")
    return 1


if __name__ == "__main__":
    sys.exit(main())
