@echo off
REM =====================================================================
REM  ubaseline - endpoint status sweep
REM  Run while the stack is up (from cmd):
REM      check_endpoints.cmd
REM  ...or from PowerShell:   .\check_endpoints.cmd
REM  Optional: pass a different base URL as arg 1, e.g.:
REM      check_endpoints.cmd http://192.168.1.50:8080
REM  Prints HTTP code + response time for every known route.
REM =====================================================================
setlocal
set "BASE=http://localhost:8080"
if not "%~1"=="" set "BASE=%~1"

echo.
echo === ubaseline endpoint sweep  %BASE% ===
echo.
call :check "GET  /"                 "%BASE%/"
call :check "GET  /docs"             "%BASE%/docs"
call :check "GET  /openapi.json"     "%BASE%/openapi.json"
call :check "GET  /api/health"           "%BASE%/api/health"
call :check "GET  /api/metrics"          "%BASE%/api/metrics"
call :check "GET  /api/alerts"           "%BASE%/api/alerts"
call :check "GET  /api/alerts?limit=5"   "%BASE%/api/alerts?limit=5"
call :check "GET  /api/results"          "%BASE%/api/results"
call :check "GET  /api/results?limit=5"  "%BASE%/api/results?limit=5"
call :check "GET  /api/baselines"        "%BASE%/api/baselines"
echo.
echo Legend:
echo   200  OK        endpoint is alive
echo   404  NOT FOUND route does not exist (check /docs for the real paths)
echo   422  VALIDATION route exists but wants query params (see /docs)
echo   500  ERROR     route exists but the handler failed (check: docker compose logs api)
echo   000  REFUSED   nothing listening - is the stack up?  docker compose ps
echo.
endlocal
goto :eof

:check
setlocal
set "URL=%~2"
curl.exe -s -o NUL -w "%~1  ->  HTTP %%{http_code}   (%%{time_total}s)" "%URL%"
echo.
endlocal
goto :eof
