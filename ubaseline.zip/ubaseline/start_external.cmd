@echo off
rem ==========================================================================
rem start_external.cmd - render .env, then run the model against the shared
rem Kafka. Safe to re-run: it only touches containers, never volumes.
rem ==========================================================================
setlocal
cd /d "%~dp0"

if not exist .env (
  echo.
  echo  No .env here. Run this once, then fill the 3 values in block 1:
  echo     copy .env.external .env ^&^& notepad .env
  exit /b 1
)

if not exist config.template.yaml (
  if exist config_template.yaml (
    echo  Fixing the underscore filename for you...
    ren config_template.yaml config.template.yaml
  ) else (
    echo  MISSING config.template.yaml - copy it into this folder.
    exit /b 1
  )
)

if exist config.runtime.yaml dir /a config.runtime.yaml | findstr /c:"<DIR>" >nul 2>&1
if not errorlevel 1 (
  echo  config.runtime.yaml is an empty DIRECTORY left behind by Docker, not the
  echo  rendered file. Removing it, then rendering fresh.
  rmdir config.runtime.yaml
)

echo.
echo [1/4] rendering config from .env
python render_config.py
if errorlevel 1 (
  echo.
  echo  Fix .env, then run me again.
  exit /b 1
)

echo.
echo [2/4] stopping the old stack (containers only - all data volumes stay)
docker compose -f docker-compose.yml -f kafka-public-listener.yml down >nul 2>&1

echo [3/4] starting clickhouse + api
docker compose -f docker-compose.external.yml up -d
if errorlevel 1 (
  echo.
  echo  Compose refused to start. Re-read the error above; the two usual ones are
  echo  "not a directory" (a missing config.runtime.yaml - this script should have
  echo  fixed it) and a bad CLICKHOUSE_USERS_XML name in .env.
  exit /b 1
)

echo.
echo [4/4] state
docker compose -f docker-compose.external.yml ps
docker compose -f docker-compose.external.yml exec api ls -l /app/config.yaml

echo.
echo  Watch the consumer:  docker compose -f docker-compose.external.yml logs -f api
echo  You want: subscribed to the topic, then "consumed N messages".
echo  Rows: docker compose -f docker-compose.external.yml exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT count() FROM ubaseline.events"
endlocal
