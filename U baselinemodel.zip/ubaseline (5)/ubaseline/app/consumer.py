# # The main service: Kafka -> normalize -> attribute -> 10-min windows ->
# # per-user features -> baseline scoring (or ClickHouse hold). Run with a real
# # broker or in --mock mode against a JSONL file (same format as events.jsonl).

# from __future__ import annotations
# import json
# import logging
# import os
# import signal
# import sys
# import time
# from collections import defaultdict

# import pandas as pd

# from .config import Config
# from .normalize import normalize
# from .attribution import Attributor
# from .windower import Windower
# from .features import prepare, build_features, build_items
# from .baseline_store import BaselineStore
# from .scoring import score_window
# from .clickhouse_sink import ClickHouseSink

# logging.basicConfig(level=logging.INFO,
#                     format="%(asctime)s %(name)-22s %(levelname)-7s %(message)s")
# log = logging.getLogger("ubaseline.consumer")


# class Pipeline:
#     """Everything between raw events and results. Transport-independent."""

#     def __init__(self, cfg: Config):
#         self.cfg = cfg
#         self.ch = ClickHouseSink(cfg.ch)
#         backend = cfg.raw.get("baseline", {}).get("backend", "files")
#         if backend == "clickhouse" and self.ch._client is not None:
#             from .baseline_ch import CHBaselineStore
#             self.store = CHBaselineStore(cfg, self.ch)      # baselines live in ClickHouse
#         else:
#             if backend == "clickhouse":
#                 log.warning("baseline.backend=clickhouse but no ClickHouse - using files")
#             self.store = BaselineStore(cfg)
#         self.attributor = Attributor(cfg)
#         self.windower = Windower(cfg.window_minutes, cfg.grace_seconds)
#         from .trainer import Trainer
#         self.trainer = Trainer(cfg, self.store, self.ch)
#         self.results: list[dict] = []          # ring for the API (last N)
#         self.counters = defaultdict(int)

#     def _excluded_user(self, user: str) -> bool:
#         """Machine/stale accounts configured in training.exclude_* are never held,
#         never trained, never stored - just counted and dropped."""
#         t = self.cfg.raw.get("training", {})
#         prefixes = tuple(t.get("exclude_prefixes", ["svc-", "svc_"]))
#         names = set(t.get("exclude_names", []))
#         u = str(user).lower()
#         return u in names or u.startswith(prefixes)

#     # ---- ingest one raw record -------------------------------------------------
#     def feed(self, raw: dict):
#         ev = normalize(raw)
#         if ev is None:
#             self.counters["records_dropped"] += 1
#             return
#         try:
#             ts = pd.Timestamp(ev["timestamp"])
#             if ts.tzinfo is None:
#                 ts = ts.tz_localize("UTC")
#             else:
#                 ts = ts.tz_convert("UTC")
#         except (ValueError, TypeError):
#             self.counters["records_dropped"] += 1
#             return
#         ev["_ts"] = ts
#         ev["_raw"] = {k: v for k, v in raw.items() if isinstance(v, (str, int, float, bool))}
#         self.attributor.observe_and_attribute(ev)
#         self.counters["events_in"] += 1
#         self.windower.add(ev)

#     # ---- seal + process windows --------------------------------------------------
#     def process_ready(self, flush: bool = False) -> list[dict]:
#         sealed = self.windower.flush_all() if flush else self.windower.seal_ready()
#         out = []
#         for win, events in sealed:
#             out.extend(self._process_window(win, events))
#         self.ch.flush_results()          # batched write of this round's results
#         return out

#     def _process_window(self, win: pd.Timestamp, events: list[dict]) -> list[dict]:
#         hour = win.hour
#         by_user = defaultdict(list)
#         for ev in events:
#             u = ev.get("attr_user")
#             if u and self.attributor.is_person_like(u):
#                 by_user[u].append(ev)
#         results = []

#         # users WITHOUT a baseline -> extract + store their features (trainer source)
#         for user, evs in sorted(by_user.items()):
#             if self.store.has_baseline(user):
#                 continue
#             if self._excluded_user(user):
#                 self.counters["excluded_user_events"] = \
#                     self.counters.get("excluded_user_events", 0) + len(evs)
#                 continue
#             try:
#                 e = prepare(pd.DataFrame(evs))
#                 feats = build_features(e)
#                 feats["eid_counts"] = {int(k): int(v) for k, v in
#                                        pd.Series([x["EventID"] for x in evs]).value_counts().items()}
#                 items = build_items(e)
#                 self.ch.insert_features(user, win, feats, items)
#                 self.counters["features_stored"] = self.counters.get("features_stored", 0) + 1
#                 log.info("held %s %s -> features stored (no baseline yet; accumulating for auto-trainer)",
#                          user, win)
#             except Exception:
#                 log.exception("feature extraction failed user=%s win=%s", user, win)

#         # users WITH baseline -> score
#         for user, evs in sorted(by_user.items()):
#             if not self.store.has_baseline(user):
#                 continue
#             df = pd.DataFrame(evs)
#             e = prepare(df)
#             feats = build_features(e)
#             if feats["event_count"] < int(self.cfg.raw.get("scoring", {}).get("min_events_to_score", 1)):
#                 continue
#             items = build_items(e)
#             eid_counts = {int(k): int(v) for k, v in df.EventID.value_counts().items()}
#             try:
#                 res = score_window(self.store, user, hour, feats, items, eid_counts)
#             except Exception:
#                 log.exception("scoring failed user=%s win=%s", user, win)
#                 continue
#             if res is None:
#                 continue
#             res["window_start"] = win.isoformat()
#             res["window"] = f"{win:%H:%M}-{(win + pd.Timedelta(self.cfg.window_minutes, 'm')):%H:%M}"
#             res["date"] = win.strftime("%Y-%m-%d")
#             res["event_count"] = int(feats["event_count"])
#             self._emit_result(res)
#             results.append(res)
#             if self.ch._client is not None:
#                 self.ch.insert_result(res, res["event_count"])

#         # events WITHOUT a baseline user (or unattributed) -> ClickHouse hold
#         if self.ch.mode == "all":
#             held = events
#         else:
#             held = [ev for ev in events
#                     if not (ev.get("attr_user")
#                             and self.attributor.is_person_like(ev["attr_user"])
#                             and (self.store.has_baseline(ev["attr_user"])
#                                  or self._excluded_user(ev["attr_user"])))]
#         for ev in held:
#             ev["_win"] = win
#             ev["_user"] = ev.get("attr_user")
#             ev["_has_baseline"] = self.store.has_baseline(ev.get("attr_user") or "")
#         if held:
#             self.ch.insert_events(held)
#             self.counters["events_held_clickhouse"] += len(held)

#         self.counters["windows_processed"] += 1
#         return results

#     def _emit_result(self, res: dict):
#         self.results.append(res)
#         if len(self.results) > 5000:
#             self.results = self.results[-5000:]
#         if res["alert"]:
#             self.counters["alerts"] += 1
#             log.warning("ALERT %s %s %s risk=%.3f ratio=%s :: %s",
#                         res["user"], res["window_start"], res["risk_level"],
#                         res["risk_score"], res["risk_ratio"],
#                         res["reasons"][0]["text"] if res["reasons"] else "")
#         else:
#             log.info("scored %s %s risk=%.3f (%s)", res["user"],
#                      res["window_start"], res["risk_score"], res["risk_level"])

#     # ---- kafka -------------------------------------------------------------------
#     def run_kafka(self):
#         from confluent_kafka import Consumer
#         conf = {"bootstrap.servers": self.cfg.kafka_brokers,
#                 "group.id": self.cfg.kafka_group,
#                 "enable.auto.commit": True, "auto.offset.reset": "latest"}
#         consumer = Consumer(conf)
#         consumer.subscribe(self.cfg.kafka_topics)
#         log.info("consuming %s from %s", self.cfg.kafka_topics, self.cfg.kafka_brokers)
#         stop = {"run": True}

#         def _stop(*_):
#             stop["run"] = False
#         import threading as _th
#         if _th.current_thread() is _th.main_thread():
#             signal.signal(signal.SIGINT, _stop)     # only legal in the main thread
#             signal.signal(signal.SIGTERM, _stop)

#         producer = None
#         if self.cfg.results_topic:
#             from confluent_kafka import Producer
#             producer = Producer({"bootstrap.servers": self.cfg.kafka_brokers})

#         try:
#             while stop["run"]:
#                 msgs = consumer.consume(num_messages=2000, timeout=1.0)
#                 batch = []
#                 for m in msgs:
#                     if m.error():
#                         continue
#                     try:
#                         batch.append(json.loads(m.value()))
#                     except json.JSONDecodeError:
#                         self.counters["records_dropped"] += 1
#                 # event-time order inside the poll batch keeps the process table sane
#                 batch.sort(key=lambda e: str(e.get("timestamp") or e.get("@timestamp") or ""))
#                 for raw in batch:
#                     self.feed(raw)
#                 results = self.process_ready()
#                 if producer:
#                     for r in results:
#                         producer.produce(self.cfg.results_topic,
#                                          key=f"{r['user']}|{r['window_start']}".encode(),
#                                          value=json.dumps(r, default=str).encode())
#                     producer.poll(0)
#                 self.store.maybe_reload()
#                 self.trainer.maybe_train()
#         finally:
#             consumer.close()
#             self.process_ready(flush=True)
#             log.info("stopped: %s", dict(self.counters))

#     # ---- mock --------------------------------------------------------------------
#     def run_mock(self, path: str):
#         log.info("MOCK mode: reading %s", path)
#         with open(path) as fh:
#             lines = [ln for ln in (l.strip() for l in fh) if ln]
#         events = []
#         for ln in lines:
#             try:
#                 events.append(json.loads(ln))
#             except json.JSONDecodeError:
#                 self.counters["records_dropped"] += 1
#         events.sort(key=lambda e: str(e.get("timestamp") or ""))
#         log.info("loaded %d events, %s -> %s", len(events),
#                  events[0].get("timestamp"), events[-1].get("timestamp"))
#         for raw in events:
#             self.feed(raw)
#         results = self.process_ready(flush=True)
#         out = f"mock_results_{int(time.time())}.jsonl"
#         with open(out, "w") as fh:
#             for r in results:
#                 fh.write(json.dumps(r, default=str) + "\n")
#         log.info("MOCK done: %d windows scored, %d alerts, results -> %s | counters=%s",
#                  len(results), self.counters["alerts"], out, dict(self.counters))


# def main():
#     cfg = Config.load(os.environ.get("UBASELINE_CONFIG", "config.yaml"))
#     pipe = Pipeline(cfg)
#     if "--mock" in sys.argv:
#         idx = sys.argv.index("--mock")
#         path = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else "events.jsonl"
#         pipe.run_mock(path)
#     else:
#         if not cfg.kafka_brokers:
#             log.error("kafka.bootstrap_servers empty - use --mock <file> or configure Kafka")
#             sys.exit(1)
#         pipe.run_kafka()


# if __name__ == "__main__":
#     main()
# The main service: Kafka -> normalize -> attribute -> 10-min windows ->
# per-user features -> baseline scoring (or ClickHouse hold). Run with a real
# broker or in --mock mode against a JSONL file (same format as events.jsonl).

from __future__ import annotations
import json
import logging
import os
import signal
import sys
import time
from collections import defaultdict

import pandas as pd

from .config import Config
from .normalize import normalize
from .attribution import Attributor
from .windower import Windower
from .features import prepare, build_features, build_items
from .baseline_store import BaselineStore
from .scoring import score_window
from .clickhouse_sink import ClickHouseSink

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(name)-22s %(levelname)-7s %(message)s")
log = logging.getLogger("ubaseline.consumer")


class Pipeline:
    """Everything between raw events and results. Transport-independent."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.ch = ClickHouseSink(cfg.ch)
        backend = cfg.raw.get("baseline", {}).get("backend", "files")
        if backend == "clickhouse" and self.ch._client is not None:
            from .baseline_ch import CHBaselineStore
            self.store = CHBaselineStore(cfg, self.ch)      # baselines live in ClickHouse
        else:
            if backend == "clickhouse":
                log.warning("baseline.backend=clickhouse but no ClickHouse - using files")
            self.store = BaselineStore(cfg)
        self.attributor = Attributor(cfg)
        self.windower = Windower(cfg.window_minutes, cfg.grace_seconds)
        self._sealed_windows = set()
        from .trainer import Trainer
        self.trainer = Trainer(cfg, self.store, self.ch)
        self.results: list[dict] = []          # ring for the API (last N)
        self.counters = defaultdict(int)

    @property
    def allowed_eids(self):
        """Set of accepted Event IDs from config (ingest.allowed_event_ids).
        Empty/missing = accept everything."""
        ids = self.cfg.raw.get("ingest", {}).get("allowed_event_ids", [])
        return set(int(i) for i in ids) if ids else None

    def _excluded_user(self, user: str) -> bool:
        """Machine/stale accounts configured in training.exclude_* are never held,
        never trained, never stored - just counted and dropped."""
        t = self.cfg.raw.get("training", {})
        prefixes = tuple(t.get("exclude_prefixes", ["svc-", "svc_"]))
        names = set(t.get("exclude_names", []))
        u = str(user).lower()
        return u in names or u.startswith(prefixes)

    # ---- ingest one raw record -------------------------------------------------
    def feed(self, raw: dict):
        ev = normalize(raw, allowed_eids=self.allowed_eids)
        if ev is None:
            self.counters["records_dropped"] += 1
            self.counters["dropped_non_whitelisted_eid"] = \
                self.counters.get("dropped_non_whitelisted_eid", 0) + 1
            return
        try:
            ts = pd.Timestamp(ev["timestamp"])
            if ts.tzinfo is None:
                ts = ts.tz_localize("Asia/Kolkata")
            else:
                ts = ts.tz_convert("Asia/Kolkata")
        except (ValueError, TypeError):
            self.counters["records_dropped"] += 1
            return
        ev["_ts"] = ts
        if ts.floor(self.windower.freq) in self._sealed_windows:
            self.counters["late_events_after_seal"] += 1
            return


        ev["_raw"] = {k: v for k, v in raw.items() if isinstance(v, (str, int, float, bool))}
        self.attributor.observe_and_attribute(ev)
        self.counters["events_in"] += 1
        self.windower.add(ev)

    # ---- seal + process windows --------------------------------------------------
    def process_ready(self, flush: bool = False) -> list[dict]:
        sealed = self.windower.flush_all() if flush else self.windower.seal_ready()
        out = []
        for win, events in sealed:
            self._sealed_windows.add(win)
            out.extend(self._process_window(win, events))
        self.ch.flush_results()          # batched write of this round's results
        return out

    def _process_window(self, win: pd.Timestamp, events: list[dict]) -> list[dict]:
        hour = win.hour
        by_user = defaultdict(list)
        for ev in events:
            u = ev.get("attr_user")
            if u and self.attributor.is_person_like(u):
                by_user[u].append(ev)
        results = []

        # users WITHOUT a baseline -> extract + store their features (trainer source)
        for user, evs in sorted(by_user.items()):
            if self.store.has_baseline(user):
                continue
            if self._excluded_user(user):
                self.counters["excluded_user_events"] = \
                    self.counters.get("excluded_user_events", 0) + len(evs)
                continue
            try:
                e = prepare(pd.DataFrame(evs))
                feats = build_features(e)
                feats["eid_counts"] = {int(k): int(v) for k, v in
                                       pd.Series([x["EventID"] for x in evs]).value_counts().items()}
                items = build_items(e)
                self.ch.insert_features(user, win, feats, items)
                self.counters["features_stored"] = self.counters.get("features_stored", 0) + 1
                log.info("held %s %s -> features stored (no baseline yet; accumulating for auto-trainer)",
                         user, win)
            except Exception:
                log.exception("feature extraction failed user=%s win=%s", user, win)

        # users WITH baseline -> score
        for user, evs in sorted(by_user.items()):
            if not self.store.has_baseline(user):
                continue
            df = pd.DataFrame(evs)
            e = prepare(df)
            feats = build_features(e)
            if feats["event_count"] < int(self.cfg.raw.get("scoring", {}).get("min_events_to_score", 1)):
                continue
            items = build_items(e)
            eid_counts = {int(k): int(v) for k, v in df.EventID.value_counts().items()}
            try:
                res = score_window(self.store, user, hour, feats, items, eid_counts)
            except Exception:
                log.exception("scoring failed user=%s win=%s", user, win)
                continue
            if res is None:
                continue
            res["window_start"] = win.isoformat()
            res["window"] = f"{win:%H:%M}-{(win + pd.Timedelta(self.cfg.window_minutes, 'm')):%H:%M}"
            res["date"] = win.strftime("%Y-%m-%d")
            res["event_count"] = int(feats["event_count"])
            self._emit_result(res)
            results.append(res)
            if self.ch._client is not None:
                self.ch.insert_result(res, res["event_count"])

        # events WITHOUT a baseline user (or unattributed) -> ClickHouse hold
        if self.ch.mode == "all":
            held = events
        else:
            held = [ev for ev in events
                    if not (ev.get("attr_user")
                            and self.attributor.is_person_like(ev["attr_user"])
                            and (self.store.has_baseline(ev["attr_user"])
                                 or self._excluded_user(ev["attr_user"])))]
        for ev in held:
            ev["_win"] = win
            ev["_user"] = ev.get("attr_user")
            ev["_has_baseline"] = self.store.has_baseline(ev.get("attr_user") or "")
        if held:
            self.ch.insert_events(held)
            self.counters["events_held_clickhouse"] += len(held)

        self.counters["windows_processed"] += 1
        return results

    def _emit_result(self, res: dict):
        self.results.append(res)
        if len(self.results) > 5000:
            self.results = self.results[-5000:]
        if res["alert"]:
            self.counters["alerts"] += 1
            log.warning("ALERT %s %s %s risk=%.3f ratio=%s :: %s",
                        res["user"], res["window_start"], res["risk_level"],
                        res["risk_score"], res["risk_ratio"],
                        res["reasons"][0]["text"] if res["reasons"] else "")
        else:
            log.info("scored %s %s risk=%.3f (%s)", res["user"],
                     res["window_start"], res["risk_score"], res["risk_level"])

    # ---- kafka -------------------------------------------------------------------
    def run_kafka(self):
        from confluent_kafka import Consumer
        conf = {"bootstrap.servers": self.cfg.kafka_brokers,
                "group.id": self.cfg.kafka_group,
                "enable.auto.commit": True, "auto.offset.reset": "latest"}
        consumer = Consumer(conf)
        consumer.subscribe(self.cfg.kafka_topics)
        log.info("consuming %s from %s", self.cfg.kafka_topics, self.cfg.kafka_brokers)
        stop = {"run": True}

        def _stop(*_):
            stop["run"] = False
        import threading as _th
        if _th.current_thread() is _th.main_thread():
            signal.signal(signal.SIGINT, _stop)     # only legal in the main thread
            signal.signal(signal.SIGTERM, _stop)

        producer = None
        if self.cfg.results_topic:
            from confluent_kafka import Producer
            producer = Producer({"bootstrap.servers": self.cfg.kafka_brokers})

        try:
            while stop["run"]:
                msgs = consumer.consume(num_messages=2000, timeout=1.0)
                batch = []
                for m in msgs:
                    if m.error():
                        continue
                    try:
                        batch.append(json.loads(m.value()))
                    except json.JSONDecodeError:
                        self.counters["records_dropped"] += 1
                # event-time order inside the poll batch keeps the process table sane
                batch.sort(key=lambda e: str(e.get("timestamp") or e.get("@timestamp") or ""))
                for raw in batch:
                    self.feed(raw)
                results = self.process_ready()
                if producer:
                    for r in results:
                        producer.produce(self.cfg.results_topic,
                                         key=f"{r['user']}|{r['window_start']}".encode(),
                                         value=json.dumps(r, default=str).encode())
                    producer.poll(0)
                self.store.maybe_reload()
                self.trainer.maybe_train()
        finally:
            consumer.close()
            self.process_ready(flush=True)
            log.info("stopped: %s", dict(self.counters))

    # ---- mock --------------------------------------------------------------------
    def run_mock(self, path: str):
        log.info("MOCK mode: reading %s", path)
        with open(path) as fh:
            lines = [ln for ln in (l.strip() for l in fh) if ln]
        events = []
        for ln in lines:
            try:
                events.append(json.loads(ln))
            except json.JSONDecodeError:
                self.counters["records_dropped"] += 1
        events.sort(key=lambda e: str(e.get("timestamp") or ""))
        log.info("loaded %d events, %s -> %s", len(events),
                 events[0].get("timestamp"), events[-1].get("timestamp"))
        for raw in events:
            self.feed(raw)
        results = self.process_ready(flush=True)
        out = f"mock_results_{int(time.time())}.jsonl"
        with open(out, "w") as fh:
            for r in results:
                fh.write(json.dumps(r, default=str) + "\n")
        log.info("MOCK done: %d windows scored, %d alerts, results -> %s | counters=%s",
                 len(results), self.counters["alerts"], out, dict(self.counters))


def main():
    cfg = Config.load(os.environ.get("UBASELINE_CONFIG", "config.yaml"))
    pipe = Pipeline(cfg)
    if "--mock" in sys.argv:
        idx = sys.argv.index("--mock")
        path = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else "events.jsonl"
        pipe.run_mock(path)
    else:
        if not cfg.kafka_brokers:
            log.error("kafka.bootstrap_servers empty - use --mock <file> or configure Kafka")
            sys.exit(1)
        pipe.run_kafka()


if __name__ == "__main__":
    main()
