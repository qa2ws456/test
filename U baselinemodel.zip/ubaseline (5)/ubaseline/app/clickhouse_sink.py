# ClickHouse sink for events the model cannot score (and, optionally, every
# event). Falls back to local JSONL files when no cluster is configured, so the
# whole service runs end-to-end on a laptop.

from __future__ import annotations
import json
import logging
import os
import threading

import numpy as np
import pandas as pd
import time

log = logging.getLogger("ubaseline.clickhouse")

DDL = [
    """
    CREATE TABLE IF NOT EXISTS {db}.events (
        timestamp        DateTime64(6, 'Asia/Kolkata'),
        date             Date,
        window_start     DateTime64(3, 'Asia/Kolkata'),
        EventID          UInt32,
        Channel          LowCardinality(String),
        Computer         LowCardinality(String),
        user             LowCardinality(String),
        attr_method      LowCardinality(String),
        has_baseline     UInt8,
        payload          String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (timestamp, Computer, EventID)
    TTL date + INTERVAL 90 DAY
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_results (
        window_start     DateTime64(3, 'Asia/Kolkata'),
        date             Date,
        hour             UInt8,
        user             LowCardinality(String),
        event_count      UInt32,
        risk_score       Float32,
        risk_level       LowCardinality(String),
        threshold        Float32,
        risk_ratio       Float32,
        alert            UInt8,
        signals          String,
        reasons          String,
        scored_at        DateTime DEFAULT now()
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (window_start, user)
    TTL date + INTERVAL 180 DAY
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_features (
        window_start     DateTime64(3, 'Asia/Kolkata'),
        date             Date,
        hour             UInt8,
        user             LowCardinality(String),
        event_count      UInt32,
        features         String,
        eid_counts       String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(date)
    ORDER BY (user, window_start)
    """,
    """
    CREATE TABLE IF NOT EXISTS {db}.window_items (
        window_start     DateTime64(3, 'Asia/Kolkata'),
        user             LowCardinality(String),
        itype            LowCardinality(String),
        value            String,
        gvalue           String,
        trusted          UInt8,
        is_public        UInt8,
        susp_dir         UInt8,
        sens_port        UInt8,
        interactive      UInt8
    ) ENGINE = MergeTree()
    ORDER BY (user, window_start, itype, value)
    """,
]


class ClickHouseSink:
    def __init__(self, cfg):
        self.cfg = cfg
        self.host = cfg.get("host", "")
        self.db = cfg.get("database", "ubaseline")
        self.mode = cfg.get("mode", "unbaselined")
        self.batch = int(cfg.get("batch_rows", 5000))
        self._client = None
        self._fallback_dir = "./clickhouse_fallback"
        self._lock = threading.Lock()
        self._ch_lock = threading.Lock()
        self._q_lock = threading.Lock()
        self._result_q: list = []   # clickhouse-connect clients are not thread-safe
        if self.host:
            try:
                import clickhouse_connect
                self._client = clickhouse_connect.get_client(
                    host=self.host, port=int(cfg.get("port", 8123)),
                    username=cfg.get("user", "default"), password=cfg.get("password", ""))
                for ddl in DDL:
                    self._client.command(ddl.format(db=self.db))
                log.info("ClickHouse connected: %s/%s", self.host, self.db)
            except Exception as exc:
                log.error("ClickHouse unavailable (%s) - falling back to JSONL at %s",
                          exc, self._fallback_dir)
                self._client = None
        else:
            log.info("ClickHouse not configured - JSONL fallback at %s", self._fallback_dir)
        os.makedirs(self._fallback_dir, exist_ok=True)

    # ------------------------------------------------------------------
    def insert_events(self, rows: list[dict]):
        """rows: normalized+attributed event dicts (with _win, _user, _has_baseline)."""
        if not rows or self.mode == "none":
            return
        payload = [(r["_ts"].to_pydatetime(), r["_ts"].date(),
                    r["_win"].to_pydatetime(), int(r["EventID"]),
                    str(r.get("Channel", ""))[:64], str(r.get("Computer", ""))[:64],
                    str(r.get("attr_user") or ""), str(r.get("attr_method", ""))[:32],
                    int(bool(r.get("_has_baseline"))),
                    json.dumps(r.get("_raw", {}), default=str))
                   for r in rows]
        if self._client is not None:
            try:
                with self._ch_lock:
                    self._client.insert(f"{self.db}.events", payload,
                                    column_names=["timestamp", "date", "window_start", "EventID",
                                                  "Channel", "Computer", "user", "attr_method",
                                                  "has_baseline", "payload"])
                return
            except Exception as exc:                              # pragma: no cover
                log.error("ClickHouse insert failed (%s) - JSONL fallback this batch", exc)
        self._write_fallback("events.jsonl", payload)

    def insert_result(self, res: dict, event_count: int):
        """Queue one result row; flushed to ClickHouse in BATCHES (many tiny
        inserts are what kills the HTTP connection under load). Never drops:
        failed batches go to the JSONL fallback."""
        if self.mode == "none":
            return
        ws = pd.Timestamp(res["window_start"])       # comes as an ISO string
        row = (ws.to_pydatetime(), ws.date(), int(res["hour"]), res["user"],
               int(event_count), float(res["risk_score"]), res["risk_level"],
               float(res["threshold"]), float(res["risk_ratio"] or 0.0),
               int(bool(res["alert"])), json.dumps(res["signals"]),
               json.dumps(res["reasons"]))
        with self._q_lock:
            self._result_q.append(row)
        if len(self._result_q) >= 20:
            self.flush_results()

    def flush_results(self):
        """Insert all queued rows in ONE request; JSONL fallback on failure."""
        with self._q_lock:
            rows, self._result_q = self._result_q, []
        if not rows:
            return
        if self._client is None:
            self._write_fallback("window_results.jsonl", [list(map(str, r)) for r in rows])
            return
        try:
            with self._ch_lock:
                self._client.insert(
                    f"{self.db}.window_results", rows,
                    column_names=["window_start", "date", "hour", "user", "event_count",
                                  "risk_score", "risk_level", "threshold", "risk_ratio",
                                  "alert", "signals", "reasons"])
        except Exception as exc:
            log.error("ClickHouse result BATCH insert failed (%s) - %d rows to JSONL fallback",
                      exc, len(rows))
            self._write_fallback("window_results.jsonl", [list(map(str, r)) for r in rows])

    def _query_df(self, sql: str):
        """pandas DataFrame from a SELECT, across clickhouse-connect versions.
        Serialized: the API thread and the consumer thread share this client."""
        with self._ch_lock:
            c = self._client
            if hasattr(c, "query_df"):
                return c.query_df(sql)
            res = c.query(sql)
            return pd.DataFrame(res.result_rows, columns=list(res.column_names))

    # ---- feature store for unbaselined users (the auto-trainer reads this) -------
    def insert_features(self, user, win, feats: dict, items):
        """Store one window's extracted features + categorical items."""
        if self.mode == "none":
            return
        items_plain = []
        for r in (items.to_dict("records") if items is not None and len(items) else []):
            items_plain.append({k: bool(v) if isinstance(v, (bool, np.bool_)) else v
                                for k, v in r.items()})
        frow = [win.to_pydatetime(), win.date(), int(win.hour), user,
                int(feats.get("event_count", 0)),
                __import__("json").dumps(feats, default=str),
                __import__("json").dumps(feats.get("eid_counts", {}), default=str)]
        irows = [[win.to_pydatetime(), user, r.get("itype", ""),
                  str(r.get("value", ""))[:512], str(r.get("gvalue", ""))[:512],
                  int(bool(r.get("trusted"))), int(bool(r.get("is_public"))),
                  int(bool(r.get("susp_dir"))), int(bool(r.get("sens_port"))),
                  int(bool(r.get("interactive")))] for r in items_plain]
        if self._client is not None:
            try:
                with self._ch_lock:
                    self._client.insert(f"{self.db}.window_features", [frow],
                                    column_names=["window_start", "date", "hour", "user",
                                                  "event_count", "features", "eid_counts"])
                if irows:
                    with self._ch_lock:
                        self._client.insert(f"{self.db}.window_items", irows,
                                        column_names=["window_start", "user", "itype", "value",
                                                      "gvalue", "trusted", "is_public",
                                                      "susp_dir", "sens_port", "interactive"])
                return
            except Exception as exc:
                log.error("ClickHouse feature insert failed (%s) - JSONL fallback", exc)
        self._write_fallback("window_features.jsonl", [frow])
        if irows:
            self._write_fallback("window_items.jsonl", irows)

    def query_features(self):
        """All stored windows as a DataFrame with parsed feature dicts.
        Reads ClickHouse when configured, else the JSONL fallback files."""
        try:
            if self._client is not None:
                df = self._query_df(
                    f"SELECT window_start, date, hour, user, features FROM {self.db}.window_features")
                if df is None or df.empty or df.shape[1] == 0:   # empty store = no candidates
                    return None
                df.columns = ["window_start", "date", "hour", "user", "features"]
            else:
                p = os.path.join(self._fallback_dir, "window_features.jsonl")
                if not os.path.exists(p):
                    return None
                rows = []
                with open(p) as fh:
                    for line in fh:
                        r = json.loads(line)
                        rows.append(r)
                df = pd.DataFrame(rows, columns=["window_start", "date", "hour", "user",
                                                 "event_count", "features", "eid_counts"])                        if len(rows[0]) == 7 else                      pd.DataFrame(rows, columns=["window_start", "date", "hour",
                                                 "user", "features"])
            df["feats"] = df.features.map(json.loads)
            df["window_start"] = pd.to_datetime(df.window_start, utc=False)
            df["date"] = df.window_start.dt.strftime("%Y-%m-%d")
            df["hour"] = df.hour.astype(int)
            return df.sort_values("window_start").reset_index(drop=True)
        except Exception:
            log.exception("query_features failed")
            return None

    def query_items(self, user: str):
        try:
            if self._client is not None:
                df = self._query_df(
                    f"SELECT window_start, itype, value, gvalue, trusted, is_public, "
                    f"susp_dir, sens_port, interactive FROM {self.db}.window_items "
                    f"WHERE user = '{user}'")
            else:
                p = os.path.join(self._fallback_dir, "window_items.jsonl")
                if not os.path.exists(p):
                    return None
                rows = [json.loads(l) for l in open(p)]
                df = pd.DataFrame(rows, columns=["window_start", "user", "itype", "value",
                                                 "gvalue", "trusted", "is_public",
                                                 "susp_dir", "sens_port", "interactive"])
                df = df[df.user == user].drop(columns=["user"])
            if df is None or not len(df) or df.shape[1] == 0:
                return None
            df["window_start"] = pd.to_datetime(df.window_start, utc=False)
            for c in ("trusted", "is_public", "susp_dir", "sens_port", "interactive"):
                df[c] = df[c].astype(bool)
            return df.reset_index(drop=True)
        except Exception:
            log.exception("query_items failed")
            return None

    def _write_fallback(self, name, payload):
        with self._lock:
            with open(os.path.join(self._fallback_dir, name), "a") as fh:
                for row in payload:
                    fh.write(json.dumps(row, default=str) + "\n")
