# ClickHouse-backed baseline store: ALL baselines (numeric stats, inventories,
# rarity, activation, thresholds, config, forest) live in ClickHouse tables -
# no model.pkl, no baseline parquet files. A RAM cache is built at startup and
# on every version bump so scoring stays microsecond-fast.
#
# Tables (created on first use):
#   baseline_stats       (user, hour, feature, med, mad, p95, med_u, mad_u)
#   baseline_known       (user, itype, value)                        [inventories]
#   baseline_grarity     (itype, gvalue, gcnt)                       [global rarity]
#   baseline_eid_rarity  (user, EventID, ucnt)
#   baseline_activation  (user, feature, maxval)
#   baseline_thresholds  (user, hour, threshold)
#   baseline_meta        (key, value)  -> config JSON, forest blob, version
#
# Enable with config.yaml:  baseline: { backend: "clickhouse" }

from __future__ import annotations
import base64
import json
import logging
import pickle
import threading
import time

import numpy as np
import pandas as pd

log = logging.getLogger("ubaseline.baseline_ch")

DDL = [
    """CREATE TABLE IF NOT EXISTS {db}.baseline_stats (
        user String, hour UInt8, feature String,
        med Float64, mad Float64, p95 Float64, med_u Float64, mad_u Float64
    ) ENGINE = MergeTree() ORDER BY (user, hour, feature)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_known (
        user String, itype String, value String
    ) ENGINE = ReplacingMergeTree() ORDER BY (user, itype, value)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_grarity (
        itype String, gvalue String, gcnt Float64
    ) ENGINE = SummingMergeTree() ORDER BY (itype, gvalue)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_eid_rarity (
        user String, EventID UInt32, ucnt Float64
    ) ENGINE = SummingMergeTree() ORDER BY (user, EventID)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_activation (
        user String, feature String, maxval Float64
    ) ENGINE = ReplacingMergeTree() ORDER BY (user, feature)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_thresholds (
        user String, hour UInt8, threshold Float64
    ) ENGINE = ReplacingMergeTree() ORDER BY (user, hour)""",
    """CREATE TABLE IF NOT EXISTS {db}.baseline_meta (
        key String, value String
    ) ENGINE = ReplacingMergeTree() ORDER BY key""",
]


def ensure_tables(sink):
    for ddl in DDL:
        sink._client.command(ddl.format(db=sink.db))


# ==================================================================================
# WRITERS
# ==================================================================================
def save_model_to_ch(sink, model: dict, parquet_dir: str | None = None):
    """Write a whole notebook-style model dict (from model.pkl) + its parquet
    sidecars into the ClickHouse baseline tables. Bumps the version."""
    import os
    ensure_tables(sink)
    db = sink.db
    cfg = model.get("config", {})
    num = model.get("numeric_baseline", {})

    # ---- stats (pivot the numeric frames into long rows) ----
    med_h, mad_h, p95_h = (num.get("med_h"), num.get("mad_h"), num.get("p95_h"))
    med_u, mad_u = num.get("med_u"), num.get("mad_u")
    rows = []
    if med_h is not None and len(med_h):
        for (u, h) in med_h.index:
            for fkey in med_h.columns:
                mu = float(med_u.loc[u, fkey]) if med_u is not None and u in med_u.index else 0.0
                du = float(mad_u.loc[u, fkey]) if mad_u is not None and u in mad_u.index else 0.0
                rows.append((u, int(h), fkey,
                             float(med_h.loc[(u, h), fkey]),
                             float(mad_h.loc[(u, h), fkey]) if mad_h is not None else 0.0,
                             float(p95_h.loc[(u, h), fkey]) if p95_h is not None else 0.0,
                             mu, du))
    if rows:
        sink._client.insert(f"{db}.baseline_stats", rows,
                            column_names=["user", "hour", "feature", "med", "mad",
                                          "p95", "med_u", "mad_u"])

    # ---- parquet sidecars ----
    def _read(name, cols):
        p = os.path.join(parquet_dir or ".", name)
        return pd.read_parquet(p) if os.path.exists(p) else pd.DataFrame(columns=cols)

    kn = _read("baseline_inventories.parquet", ["user", "itype", "value"])
    if len(kn):
        sink._client.insert(f"{db}.baseline_known",
                            [(r.user, r.itype, r.value) for r in kn.itertuples()],
                            column_names=["user", "itype", "value"])
    gr = _read("baseline_global_rarity.parquet", ["itype", "gvalue", "gcnt"])
    if len(gr):
        sink._client.insert(f"{db}.baseline_grarity",
                            [(r.itype, r.gvalue, float(r.gcnt)) for r in gr.itertuples()],
                            column_names=["itype", "gvalue", "gcnt"])
    er = _read("baseline_eventid_rarity.parquet", ["user", "EventID", "ucnt"])
    if len(er):
        sink._client.insert(f"{db}.baseline_eid_rarity",
                            [(r.user, int(r.EventID), float(r.ucnt)) for r in er.itertuples()],
                            column_names=["user", "EventID", "ucnt"])

    # ---- activation: from parquet if present, else pkl has none ----
    act = _read("baseline_activation.parquet", ["user"])
    if len(act) and "user" not in act.columns:
        act = act.reset_index().rename(columns={act.columns[0]: "user"})
    if "user" in act.columns and len(act):
        feat_cols = [c for c in act.columns if c != "user"]
        arows = [(r.user, f, float(getattr(r, f))) for r in act.itertuples() for f in feat_cols]
        if arows:
            sink._client.insert(f"{db}.baseline_activation", arows,
                                column_names=["user", "feature", "maxval"])

    # ---- thresholds: pkl surface preferred, else parquet ----
    ts = model.get("threshold_surface")
    if not isinstance(ts, pd.Series):
        tp = os.path.join(parquet_dir or ".", "threshold_surface.parquet")
        if os.path.exists(tp):
            t = pd.read_parquet(tp)
            tcol = "threshold" if "threshold" in t.columns else t.columns[-1]
            for c in ("user", "hour"):
                if c not in t.columns:
                    t = t.reset_index()
            ts = t.set_index(["user", "hour"])[tcol]
    if isinstance(ts, pd.Series) and len(ts):
        trows = [(u, int(h), float(v)) for (u, h), v in ts.items()]
        sink._client.insert(f"{db}.baseline_thresholds", trows,
                            column_names=["user", "hour", "threshold"])

    # ---- meta: config JSON + forest blob + version bump ----
    iso = model.get("isolation_forest")
    meta = [("config", json.dumps(cfg, default=str))]
    if iso is not None:
        meta.append(("forest", base64.b64encode(pickle.dumps(iso)).decode()))
    sink._client.insert(f"{db}.baseline_meta", meta, column_names=["key", "value"])
    bump_version(sink)
    log.info("model saved to ClickHouse: %d stat rows, %d known, version=%s",
             len(rows), len(kn), get_version(sink))


def merge_user_to_ch(sink, fitted: dict):
    """Trainer merge for ONE user: replace their rows, add corpus counts, bump."""
    ensure_tables(sink)
    db = sink.db
    u = fitted["user"]
    with sink._ch_lock:
        for tbl in ("baseline_stats", "baseline_known", "baseline_eid_rarity",
                    "baseline_activation", "baseline_thresholds"):
            sink._client.command(f"ALTER TABLE {db}.{tbl} DELETE WHERE user='{u}'")
        # stats: long rows per (user, hour, feature)
        med_h, mad_h, p95_h = (fitted.get("med_h"), fitted.get("mad_h"), fitted.get("p95_h"))
        srows = []
        if med_h is not None and len(med_h):
            for (uu, h) in med_h.index:
                for fname in med_h.columns:
                    srows.append((uu, int(h), fname,
                                  float(med_h.loc[(uu, h), fname]),
                                  float(mad_h.loc[(uu, h), fname]) if mad_h is not None else 0.0,
                                  float(p95_h.loc[(uu, h), fname]) if p95_h is not None else 0.0,
                                  0.0, 0.0))
        if srows:
            sink._client.insert(f"{db}.baseline_stats", srows,
                                column_names=["user", "hour", "feature", "med", "mad",
                                              "p95", "med_u", "mad_u"])
        if fitted["known"]:
            sink._client.insert(f"{db}.baseline_known",
                                sorted(fitted["known"]),
                                column_names=["user", "itype", "value"])
        if fitted["gcnt"]:
            sink._client.insert(f"{db}.baseline_grarity",
                                [(k[0], k[1], float(v)) for k, v in fitted["gcnt"].items()],
                                column_names=["itype", "gvalue", "gcnt"])
        if fitted["eid_ucnt"]:
            sink._client.insert(f"{db}.baseline_eid_rarity",
                                [(uu, int(e), float(v)) for (uu, e), v in fitted["eid_ucnt"].items()],
                                column_names=["user", "EventID", "ucnt"])
        arows = [(u, f, float(fitted["act_max"].loc[u, f]))
                 for f in fitted["act_max"].columns] if len(fitted["act_max"]) else []
        if arows:
            sink._client.insert(f"{db}.baseline_activation", arows,
                                column_names=["user", "feature", "maxval"])
        trows = [(uu, int(h), float(v)) for (uu, h), v in fitted["thresholds"].items()]
        if trows:
            sink._client.insert(f"{db}.baseline_thresholds", trows,
                                column_names=["user", "hour", "threshold"])
        bump_version(sink)
    log.info("baseline merged into ClickHouse: principal %s", u)


def bump_version(sink):
    cur = get_version(sink)
    v = (cur if cur is not None else 0) + 1
    sink._client.command(
        f"ALTER TABLE {sink.db}.baseline_meta DELETE WHERE key='version'")
    sink._client.insert(f"{sink.db}.baseline_meta", [("version", str(v))],
                        column_names=["key", "value"])


def get_version(sink):
    """Current model version, or None if ClickHouse is unreachable.
    (0 is a REAL value = table exists but no version row yet; None = cannot know.)"""
    try:
        res = sink._client.query(
            f"SELECT value FROM {sink.db}.baseline_meta FINAL WHERE key='version'")
        return int(res.result_rows[0][0]) if res.result_rows else 0
    except Exception:
        return None


# ==================================================================================
# THE STORE (same interface as BaselineStore; RAM cache built from ClickHouse)
# ==================================================================================
class CHBaselineStore:
    ch_backed = True

    def __init__(self, cfg, sink):
        self.sink = sink
        self.dir = cfg.baseline_dir                 # kept for compatibility
        self.defaults = dict(cfg.scoring_defaults)
        self.hot_reload_seconds = cfg.hot_reload_seconds
        self._loaded_at = 0.0
        self._version = -1
        self._lock = threading.Lock()
        ensure_tables(sink)
        self._load()

    # ---------------------------------------------------------------- load
    def _load(self, keep_old_on_failure: bool = False):
        sink = self.sink
        db = sink.db
        failed = 0

        def q(sql):
            nonlocal failed
            try:
                with sink._ch_lock:
                    res = sink._client.query(sql)
                return pd.DataFrame(res.result_rows, columns=list(res.column_names))
            except Exception as exc:
                failed += 1
                log.warning("baseline query failed: %s", exc)
                return pd.DataFrame()

        # meta
        cfg, iso = {}, None
        m = q(f"SELECT key, value FROM {db}.baseline_meta FINAL")
        if len(m):
            kv = dict(zip(m.key, m.value))
            if "config" in kv:
                try:
                    cfg = json.loads(kv["config"])
                except Exception:
                    cfg = {}
            if "forest" in kv and kv["forest"]:
                try:
                    iso = pickle.loads(base64.b64decode(kv["forest"]))
                except Exception:
                    iso = None

        # stats -> wide frames
        num = {}
        med_u_map, mad_u_map = {}, {}
        s_ = q(f"SELECT user, hour, feature, med, mad, p95, med_u, mad_u FROM {db}.baseline_stats")
        if len(s_):
            s_ = s_.copy()
            s_["hour"] = s_.hour.astype(int)
            for col, key in (("med", "med_h"), ("mad", "mad_h"), ("p95", "p95_h")):
                num[key] = (s_.set_index(["user", "hour", "feature"])[col]
                              .unstack("feature"))
            for r in s_.itertuples():
                med_u_map[r.user] = float(r.med_u)
                mad_u_map[r.user] = float(r.mad_u)
        num["med_u"] = None
        num["mad_u"] = None

        # known set
        known = set()
        k = q(f"SELECT user, itype, value FROM {db}.baseline_known FINAL")
        if len(k):
            known = set(map(tuple, k.to_numpy()))

        # global rarity
        gcnt = {}
        g = q(f"SELECT itype, gvalue, sum(gcnt) gcnt FROM {db}.baseline_grarity "
              f"FINAL GROUP BY itype, gvalue")
        if len(g):
            gcnt = {(r.itype, r.gvalue): float(r.gcnt) for r in g.itertuples()}

        # eid rarity (+ totals reconstructed exactly)
        eid_ucnt, eid_utot, eid_gcnt, eid_gtot = {}, {}, {}, 0.0
        e = q(f"SELECT user, EventID, sum(ucnt) ucnt FROM {db}.baseline_eid_rarity "
              f"FINAL GROUP BY user, EventID")
        for r in e.itertuples():
            eid_ucnt[(r.user, int(r.EventID))] = float(r.ucnt)
            eid_utot[r.user] = eid_utot.get(r.user, 0.0) + float(r.ucnt)
            eid_gcnt[int(r.EventID)] = eid_gcnt.get(int(r.EventID), 0.0) + float(r.ucnt)
            eid_gtot += float(r.ucnt)

        # activation -> wide
        act_max = None
        a = q(f"SELECT user, feature, max(maxval) maxval FROM {db}.baseline_activation "
              f"FINAL GROUP BY user, feature")
        if len(a):
            act_max = (a.set_index(["user", "feature"])["maxval"].unstack("feature"))

        # thresholds
        thresholds = None
        t = q(f"SELECT user, hour, max(threshold) threshold FROM {db}.baseline_thresholds "
              f"FINAL GROUP BY user, hour")
        if len(t):
            thresholds = pd.Series({(r.user, int(r.hour)): float(r.threshold)
                                    for r in t.itertuples()})

        stat_features = list(cfg.get("stat_features", []))
        act_features = list(cfg.get("act_features", []))
        principals = set(cfg.get("principals", []))
        if "med_h" in num and len(num["med_h"]):
            principals |= {u for u, _ in num["med_h"].index}
        elif act_max is not None:
            principals |= set(act_max.index)

        # ---- commit policy: never swap a working model for an empty one just
        # because the DB hiccuped during the reload ------------------------------
        had_principals = bool(getattr(self, "principals", None))
        if keep_old_on_failure and failed and not principals and had_principals:
            log.error("baseline reload ABORTED (%d query failures) - keeping previous model",
                      failed)
            return

        self.cfg, self.iso = cfg, iso
        self.stat_features, self.act_features = stat_features, act_features
        self.act_weights = dict(cfg.get("act_weights", {}))
        self.num, self._med_u_map, self._mad_u_map = num, med_u_map, mad_u_map
        self.known, self.gcnt = known, gcnt
        self.eid_ucnt, self.eid_utot = eid_ucnt, eid_utot
        self.eid_gcnt, self.eid_gtot = eid_gcnt, eid_gtot
        self.act_max, self.thresholds = act_max, thresholds
        self.principals = principals
        v = get_version(sink)
        self._version = v if v is not None else getattr(self, "_version", 0)
        self._loaded_at = time.time()
        log.info("CH baseline loaded: %d principals, %d known items, %d EID rows, version=%s",
                 len(principals), len(known), len(eid_ucnt), self._version)

    # ---------------------------------------------------------------- interface
    def maybe_reload(self, force: bool = False):
        if not force and time.time() - self._loaded_at < self.hot_reload_seconds:
            return
        v = get_version(self.sink)
        if v is None:
            log.warning("ClickHouse unreachable - version check skipped, keeping current model")
            self._loaded_at = time.time()          # back off, retry next interval
            return
        if force or v != self._version:
            log.info("baseline version changed %s -> %s - reloading from ClickHouse",
                     self._version, v)
            with self._lock:
                self._load(keep_old_on_failure=True)

    def has_baseline(self, user): return user in self.principals

    def const(self, name):
        if name in self.cfg:
            return float(self.cfg[name])
        up = name.upper()
        if up in self.cfg:
            return float(self.cfg[up])
        wmap = {"w_stat": "s_stat", "w_nov": "s_nov", "w_rare": "s_rare",
                "w_act": "s_act", "w_ml": "s_ml"}
        if name in wmap and isinstance(self.cfg.get("weights"), dict):
            return float(self.cfg["weights"][wmap[name]])
        return float(self.defaults.get(name))

    def cell(self, user, hour):
        if "med_h" not in self.num or not self.stat_features:
            return None
        try:
            med = self.num["med_h"].loc[(user, hour), self.stat_features].to_numpy(float)
            mad = self.num["mad_h"].loc[(user, hour), self.stat_features].to_numpy(float)
            p95 = self.num["p95_h"].loc[(user, hour), self.stat_features].to_numpy(float)
        except KeyError:
            return None
        madu = np.full(len(self.stat_features), self._mad_u_map.get(user, 0.0))
        return med, mad, madu, p95

    def act_max_row(self, user):
        if self.act_max is None or user not in self.act_max.index:
            return None
        return self.act_max.loc[user]

    def threshold(self, user, hour):
        if self.thresholds is not None:
            try:
                return float(self.thresholds.loc[(user, hour)])
            except (KeyError, TypeError):
                pass
        return float(self.const("alert_threshold"))


# # ClickHouse-backed baseline store: ALL baselines (numeric stats, inventories,
# # rarity, activation, thresholds, config, forest) live in ClickHouse tables -
# # no model.pkl, no baseline parquet files. A RAM cache is built at startup and
# # on every version bump so scoring stays microsecond-fast.
# #
# # Tables (created on first use):
# #   baseline_stats       (user, hour, feature, med, mad, p95, med_u, mad_u)
# #   baseline_known       (user, itype, value)                        [inventories]
# #   baseline_grarity     (itype, gvalue, gcnt)                       [global rarity]
# #   baseline_eid_rarity  (user, EventID, ucnt)
# #   baseline_activation  (user, feature, maxval)
# #   baseline_thresholds  (user, hour, threshold)
# #   baseline_meta        (key, value)  -> config JSON, forest blob, version
# #
# # Enable with config.yaml:  baseline: { backend: "clickhouse" }

# from __future__ import annotations
# import base64
# import json
# import logging
# import pickle
# import threading
# import time

# import numpy as np
# import pandas as pd

# log = logging.getLogger("ubaseline.baseline_ch")

# DDL = [
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_stats (
#         user String, hour UInt8, feature String,
#         med Float64, mad Float64, p95 Float64, med_u Float64, mad_u Float64
#     ) ENGINE = MergeTree() ORDER BY (user, hour, feature)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_known (
#         user String, itype String, value String
#     ) ENGINE = ReplacingMergeTree() ORDER BY (user, itype, value)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_grarity (
#         itype String, gvalue String, gcnt Float64
#     ) ENGINE = SummingMergeTree() ORDER BY (itype, gvalue)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_eid_rarity (
#         user String, EventID UInt32, ucnt Float64
#     ) ENGINE = SummingMergeTree() ORDER BY (user, EventID)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_activation (
#         user String, feature String, maxval Float64
#     ) ENGINE = ReplacingMergeTree() ORDER BY (user, feature)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_thresholds (
#         user String, hour UInt8, threshold Float64
#     ) ENGINE = ReplacingMergeTree() ORDER BY (user, hour)""",
#     """CREATE TABLE IF NOT EXISTS {db}.baseline_meta (
#         key String, value String
#     ) ENGINE = ReplacingMergeTree() ORDER BY key""",
# ]


# def ensure_tables(sink):
#     for ddl in DDL:
#         sink._client.command(ddl.format(db=sink.db))


# # ==================================================================================
# # WRITERS
# # ==================================================================================
# def save_model_to_ch(sink, model: dict, parquet_dir: str | None = None):
#     """Write a whole notebook-style model dict (from model.pkl) + its parquet
#     sidecars into the ClickHouse baseline tables. Bumps the version."""
#     import os
#     ensure_tables(sink)
#     db = sink.db
#     cfg = model.get("config", {})
#     num = model.get("numeric_baseline", {})

#     # ---- stats (pivot the numeric frames into long rows) ----
#     med_h, mad_h, p95_h = (num.get("med_h"), num.get("mad_h"), num.get("p95_h"))
#     med_u, mad_u = num.get("med_u"), num.get("mad_u")
#     rows = []
#     if med_h is not None and len(med_h):
#         for (u, h) in med_h.index:
#             for fkey in med_h.columns:
#                 mu = float(med_u.loc[u, fkey]) if med_u is not None and u in med_u.index else 0.0
#                 du = float(mad_u.loc[u, fkey]) if mad_u is not None and u in mad_u.index else 0.0
#                 rows.append((u, int(h), fkey,
#                              float(med_h.loc[(u, h), fkey]),
#                              float(mad_h.loc[(u, h), fkey]) if mad_h is not None else 0.0,
#                              float(p95_h.loc[(u, h), fkey]) if p95_h is not None else 0.0,
#                              mu, du))
#     if rows:
#         sink._client.insert(f"{db}.baseline_stats", rows,
#                             column_names=["user", "hour", "feature", "med", "mad",
#                                           "p95", "med_u", "mad_u"])

#     # ---- parquet sidecars ----
#     def _read(name, cols):
#         p = os.path.join(parquet_dir or ".", name)
#         return pd.read_parquet(p) if os.path.exists(p) else pd.DataFrame(columns=cols)

#     kn = _read("baseline_inventories.parquet", ["user", "itype", "value"])
#     if len(kn):
#         sink._client.insert(f"{db}.baseline_known",
#                             [(r.user, r.itype, r.value) for r in kn.itertuples()],
#                             column_names=["user", "itype", "value"])
#     gr = _read("baseline_global_rarity.parquet", ["itype", "gvalue", "gcnt"])
#     if len(gr):
#         sink._client.insert(f"{db}.baseline_grarity",
#                             [(r.itype, r.gvalue, float(r.gcnt)) for r in gr.itertuples()],
#                             column_names=["itype", "gvalue", "gcnt"])
#     er = _read("baseline_eventid_rarity.parquet", ["user", "EventID", "ucnt"])
#     if len(er):
#         sink._client.insert(f"{db}.baseline_eid_rarity",
#                             [(r.user, int(r.EventID), float(r.ucnt)) for r in er.itertuples()],
#                             column_names=["user", "EventID", "ucnt"])

#     # ---- activation: from parquet if present, else pkl has none ----
#     act = _read("baseline_activation.parquet", ["user"])
#     if len(act) and "user" not in act.columns:
#         act = act.reset_index().rename(columns={act.columns[0]: "user"})
#     if "user" in act.columns and len(act):
#         feat_cols = [c for c in act.columns if c != "user"]
#         arows = [(r.user, f, float(getattr(r, f))) for r in act.itertuples() for f in feat_cols]
#         if arows:
#             sink._client.insert(f"{db}.baseline_activation", arows,
#                                 column_names=["user", "feature", "maxval"])

#     # ---- thresholds: pkl surface preferred, else parquet ----
#     ts = model.get("threshold_surface")
#     if not isinstance(ts, pd.Series):
#         tp = os.path.join(parquet_dir or ".", "threshold_surface.parquet")
#         if os.path.exists(tp):
#             t = pd.read_parquet(tp)
#             tcol = "threshold" if "threshold" in t.columns else t.columns[-1]
#             for c in ("user", "hour"):
#                 if c not in t.columns:
#                     t = t.reset_index()
#             ts = t.set_index(["user", "hour"])[tcol]
#     if isinstance(ts, pd.Series) and len(ts):
#         trows = [(u, int(h), float(v)) for (u, h), v in ts.items()]
#         sink._client.insert(f"{db}.baseline_thresholds", trows,
#                             column_names=["user", "hour", "threshold"])

#     # ---- meta: config JSON + forest blob + version bump ----
#     iso = model.get("isolation_forest")
#     meta = [("config", json.dumps(cfg, default=str))]
#     if iso is not None:
#         meta.append(("forest", base64.b64encode(pickle.dumps(iso)).decode()))
#     sink._client.insert(f"{db}.baseline_meta", meta, column_names=["key", "value"])
#     bump_version(sink)
#     log.info("model saved to ClickHouse: %d stat rows, %d known, version=%s",
#              len(rows), len(kn), get_version(sink))


# def merge_user_to_ch(sink, fitted: dict):
#     """Trainer merge for ONE user: replace their rows, add corpus counts, bump."""
#     ensure_tables(sink)
#     db = sink.db
#     u = fitted["user"]
#     with sink._ch_lock:
#         for tbl in ("baseline_stats", "baseline_known", "baseline_eid_rarity",
#                     "baseline_activation", "baseline_thresholds"):
#             sink._client.command(f"ALTER TABLE {db}.{tbl} DELETE WHERE user='{u}'")
#         # stats: long rows per (user, hour, feature)
#         med_h, mad_h, p95_h = (fitted.get("med_h"), fitted.get("mad_h"), fitted.get("p95_h"))
#         srows = []
#         if med_h is not None and len(med_h):
#             for (uu, h) in med_h.index:
#                 for fname in med_h.columns:
#                     srows.append((uu, int(h), fname,
#                                   float(med_h.loc[(uu, h), fname]),
#                                   float(mad_h.loc[(uu, h), fname]) if mad_h is not None else 0.0,
#                                   float(p95_h.loc[(uu, h), fname]) if p95_h is not None else 0.0,
#                                   0.0, 0.0))
#         if srows:
#             sink._client.insert(f"{db}.baseline_stats", srows,
#                                 column_names=["user", "hour", "feature", "med", "mad",
#                                               "p95", "med_u", "mad_u"])
#         if fitted["known"]:
#             sink._client.insert(f"{db}.baseline_known",
#                                 sorted(fitted["known"]),
#                                 column_names=["user", "itype", "value"])
#         if fitted["gcnt"]:
#             sink._client.insert(f"{db}.baseline_grarity",
#                                 [(k[0], k[1], float(v)) for k, v in fitted["gcnt"].items()],
#                                 column_names=["itype", "gvalue", "gcnt"])
#         if fitted["eid_ucnt"]:
#             sink._client.insert(f"{db}.baseline_eid_rarity",
#                                 [(uu, int(e), float(v)) for (uu, e), v in fitted["eid_ucnt"].items()],
#                                 column_names=["user", "EventID", "ucnt"])
#         arows = [(u, f, float(fitted["act_max"].loc[u, f]))
#                  for f in fitted["act_max"].columns] if len(fitted["act_max"]) else []
#         if arows:
#             sink._client.insert(f"{db}.baseline_activation", arows,
#                                 column_names=["user", "feature", "maxval"])
#         trows = [(uu, int(h), float(v)) for (uu, h), v in fitted["thresholds"].items()]
#         if trows:
#             sink._client.insert(f"{db}.baseline_thresholds", trows,
#                                 column_names=["user", "hour", "threshold"])
#         bump_version(sink)
#     log.info("baseline merged into ClickHouse: principal %s", u)


# def bump_version(sink):
#     v = get_version(sink) + 1
#     sink._client.command(
#         f"ALTER TABLE {sink.db}.baseline_meta DELETE WHERE key='version'")
#     sink._client.insert(f"{sink.db}.baseline_meta", [("version", str(v))],
#                         column_names=["key", "value"])


# def get_version(sink) -> int:
#     try:
#         res = sink._client.query(
#             f"SELECT value FROM {sink.db}.baseline_meta FINAL WHERE key='version'")
#         return int(res.result_rows[0][0]) if res.result_rows else 0
#     except Exception:
#         return 0


# # ==================================================================================
# # THE STORE (same interface as BaselineStore; RAM cache built from ClickHouse)
# # ==================================================================================
# class CHBaselineStore:
#     ch_backed = True

#     def __init__(self, cfg, sink):
#         self.sink = sink
#         self.dir = cfg.baseline_dir                 # kept for compatibility
#         self.defaults = dict(cfg.scoring_defaults)
#         self.hot_reload_seconds = cfg.hot_reload_seconds
#         self._loaded_at = 0.0
#         self._version = -1
#         self._lock = threading.Lock()
#         ensure_tables(sink)
#         self._load()

#     # ---------------------------------------------------------------- load
#     def _load(self):
#         sink = self.sink
#         db = sink.db

#         def q(sql):
#             with sink._ch_lock:
#                 res = sink._client.query(sql)
#             return pd.DataFrame(res.result_rows, columns=list(res.column_names))

#         # meta
#         cfg = {}
#         iso = None
#         try:
#             m = q(f"SELECT key, value FROM {db}.baseline_meta FINAL")
#             kv = dict(zip(m.key, m.value))
#             if "config" in kv:
#                 cfg = json.loads(kv["config"])
#             if "forest" in kv and kv["forest"]:
#                 try:
#                     iso = pickle.loads(base64.b64decode(kv["forest"]))
#                 except Exception:
#                     iso = None
#         except Exception as exc:
#             log.warning("baseline_meta read failed: %s", exc)
#         self.cfg = cfg
#         self.iso = iso
#         self._version = get_version(sink)

#         self.stat_features = list(cfg.get("stat_features", []))
#         self.act_features = list(cfg.get("act_features", []))
#         self.act_weights = dict(cfg.get("act_weights", {}))

#         # stats -> wide frames
#         self.num = {}
#         try:
#             s = q(f"SELECT user, hour, feature, med, mad, p95, med_u, mad_u "
#                   f"FROM {db}.baseline_stats")
#             if len(s):
#                 s = s.copy()
#                 s["hour"] = s.hour.astype(int)
#                 for col, key in (("med", "med_h"), ("mad", "mad_h"), ("p95", "p95_h")):
#                     wide = (s.set_index(["user", "hour", "feature"])[col]
#                               .unstack("feature"))
#                     self.num[key] = wide
#                 med_u = s.groupby("user").first()[["med_u"]].drop_duplicates()
#                 mad_u = s.groupby("user").first()[["mad_u"]].drop_duplicates()
#                 self.num["med_u"] = None
#                 self.num["mad_u"] = None
#                 self._med_u_map = {(r.user): float(r.med_u) for r in s.itertuples()}
#                 self._mad_u_map = {(r.user): float(r.mad_u) for r in s.itertuples()}
#         except Exception as exc:
#             log.warning("baseline_stats read failed: %s", exc)

#         # known set
#         self.known = set()
#         try:
#             k = q(f"SELECT user, itype, value FROM {db}.baseline_known FINAL")
#             self.known = set(map(tuple, k.to_numpy())) if len(k) else set()
#         except Exception as exc:
#             log.warning("baseline_known read failed: %s", exc)

#         # global rarity
#         self.gcnt = {}
#         try:
#             g = q(f"SELECT itype, gvalue, sum(gcnt) gcnt FROM {db}.baseline_grarity "
#                   f"FINAL GROUP BY itype, gvalue")
#             self.gcnt = {(r.itype, r.gvalue): float(r.gcnt) for r in g.itertuples()} if len(g) else {}
#         except Exception as exc:
#             log.warning("baseline_grarity read failed: %s", exc)

#         # eid rarity (+ totals reconstructed exactly, as in the file store)
#         self.eid_ucnt, self.eid_utot, self.eid_gcnt, self.eid_gtot = {}, {}, {}, 0.0
#         try:
#             e = q(f"SELECT user, EventID, sum(ucnt) ucnt FROM {db}.baseline_eid_rarity "
#                   f"FINAL GROUP BY user, EventID")
#             for r in e.itertuples():
#                 self.eid_ucnt[(r.user, int(r.EventID))] = float(r.ucnt)
#                 self.eid_utot[r.user] = self.eid_utot.get(r.user, 0.0) + float(r.ucnt)
#                 self.eid_gcnt[int(r.EventID)] = self.eid_gcnt.get(int(r.EventID), 0.0) + float(r.ucnt)
#                 self.eid_gtot += float(r.ucnt)
#         except Exception as exc:
#             log.warning("baseline_eid_rarity read failed: %s", exc)

#         # activation -> wide
#         self.act_max = None
#         try:
#             a = q(f"SELECT user, feature, max(maxval) maxval FROM {db}.baseline_activation "
#                   f"FINAL GROUP BY user, feature")
#             if len(a):
#                 self.act_max = (a.set_index(["user", "feature"])["maxval"]
#                                   .unstack("feature"))
#         except Exception as exc:
#             log.warning("baseline_activation read failed: %s", exc)

#         # thresholds
#         self.thresholds = None
#         try:
#             t = q(f"SELECT user, hour, max(threshold) threshold FROM {db}.baseline_thresholds "
#                   f"FINAL GROUP BY user, hour")
#             if len(t):
#                 self.thresholds = pd.Series(
#                     {(r.user, int(r.hour)): float(r.threshold) for r in t.itertuples()})
#         except Exception as exc:
#             log.warning("baseline_thresholds read failed: %s", exc)

#         self.principals = set(cfg.get("principals", []))
#         if "med_h" in self.num and len(self.num["med_h"]):
#             self.principals |= {u for u, _ in self.num["med_h"].index}
#         elif self.act_max is not None:
#             self.principals |= set(self.act_max.index)
#         self._loaded_at = time.time()
#         log.info("CH baseline loaded: %d principals, %d known items, %d EID rows, version=%d",
#                  len(self.principals), len(self.known), len(self.eid_ucnt), self._version)

#     # ---------------------------------------------------------------- interface
#     def maybe_reload(self, force: bool = False):
#         if not force and time.time() - self._loaded_at < self.hot_reload_seconds:
#             return
#         try:
#             v = get_version(self.sink)
#         except Exception:
#             return
#         if force or v != self._version:
#             log.info("baseline version changed %s -> %s - reloading from ClickHouse",
#                      self._version, v)
#             with self._lock:
#                 self._load()

#     def has_baseline(self, user): return user in self.principals

#     def const(self, name):
#         if name in self.cfg:
#             return float(self.cfg[name])
#         up = name.upper()
#         if up in self.cfg:
#             return float(self.cfg[up])
#         wmap = {"w_stat": "s_stat", "w_nov": "s_nov", "w_rare": "s_rare",
#                 "w_act": "s_act", "w_ml": "s_ml"}
#         if name in wmap and isinstance(self.cfg.get("weights"), dict):
#             return float(self.cfg["weights"][wmap[name]])
#         return float(self.defaults.get(name))

#     def cell(self, user, hour):
#         if "med_h" not in self.num or not self.stat_features:
#             return None
#         try:
#             med = self.num["med_h"].loc[(user, hour), self.stat_features].to_numpy(float)
#             mad = self.num["mad_h"].loc[(user, hour), self.stat_features].to_numpy(float)
#             p95 = self.num["p95_h"].loc[(user, hour), self.stat_features].to_numpy(float)
#         except KeyError:
#             return None
#         madu = np.full(len(self.stat_features), self._mad_u_map.get(user, 0.0))
#         return med, mad, madu, p95

#     def act_max_row(self, user):
#         if self.act_max is None or user not in self.act_max.index:
#             return None
#         return self.act_max.loc[user]

#     def threshold(self, user, hour):
#         if self.thresholds is not None:
#             try:
#                 return float(self.thresholds.loc[(user, hour)])
#             except (KeyError, TypeError):
#                 pass
#         return float(self.const("alert_threshold"))
