#!/usr/bin/env python3
"""
render_config.py - turn .env + config.template.yaml into config.runtime.yaml.

Why: the api reads /app/config.yaml, which the Dockerfile bakes from
config.docker.yaml. Baking means every config edit needs `up -d --build api`.
Instead, this renders the environment-specific values out of ONE file (.env) and
docker-compose bind-mounts the result over /app/config.yaml -> config edits become
`docker compose restart api`, and a new server only ever needs .env edited.

    python render_config.py                  # .env + template -> config.runtime.yaml
    python render_config.py --check          # render to stdout, write nothing
    python render_config.py --print          # full output to stdout
    python render_config.py --env prod.env --out /tmp/c.yaml --template t.yaml

Placeholder syntax (same shapes docker compose uses, so the two files look alike):

    ${VAR}              value; empty string if unset
    ${VAR:-fallback}    fallback if unset OR empty
    ${VAR:?message}     abort with "message" if unset OR empty   (use for secrets)
    ${VAR[]}            comma-separated value -> YAML flow list, e.g.
                        AD_DOMAINS=a,b  ->  [a, b]   (numbers stay numbers;
                        all-whitespace entries dropped; empty -> [])

Requires PyYAML to *validate* the output; if it is missing, rendering still works
and you get a warning instead of a hard failure.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
TOKEN_RE = re.compile(r"\$\{([^}]*)\}")


# --------------------------------------------------------------------------- env
def load_env(path: str) -> dict[str, str]:
    """Parse a dotenv file: KEY=value, optional `export `, quotes, # comments."""
    env: dict[str, str] = {}
    try:
        raw = open(path, "r", encoding="utf-8-sig").read()
    except FileNotFoundError:
        sys.exit(f"error: env file not found: {path}\n"
                 f"       cp .env.example .env and edit it before deploying.")
    for lineno, line in enumerate(raw.splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            sys.exit(f"error: {path}:{lineno}: not a KEY=value line: {line!r}")
        key, _, value = line.partition("=")
        key = key.strip()
        if not NAME_RE.fullmatch(key):
            sys.exit(f"error: {path}:{lineno}: invalid variable name {key!r}")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        elif " #" in value:                      # trailing comment on unquoted value
            value = value.split(" #", 1)[0].rstrip()
        env[key] = value
    return env


# ------------------------------------------------------------------- substitution
def _quote(item: str) -> str:
    if re.fullmatch(r"-?\d+", item) or re.fullmatch(r"-?\d*\.\d+", item):
        return item
    return '"' + item.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _as_list(raw: str) -> str:
    items = [p.strip() for p in raw.split(",")]
    items = [p for p in items if p]
    return "[]" if not items else "[" + ", ".join(_quote(i) for i in items) + "]"


def resolve(inner: str, env: dict[str, str], where: str) -> str:
    """Expand one ${...} body. Returns the replacement text (already typed)."""
    as_list = False
    m = NAME_RE.match(inner)
    if not m:
        sys.exit(f"error: {where}: placeholder body {inner!r} is not a valid "
                   f"variable name (a dollar-brace inside a comment? reword it)")
    name = m.group(0)
    rest = inner[len(name):]
    # the list flag may sit right after the name (VAR[]:-def) or at the end (VAR:-def[])
    if rest.startswith("[]"):
        as_list, rest = True, rest[2:]
    elif rest.endswith("[]"):
        as_list, rest = True, rest[:-2]

    value = env.get(name)
    if rest == "":
        pass
    elif rest.startswith(":-"):
        if not value:
            value = rest[2:]
    elif rest.startswith("-"):
        if value is None:
            value = rest[1:]
    elif rest.startswith(":?"):
        if not value:
            sys.exit(f"error: {where}: {name} is required -> {rest[2:] or 'set it in .env'}")
    elif rest.startswith("?"):
        if value is None:
            sys.exit(f"error: {where}: {name} is required -> {rest[1:] or 'set it in .env'}")
    else:
        sys.exit(f"error: {where}: unsupported operator in ${{{inner}}}")

    value = value or ""
    return _as_list(value) if as_list else value


def expand(text: str, env: dict[str, str], where: str) -> str:
    return TOKEN_RE.sub(lambda m: resolve(m.group(1), env, where), text)


# --------------------------------------------------------------------- validation
def sanity_check(out: str, path: str, env: dict[str, str] | None = None) -> None:
    left = TOKEN_RE.findall(out)
    unresolved = [t for t in left if not t.startswith("!")]
    if unresolved:
        sys.exit(f"error: {path}: placeholders left unresolved: "
                 f"{', '.join('${%s}' % u for u in unresolved[:6])}")
    try:
        import yaml  # type: ignore
    except ImportError:
        print(f"warning: PyYAML unavailable - skipping structural validation of {path}",
              file=sys.stderr)
        return
    try:
        data = yaml.safe_load(out)
    except Exception as exc:                                  # noqa: BLE001
        sys.exit(f"error: {path}: rendered YAML does not parse: {exc}")
    checks = {
        "kafka": None, "window": None, "scoring": None, "attribution": None,
        "clickhouse": None, "api": None, "training": None, "ingest": None,
    }
    missing = [k for k in checks if not isinstance(data.get(k), dict)]
    if missing:
        sys.exit(f"error: {path}: missing/!dict config sections: {', '.join(missing)}")
    if not data["attribution"].get("strip_domains"):
        sys.exit(f"error: {path}: attribution.strip_domains is empty -> "
                 f"set AD_DOMAINS in .env (or one person = two users)")
    if not data["clickhouse"].get("password"):
        sys.exit(f"error: {path}: clickhouse.password is empty -> set CLICKHOUSE_PASSWORD")
    for key, want in (("window", "timezone"), ("clickhouse", "mode"),
                      ("training", "min_days"), ("ingest", "allowed_event_ids")):
        if want not in data[key]:
            sys.exit(f"error: {path}: {key}.{want} missing from template")
    if not (env or {}).get("AD_DOMAINS", "").strip():
        print("\n"
              "  !!! WARNING: AD_DOMAINS is empty in your .env.\n"
              "      Domain-qualified accounts stay un-normalised, so one human becomes\n"
              "      two principals (e.g. DAS\\Aarya from Sysmon vs Aarya from Security)\n"
              "      and each gets a separate, half-trained baseline. If your endpoints\n"
              "      really are in a workgroup (no domain) this is fine. Otherwise find\n"
              "      the domains from live data:\n"
              "        SELECT DISTINCT splitByChar('\\\\', user)[1]\n"
              "        FROM ubaseline.events WHERE position(user, '\\\\') > 0\n",
              file=sys.stderr)
    tz = data["window"]["timezone"]
    if "/" not in tz:
        sys.exit(f"error: {path}: window.timezone={tz!r} is not an IANA zone "
                 f"(use Asia/Kolkata, not 'IST' or '+5:30')")
    ev = data["ingest"]["allowed_event_ids"]
    if not (isinstance(ev, list) and ev and all(isinstance(x, int) for x in ev)):
        sys.exit(f"error: {path}: ingest.allowed_event_ids must be a list of ints, got {ev!r}")
    print(f"  validated: {len(ev)} event ids, strip_domains="
          f"{data['attribution']['strip_domains']}, tz={tz}, mode={data['clickhouse']['mode']}, "
          f"min_days={data['training']['min_days']}, bootstrap={data['kafka']['bootstrap_servers']}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--env", default=".env")
    ap.add_argument("--template", default="config.template.yaml")
    ap.add_argument("--out", default="config.runtime.yaml")
    ap.add_argument("--print", action="store_true", dest="to_stdout")
    ap.add_argument("--check", action="store_true", help="render + validate, write nothing")
    args = ap.parse_args()

    if not os.path.exists(args.template):
        sys.exit(f"error: template not found: {args.template}")
    env = load_env(args.env)
    # .env may reference other .env vars; expand them first (2 passes, then stop)
    for _ in range(3):
        before = dict(env)
        env = {k: expand(v, env, f"{args.env}:{k}") if "${" in v else v
               for k, v in env.items()}
        if env == before:
            break
    # os.environ wins over .env so CI / a one-off shell can override
    for k in list(env):
        if os.environ.get(k):
            env[k] = os.environ[k]

    template = open(args.template, encoding="utf-8").read()
    out = expand(template, env, args.template)

    if not out.strip():
        sys.exit(f"error: rendered config is empty - is {args.template} non-empty?")
    sanity_check(out, args.out if not args.check else "<stdout>", env)

    if args.check:
        print(f"  check ok: {args.template} + {args.env} render cleanly")
        return 0
    if args.to_stdout:
        sys.stdout.write(out)
        return 0

    existed = os.path.exists(args.out)
    with open(args.out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(out)
    print(f"  wrote {args.out} ({'updated' if existed else 'created'})")
    print(f"  next: docker compose restart api"
          f"{'' if existed else '   (first render: api must re-create/mount it)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
