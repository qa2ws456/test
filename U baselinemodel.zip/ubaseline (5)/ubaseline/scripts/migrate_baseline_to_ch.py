# One-time migration: push the existing baseline_output/ (model.pkl + parquets)
# into the ClickHouse baseline tables. After this + backend:"clickhouse",
# the files are no longer the source of truth.
#
#   python scripts\migrate_baseline_to_ch.py
#
import os
import pickle
import sys

sys.path.insert(0, ".")
from app.config import Config
from app.clickhouse_sink import ClickHouseSink
from app.baseline_ch import save_model_to_ch, get_version

cfg = Config.load(os.environ.get("UBASELINE_CONFIG", "config.yaml"))
sink = ClickHouseSink(cfg.ch)
if sink._client is None:
    sys.exit("ClickHouse not connected - check config.yaml clickhouse.host/password")

d = cfg.baseline_dir
with open(os.path.join(d, "model.pkl"), "rb") as fh:
    model = pickle.load(fh)

save_model_to_ch(sink, model, parquet_dir=d)
print("migration complete.")
print("  version in ClickHouse :", get_version(sink))
print("next step: config.yaml -> baseline: { backend: \"clickhouse\" } and restart the service")
