#!/usr/bin/env bash
# ============================================================================
# backup-clickhouse.sh - nightly ClickHouse backup (run on the Docker host).
#
# Takes a consistent snapshot of the named volume ubaseline_clickhouse_data
# into ./backups/clickhouse-<stamp>.tgz and prunes backups older than 14 days.
#
# Set up with cron (host):  sudo crontab -e
#   15 2 * * * cd /opt/ubaseline && ./backup-clickhouse.sh >> backups/backup.log 2>&1
#
# Restore (drill this once!):
#   docker compose stop clickhouse
#   docker run --rm -v ubaseline_clickhouse_data:/var/lib/clickhouse \
#     -v "$(pwd)":/backup alpine sh -c \
#     "rm -rf /var/lib/clickhouse/* && tar xzf /backup/backups/clickhouse-<stamp>.tgz -C /var/lib/clickhouse"
#   docker compose start clickhouse
# ============================================================================
set -euo pipefail

cd "$(dirname "$0")"
mkdir -p backups
STAMP=$(date +%F-%H%M)
TARGET="backups/clickhouse-${STAMP}.tgz"

echo "[$(date '+%F %T')] stopping clickhouse for a consistent snapshot ..."
docker compose stop clickhouse

echo "[$(date '+%F %T')] packing volume -> ${TARGET} ..."
docker run --rm \
  -v ubaseline_clickhouse_data:/var/lib/clickhouse \
  -v "$(pwd)/backups":/backup \
  alpine tar czf "/backup/clickhouse-${STAMP}.tgz" -C /var/lib/clickhouse .

echo "[$(date '+%F %T')] starting clickhouse ..."
docker compose start clickhouse

echo "[$(date '+%F %T')] pruning backups older than 14 days ..."
find backups -name 'clickhouse-*.tgz' -mtime +14 -delete

ls -lh "${TARGET}"
echo "[$(date '+%F %T')] backup finished OK"
