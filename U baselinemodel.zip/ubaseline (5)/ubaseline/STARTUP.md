# ubaseline — start / stop / verify runbook  (v2, `.env`-driven)

Every value now comes from **`.env`**. You do not edit `docker-compose.yml`,
`kafka-public-listener.yml`, `nginx/nginx.conf` or `winlogbeat.yml` any more, and a config
change no longer needs `--build`. The loop is: **edit `.env` → `python render_config.py` →
`restart api`**.

Hard rules
- Kafka must always start with `-f kafka-public-listener.yml`, or the 9094 listener (and with it Winlogbeat) is gone.
- Start consumers before producers, so nothing is produced while nothing reads it.
- One Winlogbeat instance per data path (`winlogbeat.lock`). Never two.
- **Never `docker compose down -v`** — it deletes the ClickHouse volume = your whole dataset.
- Inside a container use `cat`/`ls`; `type`/`dir` are Windows builtins and do not exist there.

Filenames are load-bearing (your project briefly had the underscore variants):
`config.template.yaml` → input, `config.runtime.yaml` → output, `API_CONFIG_FILE` in `.env`
must name exactly the file that exists, and `CLICKHOUSE_USERS_XML` must name the real
users.xml **file** (yours: `clickhouse_users.xml`).

---

# A. THIS WINDOWS BOX

## A0. Once, and after **any** `.env` edit

```
cd /d "C:\Users\Aarya.DAS\Downloads\ubaseline (5)\ubaseline"
python render_config.py
```
→ `validated: 41 event ids, strip_domains=['DAS', ...], tz=Asia/Kolkata, mode=all, ...`
→ if it prints **`WARNING: AD_DOMAINS is empty`**, fix `.env` — that warning means the
`DAS\Aarya` vs `Aarya` split is coming back.

```
findstr /I "CLICKHOUSE_USERS_XML API_CONFIG_FILE KAFKA_ADVERTISED_HOST AD_DOMAINS UBASELINE_TIMEZONE" .env
```
→ `clickhouse_users.xml`, `config.runtime.yaml`, `192.168.32.1`, `DAS`, `Asia/Kolkata`

Only the first time, sanity-check the config you are about to switch to against what is
running right now (identical = the new mount is a no-op):
```
docker compose exec api cat /app/config.yaml > current_config.txt
findstr /I "timezone strip_domains mode password min_days" current_config.txt
findstr /I "timezone strip_domains mode password min_days" config.runtime.yaml
```
→ the two outputs must agree. If they don't, either fix `.env` or set
`API_CONFIG_FILE=config.docker.yaml` to keep using the file you already trust.

## A1. Cold start (after a reboot / Docker Desktop just started)

```
docker version
```
→ error means start Docker Desktop and wait.

```
cd /d "C:\Users\Aarya.DAS\Downloads\ubaseline (5)\ubaseline"
docker ps -a --filter "name=ubaseline"
```
→ see what's already up. A second `Up` kafka is a problem; `Exited` containers are not.

```
docker compose -f docker-compose.yml -f kafka-public-listener.yml up -d clickhouse
docker compose -f docker-compose.yml -f kafka-public-listener.yml up -d kafka
docker compose -f docker-compose.yml -f kafka-public-listener.yml up -d api
docker compose ps
```
→ `ubaseline-clickhouse ... (healthy)`, `ubaseline-kafka ... (healthy)`, `ubaseline-api  Up`.

**Admin window 2 — the producer, last so it never writes into an unread topic:**
```
cd /d "C:\Users\Aarya.DAS\Downloads\winlogbeat-9.5.3-windows-x86_64\winlogbeat-9.5.3-windows-x86_64"
winlogbeat.exe test config -c winlogbeat.yml
winlogbeat.exe test output -c winlogbeat.yml
winlogbeat.exe -e -c winlogbeat.yml
```
→ `Config OK`, `... connection is up`, then a stream of events. Leave that window open
(no service installed yet; `sc query winlogbeat` → 1060 is expected).

**Window 3 — watch the model:**
```
cd /d "C:\Users\Aarya.DAS\Downloads\ubaseline (5)\ubaseline"
docker compose logs -f --tail=50 api
```
→ `consumed ... messages`, `window sealed`, `features built`. Ctrl+C leaves the tail; it
does not stop the container.

**Window 4 — dashboard (dev only):**
```
cd /d "C:\Users\Aarya.DAS\Downloads\prompt\dashboard"
python -m http.server 5500
```
→ `http://localhost:5500`, backend at `http://localhost:8080` via the bridge. Never serve
the project root (it exposes `app/`), never use `file://`.

## A2. Verify each layer separately (this is how you localise a break)

**Config actually reached the container:**
```
docker compose exec api ls -l /app/config.yaml
docker compose exec api cat /app/config.yaml | findstr /I "timezone strip_domains mode bootstrap"
```
→ first command must show a **file** (`-rw-r--r-- ... 3xxx`), not `drwxr-xr-x ... 4096`.
An empty **directory** there means `API_CONFIG_FILE` names a file that doesn't exist
(Docker creates a dir for a missing bind source) — see §C.

**ClickHouse mount is a file too:**
```
docker compose exec clickhouse ls -l /etc/clickhouse-server/users.d/
```
→ `custom-users.xml` as a file. If the folder looks empty, `CLICKHOUSE_USERS_XML` in
`.env` doesn't match your real filename.

**Kafka listeners + topic:**
```
docker compose exec kafka sh -c "echo $KAFKA_ADVERTISED_LISTENERS"
netstat -an | findstr 9094
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
```
→ listener list ends with `PLAINTEXT_PUBLIC://192.168.32.1:9094`; 9094 `LISTENING` with
`ESTABLISHED` pairs from Winlogbeat; `--list` contains **`win-events`**. Only
`__consumer_offsets` = nothing has produced yet, or the overlay isn't applied.

**Data flowing (connectivity to Kafka proves nothing — rows do):**
```
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT count() FROM ubaseline.events"
```
→ run twice a few seconds apart, must **grow**.

**Identity, time base, windows:**
```
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT user, attr_method, count() AS c FROM ubaseline.events GROUP BY user, attr_method ORDER BY c DESC LIMIT 20"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT toString(timestamp) FROM ubaseline.events ORDER BY timestamp DESC LIMIT 3"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SHOW CREATE TABLE ubaseline.events"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT count() FROM ubaseline.window_features"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT user, toString(window_start) AS ws, count() AS c FROM ubaseline.window_features GROUP BY user, ws HAVING c > 1 ORDER BY ws DESC LIMIT 20"
```
→ one `Aarya` carrying both `A1_sysmon` and `A2_security`, no `DAS\Aarya`; IST wall times;
DDL says `DateTime64(6,'Asia/Kolkata')`; features > 0; last query **empty**.

**Scoring / lag / endpoints:**
```
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SELECT user, count() FROM ubaseline.window_results GROUP BY user"
docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --describe --group ubaseline-scorer
check_endpoints.cmd
```
→ `window_results` stays empty until a user passes 7 distinct days / 200 events (normal);
`LAG` near 0, growing = the api can't keep up; all endpoints `200`.
Browser extras: `http://localhost:8080/health`, `/docs`, Kafka UI `http://localhost:8081`.

## A3. Stop (data preserved)

```
docker compose stop
```
Winlogbeat: Ctrl+C in its window (or `sc stop winlogbeat` once it *is* a service).
Producer first, then consumers. ClickHouse and Kafka data survive on named volumes.

## A4. Restart after a **config** change (timezone, AD_DOMAINS, thresholds, mode, retention)

```
notepad .env
python render_config.py
docker compose restart api
docker compose exec api cat /app/config.yaml | findstr /I "timezone strip_domains mode"
```
→ **no `--build`** — the config is mounted, not baked. Compose-level values (ports, kafka
env, `.env` secrets) additionally need a recreate: `up -d --force-recreate clickhouse`
(or `api`). If you set `API_CONFIG_FILE=config.docker.yaml`, you're back to hand-editing
that file + `up -d --build api`.

## A5. Restart after a **code** change (`app\*.py`, Dockerfile)

```
docker compose -f docker-compose.yml -f kafka-public-listener.yml up -d --build api
docker compose logs -f --tail=50 api
```

## A6. Kafka restart / recovery — and the volume proof

```
docker compose -f docker-compose.yml -f kafka-public-listener.yml up -d --force-recreate kafka
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
```
→ `win-events` **must still be listed** (that is the fix for the outage that wiped it twice).
If a fresh machine has no topic, it auto-creates on the next produce, or make it explicit:
```
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --topic win-events --partitions 1 --replication-factor 1
```

## A7. Clean slate (wipe + relearn) — destroys data on purpose

```
docker compose stop api
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "DROP TABLE IF EXISTS ubaseline.events"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "DROP TABLE IF EXISTS ubaseline.window_results"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "DROP TABLE IF EXISTS ubaseline.window_features"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "DROP TABLE IF EXISTS ubaseline.window_items"
docker compose exec clickhouse clickhouse-client --password ubaseline123 --query "SHOW TABLES FROM ubaseline"
docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group ubaseline-scorer --topic win-events --reset-offsets --to-latest --execute
docker compose start api
```
→ **DROP, not TRUNCATE**: TRUNCATE cannot change a column's timezone, and
`CREATE TABLE IF NOT EXISTS` never alters an existing table — only a DROP lets the IST DDL
land. Run it whenever `timezone`/`strip_domains` change, because baselines trained on the
old spelling or the old hour buckets are invalid. **Baselines are gone → retraining.**

## A8. Feed the historical corpus (host script → uses `config.yaml`, not the container's)

```
python <your-producer-script> "C:\Users\Aarya.DAS\Downloads\prompt\events.jsonl"
```
(use whatever you used before - the one that produced into `win-events` from the project
folder; I don't have its filename in the workspace so confirm it with
`dir /b *.py` and `findstr /S /I "events.jsonl" *.py`.)
That script runs on the host, so it reads **`config.yaml`** with `localhost:9092` /
`clickhouse.host: localhost` — never point `config.yaml` at `ubaseline-kafka:29092`, that
name only resolves inside the compose network. Feed **once** per clean slate; a second feed
without a wipe re-creates the duplicate-window symptom. Test files are historical (Aug 2026
timestamps), so `min_days` is judged on distinct dates present, not wall-clock.

---

# B. LINUX SERVER

Full manifest of what to copy: **`SERVER-FILES.md`**. The short version —
`.env`-driven compose, `render_config.py`, `config.template.yaml`,
`clickhouse_users.xml`, `app/`, `nginx/`, `frontend/`, `certs/`. Nothing Windows-side.
Do **not** copy this laptop's `.env` (it has `192.168.32.1`, `API_BIND_IP=0.0.0.0`,
`ubaseline123`) and do **not** copy `config.runtime.yaml` — generate it there.

```
sudo apt-get update && sudo apt-get install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
git clone <your-repo> /opt/ubaseline && cd /opt/ubaseline
cp .env.example .env && nano .env
openssl rand -hex 24
mkdir -p certs frontend nginx
sudo timedatectl set-timezone Asia/Kolkata
sudo ufw allow from 10.0.0.0/24 to any port 9094 proto tcp
sudo ufw allow 443/tcp && sudo ufw allow 22/tcp && sudo ufw enable
python3 render_config.py
```
Then the same three `-f` files, with the prod overlay (needs `frontend/index.html` +
`certs/*.pem`, or nginx will fail and the dashboard won't have an origin):
```
docker compose -f docker-compose.yml -f kafka-public-listener.yml -f docker-compose.prod.yml config --quiet
docker compose -f docker-compose.yml -f kafka-public-listener.yml -f docker-compose.prod.yml up -d
docker compose ps
docker compose logs -f api
```
Linux equivalents of A2:
```
ss -ltnp | grep 9094
sudo ss -ltnp | grep -E "8080|8123|9092"
docker compose exec api ls -l /app/config.yaml
docker compose exec clickhouse clickhouse-client --password "$CLICKHOUSE_PASSWORD" --query "SELECT count() FROM ubaseline.events"
curl -fsS localhost:8080/health
```
→ the `ss` line for 8080/8123/9092 must show `127.0.0.1`, never `0.0.0.0`.

Kafka UI over a tunnel: `ssh -L 8081:127.0.0.1:8081 user@server` → `http://localhost:8081`.
Nightly backup + health probe:
```
sudo install -m 755 backup-clickhouse.sh /usr/local/bin/
( crontab -l 2>/dev/null; echo "15 2 * * * /usr/local/bin/backup-clickhouse.sh >> /var/log/ubaseline-backup.log 2>&1" ) | crontab -
( crontab -l 2>/dev/null; echo "*/5 * * * * curl -fsS localhost:8080/health || logger -t ubaseline api-down" ) | crontab -
```
Endpoints are unchanged in shape — only `setx /M UBASELINE_KAFKA_HOST <server ip>` per box.

---

# C. Symptom → cause → fix

| Symptom | Cause | Fix |
|---|---|---|
| compose prints `missing_in_.env` | no `.env` in the folder you ran from | A0; always `cd` to the project root first |
| `duplicate key "services"` / values from the old file win | compose file pasted **on top of** the old one (both copies inside) | delete the file, paste once, then `findstr /N /C:"services:" docker-compose.yml` → exactly 1 |
| `docker compose exec api` fails with a config/YAML error right after adopting `.env` | `config.runtime.yaml` missing → Docker made an empty **directory** at `/app/config.yaml` | `dir config.runtime.yaml`; run `python render_config.py`; if a dir exists inside the container, `docker compose down` (no `-v`) and `up -d` again |
| api loads but with the *old* values | you edited `config.docker.yaml`/`config.yaml` while `API_CONFIG_FILE=config.runtime.yaml`, or forgot to render | `.env` → render → `restart api` (A4) |
| `WARNING: AD_DOMAINS is empty` from the renderer | a forgotten `.env` key → one human = two principals again | set `AD_DOMAINS`, render, then A7 (stored rows are already split) |
| `docker compose exec clickhouse` → ClickHouse won't start / users.d error | `CLICKHOUSE_USERS_XML` points at a **directory** (`clickhouse-users.xml` is an empty dir from exactly this mistake) | set it to `clickhouse_users.xml` (the real file), `up -d --force-recreate clickhouse` |
| `volume ubaseline_clickhouse_data not found` | an `external: true` compose (the old one) on a fresh machine | use the current compose (auto-creates), or `docker volume create ubaseline_clickhouse_data` |
| Winlogbeat: `dial tcp …:9094 … actively refused` | kafka recreated without the overlay | A6 |
| `--list` shows only `__consumer_offsets` | kafka recreated **and** no `kafka_data` volume | confirm the volume exists (`docker volume ls`), then A6 |
| api logs clean but 0 rows in `events` | nothing produced yet, or `ingest.allowed_event_ids` dropped it | start Winlogbeat; check the whitelist in `.env` |
| `data path … winlogbeat.lock` | two Winlogbeat instances | kill the other one; one window |
| `sc query winlogbeat` → **1060** | no service installed (expected) | A1 window, or install the service (see below) |
| times 5.5 h off somewhere | table created before the IST change | A7 (DROP, not TRUNCATE) |
| same `(user, window_start)` twice | late events reopened a sealed window | guard in `consumer.py`; re-verify with the A2 `HAVING c > 1` query |
| LAG climbs while api is `Up` | one consumer + burst feeds, or a slow CH insert | raise `CH_BATCH_ROWS`; scale `KAFKA_PARTITIONS` with >1 consumer |
| `address already in use` on 8080/9092/8123 | host process holding it | `netstat -ano \| findstr 8080` then kill that PID |

Production hardening, not part of the daily loop: install Winlogbeat as a service
(`install-service-winlogbeat.ps1`, or `winlogbeat.exe service install` on 9.x — whichever
exists in your zip; verify with `sc query winlogbeat`), and check NTP on every endpoint
(`w32tm /query /status`) because windows are bucketed from the *event* timestamp.

# D. What changed in this file (v1 → v2)
1. **New A0** (`.env` + `render_config.py` gate) and a `config.runtime.yaml` vs
   running-config comparison before the first restart.
2. **A4 rewritten**: config changes are `restart api`, no `--build` (the config is mounted
   now, not baked). `--build` survives only in A5 for `app\*.py`.
3. **Fixed a broken command I had given you**: `docker compose exec api type …` → `cat`
   (`type` is a cmd builtin; the container is Linux).
4. **New checks**: `exec api ls -l /app/config.yaml` and `exec clickhouse ls -l …/users.d/`
   — both are the empty-directory-mount traps; plus `findstr /N "services:"` for doubled
   compose files and `ss -ltnp` for accidentally published ports.
5. **A6 promoted to a test**: `win-events` surviving `--force-recreate kafka` is now the
   explicit proof the volume works.
6. **A7** now includes the consumer-group offset reset and states *why* DROP beats TRUNCATE.
7. **A8** documents that the host feed script reads `config.yaml` with `localhost:9092`,
   and that it must never point at `ubaseline-kafka:29092`.
8. **§B** references `SERVER-FILES.md`, adds `python3 render_config.py`, warns against
   copying `.env`/`config.runtime.yaml`, and requires all three `-f` files once
   `frontend/`+`certs/` exist.
9. **§C** grew from 12 to 16 rows, all `.env`-migration and mount-related additions.
10. Filename guardrail up top: dotted `config.template.yaml` / `config.runtime.yaml`, and
    `CLICKHOUSE_USERS_XML` naming your underscore file.
