# Core pipeline: normalize -> attribute -> window -> features -> score.
# Faithful port of the notebook's sections 03/07-08/10/11/16-19; same feature
# names and same scoring math so baseline_output/ artifacts score identically.

from __future__ import annotations

# =====================================================================================
# CONFIG
# =====================================================================================
import os
import yaml
from dataclasses import dataclass, field


def _load(path: str) -> dict:
    # with open(path) as f:
    with open(path,encoding="utf-8-sig") as f:
        return yaml.safe_load(f) or {}


@dataclass
class Config:
    raw: dict

    @staticmethod
    def load(path: str = "config.yaml") -> "Config":
        cfg = _load(path) if os.path.exists(path) else {}
        return Config(cfg)

    # kafka
    @property
    def kafka_brokers(self):        return self.raw.get("kafka", {}).get("bootstrap_servers", "")
    @property
    def kafka_group(self):          return self.raw.get("kafka", {}).get("group_id", "ubaseline-scorer")
    @property
    def kafka_topics(self):         return self.raw.get("kafka", {}).get("topics", ["win-events"])
    @property
    def results_topic(self):        return self.raw.get("kafka", {}).get("results_topic", "")
    # window
    @property
    def window_minutes(self):       return int(self.raw.get("window", {}).get("minutes", 10))
    @property
    def grace_seconds(self):       return int(self.raw.get("window", {}).get("grace_seconds", 120))
    # baseline
    @property
    def baseline_dir(self):         return self.raw.get("baseline", {}).get("dir", "./baseline_output")
    @property
    def hot_reload_seconds(self):   return int(self.raw.get("baseline", {}).get("hot_reload_seconds", 300))
    # scoring defaults (model.pkl overrides)
    @property
    def scoring_defaults(self) -> dict:
        s = self.raw.get("scoring", {})
        keys = ("z0", "z1", "k_stat", "k_nov", "k_rare", "k_act",
                "w_stat", "w_nov", "w_rare", "w_act", "w_ml", "alert_threshold")
        return {k: s[k] for k in keys if k in s}
    # attribution
    @property
    def builtin(self):              return set(self.raw.get("attribution", {}).get("builtin", []))
    @property
    def strip_domains(self):        return self.raw.get("attribution", {}).get("strip_domains", ["CORP"])
    @property
    def proc_ttl_min(self):         return int(self.raw.get("attribution", {}).get("process_table_ttl_minutes", 240))
    # clickhouse
    @property
    def ch(self) -> dict:           return self.raw.get("clickhouse", {})
    @property
    def api(self) -> dict:          return self.raw.get("api", {})
