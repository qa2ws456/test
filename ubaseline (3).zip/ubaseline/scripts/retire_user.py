# Retire one user from baseline_output/ so the auto-trainer can rebuild them
# from scratch on NEW data.
#
#   python scripts/retire_user.py <baseline_dir> <username>
#   e.g.  python scripts\retire_user.py .\baseline_output charlie.brown
#
# Removes the user from: model.pkl (principals, numeric stats, threshold
# surface) and from every baseline parquet (inventories, EID rarity,
# activation, threshold surface). Other users are untouched.
# BACKUP baseline_output/ first - this edits artifacts in place.

import os
import pickle
import sys

import pandas as pd

baseline_dir = sys.argv[1] if len(sys.argv) > 1 else "./baseline_output"
users = sys.argv[2:]
if not users:
    sys.exit("usage: python scripts/retire_user.py <baseline_dir> <user1> [user2] ...")
user = users[0]   # legacy single-user behaviour retained below via loop wrapper

def retire(baseline_dir: str, user: str):
    # ---------- model.pkl ----------
    pkl = os.path.join(baseline_dir, "model.pkl")
    with open(pkl, "rb") as fh:
        model = pickle.load(fh)

    cfg = model.get("config", {})
    before = list(cfg.get("principals", []))
    cfg["principals"] = [p for p in before if p != user]
    print(f"principals: {before} -> {cfg['principals']}")

    num = model.get("numeric_baseline", {})
    for key in ("med_h", "mad_h", "p95_h", "p05_h", "p25_h", "p75_h", "max_h", "med_u", "mad_u"):
        df = num.get(key)
        if df is None or not len(df):
            continue
        try:
            if isinstance(df.index, pd.MultiIndex):
                num[key] = df.drop(index=user, level=0, errors="ignore")
            elif user in df.index:
                num[key] = df.drop(index=user, errors="ignore")
        except Exception as exc:
            print(f"  (kept {key} unchanged: {exc})")

    ts = model.get("threshold_surface")
    if isinstance(ts, pd.Series) and len(ts):
        try:
            if isinstance(ts.index, pd.MultiIndex):
                model["threshold_surface"] = ts.drop(index=user, level=0, errors="ignore")
            elif user in ts.index:
                model["threshold_surface"] = ts.drop(index=user, errors="ignore")
        except Exception as exc:
            print(f"  (threshold surface kept: {exc})")

    tmp = pkl + ".tmp"
    with open(tmp, "wb") as fh:
        pickle.dump(model, fh)
    os.replace(tmp, pkl)
    print(f"model.pkl updated ({user} removed)")

    # ---------- parquets ----------
    def _drop_rows(path, col="user"):
        if not os.path.exists(path):
            return
        df = pd.read_parquet(path)
        if not len(df):
            return
        if col in df.columns:
            n0 = len(df)
            df = df[df[col] != user]
            if len(df) != n0:
                df.to_parquet(path, index=False)
                print(f"{os.path.basename(path)}: {n0 - len(df)} row(s) removed")
        elif df.index.name == col or (isinstance(df.index, pd.MultiIndex) and col in df.index.names):
            n0 = len(df)
            level = df.index.names.index(col) if isinstance(df.index, pd.MultiIndex) else None
            df = df.drop(index=user, level=level, errors="ignore") if level is not None \
                else df.drop(index=user, errors="ignore")
            if len(df) != n0:
                df.reset_index().to_parquet(path, index=False)
                print(f"{os.path.basename(path)}: {n0 - len(df)} row(s) removed (indexed)")

    _drop_rows(os.path.join(baseline_dir, "baseline_inventories.parquet"))
    _drop_rows(os.path.join(baseline_dir, "baseline_eventid_rarity.parquet"))
    _drop_rows(os.path.join(baseline_dir, "baseline_activation.parquet"))
    _drop_rows(os.path.join(baseline_dir, "threshold_surface.parquet"))

    print(f"DONE. {user} is no longer baselined. The auto-trainer will rebuild "
          f"them once their NEW data reaches training.min_days/min_events.")
    print("Caveats: corpus-wide rarity counts (gcnt) still include their old "
          "contributions (minor); the shared IsolationForest was not refit (tiebreaker only).")

for u in users:
    print(f"=== retiring {u} ===")
    retire(baseline_dir, u)
print("\nALL DONE.")
